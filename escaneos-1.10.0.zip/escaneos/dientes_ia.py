"""Identificación de dientes con IA (solo en la PC de la Dra.): PROPONE el número FDI de cada diente de un escaneo
que no pasó por MetronTrack. Es una propuesta: el doctor la revisa en «Dientes» antes de usar el análisis.

Usa el modelo CrossTooth (Point Transformer) que la Dra. tiene en su Escritorio (carpeta «CrossTooth_CVPR2025») y
PyTorch; no se distribuye con la app. La pieza compilada «pointops» del modelo se sustituye aquí por PyTorch puro.
Con el motor de IA del equipo (dientes_ia_worker.py) corre en la GPU y ve cada arcada seis veces (normal, en espejo
y girada); sin él, dos veces en el procesador.

Después se ordena lo que dice la red: dientes enteros, uno por número, en secuencia por la arcada, con dentición
permanente o mixta (dientes de leche por su ancho y su corona baja) y comparando los dos lados. Medido contra 46
casos revisados por la Dra.: 92 % de los dientes con el número correcto (antes 90 %), 26 casos sin ningún error.
Si la red deja un hueco donde sobresale una corona (un incisivo a medio salir), ese diente se recupera igual.
Los modelos zocalados confunden a la red: si el caso trae el escaneo sin zócalo, la red trabaja sobre ese.
"""
from __future__ import annotations

import os
import sys
import types

import numpy as np

_MODELO = None
# orientación con la que el modelo acierta más, medida en el marco del análisis (oclusión en z = 0, anterior −y)
_GIRO = {"sup": np.array([[0, 0, 1], [-1, 0, 0], [0, -1, 0]], float), "inf": np.eye(3)}
_IZQ_PRIMERO = {"sup": False, "inf": True}  # qué lado son las clases 1–8 del modelo


def carpeta_modelo():
    for base in (os.environ.get("ORTHOLAB_CROSSTOOTH"),
                 os.path.join(os.path.expanduser("~"), "OneDrive", "Escritorio", "CrossTooth_CVPR2025"),
                 os.path.join(os.path.expanduser("~"), "Desktop", "CrossTooth_CVPR2025")):
        if base and os.path.exists(os.path.join(base, "models", "PTv1", "point_best_model.pth")):
            return base
    return None


def python_ia():
    """El motor de IA del equipo (PyTorch con CUDA): con él la red corre en la GPU, en segundos."""
    for r in (os.environ.get("OLS_PYTHON_IA"),
              os.path.join(os.environ.get("APPDATA", ""), "cavy-segmentator", "ai-runtime", "python", "python.exe")):
        if r and os.path.isfile(r):
            return r
    return None


def disponible() -> bool:
    if carpeta_modelo() is None:
        return False
    if python_ia():
        return True
    from importlib.util import find_spec

    try:  # sin importarlos: PyTorch tarda en cargar y esto se pregunta al pintar la tarjeta
        return find_spec("torch") is not None and find_spec("einops") is not None
    except Exception:  # noqa: BLE001
        return False


# ----------------------------------------------------------------------------- «pointops» en PyTorch puro
def _pointops():
    import torch

    def knn(xyz, new_xyz, k, bloque=2048):
        idx = []
        for i in range(0, len(new_xyz), bloque):
            idx.append(torch.cdist(new_xyz[i:i + bloque], xyz).topk(k, dim=1, largest=False).indices)
        return torch.cat(idx, 0)

    def queryandgroup(feat, xyz, offset, new_xyz, new_offset, nsample, use_xyz=True, idx=None):
        if new_xyz is None:
            new_xyz = xyz
        if idx is None:
            idx = knn(xyz, new_xyz, nsample)
        grupo_xyz = xyz[idx] - new_xyz.unsqueeze(1)
        grupo = feat[idx]
        return (torch.cat([grupo_xyz, grupo], -1) if use_xyz else grupo), idx

    def furthestsampling(xyz, offset, new_offset):
        n, m = int(offset[-1]), int(new_offset[-1])
        dist = torch.full((n,), 1e10, dtype=xyz.dtype, device=xyz.device)
        elegidos = torch.zeros(m, dtype=torch.long, device=xyz.device)
        actual = 0
        for i in range(m):
            elegidos[i] = actual
            dist = torch.minimum(dist, ((xyz - xyz[actual]) ** 2).sum(1))
            actual = int(torch.argmax(dist))
        return elegidos

    def interpolation(xyz, new_xyz, feat, offset, new_offset, k=3):
        idx = knn(xyz, new_xyz, k)
        w = 1.0 / ((xyz[idx] - new_xyz.unsqueeze(1)).norm(dim=2) + 1e-8)
        w = w / w.sum(1, keepdim=True)
        return (feat[idx] * w.unsqueeze(-1)).sum(1)

    m = types.SimpleNamespace(queryandgroup=queryandgroup, furthestsampling=furthestsampling, interpolation=interpolation)
    return m


def _modelo():
    global _MODELO
    if _MODELO is None:
        import torch

        base = carpeta_modelo()
        if base is None:
            raise RuntimeError("No encuentro la carpeta «CrossTooth_CVPR2025» con el modelo.")
        ruta = "models.PointTransformer.libs.pointops.functions"
        partes = ruta.split(".")
        for i in range(1, len(partes) + 1):
            sys.modules.setdefault(".".join(partes[:i]), types.ModuleType(".".join(partes[:i])))
        sys.modules[ruta].pointops = _pointops()
        with open(os.path.join(base, "models", "PTv1", "point_transformer_seg.py"), encoding="utf-8") as f:
            codigo = f.read().split("if __name__ ==")[0].replace("torch.cuda.IntTensor(n_o)",
                                                                 "torch.tensor(n_o, dtype=torch.int32)")
        mod = types.ModuleType("ortholab_pt_seg")
        exec(compile(codigo, "point_transformer_seg.py", "exec"), mod.__dict__)  # noqa: S102  (código local de la Dra.)
        torch.set_num_threads(max(1, min(8, (os.cpu_count() or 2) // 2)))
        red = mod.PointTransformerSeg38(in_channels=6, num_classes=19, pretrain=False, add_cbl=False, enable_pic_feat=False)
        red.load_state_dict(torch.load(os.path.join(base, "models", "PTv1", "point_best_model.pth"), map_location="cpu"))
        red.eval()
        if torch.cuda.is_available():
            red = red.cuda()
        _MODELO = red
    return _MODELO


def _a_fdi(clase, jaw):
    out = np.zeros(len(clase), np.uint8)
    for c in range(1, 17):
        n = c if c <= 8 else c - 8
        izq = (c <= 8) == _IZQ_PRIMERO[jaw]
        cuad = (2 if izq else 1) if jaw == "sup" else (3 if izq else 4)
        out[clase == c] = cuad * 10 + n
    return out


def crudo(V, F, jaw, pasadas=2, progreso=None):
    """Lo que dice la red, sin ordenar: FDI por vértice (uint8, 0 = encía) de una arcada ya alineada."""
    import torch
    from scipy.spatial import cKDTree

    red = _modelo()
    V = np.asarray(V, np.float64)
    F = np.asarray(F, np.int64)
    cen = V[F].mean(1)
    nor = np.cross(V[F[:, 1]] - V[F[:, 0]], V[F[:, 2]] - V[F[:, 0]])
    nor /= np.maximum(np.linalg.norm(nor, axis=1, keepdims=True), 1e-12)
    R = _GIRO[jaw]
    puntos, clases = [], []
    for k in range(pasadas):
        if progreso:
            progreso(f"Identificando los dientes de la arcada {'superior' if jaw == 'sup' else 'inferior'}… ({k + 1}/{pasadas})")
        idx = np.random.default_rng(k).choice(len(cen), 16000, replace=len(cen) < 16000)
        p = cen[idx] @ R.T
        p = p - p.mean(0)
        p = p / np.sqrt((p ** 2).sum(1)).max()
        x = torch.from_numpy(np.c_[p, nor[idx] @ R.T].astype(np.float32)).T.unsqueeze(0)
        with torch.no_grad():
            seg, _ = red(x)
        puntos.append(cen[idx])
        clases.append(_a_fdi(seg[0].argmax(0).numpy(), jaw))
    puntos, clases = np.vstack(puntos), np.concatenate(clases)
    # a cada vértice, la etiqueta más votada entre las 5 caras clasificadas más cercanas
    _, vec = cKDTree(puntos).query(V, k=5)
    votos = clases[vec]
    lab = np.array([np.bincount(v, minlength=50).argmax() for v in votos], np.uint8)
    return lab


# vistas de la arcada que se le muestran a la red (espejo, giro en grados sobre el eje oclusal): lo que ve en una
# y en su espejo se promedia, así sus confusiones de lado y de número se compensan
VISTAS = ((False, 0.0), (True, 0.0), (False, 6.0), (True, -6.0), (False, -6.0), (True, 6.0))


# zócalo alto (los modelos zocalados de AccuDesign miden ~22 mm): la red solo ve los RECORTE mm más oclusales
ZOCALO_ALTO, RECORTE = 18.0, 14.0


def probabilidades(V, F, jaw, vistas=VISTAS, progreso=None):
    """Probabilidad de cada vértice de ser encía (columna 0) o cada uno de los 16 lugares de la arcada (columnas
    1–16, en el orden de _casillas: de la derecha del paciente a la izquierda), promediando varias vistas."""
    import torch
    from scipy.spatial import cKDTree

    red = _modelo()
    disp = next(red.parameters()).device
    V = np.asarray(V, np.float64)
    F = np.asarray(F, np.int64)
    # solo la zona de los dientes: un zócalo alto (y la encía rellena de los modelos zocalados) confunde a la red,
    # que se entrenó con escaneos sin zócalo. Lo de más allá de RECORTE mm del plano oclusal es encía o zócalo.
    h = -V[:, 2] if jaw == "sup" else V[:, 2]
    dentro = h > -RECORTE if np.ptp(h) > ZOCALO_ALTO else np.ones(len(V), bool)
    F = F[dentro[F].all(1)]
    cen = V[F].mean(1)
    nor = np.cross(V[F[:, 1]] - V[F[:, 0]], V[F[:, 2]] - V[F[:, 0]])
    nor /= np.maximum(np.linalg.norm(nor, axis=1, keepdims=True), 1e-12)
    R = _GIRO[jaw]
    # clase de la red (1–16) → columna de casilla, sin espejo y con espejo
    cas = [f for f, _ in _casillas(jaw)]
    col = np.zeros((2, 19), int)
    for cl in range(1, 17):
        fdi = int(_a_fdi(np.array([cl]), jaw)[0])
        col[0, cl] = 1 + cas.index(fdi)
        col[1, cl] = 1 + cas.index(_espejo_fdi(fdi))
    suma = np.zeros((len(V), 17), np.float32)
    peso = np.zeros(len(V), np.float32)
    for k, (espejo, grados) in enumerate(vistas):
        if progreso:
            progreso(f"Identificando los dientes de la arcada {'superior' if jaw == 'sup' else 'inferior'}… "
                     f"({k + 1}/{len(vistas)})")
        idx = np.random.default_rng(k).choice(len(cen), 16000, replace=len(cen) < 16000)
        a = np.radians(grados)
        G = np.array([[np.cos(a), -np.sin(a), 0], [np.sin(a), np.cos(a), 0], [0, 0, 1]])
        if espejo:
            G = np.diag([-1.0, 1.0, 1.0]) @ G
        p = cen[idx] @ G.T @ R.T
        p = p - p.mean(0)
        p = p / np.sqrt((p ** 2).sum(1)).max()
        x = torch.from_numpy(np.c_[p, nor[idx] @ G.T @ R.T].astype(np.float32)).T.unsqueeze(0).to(disp)
        with torch.no_grad():
            seg, _ = red(x)
        pr = torch.softmax(seg[0].float(), 0).cpu().numpy()  # (19, n)
        q = np.zeros((len(idx), 17), np.float32)
        q[:, 0] = pr[0] + pr[17:].sum(0)
        np.add.at(q.T, col[int(espejo), 1:17], pr[1:17])
        # a cada vértice, el promedio de las 5 caras muestreadas más cercanas
        d, vec = cKDTree(cen[idx]).query(V, k=5)
        suma += q[vec].mean(1)
        peso += 1
    out = suma / peso[:, None]
    out[~dentro] = 0
    out[~dentro, 0] = 1
    return out


def _espejo_fdi(fdi):
    q, n = divmod(int(fdi), 10)
    return {1: 2, 2: 1, 3: 4, 4: 3, 5: 6, 6: 5, 7: 8, 8: 7}[q] * 10 + n


def etiquetas_de(prob, jaw):
    """FDI por vértice (0 = encía) a partir de las probabilidades."""
    cas = np.array([f for f, _ in _casillas(jaw)], np.uint8)
    # primero diente o encía (con la suma de todos los dientes: entre vistas la red puede dudar si es el 11 o el
    # 21, y eso no lo hace menos diente), luego cuál
    diente = prob[:, 1:].sum(1) > prob[:, 0]
    return np.where(diente, cas[prob[:, 1:].argmax(1)], 0).astype(np.uint8)


def _en_gpu(U, FU, L, FL, progreso=None, timeout=900):
    """Probabilidades de las dos arcadas calculadas por el motor de IA (dientes_ia_worker.py), o None si no se pudo."""
    import subprocess
    import tempfile

    py = python_ia()
    if not py:
        return None
    tmp = tempfile.mkdtemp(prefix="ols-dientes-")
    entrada, salida = os.path.join(tmp, "entrada.npz"), os.path.join(tmp, "salida.npz")
    try:
        np.savez(entrada, U=np.asarray(U, np.float32), FU=np.asarray(FU, np.int32), L=np.asarray(L, np.float32),
                 FL=np.asarray(FL, np.int32))
        env = dict(os.environ, PYTHONIOENCODING="utf-8")
        if carpeta_modelo():
            env["ORTHOLAB_CROSSTOOTH"] = carpeta_modelo()
        proc = subprocess.Popen([py, "-X", "utf8", "-I", os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                                     "dientes_ia_worker.py"), entrada, salida],
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8",
                                errors="replace", env=env, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        for linea in proc.stdout:
            linea = linea.strip()
            if linea.startswith("PASO ") and progreso:
                progreso(linea[5:].partition(" ")[2])
        proc.wait(timeout=timeout)
        if proc.returncode != 0 or not os.path.isfile(salida):
            return None
        z = np.load(salida)
        return {"sup": z["pu"].astype(np.float32) / 255, "inf": z["pl"].astype(np.float32) / 255}
    except Exception:  # noqa: BLE001  (sin GPU o el motor falló: se hace aquí, en el procesador)
        return None
    finally:
        import shutil

        shutil.rmtree(tmp, ignore_errors=True)


def transferir(Vo, lab, Vd, jaw, tope=0.6):
    """Pasa la numeración `lab` del modelo Vo al modelo Vd del mismo escaneo (el sin zócalo → el zocalado), los
    dos ya en el marco del análisis: se afina con un ICP rígido sobre los dientes y cada vértice toma el número
    del vértice más cercano (encía si no hay ninguno a menos de `tope` mm)."""
    from scipy.spatial import cKDTree

    Vo = np.asarray(Vo, np.float64)
    Vd = np.asarray(Vd, np.float64)
    hd = -Vd[:, 2] if jaw == "sup" else Vd[:, 2]
    arbol = cKDTree(Vd[hd > -8])
    dientes = np.flatnonzero(lab > 0)
    if len(dientes) < 100:
        return np.zeros(len(Vd), np.uint8)
    P = Vo[dientes[np.random.default_rng(0).choice(len(dientes), min(6000, len(dientes)), replace=False)]]
    R, t = np.eye(3), np.zeros(3)
    for _ in range(20):
        Q = P @ R.T + t
        d, i = arbol.query(Q)
        ok = d < max(1.0, 3 * np.median(d))
        if ok.sum() < 50:
            break
        A, B = Q[ok], arbol.data[i[ok]]
        ma, mb = A.mean(0), B.mean(0)
        u, _, vt = np.linalg.svd((A - ma).T @ (B - mb))
        Ri = (u @ vt).T
        if np.linalg.det(Ri) < 0:
            vt[-1] *= -1
            Ri = (u @ vt).T
        R, t = Ri @ R, Ri @ t + mb - Ri @ ma
        if np.median(d[ok]) < 0.02:
            break
    Vo2 = Vo @ R.T + t
    d, i = cKDTree(Vo2).query(Vd)
    return np.where(d < tope, np.asarray(lab, np.uint8)[i], 0).astype(np.uint8)


def identificar_arcadas(U, FU, L, FL, progreso=None, sin_zocalo=None):
    """FDI por vértice de las dos arcadas ya alineadas (marco del análisis): {"sup": uint8, "inf": uint8}.
    En la GPU (motor de IA) se le muestran a la red seis vistas de cada arcada; sin GPU, dos (tarda ~1 min).
    `sin_zocalo`: si las arcadas son los modelos zocalados y se tiene el escaneo sin zócalo del mismo caso
    (también alineado: {"sup": (V, F), "inf": (V, F)}), la red trabaja sobre ese, que es como los que aprendió
    (el zócalo y la encía rellena del zocalado la confunden), y la numeración se pasa al zocalado."""
    if sin_zocalo:
        crudo = identificar_arcadas(*sin_zocalo["sup"], *sin_zocalo["inf"], progreso=progreso)
        if progreso:
            progreso("Pasando la numeración al modelo con zócalo…")
        return {"sup": transferir(sin_zocalo["sup"][0], crudo["sup"], U, "sup"),
                "inf": transferir(sin_zocalo["inf"][0], crudo["inf"], L, "inf")}
    prob = _en_gpu(U, FU, L, FL, progreso)
    if prob is None:
        prob = {"sup": probabilidades(U, FU, "sup", VISTAS[:2], progreso),
                "inf": probabilidades(L, FL, "inf", VISTAS[:2], progreso)}
    if progreso:
        progreso("Ordenando y numerando los dientes…")
    return {"sup": ordenar(U, etiquetas_de(prob["sup"], "sup"), "sup"),
            "inf": ordenar(L, etiquetas_de(prob["inf"], "inf"), "inf")}


def identificar(V, F, jaw, pasadas=2, progreso=None):
    """FDI por vértice (uint8, 0 = encía) de una arcada ya alineada (marco del análisis). `jaw`: «sup» o «inf»."""
    return ordenar(V, crudo(V, F, jaw, pasadas, progreso), jaw)


# anchos mesiodistales promedio (mm) por posición 1–8: (superior, inferior)
_ANCHO = {1: (8.6, 5.3), 2: (6.6, 5.9), 3: (7.6, 6.8), 4: (7.0, 7.0), 5: (6.6, 7.2), 6: (10.2, 11.1), 7: (9.3, 10.4),
          8: (8.8, 10.2)}


def _casillas(jaw):
    """Los 16 lugares de la arcada, de la derecha del paciente a la izquierda: [(FDI, posición 1–8)]."""
    der, izq = (1, 2) if jaw == "sup" else (4, 3)
    return [(der * 10 + n, n) for n in range(8, 0, -1)] + [(izq * 10 + n, n) for n in range(1, 9)]


def _arco(V, T):
    """Posición de cada vértice a lo largo de la arcada (mm; − = derecha del paciente, 0 = frente) y distancia
    al centro (para medir el grosor vestíbulo-lingual)."""
    from scipy.ndimage import gaussian_filter1d

    yc = float(np.percentile(V[T, 1], 85))
    th = np.degrees(np.arctan2(V[:, 0], -(V[:, 1] - yc)))
    rad = np.hypot(V[:, 0], V[:, 1] - yc)
    bins = np.arange(-150.0, 151.0, 2.0)
    r = np.full(len(bins), np.nan)
    for i, b in enumerate(bins):
        m = T & (th >= b - 2) & (th < b + 2)
        if m.sum() >= 25:
            r[i] = np.median(rad[m])
    ok = ~np.isnan(r)
    if ok.sum() < 6:
        return th * 0.45, rad
    ct = bins[ok]
    rs = gaussian_filter1d(np.interp(ct, ct, r[ok]), 4, mode="nearest")  # línea media de las coronas, suavizada
    cx, cy = rs * np.sin(np.radians(ct)), yc - rs * np.cos(np.radians(ct))
    largo = np.r_[0.0, np.cumsum(np.hypot(np.diff(cx), np.diff(cy)))]
    largo -= np.interp(0.0, ct, largo)
    pend = (largo[-1] - largo[0]) / max(ct[-1] - ct[0], 1e-6)
    sv = np.interp(th, ct, largo)
    sv = np.where(th < ct[0], largo[0] + (th - ct[0]) * pend, sv)
    sv = np.where(th > ct[-1], largo[-1] + (th - ct[-1]) * pend, sv)
    return sv, rad


def _corte(sv, h, rad, a, b):
    """Dónde se tocan dos dientes entre a y b (mm sobre la arcada): donde la corona es más baja y más delgada."""
    bordes = np.arange(a, b + 0.3, 0.3)
    if len(bordes) < 4:
        return 0.5 * (a + b)
    alto, grosor = [], []
    for x in bordes:
        m = (sv >= x - 0.3) & (sv < x + 0.3)
        if m.sum() < 8:
            alto.append(np.nan); grosor.append(np.nan)
            continue
        hm = h[m]
        tope = np.percentile(hm, 95)
        alto.append(tope)
        oclusal = rad[m][hm > tope - 2.5]
        grosor.append(np.percentile(oclusal, 95) - np.percentile(oclusal, 5) if len(oclusal) > 4 else np.nan)
    alto, grosor = np.array(alto), np.array(grosor)
    if np.isnan(alto).all():
        return 0.5 * (a + b)

    def norma(x):
        x = np.where(np.isnan(x), np.nanmin(x), x)
        return (x - x.min()) / max(np.ptp(x), 1e-6)
    return float(bordes[int(np.argmin(norma(alto) + norma(grosor)))])


def ordenar(V, lab, jaw):
    """Deja la propuesta de la red como dientes enteros, uno por número y en orden a lo largo de la arcada:
    separa los que la red unió, junta los pedazos de un mismo diente y numera en secuencia (un molar no puede
    llamarse premolar aunque falte un diente: cuenta el ancho de cada corona y los huecos)."""
    V = np.asarray(V, np.float64)
    lab = np.array(lab, np.uint8)
    r = piezas_de(V, lab, jaw)
    if r is None:
        return lab
    piezas, sv = r
    return _numerar_arcada(V, lab, jaw, piezas, sv)


def piezas_de(V, lab, jaw):
    """Pasos 1–3: los dientes enteros (índices de vértices, en orden por la arcada) y la posición sobre la arcada
    de cada vértice. `lab` se retoca en su lugar (pedacitos sueltos). None si casi no hay dientes."""
    from scipy.spatial import cKDTree

    # pedacitos con otro número (dentro de un diente o en el borde del escaneo): toman lo que tienen alrededor
    nums, cuenta = np.unique(lab[lab > 0], return_counts=True)
    if not len(nums):
        return None
    minimo = max(150, 0.25 * float(np.median(cuenta)))
    resto = np.isin(lab, nums[cuenta < minimo])
    if resto.any() and (~resto).any():
        _, vec = cKDTree(V[~resto]).query(V[resto], k=7)
        lab[resto] = [np.bincount(v, minlength=50).argmax() for v in lab[~resto][vec]]
    T = lab > 0
    if T.sum() < 300:
        return None
    k_jaw = 0 if jaw == "sup" else 1
    sv, rad = _arco(V, T)
    h = -V[:, 2] if jaw == "sup" else V[:, 2]
    # 1) piezas: cada número de la red, partido donde deja un hueco a lo largo de la arcada
    piezas = []
    for t in np.unique(lab[T]):
        idx = np.flatnonzero(lab == t)
        idx = idx[np.argsort(sv[idx])]
        cortes = np.flatnonzero(np.diff(sv[idx]) > 1.2)
        for parte in np.split(idx, cortes + 1):
            if len(parte) >= 120:
                piezas.append(parte)

    def tramo(idx):
        return float(np.percentile(sv[idx], 2)), float(np.percentile(sv[idx], 98))

    # 2) dos dientes que la red pintó como uno: la pieza mide mucho más que un diente → se corta donde se tocan
    finales = []
    for p in piezas:
        a, b = tramo(p)
        clase = int(np.bincount(lab[p], minlength=50).argmax()) % 10
        e = _ANCHO.get(clase, (8.0, 8.0))[k_jaw]
        ancho = b - a
        n = 1
        tope = 1.35 * e if clase in (1, 2) else max(1.4 * e, e + 3.2)
        if ancho > tope:
            n = int(max(2, round(ancho / max(e, 6.0))))
        if n == 1:
            # apiñados, dos dientes se enciman a lo largo de la arcada y no «miden» de más sobre ella: se mira
            # también su largo real en planta, y se cortan a lo largo de su propio eje
            q = V[p, :2] - V[p, :2].mean(0)
            eje = np.linalg.svd(q[:: max(1, len(q) // 2000)], full_matrices=False)[2][0]
            t = q @ eje
            t0, t1 = np.percentile(t, [2, 98])
            if t1 - t0 > max(1.35 * e, e + 3.0):
                medio = 0.5 * (t0 + t1)
                c = _corte(t, h[p], rad[p], medio - 0.22 * (t1 - t0), medio + 0.22 * (t1 - t0))
                partes = [p[t < c], p[t >= c]]
                if min(len(x) for x in partes) >= 120:
                    finales.extend(partes)
                    continue
            finales.append(p)
            continue
        cortes = []
        for j in range(1, n):
            medio = a + ancho * j / n
            cortes.append(_corte(sv[p], h[p], rad[p], medio - 0.22 * ancho / n * 2, medio + 0.22 * ancho / n * 2))
        lim = [-np.inf] + cortes + [np.inf]
        for j in range(n):
            parte = p[(sv[p] >= lim[j]) & (sv[p] < lim[j + 1])]
            if len(parte) >= 120:
                finales.append(parte)
    piezas = finales
    # 3) pedazos de un mismo diente: dos piezas que ocupan el mismo tramo de la arcada, o una muy angosta
    cambio = True
    while cambio and len(piezas) > 1:
        cambio = False
        piezas.sort(key=lambda p: np.median(sv[p]))
        tr = [tramo(p) for p in piezas]
        for i in range(len(piezas) - 1):
            (a0, a1), (b0, b1) = tr[i], tr[i + 1]
            chico = min(a1 - a0, b1 - b0)
            junto = max(a1, b1) - min(a0, b0)
            # dos pedazos de un mismo diente tienen el centro casi en el mismo sitio; dos dientes apiñados no
            cabe = min(_ANCHO.get(int(np.bincount(lab[q], minlength=50).argmax()) % 10, (8.0, 8.0))[k_jaw]
                       for q in (piezas[i], piezas[i + 1]))
            dc = float(np.linalg.norm(V[piezas[i], :2].mean(0) - V[piezas[i + 1], :2].mean(0)))
            comun = min(a1, b1) - max(a0, b0)
            # un diente que la red partió en dos números vecinos (el 46 mitad «47», mitad «46»): juntos miden lo
            # de un diente y al menos uno es demasiado angosto para ser un diente entero
            num = [int(np.bincount(lab[q], minlength=50).argmax()) for q in (piezas[i], piezas[i + 1])]
            esp = [_MEDIDO[jaw].get(t % 10, 8.0) for t in num]
            partido = abs(num[0] - num[1]) == 1 and chico < 0.6 * min(esp) and junto <= 1.1 * max(esp)
            if partido or dc < 0.5 * cabe or comun > 0.6 * chico or (chico < 2.6 and junto <= 12.5):
                piezas[i] = np.concatenate([piezas[i], piezas[i + 1]])
                del piezas[i + 1]
                cambio = True
                break
    # pedacitos en el borde del escaneo (mucho más chicos que los dientes): no son un diente
    if len(piezas) > 2:
        mediana = float(np.median([len(p) for p in piezas]))
        piezas = [p for p in piezas if len(p) >= 0.3 * mediana]
    while len(piezas) > 16:  # no caben más de 16 dientes: se juntan las dos piezas con el centro más cercano
        cen = [V[p, :2].mean(0) for p in piezas]
        i = int(np.argmin([np.linalg.norm(cen[k] - cen[k + 1]) for k in range(len(piezas) - 1)]))
        piezas[i] = np.concatenate([piezas[i], piezas[i + 1]])
        del piezas[i + 1]
    piezas.sort(key=lambda p: np.median(sv[p]))
    piezas = sorted(piezas + _huecos(V, piezas, sv, rad, h), key=lambda p: np.median(sv[p]))
    return piezas, sv


def _huecos(V, piezas, sv, rad, h):
    """Dientes que la red no vio (un incisivo a medio salir, uno girado…): en un hueco entre dos dientes de al
    menos 4.5 mm, si algo sobresale bien por encima del margen de la encía de los vecinos, es una corona. Se toma
    la zona conectada que sobresale y se afina su contorno (_afinar)."""
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components
    from scipy.spatial import cKDTree

    if len(piezas) < 2:
        return []
    nuevas = []
    tr = [(float(np.percentile(sv[p], 2)), float(np.percentile(sv[p], 98))) for p in piezas]
    for i in range(len(piezas) - 1):
        a, b = tr[i][1], tr[i + 1][0]
        if b - a < 4.5:
            continue
        vec = np.concatenate([piezas[i], piezas[i + 1]])
        margen = float(np.median([np.percentile(h[piezas[k]], 5) for k in (i, i + 1)]))  # dónde empieza la corona
        r0, r1 = np.percentile(rad[vec], [2, 98])
        ven = np.flatnonzero((sv > a + 0.3) & (sv < b - 0.3) & (rad > r0 - 1.0) & (rad < r1 + 1.0) & (h > margen))
        if len(ven) < 150 or np.percentile(h[ven], 99) < margen + 1.5:
            continue  # nada sobresale: espacio de una extracción, diastema o reborde
        pares = cKDTree(V[ven]).query_pairs(0.8, output_type="ndarray")
        if not len(pares):
            continue
        g = coo_matrix((np.ones(len(pares)), (pares[:, 0], pares[:, 1])), shape=(len(ven), len(ven)))
        _, comp = connected_components(g, directed=False)
        grande = np.bincount(comp).argmax()
        pieza = ven[comp == grande]
        ancho = np.percentile(sv[pieza], 98) - np.percentile(sv[pieza], 2)
        alto = np.percentile(h[pieza], 98) - np.percentile(h[pieza], 2)
        if len(pieza) >= 150 and ancho >= 3.5 and alto >= 1.5:
            pieza = _afinar(V, piezas, i, pieza, sv, rad, h, margen)
            nuevas.append(pieza)
    return nuevas


def _afinar(V, piezas, i, pieza, sv, rad, h, margen):
    """Contorno de una corona recuperada: puede llegar hasta el borde real de los dientes vecinos (no a una
    ventana recta), y no más gruesa (vestíbulo-palatino) que la propia corona en su borde incisal u oclusal, para
    no llevarse la encía de al lado. Lo conectado a la punta, con el borde suavizado."""
    from scipy.spatial import cKDTree

    ocupado = np.zeros(len(V), bool)
    for q in piezas:
        ocupado[q] = True
    punta = pieza[h[pieza] >= np.percentile(h[pieza], 80)]
    r0, r1 = np.percentile(rad[punta], [2, 98])
    c0, c1 = np.median(sv[piezas[i]]), np.median(sv[piezas[i + 1]])
    cand = np.flatnonzero(~ocupado & (sv > c0) & (sv < c1) & (rad > r0 - 0.8) & (rad < r1 + 0.8) & (h > margen))
    if len(cand) < 150:
        return pieza
    # lo conectado a la punta (vecinos a menos de 0.6 mm; así no importa si la malla viene partida en parches)
    arbol = cKDTree(V[cand])
    dentro = np.zeros(len(cand), bool)
    dentro[np.isin(cand, punta)] = True
    frente = np.flatnonzero(dentro)
    while len(frente):
        nuevos = np.unique(np.concatenate(arbol.query_ball_point(V[cand[frente]], 0.6)))
        nuevos = nuevos[~dentro[nuevos]]
        dentro[nuevos] = True
        frente = nuevos
    out = cand[dentro]
    # borde suavizado: un vértice queda si la mayoría de lo que tiene alrededor (1 mm) es corona
    todo = cKDTree(V)
    marca = np.zeros(len(V), bool)
    marca[out] = True
    cerca = todo.query_ball_point(V[np.concatenate([out, cand[~dentro]])], 1.0)
    voto = np.array([marca[c].mean() for c in cerca])
    out = np.concatenate([out, cand[~dentro]])[voto > 0.5]
    out = out[~ocupado[out]]
    return out if 0.6 * len(pieza) <= len(out) <= 2.5 * len(pieza) else pieza


def _numerar_arcada(V, lab, jaw, piezas, sv):
    def tramo(idx):
        return float(np.percentile(sv[idx], 2)), float(np.percentile(sv[idx], 98))

    # 4) numerar en secuencia: a cada pieza un lugar de la arcada, siempre avanzando de derecha a izquierda.
    # Se prueban dos explicaciones de la arcada: solo permanentes, o dentición mixta (con dientes de leche,
    # que la red llama como su permanente: el 55 sale «15», o corre los números uno: el 36 sale «37»); se queda
    # la que mejor explica los anchos de las coronas.
    tr = [tramo(p) for p in piezas]
    perm = _numerar(piezas, tr, lab, V, jaw, mixta=False)
    mix = _numerar(piezas, tr, lab, V, jaw, mixta=True)
    molar_leche = any(f // 10 >= 5 and f % 10 >= 4 for f in mix[1])
    elegido = mix if molar_leche and mix[0] > perm[0] + MARGEN_MIXTA else perm
    out = np.zeros(len(lab), np.uint8)
    for p, fdi in zip(piezas, elegido[1]):
        out[p] = fdi
    return out


# rasgos de cada corona tal como la recorta la red (piezas emparejadas con el diente real en 46 casos revisados por
# la Dra.): ancho a lo largo de la arcada (p2–p98, mm) por posición 1–8 (permanentes) y 1–5 (de leche)
_MEDIDO = {"sup": {1: 8.8, 2: 7.4, 3: 8.4, 4: 9.0, 5: 8.2, 6: 11.8, 7: 10.5, 8: 9.2},
           "inf": {1: 5.6, 2: 6.3, 3: 6.9, 4: 8.0, 5: 8.5, 6: 11.9, 7: 10.6, 8: 10.5}}
_MEDIDO_T = {"sup": {1: 7.0, 2: 6.2, 3: 6.5, 4: 7.6, 5: 8.8}, "inf": {1: 4.6, 2: 5.1, 3: 6.7, 4: 8.1, 5: 9.5}}
_DISP = {1: 0.6, 2: 0.65, 3: 0.65, 4: 1.1, 5: 0.9, 6: 1.0, 7: 1.1, 8: 1.3}
# alto de la corona (p2–p98 en el eje oclusal) de caninos y premolares frente a sus temporales: los de leche son
# mucho más bajos. (mediana, dispersión) por posición 3–5
_ALTO = {"sup": {3: (8.0, 1.4), 4: (5.9, 1.3), 5: (5.3, 1.2)}, "inf": {3: (7.9, 1.4), 4: (6.4, 1.1), 5: (5.4, 1.1)}}
_ALTO_T = {"sup": {3: (4.0, 0.8), 4: (2.8, 0.7), 5: (2.8, 0.6)}, "inf": {3: (4.6, 0.8), 4: (3.4, 0.6), 5: (3.3, 0.7)}}
# pesos de la numeración (ajustados con los mismos casos)
PESO_VOTO = 1.0         # lo que dice la red
PESO_ANCHO = 0.25       # que el ancho de la corona sea el de ese diente
PESO_ALTO = 0.25        # que el alto de la corona sea de permanente o de leche
PENA_TEMPORAL = 0.15    # un diente de leche necesita algo más de evidencia que uno permanente
MARGEN_MIXTA = 0.2      # la dentición mixta tiene que explicar la arcada claramente mejor
PESO_SIMETRIA = 0.8     # cada par 13-23, 16-26… a la misma distancia de la línea media


def _lugares(jaw, mixta):
    """Los lugares posibles de la arcada, de la derecha del paciente a la izquierda: [(FDI, posición, de leche,
    orden)]. Un lugar 1–5 puede ser permanente o de leche (mismo orden: se excluyen entre sí)."""
    der, izq = (1, 2) if jaw == "sup" else (4, 3)
    out = []
    for k, (q, pos) in enumerate([(der, n) for n in range(8, 0, -1)] + [(izq, n) for n in range(1, 9)]):
        out.append((q * 10 + pos, pos, False, k))
        if mixta and pos <= 5:
            out.append(((q + 4) * 10 + pos, pos, True, k))
    return out


def _erupcion(a, b):
    """Castigo a dos dientes vecinos de un mismo lado (a antes que b, de derecha a izquierda) que no pueden convivir:
    un diente de leche obliga a que los de distal hasta el 5 también lo sean (el 54 no está con el 15)."""
    if (a[3] < 8) != (b[3] < 8):
        return 0.0
    distal, mesial = (a, b) if a[3] < 8 else (b, a)
    if mesial[2] and not distal[2] and distal[1] <= 5:
        return 0.3 if (mesial[1] == 3 and distal[1] == 4) else 3.0   # 53 con 14: pasa (el 14 sale antes)
    return 0.0


def _simetria(js, lug, tr):
    """Cuántos dientes de canino a distal tienen enfrente, a la misma distancia de la línea media, un diente con su
    mismo número (pares 13-23, 16-26…)."""
    cen = [0.5 * (a + b) for a, b in tr]
    anc = [b - a for a, b in tr]
    der = [i for i, j in enumerate(js) if lug[j][3] < 8]
    izq = [i for i, j in enumerate(js) if lug[j][3] >= 8]
    n = 0
    for i in der:
        if lug[js[i]][1] < 3 or not izq:
            continue
        k = min(izq, key=lambda k: abs(abs(cen[k]) - abs(cen[i])))
        if abs(abs(cen[k]) - abs(cen[i])) < 0.4 * min(anc[i], anc[k]) and lug[js[k]][1] == lug[js[i]][1]:
            n += 1
    return n


def _numerar(piezas, tr, lab, V, jaw, mixta):
    """Programación dinámica: (puntaje, [FDI por pieza])."""
    lug = _lugares(jaw, mixta)
    n, m = len(piezas), len(lug)
    xc = [float(np.median(V[p, 0])) for p in piezas]
    h = -V[:, 2] if jaw == "sup" else V[:, 2]
    altos = [float(np.percentile(h[p], 98) - np.percentile(h[p], 2)) for p in piezas]
    pts = np.full((n, m), -1e9)
    for i, p in enumerate(piezas):
        votos = np.bincount(lab[p], minlength=90) / len(p)
        ancho = tr[i][1] - tr[i][0]
        for j, (fdi, pos, temp, k) in enumerate(lug):
            q = fdi // 10 - (4 if temp else 0)    # cuadrante permanente de ese lado
            fp = q * 10 + pos                       # la red solo conoce permanentes: vota por el permanente
            v = PESO_VOTO * votos[fp] + 0.35 * sum(votos[c * 10 + pos] for c in (1, 2, 3, 4) if c != q)
            if mixta and pos >= 3 and pos < 8:
                # con dientes de leche la red suele correr el número uno hacia distal (el 75 sale «36»)
                v = max(v, 0.8 * PESO_VOTO * votos[fp + 1])
            e = (_MEDIDO_T if temp else _MEDIDO)[jaw][pos]
            z = (ancho - e) / _DISP[pos]
            v -= PESO_ANCHO * min(0.5 * z * z, 8.0)
            if mixta and 3 <= pos <= 5:
                mu, sd = (_ALTO_T if temp else _ALTO)[jaw][pos]
                za = (altos[i] - mu) / sd
                v -= PESO_ALTO * min(0.5 * za * za, 8.0)
            lado_der = k < 8
            if (lado_der and xc[i] > 3.0) or (not lado_der and xc[i] < -3.0):
                v -= 0.6
            if pos == 8:
                v -= 1.0 if mixta else 0.25
            if mixta and pos == 7:
                v -= 0.3
            if temp:
                v -= PENA_TEMPORAL
            pts[i, j] = v
    orden = np.array([x[3] for x in lug])
    # un pedazo angosto puede ser parte del diente anterior (la red lo cortó): lleva su mismo número
    pedazo = [tr[i][1] - tr[i][0] < 3.5 for i in range(n)]
    mejor = np.full((n, m), -1e9)
    antes = np.zeros((n, m), int)
    mejor[0] = pts[0]
    for i in range(1, n):
        hueco = max(0.0, tr[i][0] - tr[i - 1][1])
        faltan = int(round(hueco / 7.5))
        for j in range(m):
            if pedazo[i] and mejor[i - 1, j] - 0.3 > mejor[i, j]:
                mejor[i, j] = mejor[i - 1, j] - 0.3
                antes[i, j] = j
            for q in range(m):
                if orden[q] >= orden[j]:
                    continue
                valor = mejor[i - 1, q] - 0.45 * abs(orden[j] - orden[q] - 1 - faltan) + pts[i, j]
                if mixta:
                    valor -= _erupcion(lug[q], lug[j])
                if valor > mejor[i, j]:
                    mejor[i, j] = valor
                    antes[i, j] = q
    j = int(np.argmax(mejor[n - 1]))
    js = [0] * n
    for i in range(n - 1, -1, -1):
        js[i] = j
        j = antes[i, j]

    def puntaje(js):
        t = pts[0, js[0]]
        for i in range(1, n):
            a, b = js[i - 1], js[i]
            if a == b and pedazo[i]:
                t -= 0.3
                continue
            t += pts[i, b]
            if orden[a] >= orden[b]:
                return -1e9
            hueco = max(0.0, tr[i][0] - tr[i - 1][1])
            t -= 0.45 * abs(orden[b] - orden[a] - 1 - int(round(hueco / 7.5)))
            if mixta:
                t -= _erupcion(lug[a], lug[b])
        return t + PESO_SIMETRIA * _simetria(js, lug, tr)

    # 5) simetría: la red a veces corre los números de un solo lado (le falta ver un diente). Se prueba correr un
    # bloque de dientes desde distal un lugar, de cada lado, y se queda lo que mejor cuadra con el lado opuesto
    # (a la misma distancia de la línea media, el mismo diente)
    clave = {(x[3], x[2]): k for k, x in enumerate(lug)}
    actual = puntaje(js)
    for _ in range(4):
        mejor_js, mejor_v = None, actual
        der = [i for i in range(n) if orden[js[i]] < 8]
        izq = [i for i in range(n) if orden[js[i]] >= 8]
        bloques = [der[:k] for k in range(1, len(der) + 1)] + [izq[len(izq) - k:] for k in range(1, len(izq) + 1)]
        pass  # bloques.append(list(range(n)))  # toda la arcada corrida un lugar (la línea media mal puesta)
        for bloque in bloques:
            for d in (-1, 1):
                nuevo = list(js)
                ok = True
                for i in bloque:
                    o = orden[js[i]] + d
                    opciones = [clave[(o, t)] for t in (False, True) if (o, t) in clave]
                    cruza = (orden[js[i]] < 8) != (o < 8) and len(bloque) < n
                    if cruza or not opciones:
                        ok = False
                        break
                    nuevo[i] = max(opciones, key=lambda j: pts[i, j])  # permanente o de leche, lo que mejor le quede
                if not ok:
                    continue
                v = puntaje(nuevo)
                if v > mejor_v + 1e-6:
                    mejor_js, mejor_v = nuevo, v
        if mejor_js is None:
            break
        js, actual = mejor_js, mejor_v
    return actual, [lug[j][0] for j in js]
