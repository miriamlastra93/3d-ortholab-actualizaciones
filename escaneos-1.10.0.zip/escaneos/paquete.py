"""Paquete 3D OrthoLab (`.3dol`): los escaneos de un paciente para el doctor que lo refiere.

- **Firmado** con la llave de la Dra. Miriam (la misma de las licencias, Ed25519): solo ella puede crear paquetes
  válidos; uno alterado o hecho por otro no abre.
- **Cifrado para la computadora del doctor** (X25519 + AES-256-GCM): el doctor le manda su «código de equipo» y el
  paquete solo se abre en esa PC; reenviado a otro, no abre.
- Los modelos (STL o PLY con color) se guardan compactos (posiciones de 16 bits por eje ≈ 1 µm, comprimido LZMA) y
  en la PC del doctor se abren solo en memoria: nunca se escribe un STL/PLY a disco.

Estructura: "3DOL" | versión u16 | largo encabezado u32 | encabezado JSON | cifrado | firma (64 B)
La firma cubre todo lo anterior; el encabezado va además como dato autenticado del cifrado.
"""
from __future__ import annotations

import base64
import ctypes
import hashlib
import io
import json
import lzma
import os
import struct
import time

import numpy as np

MAGIA = b"3DOL"
VERSION = 1
PREFIJO_EQUIPO = "OLES1-"
INFO_HKDF = b"3D OrthoLab paquete de escaneos v1"
EXT = ".3dol"

# rol → (texto, ¿es modelo?)
ROLES = {
    "superior_sin_zocalo": "Superior",
    "inferior_sin_zocalo": "Inferior",
    "superior_con_zocalo": "Superior con zócalo",
    "inferior_con_zocalo": "Inferior con zócalo",
    "informe": "Informe PDF",
}


class ErrorPaquete(Exception):
    pass


# ----------------------------------------------------------------------------- llaves
def _id(publica: bytes) -> str:
    return hashlib.sha256(publica).hexdigest()[:16]


def _publica_firma() -> bytes:
    from .. import licencia

    return base64.b64decode(licencia.PUBLIC_KEY_B64)


class _Blob(ctypes.Structure):
    _fields_ = [("cbData", ctypes.c_uint32), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]


_ENTROPIA = b"3D OrthoLab Studio equipo de escaneos v1"


def _dpapi(datos: bytes, proteger: bool) -> bytes:
    """Protección de Windows (DPAPI): ligada a este usuario y esta computadora."""
    crypt32, kernel32 = ctypes.windll.crypt32, ctypes.windll.kernel32
    buf = ctypes.create_string_buffer(datos, len(datos))
    ent = ctypes.create_string_buffer(_ENTROPIA, len(_ENTROPIA))
    entrada = _Blob(len(datos), ctypes.cast(buf, ctypes.POINTER(ctypes.c_ubyte)))
    entropia = _Blob(len(_ENTROPIA), ctypes.cast(ent, ctypes.POINTER(ctypes.c_ubyte)))
    salida = _Blob()
    f = crypt32.CryptProtectData if proteger else crypt32.CryptUnprotectData
    ok = f(ctypes.byref(entrada), None, ctypes.byref(entropia), None, None, 0x1, ctypes.byref(salida))
    if not ok:
        raise ErrorPaquete("La llave de este equipo no es válida en esta computadora.")
    try:
        return ctypes.string_at(salida.pbData, salida.cbData)
    finally:
        kernel32.LocalFree(salida.pbData)


def _ruta_llave_equipo() -> str:
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return os.path.join(base, "3D OrthoLab Studio", "equipo-escaneos.bin")


def _llave_equipo():
    """Par X25519 de esta computadora (se crea la primera vez; guardado con DPAPI)."""
    from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey

    ruta = _ruta_llave_equipo()
    if os.path.exists(ruta):
        with open(ruta, "rb") as f:
            return X25519PrivateKey.from_private_bytes(_dpapi(f.read(), False))
    priv = X25519PrivateKey.generate()
    from cryptography.hazmat.primitives import serialization

    crudo = priv.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw,
                               serialization.NoEncryption())
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    with open(ruta, "wb") as f:
        f.write(_dpapi(crudo, True))
    return priv


def _crudo_publica(pub) -> bytes:
    from cryptography.hazmat.primitives import serialization

    return pub.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)


def codigo_equipo() -> str:
    """Código que el doctor le manda a la Dra. para recibir sus paquetes: OLES1-<llave pública>."""
    pub = _crudo_publica(_llave_equipo().public_key())
    return PREFIJO_EQUIPO + base64.urlsafe_b64encode(pub).decode().rstrip("=")


def leer_codigo(codigo: str) -> bytes:
    c = "".join(codigo.split())
    if not c.startswith(PREFIJO_EQUIPO):
        raise ErrorPaquete("El código de equipo debe empezar con OLES1-.")
    cuerpo = c[len(PREFIJO_EQUIPO):]
    try:
        pub = base64.urlsafe_b64decode(cuerpo + "=" * (-len(cuerpo) % 4))
    except Exception:  # noqa: BLE001
        raise ErrorPaquete("El código de equipo está incompleto.") from None
    if len(pub) != 32:
        raise ErrorPaquete("El código de equipo está incompleto.")
    return pub


def _llave_contenido(compartido: bytes, efimera_pub: bytes, equipo_pub: bytes) -> bytes:
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF

    return HKDF(algorithm=hashes.SHA256(), length=32, salt=efimera_pub + equipo_pub, info=INFO_HKDF).derive(compartido)


# ----------------------------------------------------------------------------- mallas
def limpiar_malla(v, f, col=None, minimo=0.10):
    """Quita los excedentes sueltos del escaneo (pedazos de malla que no están unidos a la arcada: lengua, carrillo,
    salpicaduras): se queda con el pedazo más grande y con los que midan al menos `minimo` de su área.
    Devuelve (v, f, col, pedazos quitados). No recorta la encía que sí está unida a la arcada."""
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components

    f = np.asarray(f, np.int64)
    n = len(v)
    if not len(f):
        return v, f.astype(np.uint32), col, 0
    # los PLY a color repiten vértices en las costuras de la textura: se unen por posición para ver qué está unido
    _, mismo = np.unique(np.round(np.asarray(v, np.float64), 3), axis=0, return_inverse=True)
    mismo = mismo.ravel()
    fu = mismo[f]
    aristas = np.vstack([fu[:, [0, 1]], fu[:, [1, 2]]])
    nu = int(mismo.max()) + 1
    g = coo_matrix((np.ones(len(aristas), np.int8), (aristas[:, 0], aristas[:, 1])), shape=(nu, nu))
    k, comp = connected_components(g, directed=False)
    cf = comp[fu[:, 0]]  # pedazo de cada cara
    area = 0.5 * np.linalg.norm(np.cross(v[f[:, 1]] - v[f[:, 0]], v[f[:, 2]] - v[f[:, 0]]), axis=1)
    por_pedazo = np.bincount(cf, weights=area, minlength=k)
    usados = np.unique(cf)
    buenos = usados[por_pedazo[usados] >= minimo * por_pedazo.max()]
    quitados = len(usados) - len(buenos)
    if not quitados:
        return v, f.astype(np.uint32), col, 0
    caras = f[np.isin(cf, buenos)]
    deja = np.zeros(n, bool)
    deja[caras.ravel()] = True
    nuevo = np.cumsum(deja) - 1
    return (np.asarray(v)[deja], nuevo[caras].astype(np.uint32), None if col is None else np.asarray(col)[deja],
            quitados)


def quitar_ajenos(v, f, col, minimo_mm2=3.0, anillos=2):
    """Quita del escaneo a color lo que no es boca: guante, separador o espejo azul/morado que el escáner captó
    pegado a la encía (en diente y encía el rojo nunca es menor que el azul). Devuelve (v, f, col, mm² quitados).
    Sin color no hay cómo distinguirlo: no hace nada."""
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components

    f = np.asarray(f, np.int64)
    if col is None or not len(f):
        return v, f.astype(np.uint32), col, 0.0
    c = np.asarray(col, np.int16)
    ajeno = (c[:, 2] - c[:, 0] > 14) & (c[:, 2] > c[:, 1] - 10)        # azulado o morado
    if not ajeno.any():
        return v, f.astype(np.uint32), col, 0.0
    # topología con los vértices unidos por posición (los PLY a color los repiten en las costuras de la textura)
    _, mismo = np.unique(np.round(np.asarray(v, np.float64), 3), axis=0, return_inverse=True)
    mismo = mismo.ravel()
    fw = mismo[f]
    nw = int(mismo.max()) + 1
    vq = np.zeros(nw, bool)
    vq[mismo[ajeno]] = True
    area = 0.5 * np.linalg.norm(np.cross(v[f[:, 1]] - v[f[:, 0]], v[f[:, 2]] - v[f[:, 0]]), axis=1)
    quitar = vq[fw].sum(1) >= 2
    fq = fw[quitar]
    if len(fq):  # solo manchas de verdad, no un reflejo azulado suelto
        ar = np.vstack([fq[:, [0, 1]], fq[:, [1, 2]]])
        k, comp = connected_components(coo_matrix((np.ones(len(ar), np.int8), (ar[:, 0], ar[:, 1])), shape=(nw, nw)),
                                       directed=False)
        cf = comp[fq[:, 0]]
        por_mancha = np.bincount(cf, weights=area[quitar], minlength=k)
        idx = np.nonzero(quitar)[0]
        quitar[idx[por_mancha[cf] < minimo_mm2]] = False
    if not quitar.any():
        return v, f.astype(np.uint32), col, 0.0
    vq[:] = False
    vq[fw[quitar].ravel()] = True
    for _ in range(anillos):  # y el borde de transición
        vq[fw[vq[fw].any(1)].ravel()] = True
    quitar = vq[fw].any(1)
    caras = f[~quitar]
    deja = np.zeros(len(v), bool)
    deja[caras.ravel()] = True
    nuevo = np.cumsum(deja) - 1
    return np.asarray(v)[deja], nuevo[caras].astype(np.uint32), np.asarray(col)[deja], float(area[quitar].sum())


def leer_malla(ruta_o_bytes, nombre: str = "", limpiar: bool = False):
    """(vértices N×3 float32, caras M×3 uint32, colores N×3 uint8 o None) de un STL o PLY."""
    import trimesh

    import logging

    tipo = (os.path.splitext(nombre or str(ruta_o_bytes))[1] or ".stl").lstrip(".").lower()
    fuente = io.BytesIO(ruta_o_bytes) if isinstance(ruta_o_bytes, (bytes, bytearray)) else ruta_o_bytes
    logging.getLogger("trimesh").setLevel(logging.CRITICAL)  # PLY con textura que no vino: no es un error
    m = trimesh.load(fuente, file_type=tipo, process=True, force="mesh")
    col = None
    try:
        # el escáner guarda el color como textura («….ply.png» junto al PLY): se pasa a color por vértice
        if m.visual.kind == "texture" and getattr(m.visual.material, "image", None) is not None:
            m.visual = m.visual.to_color()
        vc = np.asarray(m.visual.vertex_colors)
        if m.visual.kind == "vertex" and vc.ndim == 2 and len(vc) == len(m.vertices):
            if not np.all(vc[:, :3] == vc[0, :3]):  # un solo color = sin color real
                col = vc[:, :3].astype(np.uint8)
    except Exception:  # noqa: BLE001
        col = None
    v, f = np.asarray(m.vertices, np.float32), np.asarray(m.faces, np.uint32)
    if limpiar:
        v, f, col, _ = quitar_ajenos(v, f, col)   # guante / separador pegado a la encía
        v, f, col, _ = limpiar_malla(v, f, col)   # y los pedazos que queden sueltos
    return v, f, col


def _compactar(v, f, col) -> bytes:
    lo = v.min(0)
    paso = np.maximum((v.max(0) - lo) / 65535.0, 1e-9).astype(np.float32)
    q = np.round((v - lo) / paso).clip(0, 65535).astype("<u2")
    cab = struct.pack("<IIB", len(v), len(f), 1 if col is not None else 0) + lo.astype("<f4").tobytes() + paso.astype("<f4").tobytes()
    partes = [cab, q.tobytes(), np.asarray(f, "<u4").tobytes()]
    if col is not None:
        partes.append(np.asarray(col, np.uint8).tobytes())
    return b"".join(partes)


def _descompactar(b: bytes):
    nv, nf, tiene = struct.unpack_from("<IIB", b, 0)
    o = 9
    lo = np.frombuffer(b, "<f4", 3, o); o += 12
    paso = np.frombuffer(b, "<f4", 3, o); o += 12
    q = np.frombuffer(b, "<u2", nv * 3, o).reshape(nv, 3); o += nv * 6
    f = np.frombuffer(b, "<u4", nf * 3, o).reshape(nf, 3); o += nf * 12
    col = np.frombuffer(b, np.uint8, nv * 3, o).reshape(nv, 3) if tiene else None
    if f.size and int(f.max()) >= nv:
        raise ErrorPaquete("El paquete está dañado (malla).")
    return (lo + q.astype(np.float32) * paso).astype(np.float32), f, col


# ----------------------------------------------------------------------------- detectar archivos de un caso
def detectar(carpeta: str) -> dict:
    """{rol: ruta} con las reglas del escáner de 3D OrthoLab (AccuDesign/DentalCopilot):
    *UpperJaw_model* / *LowerJaw_model* → con zócalo; *-UpperJaw / *-LowerJaw → sin zócalo (el PLY con color si lo
    hay, si no el STL); *Informe*.pdf → informe. Los TotalJaw (registros de mordida) no se usan."""
    out: dict[str, str] = {}
    prioridad: dict[str, tuple] = {}
    candidatos = []
    for raiz, _, archivos in os.walk(carpeta):
        for a in archivos:
            candidatos.append(os.path.join(raiz, a))
    for r in sorted(candidatos):
        n = os.path.basename(r).lower()
        ext = os.path.splitext(n)[1]
        if "totaljaw" in n:
            continue
        if ext == ".pdf" and "informe" in n:
            out.setdefault("informe", r)
        elif ext in (".stl", ".ply"):
            for arc, clave in (("upperjaw", "superior"), ("lowerjaw", "inferior")):
                if arc not in n:
                    continue
                if "_model" in n:
                    out.setdefault(f"{clave}_con_zocalo", r)
                else:
                    rol = f"{clave}_sin_zocalo"
                    # primero la arcada tal cual («…-UpperJaw»), no variantes («-UpperJaw-marker», scanbodies…);
                    # entre iguales, el PLY (trae color)
                    nota = (0 if os.path.splitext(n)[0].endswith(arc) else 1, 0 if ext == ".ply" else 1)
                    if rol not in prioridad or nota < prioridad[rol]:
                        out[rol], prioridad[rol] = r, nota
    return out


# ----------------------------------------------------------------------------- crear (solo la Dra.)
def buscar_accudesign(carpeta: str):
    """El PDF «Informe de análisis del modelo» de AccuDesign / MetronTrack de la carpeta (o None)."""
    for raiz, _, archivos in os.walk(carpeta):
        for a in sorted(archivos):
            n = a.lower()
            if n.endswith(".pdf") and ("análisis del modelo" in n or "analisis del modelo" in n):
                return os.path.join(raiz, a)
    return None


def datos_accudesign(ruta_pdf) -> dict | None:
    """Lo que el visor del doctor usa del informe de AccuDesign (anchos dentarios, apiñamiento, Bolton, Spee…).
    Se lee en la PC de la Dra. (necesita PyMuPDF) y viaja dentro del paquete como datos."""
    if not ruta_pdf:
        return None
    try:
        from . import accudesign

        AD = accudesign.parse(ruta_pdf)
    except Exception:  # noqa: BLE001  (sin PyMuPDF o PDF distinto: el visor medirá con anchos promedio)
        return None
    AD.pop("archivo", None)
    return AD if AD.get("anchos") else None


def datos_escaner(carpeta: str) -> dict | None:
    """Las medidas del escáner para el caso: las del PDF de AccuDesign y, si no hay PDF, las que MetronTrack guardó
    en la orden (C:\\DentalOrder). Lo que falte en el PDF se completa con lo de MetronTrack."""
    ad = datos_accudesign(buscar_accudesign(carpeta))
    try:
        from . import dientes_mt

        orden = dientes_mt.carpeta_orden(carpeta)
        mt = dientes_mt.medidas(orden) if orden else None
    except Exception:  # noqa: BLE001
        mt = None
    if ad and mt:
        for k, v in mt.items():
            if not ad.get(k):
                ad[k] = v
        return ad
    return ad or mt


def datos_dientes(carpeta: str, archivos: dict, modelos: dict | None = None, limpiar: bool = True) -> dict | None:
    """La separación de dientes de MetronTrack del caso (número FDI de cada diente), ya acomodada sobre cada modelo:
    {rol: etiquetas por vértice, comprimidas en base64}. None si el caso no pasó por MetronTrack o no coincide."""
    import zlib

    etiquetas = {}
    try:
        from . import dientes_mt

        if modelos is None:
            modelos = {rol: leer_malla(r, limpiar=limpiar)[0] for rol, r in archivos.items() if rol != "informe"}
        orden = dientes_mt.carpeta_orden(carpeta)
        if orden:
            etiquetas = dict(dientes_mt.para_modelos(orden, modelos))
    except Exception:  # noqa: BLE001  (sin la separación el visor sigue funcionando)
        etiquetas = {}
    # lo que la Dra. identificó (con IA) y revisó en esta computadora, para los modelos que MetronTrack no cubrió
    for rol, V in (modelos or {}).items():
        if rol not in etiquetas:
            e = dientes_locales(V)
            if e is not None:
                etiquetas[rol] = e
    return {rol: base64.b64encode(zlib.compress(e.tobytes(), 9)).decode("ascii") for rol, e in etiquetas.items()} or None


def _ruta_dientes_locales(V) -> str:
    import hashlib

    h = hashlib.sha1(np.ascontiguousarray(V, np.float32).tobytes()).hexdigest()[:32]
    return os.path.join(os.path.expanduser("~"), "Documents", "3D OrthoLab Studio", "Escaneos", "dientes", h + ".bin")


def guardar_dientes_locales(V, etiquetas, fijo: bool = False) -> None:
    """Guarda (cifrada, en esta computadora) la numeración de dientes revisada de un modelo; la llave es el modelo.
    `fijo`: el doctor retocó el área de los dientes a mano: esa versión manda sobre la que trae el caso."""
    import zlib

    r = _ruta_dientes_locales(V)
    os.makedirs(os.path.dirname(r), exist_ok=True)
    with open(r, "wb") as f:
        f.write(_dpapi(zlib.compress(np.asarray(etiquetas, np.uint8).tobytes(), 9), True))
    if fijo:
        with open(r + ".fijo", "w") as f:
            f.write("1")


def dientes_locales_fijos(V) -> bool:
    return os.path.exists(_ruta_dientes_locales(V) + ".fijo")


def borrar_dientes_locales(V) -> None:
    r = _ruta_dientes_locales(V)
    for x in (r, r + ".fijo"):
        if os.path.exists(x):
            os.remove(x)


def dientes_locales(V):
    """FDI por vértice guardado para este modelo, o None."""
    import zlib

    try:
        r = _ruta_dientes_locales(V)
        if not os.path.exists(r):
            return None
        with open(r, "rb") as f:
            e = np.frombuffer(zlib.decompress(_dpapi(f.read(), False)), np.uint8).copy()
        return e if len(e) == len(V) else None
    except Exception:  # noqa: BLE001
        return None


def leer_dientes(datos: dict, modelos: dict) -> dict:
    """{rol: FDI por vértice (uint8)} a partir de la entrada «dientes» del paquete (solo las que cuadran)."""
    import zlib

    out = {}
    for rol, b in ((datos or {}).get("dientes") or {}).items():
        try:
            e = np.frombuffer(zlib.decompress(base64.b64decode(b)), np.uint8)
        except Exception:  # noqa: BLE001
            continue
        if rol in modelos and len(e) == len(modelos[rol][0]):
            out[rol] = e
    return out


def empaquetar(archivos: dict, info: dict, codigo_destino: str, llave_privada, datos: dict | None = None,
               limpiar: bool = True) -> bytes:
    """archivos: {rol: ruta}. info: {paciente, doctor, fecha_escaneo, numero_caso}. llave_privada: Ed25519.
    datos: {rol: objeto JSON} que viajan con el caso (p. ej. "accudesign": los anchos dentarios del informe)."""
    from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    if not any(r != "informe" for r in archivos):
        raise ErrorPaquete("El caso no tiene ningún modelo.")
    entradas, blobs, inicio = [], [], 0
    for rol, ruta in archivos.items():
        if rol not in ROLES:
            continue
        if rol == "informe":
            with open(ruta, "rb") as fh:
                blob = fh.read()
            if not blob.startswith(b"%PDF-"):
                raise ErrorPaquete(f"«{os.path.basename(ruta)}» no es un PDF.")
            tipo = "pdf"
        else:
            blob = _compactar(*leer_malla(ruta, limpiar=limpiar))  # sin excedentes sueltos
            tipo = "malla"
        entradas.append({"rol": rol, "nombre": os.path.basename(ruta), "tipo": tipo, "inicio": inicio,
                         "largo": len(blob), "sha256": hashlib.sha256(blob).hexdigest()})
        blobs.append(blob)
        inicio += len(blob)
    for rol, obj in (datos or {}).items():  # los visores anteriores ignoran las entradas «json»
        if obj is None:
            continue
        blob = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        entradas.append({"rol": rol, "nombre": rol + ".json", "tipo": "json", "inicio": inicio, "largo": len(blob),
                         "sha256": hashlib.sha256(blob).hexdigest()})
        blobs.append(blob)
        inicio += len(blob)
    manifiesto = json.dumps({"info": info, "archivos": entradas}, ensure_ascii=False).encode("utf-8")
    contenido = struct.pack("<I", len(manifiesto)) + manifiesto + b"".join(blobs)
    comprimido = lzma.compress(contenido, preset=6)

    destino = leer_codigo(codigo_destino)
    efimera = X25519PrivateKey.generate()
    efimera_pub = _crudo_publica(efimera.public_key())
    llave = _llave_contenido(efimera.exchange(X25519PublicKey.from_public_bytes(destino)), efimera_pub, destino)
    nonce = os.urandom(12)
    firmante = _crudo_publica(llave_privada.public_key())
    if firmante != _publica_firma():
        raise ErrorPaquete("La llave privada no corresponde a la de la app (no es la de 3D OrthoLab).")
    encabezado = json.dumps({"formato": VERSION, "caso_id": os.urandom(16).hex(), "creado_unix": int(time.time()),
                             "firmante": _id(firmante), "destinatario": _id(destino),
                             "efimera": base64.b64encode(efimera_pub).decode(), "nonce": base64.b64encode(nonce).decode(),
                             "compresion": "lzma"}).encode("utf-8")
    prefijo = MAGIA + struct.pack("<HI", VERSION, len(encabezado)) + encabezado
    cifrado = AESGCM(llave).encrypt(nonce, comprimido, prefijo)
    cuerpo = prefijo + cifrado
    return cuerpo + llave_privada.sign(cuerpo)


# ----------------------------------------------------------------------------- abrir (el doctor)
def encabezado(datos: bytes) -> dict:
    if len(datos) < 10 + 64 or datos[:4] != MAGIA:
        raise ErrorPaquete("Este archivo no es un caso de 3D OrthoLab.")
    version, largo = struct.unpack_from("<HI", datos, 4)
    if version != VERSION:
        raise ErrorPaquete(f"Versión de paquete no compatible ({version}): actualiza 3D OrthoLab Studio.")
    if largo > 64 * 1024 or 10 + largo + 64 > len(datos):
        raise ErrorPaquete("Este archivo no es un caso de 3D OrthoLab.")
    try:
        e = json.loads(datos[10:10 + largo])
    except ValueError:
        raise ErrorPaquete("Este archivo no es un caso de 3D OrthoLab.") from None
    e["_fin"] = 10 + largo
    return e


def abrir(datos: bytes) -> dict:
    """Verifica la firma de 3D OrthoLab, comprueba que el paquete sea para esta computadora y lo abre en memoria.
    {"info": {...}, "modelos": {rol: (v, f, col)}, "informe": bytes|None, "nombres": {rol: nombre}}"""
    from cryptography.exceptions import InvalidSignature, InvalidTag
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PublicKey
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    e = encabezado(datos)
    pub_firma = _publica_firma()
    if e.get("firmante") != _id(pub_firma):
        raise ErrorPaquete("Este paquete no fue emitido por 3D OrthoLab.")
    cuerpo, firma = datos[:-64], datos[-64:]
    try:
        Ed25519PublicKey.from_public_bytes(pub_firma).verify(firma, cuerpo)
    except InvalidSignature:
        raise ErrorPaquete("El paquete fue alterado o no fue emitido por 3D OrthoLab.") from None
    priv = _llave_equipo()
    mia = _crudo_publica(priv.public_key())
    if e.get("destinatario") != _id(mia):
        raise ErrorPaquete("Este paquete es para la computadora de otro doctor. Pide a 3D OrthoLab que te lo "
                           "mande para el código de este equipo.")
    efimera = base64.b64decode(e["efimera"])
    llave = _llave_contenido(priv.exchange(X25519PublicKey.from_public_bytes(efimera)), efimera, mia)
    prefijo = cuerpo[:e["_fin"]]
    try:
        comprimido = AESGCM(llave).decrypt(base64.b64decode(e["nonce"]), cuerpo[e["_fin"]:], prefijo)
    except InvalidTag:
        raise ErrorPaquete("El paquete fue alterado.") from None
    contenido = lzma.decompress(comprimido, memlimit=2 << 30)
    (lm,) = struct.unpack_from("<I", contenido, 0)
    man = json.loads(contenido[4:4 + lm])
    base = 4 + lm
    out = {"info": man.get("info", {}), "modelos": {}, "informe": None, "nombres": {}, "datos": {}}
    for a in man.get("archivos", []):
        b = contenido[base + a["inicio"]: base + a["inicio"] + a["largo"]]
        if hashlib.sha256(b).hexdigest() != a["sha256"]:
            raise ErrorPaquete(f"El paquete está dañado ({a['nombre']}).")
        out["nombres"][a["rol"]] = a["nombre"]
        if a["tipo"] == "pdf":
            out["informe"] = b
        elif a["tipo"] == "malla":
            out["modelos"][a["rol"]] = _descompactar(b)
        elif a["tipo"] == "json":
            out["datos"][a["rol"]] = json.loads(b)
    return out


# ----------------------------------------------------------------------------- vista previa (la Dra., sin paquete)
def desde_carpeta(carpeta: str, info: dict | None = None, limpiar: bool = True) -> dict:
    """El mismo resultado que abrir(), leyendo directo la carpeta del caso (solo en la PC de la Dra.)."""
    arch = detectar(carpeta)
    out = {"info": info or {"paciente": os.path.basename(carpeta.rstrip("\\/"))}, "modelos": {}, "informe": None,
           "nombres": {}, "datos": {}}
    ad = datos_escaner(carpeta)
    if ad:
        out["datos"]["accudesign"] = ad
    for rol, ruta in arch.items():
        out["nombres"][rol] = os.path.basename(ruta)
        if rol == "informe":
            with open(ruta, "rb") as fh:
                out["informe"] = fh.read()
        else:
            out["modelos"][rol] = leer_malla(ruta, limpiar=limpiar)
    dientes = datos_dientes(carpeta, arch, {rol: m[0] for rol, m in out["modelos"].items()})
    if dientes:
        out["datos"]["dientes"] = dientes
    return out
