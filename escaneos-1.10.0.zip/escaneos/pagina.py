"""Módulo «Análisis de modelos» (exclusivo 3D OrthoLab): los escaneos intraorales de los pacientes del doctor.

- El doctor recibe un Paquete 3D OrthoLab (.3dol) por WhatsApp, correo o Drive: lo arrastra aquí (o «Abrir
  paquete…») y queda en su biblioteca. Solo abren paquetes firmados por 3D OrthoLab y hechos para esta computadora;
  no hay «Abrir STL»: los escaneos de otros escáneres no entran.
- Tres pestañas: «Modelos», «Análisis» (lo calcula esta app en la computadora del doctor) e «Informe PDF».
- Sobre el visor, como en MetronTrack: el panel «Modelos» (mostrar u ocultar cada arcada, transparencia, zócalo,
  color real, apertura) y, abajo, las vistas rápidas con íconos.
- En «Análisis»: overjet/overbite, corte de oclusión con un plano que se arrastra, contactos, Korkhaus, espacio y
  Bolton, Moyers y arcada. Con la separación de dientes del escáner, cada diente se pinta al pasar el mouse y
  muestra su número y su ancho.
- «Medir»: regla de dos clics sobre el modelo.
- En la PC de la Dra. (donde está su llave de firma) aparecen además «Enviar al doctor…» y «Vista previa de una
  carpeta…».
"""
from __future__ import annotations

import json
import os
import shutil
import time

import numpy as np
from PySide6 import QtCore, QtGui, QtWidgets
from PySide6.QtCore import Qt

from . import analisis as AN
from . import orientacion as O
from . import paquete as PQ
from .panel_analisis import GraficaCorte, PanelAnalisis, Trabajador

TURQ = "#1995AD"
BIBLIOTECA = os.path.join(os.path.expanduser("~"), "Documents", "3D OrthoLab Studio", "Escaneos")
COLOR_SUP, COLOR_INF = "#F1ECE2", "#E9E2D4"
ROJO, VERDE, AZUL, AMBAR = "#e5534b", "#2f9e4f", "#2f7fd6", "#d99a1a"
VERDE_MD = "#3fbf9a"  # la línea mesiodistal de cada diente: verde menta (la curva del arco va en grafito)


def _palomita() -> str:
    """Imagen de la palomita de las casillas (los estilos de Qt la piden como archivo)."""
    import tempfile

    ruta = os.path.join(tempfile.gettempdir(), "ortholab-palomita.png")
    if not os.path.exists(ruta):
        pm = QtGui.QPixmap(36, 36)
        pm.fill(Qt.transparent)
        q = QtGui.QPainter(pm)
        q.setRenderHint(QtGui.QPainter.Antialiasing)
        q.setPen(QtGui.QPen(QtGui.QColor("white"), 5, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        q.drawPolyline([QtCore.QPointF(8, 19), QtCore.QPointF(15, 26), QtCore.QPointF(28, 10)])
        q.end()
        pm.save(ruta)
    return ruta.replace("\\", "/")


def _ojo(abierto: bool) -> str:
    """Imagen del ojo (abierto = la arcada se ve; tachado = oculta) para las casillas de «Modelos»."""
    import tempfile

    ruta = os.path.join(tempfile.gettempdir(), f"ortholab-ojo-{'si' if abierto else 'no'}-2.png")
    if not os.path.exists(ruta):
        pm = QtGui.QPixmap(44, 44)
        pm.fill(Qt.transparent)
        q = QtGui.QPainter(pm)
        q.setRenderHint(QtGui.QPainter.Antialiasing)
        color = QtGui.QColor("#1995AD" if abierto else "#9aa5b1")
        q.setPen(QtGui.QPen(color, 3.4, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        forma = QtGui.QPainterPath()
        forma.moveTo(4, 22)
        forma.quadTo(22, 2, 40, 22)
        forma.quadTo(22, 42, 4, 22)
        q.drawPath(forma)
        q.setBrush(color)
        q.drawEllipse(QtCore.QPointF(22, 22), 5.5, 5.5)
        if not abierto:
            q.drawLine(QtCore.QPointF(8, 38), QtCore.QPointF(36, 6))
        q.end()
        pm.save(ruta)
    return ruta.replace("\\", "/")


ESTILO_BARRA = (
    # barra de arriba y fila del caso, en claro: un solo botón resaltado («Enviar al doctor»)
    "QPushButton#b_sec{background:#ffffff;color:#3d4753;border:1px solid #cfd8dd;border-radius:9px;padding:6px 12px;}"
    "QPushButton#b_sec:hover{border-color:#1995AD;color:#0f6a7c;}"
    "QPushButton#b_sec:checked{background:#1995AD;color:white;border-color:#1995AD;font-weight:600;}"
    "QPushButton#b_volver{background:transparent;color:#0f6a7c;border:none;padding:6px 6px;font-weight:600;}"
    "QPushButton#b_volver:hover{color:#1995AD;}"
    "QPushButton#b_principal{background:#1995AD;color:white;border:none;border-radius:9px;padding:7px 14px;"
    "font-weight:600;}"
    "QPushButton#b_principal:hover{background:#147a8f;}"
    "QFrame#seg{background:#e6ecef;border-radius:10px;}"
    "QFrame#seg QPushButton{background:transparent;color:#5b6570;border:none;border-radius:8px;padding:5px 14px;}"
    "QFrame#seg QPushButton:hover{color:#0f6a7c;}"
    "QFrame#seg QPushButton:checked{background:#ffffff;color:#0f6a7c;font-weight:600;}"
    "QFrame#seg QPushButton:disabled{color:#b8c0c8;}")


def _estilo_flotante() -> str:
    return ("QFrame#flot{background:#ffffff;border:1px solid #d5dde2;border-radius:12px;}"
            "QFrame#flot QLabel{color:#2b3440;background:transparent;}"
            "QFrame#flot QCheckBox{color:#2b3440;background:transparent;spacing:8px;}"
            "QFrame#flot QCheckBox::indicator{width:18px;height:18px;border-radius:4px;border:2px solid #9aa5b1;"
            "background:#ffffff;}"
            f"QFrame#flot QCheckBox::indicator:checked{{background:#1995AD;border-color:#1995AD;image:url({_palomita()});}}"
            "QFrame#flot QCheckBox::indicator:disabled{background:#e4e8ec;border-color:#c9d1d9;}"
            # las arcadas se muestran u ocultan con un ojo, no con una palomita
            "QFrame#flot QCheckBox#ojo::indicator{width:22px;height:22px;border:none;background:transparent;"
            f"image:url({_ojo(False)});}}"
            f"QFrame#flot QCheckBox#ojo::indicator:checked{{border:none;background:transparent;image:url({_ojo(True)});}}"
            "QFrame#flot QSlider::groove:horizontal{height:4px;background:#bfe3ea;border-radius:2px;}"
            "QFrame#flot QSlider::sub-page:horizontal{background:#1995AD;border-radius:2px;}"
            "QFrame#flot QSlider::add-page:horizontal{background:#c9d3dc;border-radius:2px;}"
            "QFrame#flot QSlider::handle:horizontal{width:14px;height:14px;margin:-7px 0;border-radius:9px;"
            "background:#ffffff;border:3px solid #0f6a7c;}"
            "QFrame#flot QToolButton{border:none;border-radius:8px;background:transparent;color:#2b3440;padding:4px 8px;}"
            "QFrame#flot QToolButton:hover{background:#e3eef2;}QFrame#flot QToolButton:pressed{background:#c9e3ea;}"
            "QFrame#flot QToolButton:checked{background:#1995AD;color:white;}")


def _icono_arcada(jaw, n=44):
    """Miniatura de la arcada (la que controla cada renglón del panel «Modelos»): la boca ilustrada en el turquesa
    de la marca, con la arcada de ese renglón a todo color y la otra en gris tenue."""
    ruta = os.path.join(os.path.dirname(os.path.abspath(__file__)), "iconos", "v_abiertas.png")
    base = QtGui.QImage(ruta) if os.path.exists(ruta) else QtGui.QImage()
    if not base.isNull():
        ancho, alto = 108, 86  # se dibuja al doble y se muestra a la mitad: nítida
        esc = base.scaled(ancho, alto, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        gris = esc.convertToFormat(QtGui.QImage.Format_Grayscale8).convertToFormat(QtGui.QImage.Format_ARGB32)
        gris.setAlphaChannel(esc.convertToFormat(QtGui.QImage.Format_Alpha8))
        pm = QtGui.QPixmap(ancho, alto)
        pm.fill(Qt.transparent)
        q = QtGui.QPainter(pm)
        x0, y0, medio = (ancho - esc.width()) // 2, (alto - esc.height()) // 2, esc.height() // 2
        arriba = QtCore.QRect(0, 0, esc.width(), medio)
        abajo = QtCore.QRect(0, medio, esc.width(), esc.height() - medio)
        mia, otra = (arriba, abajo) if jaw == "sup" else (abajo, arriba)
        q.setOpacity(0.38)
        q.drawImage(QtCore.QPoint(x0 + otra.x(), y0 + otra.y()), gris, otra)
        q.setOpacity(1.0)
        q.drawImage(QtCore.QPoint(x0 + mia.x(), y0 + mia.y()), esc, mia)
        q.end()
        pm.setDevicePixelRatio(2.0)
        return pm
    pm = QtGui.QPixmap(n, int(n * 0.72))
    pm.fill(Qt.transparent)
    q = QtGui.QPainter(pm)
    q.setRenderHint(QtGui.QPainter.Antialiasing)
    h = pm.height()
    for cual, y, curva in (("sup", h * 0.30, 5), ("inf", h * 0.66, 5)):
        activo = cual == jaw
        q.setPen(QtGui.QPen(QtGui.QColor("#f08a8a" if activo else "#d7dce1"), 9 if activo else 7, Qt.SolidLine, Qt.RoundCap))
        cam = QtGui.QPainterPath()
        cam.moveTo(6, y)
        cam.quadTo(n / 2, y + curva, n - 6, y)
        q.drawPath(cam)
        q.setPen(QtGui.QPen(QtGui.QColor("#ffffff" if activo else "#eef1f4"), 4, Qt.DotLine, Qt.RoundCap))
        cam2 = QtGui.QPainterPath()
        cam2.moveTo(8, y + (2 if cual == "sup" else -2))
        cam2.quadTo(n / 2, y + curva + (2 if cual == "sup" else -2), n - 8, y + (2 if cual == "sup" else -2))
        q.drawPath(cam2)
    q.end()
    return pm


def _muted(t):
    lb = QtWidgets.QLabel(t)
    lb.setWordWrap(True)
    lb.setStyleSheet("color:#8b949e;font-size:9pt;")
    return lb


def _segmentado(nombres, al_elegir, inicial=0):
    w = QtWidgets.QFrame()
    w.setObjectName("seg")
    h = QtWidgets.QHBoxLayout(w)
    h.setContentsMargins(3, 3, 3, 3)
    h.setSpacing(2)
    g = QtWidgets.QButtonGroup(w)
    for i, n in enumerate(nombres):
        b = QtWidgets.QPushButton(n)
        b.setCheckable(True)
        b.setCursor(Qt.PointingHandCursor)
        g.addButton(b, i)
        h.addWidget(b)
    g.button(inicial).setChecked(True)
    g.idClicked.connect(al_elegir)
    w.grupo = g
    return w


def puede_enviar() -> bool:
    """¿Está aquí la llave de firma de la Dra.? (solo en su computadora)."""
    return os.path.exists(os.path.join(os.path.expanduser("~"), ".ortholab-studio", "llave_privada.pem"))


def _traslacion(x=0.0, y=0.0, z=0.0):
    T = np.eye(4)
    T[:3, 3] = (x, y, z)
    return T


ROT_X180 = np.diag([1.0, -1.0, -1.0, 1.0])
# medidas de la arcada con el aspecto de MetronTrack: línea azul pizarra, punto azul en el extremo, valor sin recuadro de color
COLOR_ARCADA, COLOR_ARCADA_FILO = "#2b3440", "#ffffff"  # la curva de la arcada: grafito con halo blanco (elegido por la Dra.)
MD_PUNTO = "#1c7059"  # los puntos de los extremos de la línea mesiodistal
MT_LINEA, MT_PUNTO, MT_PLANO = "#33456b", "#1995AD", "#8f7ae6"
COLOR_AREA_GRIS, COLOR_AREA_DIENTE = (214, 216, 218), (242, 100, 40)  # «Modificar área», como MetronTrack
NIVEL_COLOR = {0: "#2e9e5b", 1: "#d39b1c", 2: "#e07b22", 3: "#d64541"}
# colores propios de las relaciones oclusales: superior coral, inferior violeta (los dientes, en turquesa)
COLOR_REL_SUP, COLOR_REL_INF = "#f2643d", "#6c5ce7"
# dientes que se pintan en cada relación oclusal (como MetronTrack)
DIENTES_RELACION = {"molar": {"sup": (16, 26), "inf": (46, 36)},
                    "canina": {"sup": (13, 23), "inf": (43, 33, 44, 34)},
                    }
# color de cada diente en «Dientes», por GRUPO (propio de 3D OrthoLab, en su gama): incisivos, caninos, premolares y molares
COLOR_DIENTE = {1: (240, 190, 60), 2: (240, 190, 60),     # incisivos: amarillo
                3: (224, 84, 132),                           # caninos: rosa frambuesa (el que resalta)
                4: (46, 150, 104), 5: (46, 150, 104),        # premolares: verde
                6: (40, 72, 126), 7: (40, 72, 126), 8: (40, 72, 126)}  # molares: azul marino (paleta F, la que eligió Miriam)


# vistas que sirven en cada análisis; las demás se bloquean (como en MetronTrack)
_OCLUSALES = ("separadas", "oclusal_sup", "oclusal_inf")
_LATERALES = ("frente", "derecha", "izquierda")
VISTAS_DE = {"overjet": _LATERALES, "lmedia": _LATERALES, "molar": ("derecha", "izquierda"),
             "canina": ("derecha", "izquierda"), "corte": _LATERALES + ("atras", "oclusal_sup", "oclusal_inf"),
             "contactos": _LATERALES + ("atras",) + _OCLUSALES, "korkhaus": _OCLUSALES, "espacio": _OCLUSALES, "bolton": _OCLUSALES,
             "moyers": _OCLUSALES, "arcada": _OCLUSALES, "forma": _OCLUSALES, "longitud": _OCLUSALES,
             "simetria": _OCLUSALES, "dientes": _OCLUSALES}


def nombre_punto(nombre: str) -> str:
    """Qué es anatómicamente cada punto que se arrastra (p. ej. «molar_der_sup»)."""
    partes = nombre.split("_")
    if partes[0] == "lm":
        return "Línea media superior (entre 11 y 21)" if partes[1] == "sup" else "Línea media inferior (entre 41 y 31)"
    cual, lado, arc = partes
    der = lado == "der"
    if cual == "molar":
        return (f"Cúspide mesiovestibular del primer molar superior ({16 if der else 26})" if arc == "sup" else
                f"Surco mesiovestibular del primer molar inferior ({46 if der else 36})")
    return (f"Cúspide del canino superior ({13 if der else 23})" if arc == "sup" else
            f"Tronera entre el canino y el primer premolar inferiores ({'43 y 44' if der else '33 y 34'})")


def _icono_vista(vista):
    ic = QtGui.QIcon()
    ic.addPixmap(_dibujo_vista(vista, "#3d4753"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
    ic.addPixmap(_dibujo_vista(vista, "#ffffff"), QtGui.QIcon.Normal, QtGui.QIcon.On)
    ic.addPixmap(_dibujo_vista(vista, "#c9d0d7"), QtGui.QIcon.Disabled, QtGui.QIcon.Off)
    return ic


def _dibujo_vista(vista, color="#3d4753", n=56):
    """Íconos de las vistas rápidas (arcadas dibujadas, como en MetronTrack)."""
    pm = QtGui.QPixmap(n, n)
    pm.fill(Qt.transparent)
    p = QtGui.QPainter(pm)
    p.setRenderHint(QtGui.QPainter.Antialiasing)
    c = QtGui.QColor(color)
    gruesa = QtGui.QPen(c, 7, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
    p.setPen(gruesa)

    def u(cx, cy, rx, ry, abajo=True):  # arcada por oclusal
        cam = QtGui.QPainterPath()
        s = 1 if abajo else -1
        cam.moveTo(cx - rx, cy - s * ry)
        cam.cubicTo(cx - rx, cy + s * ry * 1.7, cx + rx, cy + s * ry * 1.7, cx + rx, cy - s * ry)
        p.drawPath(cam)

    def banda(y, curva):  # arcada vista de frente
        cam = QtGui.QPainterPath()
        cam.moveTo(8, y)
        cam.quadTo(28, y + curva, 48, y)
        p.drawPath(cam)

    if vista == "frente":
        banda(20, 6)
        banda(36, 6)
    elif vista == "atras":
        banda(22, -6)
        banda(38, -6)
    elif vista in ("derecha", "izquierda"):
        if vista == "izquierda":
            p.translate(n, 0)
            p.scale(-1, 1)
        for y in (20, 36):
            cam = QtGui.QPainterPath()
            cam.moveTo(10, y + 4)
            cam.quadTo(14, y - 3, 30, y - 1)
            cam.lineTo(48, y)
            p.drawPath(cam)
    elif vista == "separadas":
        p.setPen(QtGui.QPen(c, 5, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        u(15, 28, 9, 9, abajo=False)
        u(41, 28, 9, 9, abajo=True)
    elif vista == "oclusal_sup":
        u(28, 30, 17, 12, abajo=False)
    elif vista == "oclusal_inf":
        u(28, 26, 17, 12, abajo=True)
    p.end()
    return pm


class AnalisisModelos(QtWidgets.QWidget):
    volver = QtCore.Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.caso = None          # {"info", "modelos", "informe", "datos"}
        self.ruta_caso = None     # el .3dol en la biblioteca (para guardar las correcciones del doctor)
        self.id_caso = None
        self.marco = None
        self._actores = {}
        self._mallas = {}
        self._v0 = {}
        self._plotter = None
        self._pdf_buf = None
        self.vis = {"sup": True, "inf": True}     # arcadas visibles
        self.opac = {"sup": 1.0, "inf": 1.0}      # transparencia de cada arcada
        self.modo = 0             # 0 Modelos · 1 Análisis · 2 Informe
        # análisis
        self.an = None            # analisis.Caso cuando termina el cálculo
        self._an_roles = None     # {"sup": rol, "inf": rol} de las mallas analizadas
        self._an_act = {}
        self._an_malla = {}
        self._an_base = {}        # color de cada vértice sin resaltar
        self._trazos = []
        self._asas = []           # puntos que se arrastran con el mouse
        self._arrastre = None
        # recuadro con solo los dientes de la relación (clase molar / canina), para acomodar sus puntos
        self._rel = {}            # lo dibujado por lado: dientes, rectas, puntos y asas
        self._mini = None         # su visor 3D (se crea la primera vez)
        self._mini_lado = "der"
        self._mini_clave = None
        self._mini_actores = []
        self._mini_act = {"sup": [], "inf": []}
        self._mini_asas = []
        self._mini_arrastre = None
        self._mini_visible = False
        self._regla = []          # puntos y actores de «Medir»
        self.disp = "junto"       # junto · separadas
        self._acomodo = {"sup": np.eye(4), "inf": np.eye(4)}  # cómo acomodó el doctor cada arcada (vista separada)
        self._acom = None         # arcada que se está acomodando sola (doble clic sobre ella)
        self._acom_pos = None
        self._pose_cache = {}
        self._dientes_fijos = False   # el doctor retocó a mano el área de los dientes (se guarda con el modelo)
        self._md_edit = None          # punto mesial/distal en edición (doble clic sobre él): (arcada, diente, extremo)
        self._corte_contactos = False  # «Contactos» con el corte puesto
        self._md_arrastra = False
        QtGui.QShortcut(QtGui.QKeySequence(Qt.Key_Escape), self, activated=lambda: self._md_terminar())
        self._trazo = None            # «Modificar área»: trazo del pincel en curso
        self._arboles = {}
        self._clic = None         # None · "medir" · "punto"
        self._press = None
        self._mov = None
        self._gen = 0             # para descartar análisis de un caso que ya se cerró
        self._hilo = None
        self._hover = None        # (arcada, FDI) resaltado
        self._hover_act = None
        self._corte_activo = False
        self._corte_plano = "diente"   # diente (a través del diente, perpendicular a la arcada) · sagital · transversal
        self._corte_valor = None
        self._corte_act = []
        self._corte_mallas = {}
        self._corte_ultimo = None
        self._armar()
        self._cargar_biblioteca()

    # ------------------------------------------------------------------ interfaz
    def _armar(self):
        v = QtWidgets.QVBoxLayout(self)
        v.setContentsMargins(18, 12, 18, 10)
        top = QtWidgets.QHBoxLayout()
        self.setStyleSheet(self.styleSheet() + ESTILO_BARRA)
        top.setSpacing(8)
        b = QtWidgets.QPushButton("‹  Inicio")
        b.setObjectName("b_volver")
        b.setCursor(Qt.PointingHandCursor)
        b.clicked.connect(self.volver.emit)
        top.addWidget(b)
        t = QtWidgets.QLabel("Análisis de modelos")
        t.setStyleSheet("font-size:14pt;font-weight:600;")
        top.addSpacing(4)
        top.addWidget(t)
        sub = QtWidgets.QLabel("3D OrthoLab")
        sub.setStyleSheet("color:#8792a0;font-size:9.5pt;")
        top.addWidget(sub, 0, Qt.AlignVCenter)
        top.addStretch(1)
        b_abrir = QtWidgets.QPushButton("Abrir paquete")
        b_abrir.setObjectName("b_sec")
        b_abrir.setCursor(Qt.PointingHandCursor)
        b_abrir.clicked.connect(self.abrir_dialogo)
        top.addWidget(b_abrir)
        if puede_enviar():
            b_prev = QtWidgets.QPushButton("Abrir carpeta")
            b_prev.setObjectName("b_sec")
            b_prev.setCursor(Qt.PointingHandCursor)
            b_prev.setToolTip("Vista previa: ver un caso directo de su carpeta (solo en tu computadora)")
            b_prev.clicked.connect(self.vista_previa)
            top.addWidget(b_prev)
            b_env = QtWidgets.QPushButton("Enviar al doctor")
            b_env.setObjectName("b_principal")
            b_env.setCursor(Qt.PointingHandCursor)
            b_env.clicked.connect(self.enviar)
            top.addWidget(b_env)
        v.addLayout(top)

        cuerpo = QtWidgets.QHBoxLayout()
        # izquierda: código del equipo y biblioteca
        self.izq = izq = QtWidgets.QFrame()
        izq.setFixedWidth(300)
        izq.setStyleSheet("QFrame#izq{background:#1b1f25;border-radius:12px;}")
        izq.setObjectName("izq")
        iv = QtWidgets.QVBoxLayout(izq)
        iv.setContentsMargins(14, 12, 14, 12)
        h = QtWidgets.QLabel("Código de este equipo")
        h.setStyleSheet("font-weight:700;")
        iv.addWidget(h)
        iv.addWidget(_muted("Mándaselo a 3D OrthoLab una sola vez: tus casos llegarán hechos para esta computadora."))
        self.e_codigo = QtWidgets.QLineEdit()
        self.e_codigo.setReadOnly(True)
        self.e_codigo.setStyleSheet("font-family:Consolas;font-size:9pt;")
        try:
            self.e_codigo.setText(PQ.codigo_equipo())
        except Exception as exc:  # noqa: BLE001
            self.e_codigo.setText(f"(no disponible: {exc})")
            try:  # que quede el detalle en el registro de la app, para poder arreglarlo
                import sys
                import traceback

                from ..ortholab import reparar

                reparar.anotar("Análisis de modelos: no se pudo generar el código de equipo",
                               traceback.format_exc() + "\nejecutable: " + sys.executable + "\nsys.path:\n  "
                               + "\n  ".join(sys.path))
            except Exception:  # noqa: BLE001
                pass
            self.e_codigo.setToolTip("A esta instalación le falta un componente. Reinstala 3D OrthoLab Studio con su "
                                     "instalador más reciente." if isinstance(exc, ImportError) else str(exc))
        iv.addWidget(self.e_codigo)
        b_cp = QtWidgets.QPushButton("Copiar código")
        b_cp.clicked.connect(lambda: (QtGui.QGuiApplication.clipboard().setText(self.e_codigo.text()),
                                      b_cp.setText("Copiado ✓")))
        iv.addWidget(b_cp)
        iv.addSpacing(12)
        h = QtWidgets.QLabel("Mis casos")
        h.setStyleSheet("font-weight:700;")
        iv.addWidget(h)
        self.lista = QtWidgets.QListWidget()
        self.lista.setStyleSheet("QListWidget{background:#11161c;border:none;border-radius:8px;}"
                                 "QListWidget::item{padding:8px;border-bottom:1px solid #222a33;}")
        self.lista.itemClicked.connect(lambda it: self.abrir_archivo(it.data(Qt.UserRole)))
        iv.addWidget(self.lista, 1)
        iv.addWidget(_muted("Arrastra aquí el archivo .3dol que te mandó 3D OrthoLab."))
        cuerpo.addWidget(izq)

        # derecha: título, pestañas, visor / informe
        der = QtWidgets.QVBoxLayout()
        fila = QtWidgets.QHBoxLayout()
        self.titulo = QtWidgets.QLabel("Abre un caso para verlo en 3D")
        self.titulo.setStyleSheet("font-size:14pt;font-weight:600;")
        fila.addWidget(self.titulo, 1)
        self.b_medir = QtWidgets.QPushButton("Medir")
        self.b_medir.setObjectName("b_sec")
        self.b_medir.setCursor(Qt.PointingHandCursor)
        self.b_medir.setCheckable(True)
        self.b_medir.setToolTip("Haz clic en dos puntos del modelo para medir la distancia en mm")
        self.b_medir.toggled.connect(lambda on: self.modo_clic("medir" if on else None))
        fila.addWidget(self.b_medir)
        fila.addSpacing(10)
        self.seg_modo = _segmentado(["Modelos", "Análisis", "Informe PDF"], self._elegir_modo, 0)
        fila.addWidget(self.seg_modo)
        self.b_inf_guardar = QtWidgets.QPushButton("Guardar PDF…")
        self.b_inf_guardar.setObjectName("b_sec")
        self.b_inf_guardar.setCursor(Qt.PointingHandCursor)
        self.b_inf_guardar.setToolTip("Guarda el informe de 3D OrthoLab Studio de este caso")
        self.b_inf_guardar.clicked.connect(self._guardar_informe)
        self.b_inf_guardar.setVisible(False)
        # el informe con el modelo zocalado (marfil) o con el escaneo a color (PLY), como el de MetronTrack
        self.cmb_inf_modelo = QtWidgets.QComboBox()
        self.cmb_inf_modelo.addItem("Con zócalo", True)
        self.cmb_inf_modelo.addItem("A color (PLY)", False)
        self.cmb_inf_modelo.setToolTip("Con qué modelo se hacen las vistas y las medidas del informe")
        self.cmb_inf_modelo.setVisible(False)
        self.cmb_inf_modelo.activated.connect(self._inf_modelo_cambiado)
        self._inf_pendiente = False
        fila.addSpacing(6)
        fila.addWidget(self.cmb_inf_modelo)
        fila.addWidget(self.b_inf_guardar)
        der.addLayout(fila)
        self.pila = QtWidgets.QStackedWidget()
        w3d = QtWidgets.QWidget()
        v3 = QtWidgets.QVBoxLayout(w3d)
        v3.setContentsMargins(0, 6, 0, 0)
        zona = QtWidgets.QHBoxLayout()
        zona.setSpacing(0)  # la barra de análisis va pegada al visor
        self.caja3d = QtWidgets.QVBoxLayout()
        self.vacio = QtWidgets.QLabel("Aquí verás los modelos del escaneo\n\nArrastra aquí el paquete .3dol"
                                      + ("\no la carpeta del escaneo (o sus STL / PLY)" if puede_enviar() else ""))
        self.vacio.setAlignment(Qt.AlignCenter)
        self.vacio.setStyleSheet("color:#8b949e;font-size:13pt;border:2px dashed #3a414b;border-radius:14px;")
        self.caja3d.addWidget(self.vacio, 1)
        zona.addLayout(self.caja3d, 1)
        self.panel = PanelAnalisis(self)
        self.panel.setVisible(False)
        zona.addWidget(self.panel)
        v3.addLayout(zona, 1)
        pie = QtWidgets.QHBoxLayout()
        self.l_aviso = QtWidgets.QLabel("")
        self.l_aviso.setStyleSheet("color:#e3b341;font-size:9pt;")
        pie.addWidget(self.l_aviso, 1)
        marca = QtWidgets.QLabel("Escaneado por 3D OrthoLab · Dra. Miriam Lastra")
        marca.setStyleSheet(f"color:{TURQ};font-size:9pt;")
        pie.addWidget(marca)
        v3.addLayout(pie)
        self.pila.addWidget(w3d)
        try:  # el visor de PDF de Qt (las apps instaladas antes de este módulo pueden no traerlo)
            from PySide6.QtPdf import QPdfDocument
            from PySide6.QtPdfWidgets import QPdfView

            self.pdf = QPdfDocument(self)
            self.pdf_view = QPdfView()
            self.pdf_view.setDocument(self.pdf)
            self.pdf_view.setPageMode(QPdfView.PageMode.MultiPage)
            self.pdf_view.setZoomMode(QPdfView.ZoomMode.FitToWidth)
            self.pila.addWidget(self.pdf_view)
        except ImportError:
            self.pdf = None
            aviso = QtWidgets.QLabel("Para ver aquí el informe, actualiza 3D OrthoLab Studio con su instalador más reciente.")
            aviso.setAlignment(Qt.AlignCenter)
            aviso.setWordWrap(True)
            aviso.setStyleSheet("color:#8b949e;font-size:12pt;")
            self.pila.addWidget(aviso)
        der.addWidget(self.pila, 1)
        cuerpo.addLayout(der, 1)
        v.addLayout(cuerpo, 1)
        self._armar_flotantes(w3d)
        self._ajustar_controles()

    def _armar_flotantes(self, padre):
        """Panel «Modelos» y barra de vistas, flotando sobre el visor (se colocan en _colocar_flotantes)."""
        self.capas = c = QtWidgets.QFrame(padre)
        c.setObjectName("flot")
        c.setStyleSheet(_estilo_flotante())
        c.setAttribute(Qt.WA_NativeWindow)  # ventana propia: el 3D no la tapa
        cv = QtWidgets.QVBoxLayout(c)
        cv.setContentsMargins(12, 10, 12, 10)
        cv.setSpacing(6)
        cab = QtWidgets.QHBoxLayout()
        t = QtWidgets.QLabel("Modelos")
        t.setStyleSheet("font-weight:700;font-size:10pt;")
        cab.addWidget(t, 1)
        self.b_plegar = QtWidgets.QToolButton()
        self.b_plegar.setText("▴")
        self.b_plegar.clicked.connect(self._plegar_capas)
        cab.addWidget(self.b_plegar)
        cv.addLayout(cab)
        self.capas_cuerpo = cuerpo = QtWidgets.QWidget()
        cuerpo.setStyleSheet("background:transparent;")
        g = QtWidgets.QGridLayout(cuerpo)
        g.setContentsMargins(0, 0, 0, 0)
        g.setVerticalSpacing(6)
        self.cb_arc, self.sl_arc = {}, {}
        for i, (jaw, nombre) in enumerate((("sup", "Superior"), ("inf", "Inferior"))):
            cb = QtWidgets.QCheckBox(nombre)
            cb.setObjectName("ojo")
            cb.setCursor(Qt.PointingHandCursor)
            cb.setToolTip(f"Mostrar u ocultar la arcada {nombre.lower()}")
            cb.setChecked(True)
            cb.toggled.connect(lambda on, jaw=jaw: self._capa_cambiada(jaw, on))
            sl = QtWidgets.QSlider(Qt.Horizontal)
            sl.setRange(10, 100)
            sl.setValue(100)
            sl.setFixedWidth(110)
            sl.setToolTip(f"Transparencia de la arcada {nombre.lower()}")
            sl.valueChanged.connect(lambda val, jaw=jaw: self._opacidad_cambiada(jaw, val))
            mini = QtWidgets.QLabel()
            mini.setPixmap(_icono_arcada(jaw))
            g.addWidget(cb, i, 0)
            g.addWidget(mini, i, 1)
            g.addWidget(sl, i, 2)
            self.cb_arc[jaw], self.sl_arc[jaw] = cb, sl
        self.cb_zocalo = QtWidgets.QCheckBox("Con zócalo")
        self.cb_zocalo.setToolTip("Modelo de estudio con zócalo, o el escaneo tal cual (a color)")
        self.cb_zocalo.toggled.connect(self._zocalo_cambiado)
        g.addWidget(self.cb_zocalo, 2, 0, 1, 2)
        self.cb_color = QtWidgets.QCheckBox("Color real")
        self.cb_color.setChecked(True)
        self.cb_color.toggled.connect(self._color_cambiado)
        g.addWidget(self.cb_color, 2, 2)
        self.l_ap = QtWidgets.QLabel("Abrir la boca")
        g.addWidget(self.l_ap, 3, 0, 1, 2)
        self.sl_ap = QtWidgets.QSlider(Qt.Horizontal)
        self.sl_ap.setRange(0, 30)
        self.sl_ap.setFixedWidth(110)
        self.sl_ap.setToolTip("Abre la boca girando la arcada inferior en bisagra")
        self.sl_ap.valueChanged.connect(lambda _: self._aplicar_apertura())
        g.addWidget(self.sl_ap, 3, 2)
        cv.addWidget(cuerpo)
        c.hide()

        self.barra_vistas = bvw = QtWidgets.QFrame(padre)
        bvw.setObjectName("flot")
        bvw.setStyleSheet(_estilo_flotante() + "QFrame#flot{border-radius:24px;}")
        bvw.setAttribute(Qt.WA_NativeWindow)
        bh = QtWidgets.QHBoxLayout(bvw)
        bh.setContentsMargins(14, 5, 14, 5)
        bh.setSpacing(4)
        self.vistas = {}
        self.g_vistas = QtWidgets.QButtonGroup(bvw)
        for nombre, vista in (("Desde atrás (lingual)", "atras"), ("Oclusal superior", "oclusal_sup"),
                              ("Derecha del paciente", "derecha"), ("Frente", "frente"),
                              ("Izquierda del paciente", "izquierda"), ("Oclusal inferior", "oclusal_inf"),
                              ("Las dos arcadas por oclusal, lado a lado", "separadas")):
            b = QtWidgets.QToolButton()
            b.setIcon(_icono_vista(vista))
            b.setIconSize(QtCore.QSize(30, 30))
            b.setToolTip(nombre)
            b.setCursor(Qt.PointingHandCursor)
            b.setFixedSize(40, 38)
            b.setCheckable(True)
            self.g_vistas.addButton(b)
            b.clicked.connect(lambda _=False, vista=vista: self.camara(vista))
            bh.addWidget(b)
            self.vistas[vista] = b
        bvw.hide()

        # gráfica del corte de oclusión, a la izquierda del modelo (como «Visualización de la oclusión»)
        self.flot_corte = fc = QtWidgets.QFrame(padre)
        fc.setObjectName("flot")
        fc.setStyleSheet(_estilo_flotante())
        fc.setAttribute(Qt.WA_NativeWindow)
        fv = QtWidgets.QVBoxLayout(fc)
        fv.setContentsMargins(8, 6, 8, 8)
        fv.setSpacing(4)
        self.l_corte = QtWidgets.QLabel("Corte")
        self.l_corte.setStyleSheet("font-weight:700;font-size:10pt;")
        fv.addWidget(self.l_corte)
        barra = QtWidgets.QHBoxLayout()
        barra.setSpacing(2)
        self.b_corte = {}
        for clave, texto, ayuda in (("diente", "Por el diente", "Corta a través del diente (de vestibular a lingual)"),
                                    ("sagital", "Sagital", "Corte de adelante hacia atrás"),
                                    ("transversal", "Transversal", "Corte de lado a lado"),
                                    ("grande", "⤢", "Agrandar o achicar la gráfica")):
            b = QtWidgets.QToolButton()
            b.setText(texto)
            b.setToolTip(ayuda)
            b.setCursor(Qt.PointingHandCursor)
            if clave == "grande":
                b.clicked.connect(self._agrandar_corte)
                barra.addStretch(1)
            else:
                b.setCheckable(True)
                b.clicked.connect(lambda _=False, clave=clave: self.poner_corte(clave))
            barra.addWidget(b)
            self.b_corte[clave] = b
        fv.addLayout(barra)
        self.grafica = GraficaCorte()
        self.grafica.setMinimumHeight(0)
        self.grafica.setFixedSize(350, 290)
        fv.addWidget(self.grafica)
        fila = QtWidgets.QHBoxLayout()
        fila.addWidget(QtWidgets.QLabel("Mover"))
        self.sl_corte = QtWidgets.QSlider(Qt.Horizontal)
        self.sl_corte.setRange(0, 1000)
        self.sl_corte.setToolTip("Recorre el corte a lo largo de la arcada")
        self.sl_corte.valueChanged.connect(self._corte_barra)
        fila.addWidget(self.sl_corte, 1)
        fv.addLayout(fila)
        ayuda = QtWidgets.QLabel("Haz clic en un diente del modelo y el corte pasa por ahí.")
        ayuda.setWordWrap(True)
        ayuda.setStyleSheet("color:#5b6570;font-size:8pt;")
        fv.addWidget(ayuda)
        fc.hide()

        # leyenda de los colores de contacto, junto a los modelos (solo en «Contactos»)
        self.flot_ley = fl = QtWidgets.QFrame(padre)
        fl.setObjectName("flot")
        fl.setStyleSheet(_estilo_flotante())
        fl.setAttribute(Qt.WA_NativeWindow)
        lv = QtWidgets.QVBoxLayout(fl)
        lv.setContentsMargins(12, 9, 12, 10)
        lv.setSpacing(3)
        t = QtWidgets.QLabel("Distancia entre arcadas")
        t.setStyleSheet("font-weight:700;font-size:9.5pt;")
        lv.addWidget(t)
        for color, texto in zip(AN.CONTACTO_COLORES, ("menos de 0.1 mm · contacto firme", "0.1 – 0.3 mm · casi en contacto",
                                                      "0.3 – 0.6 mm", "0.6 – 1 mm", "1 – 2 mm")):
            fila = QtWidgets.QLabel(f'<span style="color:{color};font-size:13pt;">■</span>&nbsp; {texto}')
            fila.setTextFormat(Qt.RichText)
            fila.setStyleSheet("font-size:9pt;")
            lv.addWidget(fila)
        nota = QtWidgets.QLabel("Sin color: a más de 2 mm")
        nota.setStyleSheet("font-size:8pt;color:#6b7682;")
        lv.addWidget(nota)
        fl.hide()
        self._ley_visible = False

        # pantalla de espera (leer los modelos, identificar dientes, analizar): animada y con frases
        from .cargando import PantallaCarga

        self.carga = PantallaCarga(padre)

        # recuadro de referencia (Bolton y apiñamiento): el diente bajo el ratón, ampliado, con su ancho (como MetronTrack)
        self.flot_ref = fr = QtWidgets.QFrame(padre)
        fr.setObjectName("flot")
        fr.setStyleSheet(_estilo_flotante())
        fr.setAttribute(Qt.WA_NativeWindow)
        rv = QtWidgets.QVBoxLayout(fr)
        rv.setContentsMargins(10, 8, 10, 8)
        rv.setSpacing(4)
        self.l_ref_t = QtWidgets.QLabel("")
        self.l_ref_t.setStyleSheet("font-weight:700;font-size:10pt;")
        rv.addWidget(self.l_ref_t)
        self.l_ref_img = QtWidgets.QLabel()
        self.l_ref_img.setFixedSize(230, 172)
        rv.addWidget(self.l_ref_img)
        self.l_ref_w = QtWidgets.QLabel("")
        self.l_ref_w.setStyleSheet("font-size:9pt;")
        rv.addWidget(self.l_ref_w)
        fr.hide()
        self._ref_visible = False
        self._ref_pl = None

        # recuadro de la relación: solo los dientes, en gris, con sus puntos (como el de MetronTrack)
        self.flot_mini = fm = QtWidgets.QFrame(padre)
        fm.setObjectName("flot")
        fm.setStyleSheet(_estilo_flotante())
        fm.setAttribute(Qt.WA_NativeWindow)
        self.mini_caja = mv = QtWidgets.QVBoxLayout(fm)
        mv.setContentsMargins(8, 6, 8, 8)
        mv.setSpacing(4)
        cab = QtWidgets.QHBoxLayout()
        cab.setSpacing(2)
        t = QtWidgets.QLabel("Acomodar puntos")
        t.setStyleSheet("font-weight:700;font-size:10pt;")
        cab.addWidget(t)
        cab.addStretch(1)
        self.b_mini = {}
        for clave, texto, ayuda in (("der", "Derecha", "Lado derecho del paciente"),
                                    ("izq", "Izquierda", "Lado izquierdo del paciente"),
                                    ("auto", "⟲", "Regresar los puntos a lo automático"),
                                    ("grande", "⤢", "Agrandar o achicar el recuadro")):
            b = QtWidgets.QToolButton()
            b.setText(texto)
            b.setToolTip(ayuda)
            b.setCursor(Qt.PointingHandCursor)
            if clave in ("der", "izq"):
                b.setCheckable(True)
                b.clicked.connect(lambda _=False, lado=clave: self._mini_elegir(lado))
            elif clave == "auto":
                b.clicked.connect(lambda: self.panel._restablecer())
            else:
                b.clicked.connect(self._mini_agrandar)
            cab.addWidget(b)
            self.b_mini[clave] = b
        mv.addLayout(cab)
        self.mini_hueco = QtWidgets.QWidget()
        self.mini_hueco.setFixedSize(330, 250)
        hl = QtWidgets.QVBoxLayout(self.mini_hueco)
        hl.setContentsMargins(0, 0, 0, 0)
        mv.addWidget(self.mini_hueco)
        self.l_mini = QtWidgets.QLabel("")
        self.l_mini.setWordWrap(True)
        self.l_mini.setTextFormat(Qt.RichText)
        self.l_mini.setStyleSheet("font-size:9pt;")
        self.l_mini.setFixedWidth(330)
        mv.addWidget(self.l_mini)
        ayuda = QtWidgets.QLabel("Arrastra el punto coral o el violeta. Con la rueda acercas; arrastrando fuera de los "
                                 "puntos giras los dientes.")
        ayuda.setWordWrap(True)
        ayuda.setStyleSheet("color:#5b6570;font-size:8pt;")
        ayuda.setFixedWidth(330)
        mv.addWidget(ayuda)
        fm.hide()
        padre.installEventFilter(self)
        self._padre3d = padre

    @staticmethod
    def _raton_metron(pl):
        """El modelo se mueve como en MetronTrack: girar con el botón izquierdo o el derecho, desplazar con el
        central (o izquierdo + derecho a la vez, ver eventFilter) y acercar con la rueda."""
        try:
            pl.enable_custom_trackball_style(left="rotate", middle="pan", right="rotate")
        except Exception:  # noqa: BLE001  (versión de pyvista sin este estilo: queda el de siempre)
            pass

    def _dos_botones(self, obj, ev):
        """Izquierdo + derecho a la vez = desplazar el modelo (como MetronTrack). True si el evento era de eso."""
        pl = self._plotter if obj is self._plotter.interactor else self._mini
        try:
            estilo = pl.iren.interactor.GetInteractorStyle()
        except Exception:  # noqa: BLE001
            return False
        ambos = Qt.LeftButton | Qt.RightButton
        tipo = ev.type()
        if tipo == QtCore.QEvent.MouseButtonPress and (ev.buttons() & ambos) == ambos:
            estilo.EndRotate()
            estilo.StartPan()
            self._pan2 = obj
            self._press = None  # no es un clic
            return True
        if getattr(self, "_pan2", None) is obj and tipo == QtCore.QEvent.MouseButtonRelease:
            estilo.EndPan()
            if not (ev.buttons() & ambos):
                self._pan2 = None
            return True
        return False

    # ------------------------------------------------------------------ «Modificar área»: pincel sobre el modelo
    def _area_evento(self, obj, ev):
        """Con «Modificar área»: el botón izquierdo elige el diente y luego pinta (lápiz) o borra (goma) su área.
        True = el evento era del pincel (la cámara no gira; para girar, el botón derecho)."""
        from scipy.spatial import cKDTree

        tipo = ev.type()
        r = obj.devicePixelRatioF()
        pos = ev.position()
        x, y = int(pos.x() * r), int((obj.height() - pos.y() - 1) * r)
        sel = self.panel.md_sel
        if tipo == QtCore.QEvent.MouseButtonPress:
            if ev.button() != Qt.LeftButton:
                return False
            jaw, p, pid = self._picar(x, y, solo=sel[0] if sel else None)
            if jaw is None:
                return False  # fuera del modelo: gira la cámara
            self._press = None
            if sel is None:
                lab = self.an.dientes(jaw)
                fdi = int(lab[pid]) if lab is not None and pid >= 0 else 0
                if fdi:
                    QtCore.QTimer.singleShot(0, lambda: self.panel.area_elegir(jaw, fdi))
                else:
                    self.aviso("Ahí no hay un diente marcado. Para marcar uno nuevo usa «Añadir».")
                return True
            self.an._anotar_paso()
            self._trazo = jaw
            self._area_pintar(jaw, p, cKDTree)
            return True
        if self._trazo is None:
            return False
        if tipo == QtCore.QEvent.MouseMove:
            jaw, p, _ = self._picar(x, y, solo=self._trazo)
            if jaw is not None:
                self._area_pintar(jaw, p, cKDTree)
            return True
        if tipo == QtCore.QEvent.MouseButtonRelease and ev.button() == Qt.LeftButton:
            self._trazo = None
            QtCore.QTimer.singleShot(0, self.panel.area_trazo)
            return True
        return False

    def _area_pintar(self, jaw, p, cKDTree):
        V = self.an.U if jaw == "sup" else self.an.L
        if self._arboles.get(jaw, (None,))[0] is not V:
            self._arboles[jaw] = (V, cKDTree(V))
        q = (AN.inversa(self._D(jaw)) @ np.r_[p, 1.0])[:3]
        idx = np.asarray(self._arboles[jaw][1].query_ball_point(q, self.panel.md_radio), np.int64)
        if not len(idx):
            return
        fdi = self.panel.md_sel[1]
        lab = self.an.etiquetas[jaw]
        base = self._an_base.get(jaw)
        if self.panel.md_goma:
            idx = idx[lab[idx] == fdi]
            lab[idx] = 0
            color = COLOR_AREA_GRIS
        else:
            lab[idx] = fdi
            color = COLOR_AREA_DIENTE
        if base is not None and len(idx):
            base[idx] = color
            self._pintar(jaw, base)
            self._plotter.render()

    # ------------------------------------------------------------------ editar el punto mesial / distal con doble clic
    def _md_bajo(self, x, y, cerca=18.0):
        """¿El cursor (píxeles del visor) está sobre el punto mesial o distal del diente elegido? → «m», «d» o None."""
        jaw, t = self.panel.diente_sel
        md = ((self.panel.res or {}).get("md") or {}).get(t)
        if not md:
            return None
        ren = self._plotter.renderer
        mejor = (cerca * self._plotter.interactor.devicePixelRatioF(), None)
        for extremo in ("m", "d"):
            p = self._a_pantalla(jaw, self._p3(jaw, md[extremo][0], md[extremo][1], 0.7))[0]
            ren.SetWorldPoint(float(p[0]), float(p[1]), float(p[2]), 1.0)
            ren.WorldToDisplay()
            d = ren.GetDisplayPoint()
            dist = float(np.hypot(d[0] - x, d[1] - y))
            if dist < mejor[0]:
                mejor = (dist, extremo)
        return mejor[1]

    def _md_cerca(self, x, y, cerca=11.0):
        """¿El cursor está sobre el extremo (mesial o distal) de la línea de ALGÚN diente? → (arcada, diente,
        extremo) o None. Así cualquier punto se agarra directo, sin elegir antes el diente."""
        md = (self.panel.res or {}).get("md") or {}
        if not md or self._plotter is None:
            return None
        ren = self._plotter.renderer
        mejor = (cerca * self._plotter.interactor.devicePixelRatioF(), None)
        for t, v in md.items():
            jaw = "sup" if t[0] in "12" else "inf"
            if not self.vis.get(jaw, True):
                continue
            a, b = np.array(v["m"][:2], float), np.array(v["d"][:2], float)
            k0 = min(0.2, 0.95 / max(float(np.linalg.norm(b - a)), 1e-6))  # donde se dibuja el punto de cada extremo
            for extremo, q in (("m", a + (b - a) * k0), ("d", b + (a - b) * k0)):
                p = self._a_pantalla(jaw, self._p3(jaw, q[0], q[1], 0.7))[0]
                ren.SetWorldPoint(float(p[0]), float(p[1]), float(p[2]), 1.0)
                ren.WorldToDisplay()
                d = ren.GetDisplayPoint()
                dist = float(np.hypot(d[0] - x, d[1] - y))
                if dist < mejor[0]:
                    mejor = (dist, (jaw, t, extremo))
        return mejor[1]

    def _md_agarrar(self, obj, ev):
        """Bolton / apiñamiento: pasar sobre el punto de un extremo lo anuncia (mano abierta) y, con el botón
        izquierdo, se agarra y se arrastra de una vez. True = el evento era de esto."""
        tipo = ev.type()
        r = obj.devicePixelRatioF()
        pos = ev.position()
        x, y = int(pos.x() * r), int((obj.height() - pos.y() - 1) * r)
        if tipo == QtCore.QEvent.MouseMove and not ev.buttons():
            cual = self._md_cerca(x, y)
            if cual:
                obj.setCursor(Qt.OpenHandCursor)
                self._md_mano = True
                self.l_aviso.setText(f"Arrastra este punto para corregir la línea del diente {cual[1]} "
                                     f"({'mesial' if cual[2] == 'm' else 'distal'}).")
            elif getattr(self, "_md_mano", False):
                obj.setCursor(Qt.ArrowCursor)
                self._md_mano = False
            return False  # el resaltado del diente sigue funcionando
        if tipo == QtCore.QEvent.MouseButtonPress and ev.button() == Qt.LeftButton:
            cual = self._md_cerca(x, y)
            if not cual:
                return False
            self._clic_gen = getattr(self, "_clic_gen", 0) + 1
            self._press = None
            self.panel.diente_sel = (cual[0], cual[1])
            self._md_edit = cual
            self._md_arrastra = True
            obj.setCursor(Qt.ClosedHandCursor)
            return True
        return False

    def _md_evento(self, obj, ev):
        """Con un punto mesial/distal en edición: el botón izquierdo lo lleva sobre la superficie de su diente
        (arrastrando o con un clic); al soltar termina. True = el evento era de esto (la cámara no gira)."""
        tipo = ev.type()
        r = obj.devicePixelRatioF()
        pos = ev.position()
        x, y = int(pos.x() * r), int((obj.height() - pos.y() - 1) * r)
        if self.panel.actual not in ("espacio", "bolton") or self.panel.diente_sel != self._md_edit[:2]:
            self._md_terminar()  # se cambió de análisis o de diente
            return False
        jaw, t, extremo = self._md_edit
        if tipo == QtCore.QEvent.MouseButtonPress:
            if ev.button() != Qt.LeftButton:
                return False
            self._press = None
            self._md_arrastra = True
            self._md_llevar(jaw, t, extremo, x, y, False)
            return True
        if tipo == QtCore.QEvent.MouseMove:
            if self._md_arrastra and (ev.buttons() & Qt.LeftButton):
                self._md_llevar(jaw, t, extremo, x, y, False)
                return True
            return False
        if tipo == QtCore.QEvent.MouseButtonRelease and ev.button() == Qt.LeftButton and self._md_arrastra:
            self._md_llevar(jaw, t, extremo, x, y, True)
            self._md_terminar()
            return True
        return False

    def _md_llevar(self, jaw, t, extremo, x, y, final):
        j, p, pid = self._picar(x, y, solo=jaw)
        if j is None:
            if final:
                self.panel.mover_md(jaw, t, extremo, *self.an.P["md"][t][extremo], final=True) \
                    if t in (self.an.P.get("md") or {}) and extremo in self.an.P["md"][t] else self.panel.remedir()
            return
        lab = self.an.dientes(jaw)
        if lab is not None and pid >= 0:  # pegado a la malla de SU diente (o de su temporal)
            n = int(lab[pid])
            if str(n - 40 if n > 50 else n) != t:
                if final:
                    self.guardar_ediciones()
                    self.panel.remedir()
                return
        q = AN.inversa(self._D(jaw)) @ np.r_[p, 1.0]
        self.panel.mover_md(jaw, t, extremo, q[0], q[1], q[2], final=final)

    def md_tras_remedir(self):
        """El panel volvió a medir mientras se arrastra: el recuadro de referencia, con el ancho nuevo."""
        if self._md_edit:
            jaw, t, _ = self._md_edit
            lab = self.an.dientes(jaw)
            fdi = int(t) if lab is None or (lab == int(t)).any() else int(t) + 40
            self._ref_mostrar((jaw, fdi))

    def _md_terminar(self):
        if not self._md_edit:
            return
        self._md_edit = None
        self._md_arrastra = False
        if self._plotter is not None:
            self._plotter.interactor.setCursor(Qt.ArrowCursor)
        self.guardar_ediciones()
        self.aviso("Punto acomodado.", 2500)

    # ------------------------------------------------------------------ «Contactos»: cómo se ven las arcadas
    def contactos_ver(self, como):
        """«cerradas» (en oclusión, de frente), «abiertas» (la boca abierta: se ven las dos caras oclusales) u
        «oclusal» (las dos arcadas lado a lado, como siempre)."""
        if self.an is None or self._plotter is None:
            return
        if como == "oclusal":
            self.camara("separadas")
            return
        if como == "cerradas":
            self.camara("frente")
            return
        self._corte_contactos = False
        self._quitar_corte()
        self._acomodo = {"sup": np.eye(4), "inf": np.eye(4)}
        self._acom = None
        self.disp = "abiertas"
        self._poner_capas(True, True)
        self.panel.mostrar(self.panel.actual, mover_camara=False)
        self._mostrar_an(True, contacto=True)
        for b in self.vistas.values():  # ninguna de las vistas rápidas es esta
            b.setAutoExclusive(False)
            b.setChecked(False)
            b.setAutoExclusive(True)
        self._plotter.camera.parallel_projection = False
        self._plotter.camera_position = [(0, -300, 0), (0, 0, 0), (0, 0, 1)]
        self._plotter.reset_camera()
        self._plotter.camera.zoom(1.15)
        self._plotter.render()
        self.panel.contactos_marcar()

    def contactos_corte(self, si):
        """Pone o quita el corte dentro de «Contactos» (con las arcadas cerradas y su gráfica del perfil)."""
        if self.an is None or self._plotter is None:
            return
        self._corte_contactos = bool(si)
        if si:
            if self.disp != "junto":
                self.disp = "junto"
            self.panel.mostrar(self.panel.actual, mover_camara=False)
            self._camara_analisis("frente", redibujar=False)
            self.poner_corte()
            self._mostrar_an(True, contacto=True)
        else:
            self._quitar_corte()
            self.panel.mostrar(self.panel.actual, mover_camara=False)
        self._plotter.render()

    def quitar_dientes_fijos(self) -> bool:
        """Borra los retoques a mano guardados de este caso y lo vuelve a abrir como llegó."""
        if not self._dientes_fijos or self.an is None:
            return False
        mods = self.caso.get("modelos") or {}
        for rol in (self._an_roles or {}).values():
            PQ.borrar_dientes_locales(mods[rol][0])
        self._dientes_fijos = False
        self._quitar_analisis()
        self._analizar()
        return True

    def eventFilter(self, obj, ev):
        if obj is getattr(self, "_padre3d", None) and ev.type() in (QtCore.QEvent.Resize, QtCore.QEvent.Show):
            QtCore.QTimer.singleShot(0, self._colocar_flotantes)
        elif (self._md_edit and self._plotter is not None and obj is self._plotter.interactor and self.an is not None
              and ev.type() in (QtCore.QEvent.MouseButtonPress, QtCore.QEvent.MouseMove, QtCore.QEvent.MouseButtonRelease)
              and self._md_evento(obj, ev)):
            return True
        elif (not self._md_edit and self._plotter is not None and obj is self._plotter.interactor and self.modo == 1
              and self.an is not None and self.an.etiquetas and self._clic is None and self._acom is None
              and self.panel.actual in ("espacio", "bolton")
              and ev.type() in (QtCore.QEvent.MouseButtonPress, QtCore.QEvent.MouseMove)
              and self._md_agarrar(obj, ev)):
            return True
        elif (self._plotter is not None and obj is self._plotter.interactor and self.modo == 1 and self.an is not None
              and self.panel.actual == "dientes" and self.panel.md_modo == "area" and self.an.etiquetas
              and ev.type() in (QtCore.QEvent.MouseButtonPress, QtCore.QEvent.MouseMove, QtCore.QEvent.MouseButtonRelease)
              and self._area_evento(obj, ev)):
            return True
        elif (self._plotter is not None and obj is self._plotter.interactor
              and ev.type() in (QtCore.QEvent.MouseButtonDblClick, QtCore.QEvent.MouseButtonPress,
                                QtCore.QEvent.MouseMove, QtCore.QEvent.MouseButtonRelease)
              and (self._acom is not None or ev.type() == QtCore.QEvent.MouseButtonDblClick)
              and self._acomodar_evento(obj, ev)):
            return True
        elif (self._plotter is not None and ev.type() in (QtCore.QEvent.MouseButtonPress, QtCore.QEvent.MouseButtonRelease)
              and (obj is self._plotter.interactor or (self._mini is not None and obj is self._mini.interactor))
              and self._arrastre is None and self._dos_botones(obj, ev)):
            return True
        elif (self._mini is not None and obj is self._mini.interactor
              and ev.type() in (QtCore.QEvent.MouseButtonPress, QtCore.QEvent.MouseMove, QtCore.QEvent.MouseButtonRelease)):
            if self._mini_evento(obj, ev):
                return True
        elif (self._plotter is not None and obj is self._plotter.interactor and self._asas and self._clic is None
              and ev.type() in (QtCore.QEvent.MouseButtonPress, QtCore.QEvent.MouseMove, QtCore.QEvent.MouseButtonRelease)
              and self._arrastrar(obj, ev)):
            return True  # se está arrastrando un punto: la cámara no gira
        elif (self._plotter is not None and obj is self._plotter.interactor
              and ev.type() == QtCore.QEvent.MouseMove and not ev.buttons()):
            # el mouse pasa sobre el modelo (a nivel de Qt: no depende de los eventos de VTK)
            r = obj.devicePixelRatioF()
            pos = ev.position()
            self._mov = (int(pos.x() * r), int((obj.height() - pos.y() - 1) * r))
            if not self._t_hover.isActive():
                self._t_hover.start()
        elif (self._plotter is not None and obj is self._plotter.interactor and ev.button() == Qt.LeftButton
              if ev.type() in (QtCore.QEvent.MouseButtonPress, QtCore.QEvent.MouseButtonRelease) else False):
            # clics sobre el modelo, también a nivel de Qt (no se consumen: la cámara sigue girando)
            r = obj.devicePixelRatioF()
            pos = ev.position()
            x, y = int(pos.x() * r), int((obj.height() - pos.y() - 1) * r)
            if ev.type() == QtCore.QEvent.MouseButtonPress:
                self._press = (x, y)
            else:
                self._soltar(x, y)
        return super().eventFilter(obj, ev)

    def _arrastrar(self, obj, ev):
        """Arrastre de un punto (asa) sobre el diente. Devuelve True si el evento era del arrastre."""
        r = obj.devicePixelRatioF()
        pos = ev.position()
        x, y = int(pos.x() * r), int((obj.height() - pos.y() - 1) * r)
        tipo = ev.type()
        if tipo == QtCore.QEvent.MouseButtonPress:
            if ev.button() != Qt.LeftButton:
                return False
            asa = self._asa_bajo(x, y)
            if asa is None:
                return False
            self._arrastre = asa
            self._press = None
            obj.setCursor(Qt.ClosedHandCursor)
            return True
        if self._arrastre is None:
            if tipo == QtCore.QEvent.MouseMove and not ev.buttons():  # avisar que el punto se puede agarrar
                bajo = self._asa_bajo(x, y)
                obj.setCursor(Qt.OpenHandCursor if bajo is not None else Qt.ArrowCursor)
                self._decir_punto(obj, bajo)
            return False
        asa = self._arrastre
        if asa.get("solo_x"):  # la línea media sigue al cursor de lado, con su plano (sin depender del modelo)
            ren = self._plotter.renderer
            ren.SetWorldPoint(asa["pos"][0], asa["pos"][1], asa["pos"][2], 1.0)
            ren.WorldToDisplay()
            ren.SetDisplayPoint(float(x), float(y), ren.GetDisplayPoint()[2])
            ren.DisplayToWorld()
            wx, _wy, _wz, ww = ren.GetWorldPoint()
            self._mover_asa(asa, [wx / (ww or 1.0), 0.0, 0.0])
            self._plotter.render()
        else:
            jaw, p, _ = self._picar(x, y, solo=asa["jaw"])  # se desliza sobre su propia arcada
            if jaw == asa["jaw"] and p is not None:
                self._mover_asa(asa, p)
                self._plotter.render()
        if tipo == QtCore.QEvent.MouseButtonRelease:
            self._arrastre = None
            obj.setCursor(Qt.ArrowCursor)
            q = AN.inversa(self._D(asa["jaw"])) @ np.r_[asa["pos"], 1.0]
            punto = asa["punto"]

            def aplicar():
                self.panel.punto_activo = punto
                self.panel.mover_punto(punto[0], q[0], q[1], q[2])
                self.panel.punto_activo = None
            QtCore.QTimer.singleShot(0, aplicar)
        return True

    def _decir_punto(self, obj, asa):
        """Al pasar el mouse sobre un punto: su nombre anatómico (en un globo y en la línea de avisos)."""
        nombre = nombre_punto(asa["punto"][2]) if asa is not None and asa["punto"][1] == "aj" else ""
        if nombre != getattr(self, "_punto_dicho", ""):
            self._punto_dicho = nombre
            if nombre:
                QtWidgets.QToolTip.showText(QtGui.QCursor.pos(), nombre + ". Arrástralo para acomodarlo.", obj)
                self.l_aviso.setText(nombre)
            else:
                QtWidgets.QToolTip.hideText()
                self.l_aviso.setText("")

    # ------------------------------------------------------------------ pantalla de espera
    def cargando(self, estado=""):
        """Muestra (o actualiza) la pantalla de espera sobre el visor, con lo que se está haciendo."""
        self.carga.setGeometry(self._padre3d.rect())
        self.carga.empezar(estado)

    def cargando_fin(self):
        self.carga.terminar()

    def _esperar(self, tarea, estado):
        """Hace `tarea` (leer y preparar modelos: sin nada de Qt) en otro hilo, con la pantalla de espera animada
        mientras tanto. Devuelve su resultado o lanza su error, como si se hubiera llamado directo."""
        import threading

        self.cargando(estado)
        res = {}

        def correr():
            try:
                res["v"] = tarea()
            except BaseException as exc:  # noqa: BLE001  (se vuelve a lanzar en el hilo de la interfaz)
                res["e"] = exc

        hilo = threading.Thread(target=correr, daemon=True)
        self.setEnabled(False)  # mientras carga no se abre otro caso ni se cambia de pestaña
        hilo.start()
        lazo = QtCore.QEventLoop()
        t = QtCore.QTimer()
        t.timeout.connect(lambda: (not hilo.is_alive()) and lazo.quit())
        t.start(40)
        lazo.exec()
        t.stop()
        self.setEnabled(True)
        if "e" in res:
            self.cargando_fin()
            raise res["e"]
        return res["v"]

    def _colocar_flotantes(self):
        if self.carga.isVisible():
            self.carga.setGeometry(self._padre3d.rect())
            self.carga.raise_()
        if self._plotter is None:
            return
        g = self._plotter.interactor.geometry()
        org = self._plotter.interactor.mapTo(self._padre3d, QtCore.QPoint(0, 0))
        self.capas.adjustSize()
        self.capas.move(org.x() + 14, org.y() + 14)
        self.barra_vistas.adjustSize()
        libre = g.width() - (self.flot_mini.width() + 14 if self._mini_visible and self.modo == 1 else 0)
        self.barra_vistas.move(org.x() + max(8, (libre - self.barra_vistas.width()) // 2),
                               org.y() + g.height() - self.barra_vistas.height() - 14)  # sin tapar el recuadro
        self.flot_corte.adjustSize()
        self.flot_corte.move(org.x() + 14, min(self.capas.y() + self.capas.height() + 10,
                                               max(org.y() + 14, org.y() + g.height() - self.flot_corte.height() - 14)))
        hay = self.caso is not None and self.modo != 2
        self.flot_mini.adjustSize()
        self.flot_mini.move(org.x() + g.width() - self.flot_mini.width() - 14,
                            org.y() + g.height() - self.flot_mini.height() - 14)
        self.flot_ref.adjustSize()
        self.flot_ref.move(org.x() + g.width() - self.flot_ref.width() - 14, org.y() + 14)
        self.flot_ley.adjustSize()
        self.flot_ley.move(org.x() + g.width() - self.flot_ley.width() - 14, org.y() + 14)
        for w, radio, ver in ((self.capas, 12, hay), (self.barra_vistas, 24, hay),
                              (self.flot_corte, 12, hay and self._corte_activo),
                              (self.flot_ref, 12, hay and self.modo == 1 and self._ref_visible),
                              (self.flot_ley, 12, hay and self.modo == 1 and self._ley_visible),
                              (self.flot_mini, 12, hay and self.modo == 1 and self._mini_visible)):
            cam = QtGui.QPainterPath()  # esquinas redondas de verdad (son ventanas propias sobre el 3D)
            cam.addRoundedRect(QtCore.QRectF(w.rect()), radio, radio)
            w.setMask(QtGui.QRegion(cam.toFillPolygon().toPolygon()))
            w.setVisible(ver)
            w.raise_()
        if self.carga.isVisible():  # la pantalla de espera tapa todo lo demás
            self.carga.raise_()

    def _agrandar_corte(self):
        grande = self.grafica.width() < 400
        self.grafica.setFixedSize(*((560, 470) if grande else (350, 290)))
        self._colocar_flotantes()

    def _plegar_capas(self):
        ver = not self.capas_cuerpo.isVisible()
        self.capas_cuerpo.setVisible(ver)
        self.b_plegar.setText("▴" if ver else "▾")
        self._colocar_flotantes()

    def aviso(self, texto, ms=6000):
        self.l_aviso.setText(texto)
        QtCore.QTimer.singleShot(ms, lambda t=texto: self.l_aviso.text() == t and self.l_aviso.setText(""))

    # ------------------------------------------------------------------ pestañas
    # ------------------------------------------------------------------ informe propio (como el de MetronTrack)
    def _informe_al_dia(self):
        inf = getattr(self, "_inf", None)
        return bool(inf) and inf[0] is self.panel.res and os.path.isfile(inf[1])

    def _info_informe(self):
        info = dict((self.caso or {}).get("info") or {})
        ad = ((self.caso or {}).get("datos") or {}).get("accudesign") or {}
        pac = ad.get("paciente") or {}
        den = (self.panel.res or {}).get("denticion") or {}
        edad = pac.get("edad")
        return dict(paciente=info.get("paciente") or pac.get("nombre"),
                    edad=f"{edad} años" if edad and str(edad).strip().isdigit() else edad,
                    genero=pac.get("genero"), doctor=info.get("doctor") or pac.get("doctor"),
                    fecha_escaneo=info.get("fecha_escaneo") or pac.get("fecha"),
                    denticion="Mixta" if den.get("mixta") else "Permanente",
                    modelo="Con zócalo" if getattr(self, "_an_tipo", "z") == "z" else "Escaneo a color (PLY)")

    def _preparar_informe(self):
        """Arma el informe de 3D OrthoLab Studio de este caso: pasa por cada análisis, toma su vista (como las del
        informe de MetronTrack) y construye el PDF (informe.py). Lo muestra en «Informe PDF»."""
        if self.an is None or self.panel.res is None or self._plotter is None:
            self.aviso("El informe se arma con el análisis del caso: espera a que termine de analizarse.")
            return False
        if not self.an.etiquetas:
            # sin la separación de dientes el visor no muestra los análisis (medirían dientes equivocados): el
            # informe tampoco (Miriam vio números sin líneas en un caso así)
            self._informe_sin_dientes()
            return False
        import tempfile

        from PIL import Image

        try:
            from . import informe as INF
        except ImportError:  # apps instaladas antes de 3D OrthoLab Studio 1.5.1 no traen reportlab
            self.aviso("Para ver el informe, actualiza 3D OrthoLab Studio con su instalador más reciente.", 10000)
            return False

        res = self.panel.res
        carpeta = tempfile.mkdtemp(prefix="informe-3dol-")
        antes = (self.modo, self.panel.actual, dict(self.panel.sub))
        cap = {}

        def foto(nombre, vista=None):
            # sin perspectiva (Miriam: «que no se vean así de levantados, que se vean simétricos»): de lado puro,
            # de frente centrado y por oclusal, como un dibujo técnico; el encuadre se ajusta al modelo y sus trazos
            cam = self._plotter.camera
            if self.modo == 1 and vista in ("frente", "derecha", "izquierda", "atras"):
                self._nivelar_camara()  # el zócalo derecho, no el plano oclusal
            cam.parallel_projection = True
            self._plotter.reset_camera()
            cam.zoom(1.08)
            self._plotter.render()
            QtWidgets.QApplication.processEvents()
            crudo = self._plotter.screenshot(None, return_img=True)
            try:  # dónde hay modelo: el mapa de profundidad (no se confunde el zócalo marfil con el fondo claro)
                prof = self._plotter.get_image_depth(fill_value=np.nan)
                mascara = np.isfinite(prof) if prof.shape[:2] == crudo.shape[:2] else None
            except Exception:  # noqa: BLE001
                mascara = None
            img = INF.recortar(crudo, 22, mascara)
            ruta = os.path.join(carpeta, nombre + ".png")
            Image.fromarray(img).save(ruta)
            cap[nombre] = ruta

        self.cargando("Preparando el informe")
        try:
            self.pila.setCurrentIndex(0)
            self._elegir_modo(0)  # las vistas del modelo, a color, sin trazos
            for vista in ("oclusal_sup", "oclusal_inf", "izquierda", "derecha", "frente"):
                self.camara(vista)
                foto(vista)
            self._elegir_modo(1)
            pasos = [("espacio", {"espacio": "6-6"}, [("separadas", "espacio")]),
                     ("bolton", {"bolton": "arcada"}, [("separadas", "bolton")])]
            if res.get("mixta") and res.get("moyers"):
                pasos.append(("moyers", {}, [("separadas", "moyers")]))
            pasos += [("overjet", {}, [("frente", "overjet_frente"), ("izquierda", "overjet_izquierda"),
                                       ("derecha", "overjet_derecha")]),
                      ("molar", {}, [("derecha", "molar_derecha"), ("izquierda", "molar_izquierda")]),
                      ("canina", {}, [("derecha", "canina_derecha"), ("izquierda", "canina_izquierda")]),
                      ("lmedia", {}, [("frente", "lmedia")]),
                      ("contactos", {}, [("separadas", "contactos")]),
                      ("korkhaus", {}, [("separadas", "korkhaus")])]
            pasos += [("arcada", {"arcada": sub}, [("separadas", sub)]) for sub in ("ancho", "longitud", "simetria", "forma")]
            for clave, subs, vistas in pasos:
                try:
                    self.panel.sub.update(subs)
                    self.panel.mostrar(clave)
                    for vista, nombre in vistas:
                        self._camara_analisis(vista)
                        foto(nombre, vista)
                except Exception as exc:  # noqa: BLE001  (una vista que falla no detiene el informe)
                    print(f"Informe: no se pudo capturar {clave}: {exc}")
            try:
                self._foto_spee(res, foto)
            except Exception as exc:  # noqa: BLE001
                print(f"Informe: no se pudo dibujar la curva de Spee: {exc}")
            try:  # las gráficas del corte sagital de overjet y overbite (las mismas del panel)
                from .panel_analisis import CorteSagital

                for t, r in (res.get("overjet") or {}).items():
                    g = CorteSagital()
                    g.resize(620, 360)
                    g.poner(AN.corte(self.an, "sup", r["x"]), AN.corte(self.an, "inf", r["xl"]), r)
                    ruta_c = os.path.join(carpeta, f"corte_{t}.png")
                    g.grab().save(ruta_c)
                    cap[f"corte_{t}"] = ruta_c
            except Exception as exc:  # noqa: BLE001
                print(f"Informe: no se pudo dibujar el corte sagital: {exc}")
            ruta = os.path.join(carpeta, "informe.pdf")
            INF.construir(ruta, self._info_informe(), INF.bloques_visor(res, cap, getattr(self.an, "AD", None)))
        except Exception as exc:  # noqa: BLE001
            self.aviso(f"No se pudo armar el informe: {exc}", 10000)
            return False
        finally:
            self.panel.sub.update(antes[2])
            self.panel.actual = antes[1]
            self._mini_ocultar()
            self.cargando_fin()
        self._inf = (res, ruta)
        if self.pdf is not None:
            self.pdf.close()
            self.pdf.load(ruta)
        return True

    def _foto_spee(self, res, foto):
        """La curva de Spee en vista lateral de la arcada inferior (como MetronTrack): la recta del borde del
        incisivo a la cúspide distal del último molar (roja) y la línea que une las cúspides (azul)."""
        puntos = (res.get("spee") or {}).get("puntos") or {}
        for lado, vista in (("der", "derecha"), ("izq", "izquierda")):
            P = puntos.get(lado)
            if not P or len(P) < 3:
                continue
            P = np.array(P, float)
            P[:, 0] += -3.0 if lado == "der" else 3.0  # un poco hacia vestibular: que no las tape la corona
            P[:, 2] += 0.6
            self._limpiar_trazos()
            self._camara_analisis(vista, redibujar=False)
            self._poner_capas(False, True)  # solo la arcada inferior
            self._aplicar_capas()
            self._limpiar_trazos()
            self._linea("inf", [P[0].tolist(), P[-1].tolist()], ROJO, 3)
            self._linea("inf", P.tolist(), AZUL, 4)
            self._puntos("inf", P.tolist(), None, AZUL, 0.5)
            foto(f"spee_{lado}", vista)
        self._poner_capas(True, True)
        self._aplicar_capas()

    def _arriba_zocalo(self):
        """«Arriba» según la cara plana del zócalo (marco del análisis), o None si el modelo no tiene zócalo.
        El análisis nivela el plano oclusal; en los modelos zocalados eso deja el zócalo inclinado en la vista
        lateral, y para el informe se ve mejor derecho (como en «Modelos»)."""
        normales = []
        for V, arriba in ((self.an.U[::4], True), (self.an.L[::4], False)):
            z = V[:, 2]
            # el 1 % más extremo cae en la cara del zócalo aunque esté inclinada respecto al plano oclusal (en
            # Renata, 4–5°); con ese plano se vuelven a tomar TODOS los puntos de la cara y se reajusta
            sel = V[z > np.percentile(z, 99)] if arriba else V[z < np.percentile(z, 1)]
            if len(sel) < 100:
                continue
            for _ in range(3):
                c = sel.mean(0)
                _, s, vt = np.linalg.svd(sel - c, full_matrices=False)
                n = vt[2]
                cerca = V[np.abs((V - c) @ n) < 0.6]
                if len(cerca) < 100:
                    break
                sel = cerca
            c = sel.mean(0)
            _, s, vt = np.linalg.svd(sel - c, full_matrices=False)
            n = vt[2] if vt[2][2] > 0 else -vt[2]
            plano = s[2] / np.sqrt(len(sel)) < 0.35  # una cara plana de verdad (no paladar ni encía)
            if plano and n[2] > 0.94:
                normales.append(n)
        if not normales:
            return None
        n = np.mean(normales, axis=0)
        return n / np.linalg.norm(n)

    def _nivelar_camara(self):
        up = self._arriba_zocalo()
        if up is None:
            return
        cam = self._plotter.camera
        f = np.array(cam.focal_point, float)
        d = np.array(cam.position, float) - f
        dist = float(np.linalg.norm(d))
        d = d - (d @ up) * up  # se mira «horizontal» respecto al zócalo
        if np.linalg.norm(d) < 1e-6:
            return
        cam.position = tuple(f + d / np.linalg.norm(d) * dist)
        cam.up = tuple(up)

    def _informe_sin_dientes(self):
        caja = QtWidgets.QMessageBox(self)
        caja.setWindowTitle("Informe PDF")
        caja.setIcon(QtWidgets.QMessageBox.Information)
        caja.setText("<b>Primero hay que identificar los dientes.</b>")
        caja.setInformativeText("Este caso no trae la separación de dientes (cada diente con su número). Sin ella los "
                                "análisis medirían dientes equivocados, así que no se muestran en el visor ni van en "
                                "el informe.")
        ia = None
        if puede_enviar():
            from . import dientes_ia

            if dientes_ia.disponible():
                ia = caja.addButton("Identificar los dientes con IA", QtWidgets.QMessageBox.AcceptRole)
        caja.addButton("Cerrar", QtWidgets.QMessageBox.RejectRole)
        caja.exec()
        if ia is not None and caja.clickedButton() is ia:
            self.seg_modo.grupo.button(1).click()  # en «Análisis», donde se revisan los dientes que propone la IA
            self.identificar_ia()

    def _inf_modelo_cambiado(self, i):
        """Rehace el informe con el otro modelo: el zocalado y el escaneo a color no comparten coordenadas, así que
        primero se vuelve a analizar (unos segundos) y al terminar se arma el informe (_analisis_listo)."""
        con = bool(self.cmb_inf_modelo.itemData(i))
        if con == self.cb_zocalo.isChecked():
            return
        self._inf = None
        self._inf_pendiente = True
        self.pila.setCurrentIndex(0)  # se ve la espera del análisis
        if not con:
            self.cb_color.setChecked(True)
        self.cb_zocalo.setChecked(con)  # → _zocalo_cambiado → _analizar

    def _rehacer_informe(self):
        self._inf_pendiente = False
        if self.modo != 2:
            return
        if self._preparar_informe():
            self._elegir_modo(2)
        else:
            self.pila.setCurrentIndex(1)

    def _guardar_informe(self):
        if not self._informe_al_dia():
            return
        import re

        nombre = re.sub(r'[\\/:*?"<>|]', "", f"{self._info_informe().get('paciente') or 'Paciente'}"
                                             f" - Informe 3D OrthoLab Studio.pdf")
        ruta, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Guardar el informe",
                                                        os.path.join(os.path.expanduser("~"), "Documents", nombre),
                                                        "PDF (*.pdf)")
        if ruta:
            shutil.copyfile(self._inf[1], ruta)
            self.aviso(f"Informe guardado: {ruta}")

    def _elegir_modo(self, i):
        if i == 2 and not self._informe_al_dia():
            if not self._preparar_informe():  # sin análisis todavía: se queda donde estaba
                self.seg_modo.grupo.button(self.modo).setChecked(True)
                return
        self.b_inf_guardar.setVisible(i == 2)
        self.cmb_inf_modelo.setVisible(i == 2 and self.cb_zocalo.isEnabled())
        self.cmb_inf_modelo.setCurrentIndex(0 if self.cb_zocalo.isChecked() else 1)
        self.modo = i
        self.pila.setCurrentIndex(1 if i == 2 else 0)
        self.modo_clic(None)
        self._ajustar_controles()
        if i != 1:
            self._mini_ocultar()
        if i == 0:
            self._quitar_corte()
            self._limpiar_trazos()
            self._resaltar(None)
            self._mostrar_an(False)
            self.disp = "junto"
            self._mostrar_mallas()
            self.camara("frente")
        elif i == 1:
            self.sl_ap.setValue(0)
            if self.an is not None:
                self._mostrar_mallas()  # oculta los actores de «Modelos»
                self.panel.mostrar(self.panel.actual)
            elif self.caso is not None and self._hilo is None and self._an_roles is None:
                self.panel.esperando("Este caso no tiene los dos modelos (superior e inferior) para analizar.")
        QtCore.QTimer.singleShot(0, self._colocar_flotantes)

    def _vistas_disponibles(self):
        """Bloquea las vistas que no sirven en lo que se está viendo (como MetronTrack)."""
        if self.modo == 1 and self.an is not None:
            ok = VISTAS_DE.get(self.panel.vista)
            if not self.an.etiquetas and self.panel.vista != "corte":
                ok = _LATERALES + ("atras", "oclusal_sup", "oclusal_inf")
        else:
            ok = _LATERALES + ("atras", "oclusal_sup", "oclusal_inf")  # «Modelos»: todo menos «separadas»
        for vista, b in self.vistas.items():
            b.setEnabled(ok is None or vista in ok)

    def _marcar_vista(self, vista):
        b = self.vistas.get(vista)
        if b is not None:
            b.setChecked(True)

    def _ajustar_controles(self):
        an = self.modo == 1
        self.panel.setVisible(an)
        self.izq.setVisible(not an)  # más espacio para el modelo y la tarjeta
        self._vistas_disponibles()
        for w in (self.l_ap, self.sl_ap):
            w.setVisible(not an)
        self.b_medir.setVisible(self.modo != 2)

    # ------------------------------------------------------------------ biblioteca
    def _indice(self) -> dict:
        try:
            with open(os.path.join(BIBLIOTECA, "indice.json"), encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            return {}

    def _guardar_indice(self, d):
        os.makedirs(BIBLIOTECA, exist_ok=True)
        with open(os.path.join(BIBLIOTECA, "indice.json"), "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=1)

    def _cargar_biblioteca(self):
        self.lista.clear()
        idx = self._indice()
        if not os.path.isdir(BIBLIOTECA):
            return
        archivos = sorted((f for f in os.listdir(BIBLIOTECA) if f.lower().endswith(PQ.EXT)),
                          key=lambda f: -os.path.getmtime(os.path.join(BIBLIOTECA, f)))
        for f in archivos:
            info = idx.get(f, {})
            texto = info.get("paciente") or os.path.splitext(f)[0]
            extra = " · ".join(x for x in (info.get("fecha_escaneo"), info.get("doctor")) if x)
            it = QtWidgets.QListWidgetItem(texto + (f"\n{extra}" if extra else ""))
            it.setData(Qt.UserRole, os.path.join(BIBLIOTECA, f))
            self.lista.addItem(it)

    def _ruta_de(self, mime):
        """Lo que se puede soltar aquí: un paquete .3dol (cualquiera) o, solo en la PC de la Dra., la carpeta del
        escaneo o sus archivos STL/PLY (se abre la vista previa de su carpeta)."""
        rutas = [u.toLocalFile() for u in mime.urls()] if mime.hasUrls() else []
        for r in rutas:
            if r and r.lower().endswith(PQ.EXT) and os.path.isfile(r):
                return r
        if puede_enviar():
            for r in rutas:
                if r and os.path.isdir(r):
                    return r
            for r in rutas:
                if r and os.path.isfile(r) and r.lower().endswith((".stl", ".ply")):
                    return os.path.dirname(r)
        return None

    def dragEnterEvent(self, e):
        if self._ruta_de(e.mimeData()):
            e.acceptProposedAction()

    def dragMoveEvent(self, e):
        if self._ruta_de(e.mimeData()):
            e.acceptProposedAction()

    def dropEvent(self, e):
        r = self._ruta_de(e.mimeData())
        if r:
            e.acceptProposedAction()
            if os.path.isdir(r):  # carpeta del escaneo (solo la Dra.): vista previa
                QtCore.QTimer.singleShot(0, lambda: self._previa(r))
            else:
                self.importar(r)

    def abrir_dialogo(self):
        r, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Abrir paquete 3D OrthoLab", os.path.expanduser("~"),
                                                     "Paquete 3D OrthoLab (*.3dol)")
        if r:
            self.importar(r)

    def importar(self, ruta):
        """Abre el paquete (si es válido y para este equipo) y lo guarda en la biblioteca."""
        if not self.abrir_archivo(ruta):
            return
        os.makedirs(BIBLIOTECA, exist_ok=True)
        destino = os.path.join(BIBLIOTECA, os.path.basename(ruta))
        if os.path.abspath(destino) != os.path.abspath(ruta):
            shutil.copy2(ruta, destino)
        self.ruta_caso = destino
        idx = self._indice()
        info = dict(self.caso.get("info") or {})
        info["recibido"] = time.strftime("%Y-%m-%d")
        idx[os.path.basename(destino)] = info
        self._guardar_indice(idx)
        self._cargar_biblioteca()

    def abrir_archivo(self, ruta) -> bool:
        QtWidgets.QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            def leer():
                with open(ruta, "rb") as f:
                    datos = f.read()
                return PQ.abrir(datos), str(PQ.encabezado(datos).get("caso_id") or "")[:32]
            caso, id_caso = self._esperar(leer, "Abriendo el paquete")
        except PQ.ErrorPaquete as exc:
            QtWidgets.QApplication.restoreOverrideCursor()
            QtWidgets.QMessageBox.warning(self, "Análisis de modelos", str(exc))
            return False
        except Exception as exc:  # noqa: BLE001
            QtWidgets.QApplication.restoreOverrideCursor()
            QtWidgets.QMessageBox.warning(self, "Análisis de modelos", f"No se pudo abrir el paquete:\n{exc}")
            return False
        QtWidgets.QApplication.restoreOverrideCursor()
        self.ruta_caso = ruta if os.path.dirname(os.path.abspath(ruta)) == os.path.abspath(BIBLIOTECA) else None
        self.id_caso = "".join(ch for ch in id_caso if ch.isalnum()) or None
        self.cargando("Preparando los modelos")
        QtWidgets.QApplication.processEvents()
        self.mostrar_caso(caso)
        if getattr(self, "_hilo", None) is None:
            self.cargando_fin()
        return True

    # ------------------------------------------------------------------ visor
    def mostrar_caso(self, caso: dict):
        self.caso = caso
        info = caso.get("info") or {}
        partes = [info.get("paciente") or "Caso"]
        if info.get("fecha_escaneo"):
            partes.append(info["fecha_escaneo"])
        if info.get("doctor"):
            partes.append(info["doctor"])
        self.titulo.setText(" · ".join(partes))
        mods = caso.get("modelos") or {}
        tiene_sin = any(r.endswith("sin_zocalo") for r in mods)
        tiene_con = any(r.endswith("con_zocalo") for r in mods)
        self.cb_zocalo.setEnabled(tiene_sin and tiene_con)
        self.cb_zocalo.blockSignals(True)
        # si el caso trae el escaneo a color, abre con él (luce más); si solo trae los zocalados, con esos
        con_color = any(c is not None for r, (_, _, c) in mods.items() if r.endswith("sin_zocalo"))
        self.cb_zocalo.setChecked(tiene_con and not (tiene_sin and con_color))
        self.cb_zocalo.blockSignals(False)
        self.cb_color.setEnabled(any(c is not None for _, _, c in mods.values()))
        ref = {r: v for r, (v, _, _) in mods.items()}
        sup = ref.get("superior_sin_zocalo", ref.get("superior_con_zocalo"))
        inf = ref.get("inferior_sin_zocalo", ref.get("inferior_con_zocalo"))
        self.marco = O.marco(sup, inf)
        self._v0 = {r: v for r, (v, _, _) in mods.items()}
        self.sl_ap.blockSignals(True)
        self.sl_ap.setValue(0)
        self.sl_ap.blockSignals(False)
        self._preparar_plotter()
        self._quitar_analisis()
        self._poner_capas(True, True)
        for jaw in ("sup", "inf"):
            self.sl_arc[jaw].setValue(100)
        self._mostrar_mallas(nueva=True)
        self.disp = "junto"
        self.camara("frente")
        # «Informe PDF» = el informe PROPIO de 3D OrthoLab Studio, armado aquí con el análisis y las vistas de este
        # caso (Miriam, 2026-11-19). El PDF de MetronTrack que traían los paquetes viejos ya no se muestra.
        self._pdf_buf = None
        self._inf = None  # (resultado del análisis del que salió, ruta del PDF)
        if self.pdf is not None:
            self.pdf.close()
        self.seg_modo.grupo.button(2).setEnabled(self.pdf is not None)
        if self.modo == 2:
            self.seg_modo.grupo.button(0).click()
        self._analizar()
        QtCore.QTimer.singleShot(0, self._colocar_flotantes)

    def _preparar_plotter(self):
        if self._plotter is not None:
            return
        from pyvistaqt import QtInteractor

        self.vacio.hide()
        self._plotter = QtInteractor(self)
        self._plotter.set_background("#dfe5ea", top="#fbfcfd")  # claro, como MetronTrack
        self._plotter.enable_anti_aliasing("ssaa")
        self._plotter.interactor.setAcceptDrops(False)  # lo que se suelte sobre el 3D lo recibe esta página
        self.caja3d.addWidget(self._plotter.interactor, 1)
        # clics (sin arrastrar) para «Medir» y mover puntos; movimiento para resaltar el diente bajo el mouse
        self._t_hover = QtCore.QTimer(self)
        self._t_hover.setSingleShot(True)
        self._t_hover.setInterval(45)
        self._t_hover.timeout.connect(self._al_pasar)
        it = self._plotter.iren.interactor
        it.AddObserver("MouseMoveEvent", self._al_mover, 1.0)
        self._plotter.interactor.setMouseTracking(True)
        self._plotter.interactor.installEventFilter(self)
        self._raton_metron(self._plotter)

    # --- capas: qué arcada se ve y con cuánta transparencia
    def _poner_capas(self, sup, inf):
        for jaw, on in (("sup", sup), ("inf", inf)):
            self.vis[jaw] = on
            self.cb_arc[jaw].blockSignals(True)
            self.cb_arc[jaw].setChecked(on)
            self.cb_arc[jaw].blockSignals(False)

    def _capa_cambiada(self, jaw, on):
        self.vis[jaw] = on
        self._aplicar_capas()

    def _opacidad_cambiada(self, jaw, val):
        self.opac[jaw] = val / 100.0
        self._aplicar_capas()

    def _aplicar_capas(self):
        if self._plotter is None:
            return
        if self.modo == 1 and self.an is not None:
            for jaw, a in self._an_act.items():
                a.SetVisibility(self.vis[jaw])
                a.GetProperty().SetOpacity(self.opac[jaw])
            self._ver_trazos()
            if self._corte_activo and self._corte_ultimo:  # la gráfica del corte solo muestra las arcadas visibles
                self._corte_movido(*self._corte_ultimo)
            self._plotter.render()
        else:
            self._mostrar_mallas()

    def _zocalo_cambiado(self, _):
        self._mostrar_mallas()
        if self.caso is not None and self._plotter is not None:  # el análisis se hace sobre el modelo que se ve
            self._quitar_analisis()
            self._analizar()

    def _color_cambiado(self, _):
        if self.modo == 1 and self.an is not None:
            self._resaltar(None)
            self._mostrar_an(True, contacto=self.panel.actual == "contactos")
            self._plotter.render()
        else:
            self._mostrar_mallas()

    def _mostrar_mallas(self, nueva=False):
        import pyvista as pv

        if self._plotter is None or not self.caso:
            return
        mods = self.caso["modelos"]
        if nueva:
            for a in self._actores.values():
                self._plotter.remove_actor(a)
            self._actores, self._mallas = {}, {}
        con = self.cb_zocalo.isChecked()
        for rol, (v, f, col) in mods.items():
            arc = "superior" if rol.startswith("superior") else "inferior"
            jaw = "sup" if arc == "superior" else "inf"
            visible = (rol.endswith("con_zocalo") == con) and self.vis[jaw]
            if rol.endswith("con_zocalo") and f"{arc}_sin_zocalo" not in mods:
                visible = self.vis[jaw]
            if self.modo == 1 and self.an is not None:
                visible = False  # en «Análisis» se ven las mallas analizadas, en el marco del análisis
            usar_color = col is not None and self.cb_color.isChecked()
            clave = (rol, usar_color)
            if rol not in self._mallas:
                self._mallas[rol] = pv.PolyData(np.asarray(v, np.float32),
                                                np.hstack([np.full((len(f), 1), 3), f]).astype(np.int64))
                if col is not None:
                    self._mallas[rol]["rgb"] = np.asarray(col, np.uint8)
            if rol in self._actores and getattr(self._actores[rol], "_clave", None) != clave:
                self._plotter.remove_actor(self._actores.pop(rol))
            if rol not in self._actores:
                if usar_color:
                    a = self._plotter.add_mesh(self._mallas[rol], scalars="rgb", rgb=True, smooth_shading=True,
                                               specular=0.25, specular_power=20, reset_camera=False)
                else:
                    a = self._plotter.add_mesh(self._mallas[rol], color=COLOR_SUP if arc == "superior" else COLOR_INF,
                                               smooth_shading=True, specular=0.35, specular_power=25,
                                               reset_camera=False)
                a._clave = clave
                self._actores[rol] = a
            self._actores[rol].SetVisibility(visible)
            self._actores[rol].GetProperty().SetOpacity(self.opac[jaw])
        self._aplicar_apertura()

    def _aplicar_apertura(self):
        if not self._mallas or self.marco is None:
            return
        g = float(self.sl_ap.value())
        inf_ref = self._v0.get("inferior_sin_zocalo", self._v0.get("inferior_con_zocalo"))
        if inf_ref is None:
            return
        punto, eje = O.bisagra(self.marco, inf_ref)
        # sentido: que los incisivos inferiores bajen al abrir
        frente = inf_ref[np.argmax((inf_ref - self.marco["centro"]) @ self.marco["adel"])]
        prueba = O.rotar(frente[None], punto, eje, 5.0)[0]
        signo = -1.0 if np.dot(prueba - frente, self.marco["arriba"]) > 0 else 1.0
        for rol, malla in self._mallas.items():
            if rol.startswith("inferior"):
                malla.points = self._v0[rol] if g == 0 else O.rotar(self._v0[rol], punto, eje, signo * g)
        self._plotter.render()

    def camara(self, vista):
        if self._plotter is None:
            return
        if self.modo == 1 and self.an is not None:
            if self.panel.vista in ("molar", "canina") and vista in ("derecha", "izquierda")                     and ("der" if vista == "derecha" else "izq") in self._rel:
                self._mini_elegir("der" if vista == "derecha" else "izq")  # cambia de lado y se acerca
                return
            self._camara_analisis(vista)
            return
        if self.marco is None:
            return
        m = self.marco
        c = m["centro"]
        if vista == "separadas":
            vista = "oclusal_sup"
        self._marcar_vista(vista)
        d, up = {"frente": (m["adel"], m["arriba"]), "atras": (-m["adel"], m["arriba"]),
                 "derecha": (m["der"], m["arriba"]),
                 "izquierda": (-m["der"], m["arriba"]), "oclusal_sup": (-m["arriba"], m["adel"]),
                 "oclusal_inf": (m["arriba"], m["adel"])}[vista]
        # por oclusal se ve una sola arcada; en las demás vistas, las dos
        self._poner_capas(vista != "oclusal_inf", vista != "oclusal_sup")
        self._mostrar_mallas()
        self._plotter.camera.parallel_projection = False
        self._plotter.camera_position = [tuple(c + d * 200), tuple(c), tuple(up)]
        self._plotter.reset_camera()
        self._plotter.camera.zoom(1.15)
        self._plotter.render()

    # ------------------------------------------------------------------ análisis: cálculo
    def _quitar_analisis(self):
        self._gen += 1
        self._md_edit = None
        self.cargando_fin()  # si había un análisis a medias, su pantalla de espera se va con él
        self._mini_ocultar()
        self._mini_clave = None
        self._quitar_corte()
        self._resaltar(None)
        self.an = None
        self._an_roles = None
        self._limpiar_trazos()
        self._limpiar_regla()
        for a in self._an_act.values():
            self._plotter.remove_actor(a)
        self._an_act, self._an_malla, self._an_base = {}, {}, {}

    def _analizar(self):
        mods = self.caso.get("modelos") or {}
        roles = None
        orden = ("con_zocalo", "sin_zocalo") if self.cb_zocalo.isChecked() else ("sin_zocalo", "con_zocalo")
        for tipo in orden:  # el modelo que el doctor está viendo
            if f"superior_{tipo}" in mods and f"inferior_{tipo}" in mods:
                roles = {"sup": f"superior_{tipo}", "inf": f"inferior_{tipo}"}
                break
        if roles is None:
            self.panel.esperando("Este caso no tiene los dos modelos (superior e inferior) para analizar.")
            return
        self._an_roles = roles
        self._an_tipo = "z" if roles["sup"].endswith("con_zocalo") else "c"
        datos = self.caso.get("datos") or {}
        AD = datos.get("accudesign") or {}
        dientes = PQ.leer_dientes(datos, mods)
        etiquetas = {jaw: dientes.get(rol) for jaw, rol in roles.items()}
        self._dientes_locales = False
        self._dientes_fijos = False
        loc = {jaw: PQ.dientes_locales(mods[rol][0]) for jaw, rol in roles.items()}
        if all(e is not None for e in loc.values()):
            if all(PQ.dientes_locales_fijos(mods[rol][0]) for rol in roles.values()):
                # el doctor retocó a mano el área de los dientes de este modelo: su versión es la que vale
                etiquetas, self._dientes_locales, self._dientes_fijos = loc, True, True
            elif puede_enviar() and all(etiquetas[j] is None or np.array_equal(etiquetas[j], loc[j]) for j in loc):
                # la numeración que la Dra. identificó con IA y revisó en esta computadora (si no hay de MetronTrack)
                etiquetas, self._dientes_locales = loc, True
        sup = mods[roles["sup"]][:2]
        inf = mods[roles["inf"]][:2]
        self.panel.esperando("Analizando el caso… (unos segundos)")
        self.cargando("Analizando el caso")
        hilo = QtCore.QThread(self)
        trab = Trabajador(sup, inf, AD.get("anchos"), AD, self._gen, etiquetas)
        trab.moveToThread(hilo)
        hilo.started.connect(trab.correr)
        # métodos de este widget: Qt los llama en el hilo de la interfaz
        trab.progreso.connect(self._an_progreso)
        trab.listo.connect(self._analisis_listo)
        trab.fallo.connect(self._an_fallo)
        trab.listo.connect(hilo.quit)
        trab.fallo.connect(hilo.quit)
        hilo.finished.connect(trab.deleteLater)
        hilo.finished.connect(hilo.deleteLater)
        self._hilo = hilo
        self._trabajadores = getattr(self, "_trabajadores", [])[-3:] + [trab]  # que no los recoja el recolector
        hilo.start()

    def _an_progreso(self, texto, gen):
        if gen == self._gen:
            self.panel.esperando(texto)
            self.cargando(texto)

    def _an_fallo(self, texto, gen):
        if gen == self._gen:
            self._hilo = None
            self.cargando_fin()
            self.panel.esperando(texto)

    def _analisis_listo(self, caso, gen):
        if gen != self._gen:
            return
        self._hilo = None
        QtCore.QTimer.singleShot(0, self.cargando_fin)  # al terminar de pintar el primer análisis
        self.an = caso
        self._cargar_ediciones()
        # la dentición que la Dra. eligió al enviar el caso (si el doctor no la cambió después)
        den = (self.caso.get("info") or {}).get("denticion")
        if den in ("Mixta", "Permanente") and "denticion" not in caso.criterio:
            caso.criterio["denticion"] = den
        self.panel.poner_caso(caso)
        if getattr(self, "_inf_pendiente", False):  # se pidió el informe con el otro modelo (zócalo / PLY)
            QtCore.QTimer.singleShot(0, self._rehacer_informe)
        if self.modo == 1:
            self._mostrar_mallas()
        else:  # el panel dibujó su primer análisis: se guarda hasta que el doctor entre a «Análisis»
            self._quitar_corte()
            self._limpiar_trazos()
            self._mostrar_an(False)
            self._plotter.render()

    # ------------------------------------------------------------------ identificar los dientes con IA (la Dra.)
    def identificar_ia(self):
        from .panel_analisis import TrabajadorIA

        if self.an is None or getattr(self, "_hilo", None) is not None:
            return
        self.panel.esperando("Preparando la identificación de dientes…")
        self.cargando("Identificando los dientes con IA")
        hilo = QtCore.QThread(self)
        mods = (self.caso or {}).get("modelos") or {}
        sin_zocalo = None
        if (self._an_roles or {}).get("sup", "").endswith("con_zocalo") and \
                "superior_sin_zocalo" in mods and "inferior_sin_zocalo" in mods:
            sin_zocalo = (tuple(mods["superior_sin_zocalo"][:2]), tuple(mods["inferior_sin_zocalo"][:2]))
        trab = TrabajadorIA(self.an, self._gen, sin_zocalo)
        trab.moveToThread(hilo)
        hilo.started.connect(trab.correr)
        trab.progreso.connect(self._an_progreso)
        trab.listo.connect(self._ia_lista)
        trab.fallo.connect(self._ia_fallo)
        trab.listo.connect(hilo.quit)
        trab.fallo.connect(hilo.quit)
        hilo.finished.connect(trab.deleteLater)
        hilo.finished.connect(hilo.deleteLater)
        self._hilo = hilo
        self._trabajadores = getattr(self, "_trabajadores", [])[-3:] + [trab]
        hilo.start()

    def _ia_fallo(self, texto, gen):
        if gen != self._gen:
            return
        self._hilo = None
        self.cargando_fin()
        self.panel.poner_caso(self.an)
        QtWidgets.QMessageBox.warning(self, "Análisis de modelos", texto)

    def _ia_lista(self, etiquetas, gen):
        if gen != self._gen:
            return
        self._hilo = None
        if not any((e > 0).any() for e in etiquetas.values()):
            self._ia_fallo("La IA no encontró dientes en este escaneo.", gen)
            return
        QtCore.QTimer.singleShot(0, self.cargando_fin)
        self.an.etiquetas = {j: np.array(e, np.uint8) for j, e in etiquetas.items()}
        self.an._etiquetas0 = {j: e.copy() for j, e in self.an.etiquetas.items()}
        self.an.renombres = []
        self.an.reproponer()
        derecho = AN.realinear(self.an)  # con los dientes ya se puede enderezar un escaneo que quedó girado
        if derecho is not self.an:
            for a in self._an_act.values():
                self._plotter.remove_actor(a)
            self._an_act, self._an_malla, self._an_base = {}, {}, {}
            self._limpiar_trazos()
            self.an = derecho
        self._dientes_locales = True
        self.guardar_dientes()
        self.guardar_ediciones()
        self.panel.actual = "dientes"
        self.panel.poner_caso(self.an)
        if self.modo == 1:
            self._mostrar_mallas()

    def guardar_dientes(self, fijo=False):
        """La numeración identificada con IA (y lo que la Dra. le corrige) se guarda con el modelo, en esta PC:
        así sigue ahí al volver a abrir el caso y viaja en el paquete para el doctor. `fijo`: se retocó a mano el
        área de un diente («Modificar área»): desde ahí toda la separación de este modelo se guarda completa."""
        if fijo:
            self._dientes_fijos = self._dientes_locales = True
        if not getattr(self, "_dientes_locales", False) or self.an is None:
            return
        try:
            mods = self.caso.get("modelos") or {}
            for jaw, rol in self._an_roles.items():
                if jaw in self.an.etiquetas:
                    PQ.guardar_dientes_locales(mods[rol][0], self.an.etiquetas[jaw], fijo=self._dientes_fijos)
            self.an.renombres = []  # ya van dentro de la numeración guardada
        except Exception:  # noqa: BLE001
            pass

    # correcciones del doctor (puntos y anchos), guardadas cifradas con la protección de Windows
    def _ruta_ediciones(self):
        if not self.ruta_caso or not self.id_caso:
            return None
        return os.path.join(BIBLIOTECA, "analisis", f"{self.id_caso}-{getattr(self, '_an_tipo', 'z')}.bin")

    def guardar_ediciones(self):
        r = self._ruta_ediciones()
        if not r or self.an is None:
            return
        try:
            os.makedirs(os.path.dirname(r), exist_ok=True)
            d = json.dumps({"P": self.an.P, "anchos": self.an.anchos, "fuente": self.an.anchos_fuente,
                            "criterio": self.an.criterio, "renombres": self.an.renombres}).encode()
            with open(r, "wb") as f:
                f.write(PQ._dpapi(d, True))
        except Exception:  # noqa: BLE001  (si no se puede guardar, el análisis sigue funcionando)
            pass

    def _cargar_ediciones(self):
        r = self._ruta_ediciones()
        if not r or not os.path.exists(r):
            return
        try:
            with open(r, "rb") as f:
                d = json.loads(PQ._dpapi(f.read(), False))
            for cambio in d.get("renombres") or []:  # correcciones del doctor a la separación de dientes
                self.an.aplicar_cambio(cambio)
            self.an.renombres = [list(x) for x in d.get("renombres") or []]
            self.an.criterio = dict(d.get("criterio") or {})
            self.an.P = d["P"]
            self.an.P.setdefault("ajustes", {})
            self.an.P.setdefault("md", {})
            self.an.anchos = {k: float(v) for k, v in d["anchos"].items()}
            self.an.anchos_fuente = d.get("fuente", self.an.anchos_fuente)
        except Exception:  # noqa: BLE001
            pass

    # ------------------------------------------------------------------ análisis: dibujo
    def _pose(self, jaw):
        """(P, medio ancho): la arcada sola y derecha — su cara oclusal de frente, su línea media vertical y
        centrada en sus dientes — para la vista de las dos arcadas lado a lado. No cambia ninguna medida."""
        an = self.an
        lab = an.etiquetas.get(jaw)
        clave = (id(an), jaw, id(lab))
        if clave in self._pose_cache:
            return self._pose_cache[clave]
        V = (an.U if jaw == "sup" else an.L).astype(np.float64)
        R, c = np.eye(3), None
        tips = {}
        if lab is not None:
            for t in np.unique(lab):
                Vt = V[lab == t]
                if not t or len(Vt) < 150:
                    continue
                z = Vt[:, 2]
                mesa = Vt[z < z.min() + 2.0] if jaw == "sup" else Vt[z > z.max() - 2.0]
                n = int(t) - (40 if t > 50 else 0)
                tips[n] = mesa.mean(0)
        if len(tips) >= 4:
            Pt = np.array(list(tips.values()))
            if len(Pt) >= 5:
                _, sv, vt = np.linalg.svd(Pt - Pt.mean(0), full_matrices=False)
                n = vt[2] if vt[2][2] > 0 else -vt[2]
                if sv[1] > 12.0 and n[2] > 0.8:  # su propio plano oclusal, de frente
                    v = np.cross(n, [0, 0, 1.0])
                    vx = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
                    R = np.eye(3) + vx + vx @ vx / (1 + n[2])
            der, izq = (1, 2) if jaw == "sup" else (4, 3)
            pares = [(tips[der * 10 + k], tips[izq * 10 + k]) for k in range(1, 8)
                     if der * 10 + k in tips and izq * 10 + k in tips]
            if len(pares) >= 2:  # los dientes homólogos quedan a la misma altura: la arcada, derecha
                d = np.array([(R @ b - R @ a)[:2] for a, b in pares])
                d = d[np.linalg.norm(d, axis=1) > 4.0]
                if len(d) >= 2:
                    u = (d / np.linalg.norm(d, axis=1, keepdims=True)).mean(0)
                    g = np.arctan2(u[1], u[0])
                    if abs(g) < np.radians(45):
                        R = np.array([[np.cos(-g), -np.sin(-g), 0], [np.sin(-g), np.cos(-g), 0], [0, 0, 1.0]]) @ R
            Q = Pt @ R.T
            x0 = (float(np.mean([0.5 * (R @ a + R @ b)[0] for a, b in pares])) if pares
                  else 0.5 * float(Q[:, 0].min() + Q[:, 0].max()))
            c = np.array([x0, 0.5 * float(Q[:, 1].min() + Q[:, 1].max()), float(Q[:, 2].mean())])
        else:  # sin los dientes identificados: centrada en sus coronas
            corona = V[np.abs(V[:, 2]) < 8.0][::10]
            if len(corona) < 50:
                corona = V[::10]
            c = np.array([0.5 * float(corona[:, 0].min() + corona[:, 0].max()),
                          0.5 * float(corona[:, 1].min() + corona[:, 1].max()), 0.0])
        # en pantalla se centra el modelo entero (su contorno), no solo sus dientes: así las dos arcadas quedan a
        # la misma altura y a la misma distancia del centro aunque una traiga mucho paladar o aletas largas
        W = V[::15] @ R.T
        x0, x1 = np.percentile(W[:, 0], [0.5, 99.5])
        y0, y1 = np.percentile(W[:, 1], [0.5, 99.5])
        c = np.array([0.5 * (x0 + x1), 0.5 * (y0 + y1), c[2]])
        P = np.eye(4)
        P[:3, :3] = R
        P[:3, 3] = -c
        medio = 0.5 * float(x1 - x0)
        self._pose_cache = {k: v for k, v in self._pose_cache.items() if k[0] == id(an)}
        self._pose_cache[clave] = (P, medio)
        return P, medio

    def _D(self, jaw):
        """Transformación de presentación (marco del análisis → pantalla) de cada arcada."""
        if self.disp == "abiertas" and self.an is not None:
            # la boca abierta en bisagra por atrás: las dos caras oclusales quedan a la vista desde el frente
            yp = float(max(self.an.U[::20, 1].max(), self.an.L[::20, 1].max())) + 6.0
            a = np.radians(-24.0 if jaw == "sup" else 34.0)
            R = np.eye(4)
            R[1, 1], R[1, 2], R[2, 1], R[2, 2] = np.cos(a), -np.sin(a), np.sin(a), np.cos(a)
            return _traslacion(0.0, yp, 0.0) @ R @ _traslacion(0.0, -yp, 0.0)
        if self.disp != "separadas" or self.an is None:
            return np.eye(4)
        P, _ = self._pose(jaw)
        dx = max(self._pose("sup")[1], self._pose("inf")[1]) + 4.0
        base = _traslacion(-dx) @ ROT_X180 @ P if jaw == "sup" else _traslacion(dx) @ P
        return self._acomodo[jaw] @ base

    # ------------------------------------------------------------------ acomodar una arcada sola (doble clic)
    def _acomodar_evento(self, obj, ev):
        """En la vista de las dos arcadas: doble clic sobre una la deja «agarrada» y el ratón la mueve solo a
        ella (girar: izquierdo o derecho; mover: central o los dos botones). Doble clic fuera, terminar."""
        tipo = ev.type()
        r = obj.devicePixelRatioF()
        pos = ev.position()
        x, y = pos.x() * r, pos.y() * r
        if tipo == QtCore.QEvent.MouseButtonDblClick:
            if ev.button() != Qt.LeftButton or self.modo != 1 or self.an is None:
                return False
            if self.panel.actual in ("espacio", "bolton") and self.panel.diente_sel:
                cual = self._md_bajo(x, obj.height() * r - y - 1)
                if cual:  # doble clic sobre el punto mesial o distal del diente elegido: se edita arrastrando
                    self._clic_gen = getattr(self, "_clic_gen", 0) + 1
                    self._press = None
                    self._md_edit = (self.panel.diente_sel[0], self.panel.diente_sel[1], cual)
                    self._md_arrastra = False
                    obj.setCursor(Qt.CrossCursor)
                    self.aviso(f"Punto {'mesial' if cual == 'm' else 'distal'} del {self.panel.diente_sel[1]}: "
                               "arrástralo sobre el diente. Al soltar queda; Esc para terminar.", 15000)
                    return True
            if self.panel.actual == "dientes" and self.an.etiquetas:  # «Marcar diente»: doble clic = añadir diente
                self._clic_gen = getattr(self, "_clic_gen", 0) + 1
                self._press = None
                jaw, _p, pid = self._picar(int(x), int(obj.height() * r - y - 1))
                if jaw is not None and pid >= 0:
                    QtCore.QTimer.singleShot(0, lambda: self.panel.marcar_doble_clic(jaw, pid))
                return True
            self._clic_gen = getattr(self, "_clic_gen", 0) + 1  # el primer clic no era para elegir un diente
            jaw = self._picar(int(x), int(obj.height() * r - y - 1))[0]
            if jaw is not None and self.disp != "separadas":
                self.aviso("Para acomodar una arcada sola, usa la vista de las dos arcadas por oclusal "
                           "(último botón de vistas).")
                return True
            self._acom = jaw
            self._acom_pos = None
            self._press = None
            if jaw is None:
                self.aviso("Listo: las arcadas quedan como las acomodaste.", 3000)
            else:
                self.aviso(f"Acomodando la arcada {'superior' if jaw == 'sup' else 'inferior'}: arrástrala para "
                           "girarla; con el botón central (o los dos botones) la mueves. La otra no se mueve. "
                           "Doble clic fuera del modelo para terminar.", 20000)
            return True
        if self._acom is None or self.disp != "separadas" or self.an is None:
            self._acom = None
            return False
        jaw = self._acom
        if tipo == QtCore.QEvent.MouseButtonPress:
            self._acom_pos = (x, y)
            self._press = None
            for a in self._trazos:  # sus trazos se vuelven a dibujar al soltar
                if getattr(a, "_jaw", None) == jaw:
                    a.SetVisibility(False)
            self._resaltar(None)
            return True
        if tipo == QtCore.QEvent.MouseMove:
            if self._acom_pos is None or not ev.buttons():
                return bool(ev.buttons())
            dx, dy = x - self._acom_pos[0], y - self._acom_pos[1]
            self._acom_pos = (x, y)
            cam = self._plotter.camera
            p, f = np.array(cam.position), np.array(cam.focal_point)
            v = (f - p) / max(np.linalg.norm(f - p), 1e-9)
            der = np.cross(v, np.array(cam.up))
            der /= max(np.linalg.norm(der), 1e-9)
            arr = np.cross(der, v)
            b = ev.buttons()
            ambos = Qt.LeftButton | Qt.RightButton
            if (b & Qt.MiddleButton) or (b & ambos) == ambos:  # mover
                alto = (2.0 * cam.parallel_scale if cam.parallel_projection
                        else 2.0 * np.linalg.norm(f - p) * np.tan(np.radians(cam.view_angle) / 2))
                mm = alto / max(obj.height() * r, 1)
                M = _traslacion(*((der * dx - arr * dy) * mm))
            else:  # girar alrededor del centro de sus dientes
                def giro(eje, grados):
                    t = np.radians(grados)
                    K = np.array([[0, -eje[2], eje[1]], [eje[2], 0, -eje[0]], [-eje[1], eje[0], 0]])
                    return np.eye(3) + np.sin(t) * K + (1 - np.cos(t)) * K @ K
                Rm = np.eye(4)
                Rm[:3, :3] = giro(arr, dx * 0.35) @ giro(der, dy * 0.35)
                c = (self._D(jaw) @ AN.inversa(self._pose(jaw)[0]))[:3, 3]
                M = _traslacion(*c) @ Rm @ _traslacion(*(-c))
            self._acomodo[jaw] = M @ self._acomodo[jaw]
            if jaw in self._an_act:
                self._an_act[jaw].user_matrix = self._D(jaw)
            self._plotter.render()
            return True
        if tipo == QtCore.QEvent.MouseButtonRelease:
            if not ev.buttons():
                self._acom_pos = None
                self.panel.mostrar(self.panel.actual, mover_camara=False)  # los trazos, en su nuevo lugar
            return True
        return False

    def _a_pantalla(self, jaw, P):
        P = np.atleast_2d(np.asarray(P, np.float64))
        D = self._D(jaw)
        return P @ D[:3, :3].T + D[:3, 3]

    def _mostrar_an(self, si, contacto=False):
        """Las mallas analizadas (una por arcada), coloreadas por vértice: contactos, color real o marfil."""
        import pyvista as pv

        if self.an is None or self._plotter is None:
            return
        mods = self.caso["modelos"]
        for jaw in ("sup", "inf"):
            rol = self._an_roles[jaw]
            col = mods[rol][2]
            modo = "contacto" if contacto else ("color" if col is not None and self.cb_color.isChecked() else "liso")
            sel = self.panel.md_sel if self.panel.md_modo == "area" else None
            if modo != "contacto" and self.modo == 1 and self.panel.vista == "dientes" and sel:
                modo = f"area-{sel[0]}-{sel[1]}"  # «Modificar área»: modelo gris, el diente elegido en naranja
            elif modo != "contacto" and self.modo == 1 and self.panel.vista == "dientes":
                modo = "dientes-" + modo
            elif modo != "contacto" and self.modo == 1 and self.panel.vista in DIENTES_RELACION:
                modo = f"relacion-{self.panel.vista}-{modo}"
            V = self.an.U if jaw == "sup" else self.an.L
            if jaw not in self._an_act:
                if not si:
                    continue
                F = self.an.FU if jaw == "sup" else self.an.FL
                m = pv.PolyData(V, np.hstack([np.full((len(F), 1), 3), F]).astype(np.int64))
                m["rgb"] = np.zeros((len(V), 3), np.uint8)
                a = self._plotter.add_mesh(m, scalars="rgb", rgb=True, smooth_shading=True, specular=0.3,
                                           specular_power=22, reset_camera=False, pickable=True)
                a._modo = None
                self._an_act[jaw], self._an_malla[jaw] = a, m
            a = self._an_act[jaw]
            if a._modo != modo:
                if modo == "contacto":
                    C = self.an.contactos()[jaw]
                    base = AN.colores_contacto(C["d"], C["occl"])
                elif modo.endswith("color"):
                    base = np.asarray(col, np.uint8)
                else:
                    c = QtGui.QColor(COLOR_SUP if jaw == "sup" else COLOR_INF)
                    base = np.tile(np.array([c.red(), c.green(), c.blue()], np.uint8), (len(V), 1))
                lab = self.an.dientes(jaw)
                if modo.startswith("area"):
                    base = np.tile(np.array(COLOR_AREA_GRIS, np.uint8), (len(V), 1))
                    if lab is not None and sel[0] == jaw:
                        base[lab == sel[1]] = COLOR_AREA_DIENTE
                if modo.startswith("relacion") and lab is not None:  # los dientes de la relación, pintados
                    base = base.copy()
                    tinte = np.array((25, 149, 173))  # el turquesa de 3D OrthoLab
                    for t in DIENTES_RELACION[self.panel.vista][jaw]:
                        m = (lab == t) | (lab == t + 40)  # o su temporal
                        base[m] = (0.3 * base[m] + 0.7 * tinte).astype(np.uint8)
                if modo.startswith("dientes") and lab is not None:  # cada diente con su color
                    base = base.copy()
                    for t in np.unique(lab):
                        if t:
                            m = lab == t
                            base[m] = (0.22 * base[m] + 0.78 * np.array(COLOR_DIENTE.get(int(t) % 10, (150, 150, 160)))
                                       ).astype(np.uint8)
                self._an_base[jaw] = base
                self._pintar(jaw, base)
                a._modo = modo
            a.user_matrix = self._D(jaw)
            a.SetVisibility(si and self.vis[jaw])
            a.GetProperty().SetOpacity(self.opac[jaw])
        self._ver_trazos()

    def _pintar(self, jaw, rgb):
        m = self._an_malla[jaw]
        m.point_data["rgb"] = rgb
        m.Modified()

    def _anotar(self, actor, jaw):
        """Cada trazo (línea, punto, etiqueta) pertenece a una arcada: se oculta junto con ella."""
        actor._jaw = jaw
        actor.SetVisibility(self.vis.get(jaw, True))
        self._trazos.append(actor)

    def _ver_trazos(self):
        for a in self._trazos:
            jaw = getattr(a, "_jaw", None)
            if jaw in self.vis:
                a.SetVisibility(self.vis[jaw])
        if self._hover and not self.vis.get(self._hover[0], True):
            self._resaltar(None)

    def _limpiar_trazos(self):
        for a in self._trazos:
            self._plotter.remove_actor(a)
        self._trazos = []
        self._asas = []
        self._arrastre = None

    def _linea(self, jaw, pts, color, ancho=4):
        import pyvista as pv

        P = self._a_pantalla(jaw, pts)
        if len(P) < 2:
            return
        a = self._plotter.add_mesh(pv.lines_from_points(P), color=color, line_width=ancho, render_lines_as_tubes=True,
                                   reset_camera=False, pickable=False)
        self._anotar(a, jaw)
        return a

    def _curva_arcada(self, jaw, pts):
        """La curva de la arcada (apiñamiento, forma de arco): gris azulado oscuro con un filo claro, de grosor fijo en
        píxeles de pantalla (no adelgaza con el zoom) y dibujada por encima del modelo, para que se distinga del
        yeso y del escaneo a color sin colores estridentes."""
        import pyvista as pv

        P = self._a_pantalla(jaw, pts)
        if len(P) < 2:
            return
        linea = pv.lines_from_points(P)
        for color, ancho, cuanto in ((COLOR_ARCADA_FILO, 10.0, 1.0), (COLOR_ARCADA, 6.5, 1.4)):
            a = self._plotter.add_mesh(linea, color=color, line_width=ancho, render_lines_as_tubes=True,
                                       reset_camera=False, pickable=False, lighting=False)
            try:  # por encima de la malla aunque quede pegada a ella
                m = a.GetMapper()
                m.SetResolveCoincidentTopologyToPolygonOffset()
                m.SetRelativeCoincidentTopologyLineOffsetParameters(0.0, -66000.0 * cuanto)
            except Exception:  # noqa: BLE001
                pass
            self._anotar(a, jaw)

    def _punteada(self, jaw, pts, color, ancho=4, raya=1.1, hueco=0.8):
        """Línea punteada (como las de MetronTrack) a lo largo de la polilínea."""
        import pyvista as pv

        P = self._a_pantalla(jaw, pts)
        if len(P) < 2:
            return
        largo = np.r_[0, np.cumsum(np.linalg.norm(np.diff(P, axis=0), axis=1))]
        if largo[-1] < 0.2:
            return
        tramos = []
        t = 0.0
        while t < largo[-1]:
            fin = min(t + raya, largo[-1])
            for u in np.linspace(t, fin, 4)[:-1]:
                du = (fin - t) / 3
                tramos += [[np.interp(u, largo, P[:, k]) for k in range(3)],
                           [np.interp(u + du, largo, P[:, k]) for k in range(3)]]
            t = fin + hueco
        a = self._plotter.add_mesh(pv.line_segments_from_points(np.array(tramos)), color=color, line_width=ancho,
                                   render_lines_as_tubes=True, reset_camera=False, pickable=False)
        self._anotar(a, jaw)

    def _puntos(self, jaw, pts, etiquetas, color, tam=0.7):
        import pyvista as pv

        P = self._a_pantalla(jaw, pts)
        for p in P:
            a = self._plotter.add_mesh(pv.Sphere(radius=tam, center=p), color=color, reset_camera=False,
                                       pickable=False)
            self._anotar(a, jaw)
        if etiquetas:
            self._textos(P, etiquetas, color, jaw, ya_en_pantalla=True)

    def _plano(self, jaw, x, ys, zs, color, opacidad=0.45, frontal=False):
        """Plano vertical translúcido con su borde. Sagital en x (de y0 a y1 y de z0 a z1); con `frontal`, el plano
        es transversal: `x` es su posición en y, y `ys` su extensión en x."""
        import pyvista as pv

        if frontal:
            esquinas = np.array([[ys[0], x, zs[0]], [ys[1], x, zs[0]], [ys[1], x, zs[1]], [ys[0], x, zs[1]]], float)
        else:
            esquinas = np.array([[x, ys[0], zs[0]], [x, ys[1], zs[0]], [x, ys[1], zs[1]], [x, ys[0], zs[1]]], float)
        P = self._a_pantalla(jaw, esquinas)
        cuadro = pv.PolyData(P, np.array([4, 0, 1, 2, 3]))
        a = self._plotter.add_mesh(cuadro, color=color, opacity=opacidad, lighting=False, reset_camera=False,
                                   pickable=False)
        self._anotar(a, jaw)
        b = self._plotter.add_mesh(pv.lines_from_points(np.vstack([P, P[:1]])), color=color, line_width=2,
                                   reset_camera=False, pickable=False)
        self._anotar(b, jaw)
        return [a, b]

    @staticmethod
    def _mover_asa(asa, p):
        """Mueve el punto y, con él, lo que lleva pegado (su plano o su línea): no se desprenden."""
        p = np.array(p, float)
        if asa.get("solo_x"):  # línea media: solo se desliza de lado
            p = np.array([p[0], asa["pos0"][1], asa["pos0"][2]])
        asa["pos"] = p
        asa["actor"].SetPosition(*p)
        for a in asa.get("sigue") or []:
            a.SetPosition(*(p - asa["pos0"]))

    def _asa(self, jaw, punto, pos, color, tam=0.62, sigue=None, solo_x=False):
        """Punto que el doctor puede arrastrar con el mouse sobre el diente. `punto`: (arcada, dónde, nombre), como
        los de «Ajustar puntos»; `pos`: dónde está, en el marco del análisis."""
        import pyvista as pv

        P = self._a_pantalla(jaw, pos)[0]
        a = self._plotter.add_mesh(pv.Sphere(radius=tam, center=(0, 0, 0)), color=color, reset_camera=False,
                                   pickable=False, specular=0.4)
        a.SetPosition(*P)
        self._anotar(a, jaw)
        self._asas.append({"jaw": jaw, "punto": punto, "pos": np.array(P, float), "pos0": np.array(P, float),
                           "actor": a, "sigue": [x for x in (sigue or []) if x is not None], "solo_x": solo_x})

    def _asa_bajo(self, x, y, radio=16, asas=None, plotter=None):
        """La asa (punto arrastrable) que está bajo el cursor, o None. (x, y) en píxeles de VTK."""
        plotter = plotter or self._plotter
        ren = plotter.renderer
        mejor, dmin = None, radio * plotter.interactor.devicePixelRatioF()
        for asa in (self._asas if asas is None else asas):
            if asas is None and not self.vis.get(asa["jaw"], True):
                continue
            ren.SetWorldPoint(asa["pos"][0], asa["pos"][1], asa["pos"][2], 1.0)
            ren.WorldToDisplay()
            dx, dy, _ = ren.GetDisplayPoint()
            d = float(np.hypot(dx - x, dy - y))
            if d < dmin:
                mejor, dmin = asa, d
        return mejor

    def _recta_diente(self, jaw, dientes, punto, hacia, largo):
        """Los dos extremos de la línea recta vertical que pasa por `punto`, justo por delante de lo más saliente
        de la corona de los `dientes` vista desde `hacia` (dirección x, y)."""
        p = np.asarray(punto, float)
        d = np.asarray(hacia, float)
        d /= max(np.linalg.norm(d), 1e-9)
        t = np.array([-d[1], d[0]])
        lab = self.an.dientes(jaw)
        V = self.an.U if jaw == "sup" else self.an.L
        sg = 1.0 if jaw == "sup" else -1.0  # hacia la encía
        fuera = None
        if lab is not None:
            Vt = V[np.isin(lab, list(dientes) + [x + 40 for x in dientes])]
            franja = Vt[np.abs((Vt[:, :2] - p[:2]) @ t) < 0.45]
            alto = (franja[:, 2] - p[2]) * sg
            en = franja[(alto >= -0.6) & (alto < largo)]
            if len(en) > 5:
                fuera = float((en[:, :2] @ d).max()) + 0.3
        base = p[:2] + d * ((fuera - float(p[:2] @ d)) if fuera is not None else 0.4)
        return [[float(base[0]), float(base[1]), float(p[2])], [float(base[0]), float(base[1]), float(p[2] + sg * largo)]]

    def _sobre_diente(self, jaw, dientes, punto, hacia, largo):
        """Línea vertical DIBUJADA SOBRE la corona (como MetronTrack): parte de `punto` y sube hacia la encía
        siguiendo la superficie del diente, dentro del plano vertical que se ve de canto desde `hacia`. De lado se
        ve recta; desde cualquier otro ángulo sigue pegada al diente en vez de quedar volando delante de él."""
        p = np.asarray(punto, float)
        d = np.asarray(hacia, float)
        d /= max(np.linalg.norm(d), 1e-9)
        t = np.array([-d[1], d[0]])
        lab = self.an.dientes(jaw)
        V = self.an.U if jaw == "sup" else self.an.L
        sg = 1.0 if jaw == "sup" else -1.0  # hacia la encía
        if lab is None:
            return self._recta_diente(jaw, dientes, punto, hacia, largo)
        Vt = V[np.isin(lab, list(dientes) + [x + 40 for x in dientes])].astype(np.float64)
        franja = Vt[np.abs((Vt[:, :2] - p[:2]) @ t) < 0.5]
        if len(franja) < 12:
            return self._recta_diente(jaw, dientes, punto, hacia, largo)
        alto = (franja[:, 2] - p[2]) * sg
        fuera = franja[:, :2] @ d
        hs = np.arange(0.0, largo + 1e-6, 0.4)
        salida = np.full(len(hs), np.nan)
        for i, h in enumerate(hs):
            m = np.abs(alto - h) < 0.35
            if m.sum() >= 2:
                salida[i] = fuera[m].max()  # lo más hacia afuera de la corona a esa altura: su cara visible
        ok = ~np.isnan(salida)
        if ok.sum() < 3:
            return self._recta_diente(jaw, dientes, punto, hacia, largo)
        hs, salida = hs[: np.flatnonzero(ok)[-1] + 1], np.interp(hs, hs[ok], salida[ok])[: np.flatnonzero(ok)[-1] + 1]
        a_lo_largo = float(p[:2] @ t)
        return [[*(t * a_lo_largo + d * (float(x) + 0.12)), float(p[2] + sg * h)] for h, x in zip(hs, salida)]

    def _linea_en_diente(self, jaw, dientes, punto, hacia, color, largo=6.5, ancho=5, punto_visible=True):
        """Línea vertical dibujada sobre la cara visible de la corona (no flotando): pasa por `punto` y sigue la
        superficie de los `dientes` hacia la encía. `hacia`: dirección (x, y) desde la que se mira. Devuelve su
        extremo gingival (para la etiqueta)."""
        pts = self._recta_diente(jaw, dientes, punto, hacia, largo)
        self._linea(jaw, pts, color, ancho)
        if punto_visible:
            self._puntos(jaw, [pts[0]], None, color, 0.45)
        return pts[0]  # donde empieza la línea (ahí va su punto)

    def _textos(self, P, etiquetas, color, jaw=None, ya_en_pantalla=False, siempre=True):
        if not ya_en_pantalla:
            P = self._a_pantalla(jaw, P)
        a = self._plotter.add_point_labels(P, etiquetas, font_size=13, text_color="white", shape_color=color,
                                           shape_opacity=0.9, point_size=1, show_points=False, always_visible=siempre,
                                           margin=2, reset_camera=False)
        self._anotar(a, jaw)
        return a

    def _valor(self, jaw, punto, texto):
        """El valor de una medida escrito junto a su línea, como en MetronTrack: texto oscuro, sin recuadro de color."""
        a = self._plotter.add_point_labels(self._a_pantalla(jaw, [punto]), [texto], font_size=14, text_color="#1f2933",
                                           shape="rounded_rect", shape_color="white", shape_opacity=0.78, bold=True,
                                           show_points=False, always_visible=True, margin=2, reset_camera=False)
        self._anotar(a, jaw)
        return a

    def _p3(self, jaw, x, y, alto=0.5):
        """Punto (x, y) del análisis sobre la cara oclusal de la arcada (un poco hacia el observador). Si (x, y) cae
        fuera del modelo, toma la altura del modelo más cercano (antes caía a z = 0 y el trazo «salía volando»)."""
        try:
            z = self.an.z_cerca(jaw, x, y)
        except AttributeError:  # casos guardados con otra versión del análisis
            z = None
        if z is None:
            z = self.an.z(jaw, x, y)
        return [x, y, z - alto if jaw == "sup" else z + alto]

    def _sobre(self, jaw, pts_xy, alto=0.5, ventana=9, sigma=4.0):
        """Puntos 3D de una línea que recorre la arcada (curva de arcada, espacio, eje medio) con la altura LISA:
        la envolvente de las cúspides (lo más cercano al observador) suavizada. Antes cada punto tomaba la altura
        del diente justo debajo y, al girar la vista, la línea zigzagueaba entre cúspides y fosas (Miriam: «cuando
        muevo la vista las líneas se ven deformadas»)."""
        from scipy.ndimage import gaussian_filter1d, maximum_filter1d, minimum_filter1d

        P = np.array([self._p3(jaw, float(x), float(y), alto) for x, y in pts_xy], float)
        if len(P) >= 3:
            z = P[:, 2]
            env = (minimum_filter1d if jaw == "sup" else maximum_filter1d)(z, size=min(ventana, len(z)), mode="nearest")
            P[:, 2] = gaussian_filter1d(env, sigma, mode="nearest")
        return P.tolist()

    def dibujar_analisis(self, clave, caso, res, mover_camara=True):
        """Lo llama el panel: acomoda la vista y dibuja los trazos de cada análisis (como MetronTrack)."""
        if self._plotter is None or self.an is None:
            return
        separadas = clave in ("contactos", "korkhaus", "espacio", "bolton", "moyers", "arcada", "forma", "longitud",
                              "simetria", "dientes")
        if clave == "bloqueado":  # sin dientes identificados: solo los modelos, de frente
            self._quitar_corte()
            self._mini_ocultar()
            self._limpiar_trazos()
            self._limpiar_regla()
            self._resaltar(None)
            self._mostrar_an(True)
            self._vistas_disponibles()
            if mover_camara:
                self._camara_analisis("frente", redibujar=False)
            self._plotter.render()
            return
        if clave == "dientes":
            for a in self._an_act.values():
                a._modo = None  # los números pueden haber cambiado: volver a colorear
        if mover_camara:
            self.disp = "separadas" if separadas else "junto"
            self._poner_capas(True, True)
        if clave != "contactos":
            self._corte_contactos = False
        if self._ley_visible != (clave == "contactos"):  # la leyenda de colores, solo con el mapa de contactos
            self._ley_visible = clave == "contactos"
            QtCore.QTimer.singleShot(0, self._colocar_flotantes)
        if clave == "corte" or (clave == "contactos" and self._corte_contactos):
            self.disp = "junto"
        else:
            self._quitar_corte()
        if clave not in ("molar", "canina"):
            self._mini_ocultar()
        self._vistas_disponibles()
        self._limpiar_trazos()
        self._limpiar_regla()
        self._resaltar(None)
        self._mostrar_an(True, contacto=(clave == "contactos"))
        P = caso.P
        if clave == "overjet":
            for t, r in res["overjet"].items():
                for jaw, x, col, z0, z1 in (("sup", r["x"], ROJO, r["z_up"] - 1.5, r["z_up"] + 9),
                                            ("inf", r["xl"], AZUL, r["z_lo"] - 9, r["z_lo"] + 1.5)):
                    y = (r["y_up"] if jaw == "sup" else r["y_lo"]) - 1.2
                    self._linea(jaw, [[x, y, z0], [x, y, z1]], col, 3)
                self._textos([[r["x"], r["y_up"] - 1.5, r["z_up"] + 9.5]], [r["par"]], ROJO, "sup")
        elif clave == "korkhaus":
            K = res["korkhaus"]
            if K:
                up, lo = P["sup"], P["inf"]
                self._dibujar_kork("sup", up["14"], up["24"], up["16"], up["26"], K.get("Pu"), K["nu"], K["Lo"],
                                   ("14", "24", "16", "26"))
                self._dibujar_kork("inf", lo["c44/45"], lo["c34/35"], lo["46"], lo["36"], K.get("Pl"), K["nl"],
                                   K["Lu"], ("44/45", "34/35", "46", "36"))
        elif clave in ("espacio", "bolton"):
            md = res.get("md") or {}
            n = AN.SEGMENTOS[self.panel.sub["espacio"]] if clave == "espacio" else 6
            for jaw in ("sup", "inf"):
                C, s = caso.curvas[jaw]
                if clave == "espacio":
                    # el tamaño de la arcada, como en MetronTrack: una curva suave y gruesa, solo del tramo que se
                    # mide (de distal a distal del último diente del segmento)
                    from scipy.ndimage import gaussian_filter1d

                    Cs = np.c_[gaussian_filter1d(C[:, 0], 5, mode="nearest"), gaussian_filter1d(C[:, 1], 5, mode="nearest")]
                    fin = [AN.LADO[(jaw, lado)][n - 1] for lado in ("der", "izq")]
                    tramo = np.ones(len(C), bool)
                    if all(t in md for t in fin):
                        lim = sorted(AN.s_de(C, s, md[t]["d"][:2]) for t in fin)
                        tramo = (s >= lim[0]) & (s <= lim[1])
                    if tramo.sum() >= 4:
                        Ct = Cs[tramo]
                        paso = max(1, len(Ct) // 120)
                        self._curva_arcada(jaw, self._sobre(jaw, Ct[::paso], 0.5))
                # la línea mesiodistal de cada diente del segmento (sigue su angulación), como en MetronTrack
                for lado in ("der", "izq"):
                    for t in AN.LADO[(jaw, lado)][:n]:
                        if t in md:
                            a, b = np.array(md[t]["m"][:2]), np.array(md[t]["d"][:2])
                            # RECTA de extremo a extremo (como MetronTrack): con puntos intermedios, cada uno a la
                            # altura de la cúspide o la fosa de debajo, al girar la vista se veía en zigzag
                            pts = [self._p3(jaw, *a, 0.7), self._p3(jaw, *b, 0.7)]
                            pts.insert(1, ((np.array(pts[0]) + np.array(pts[1])) / 2).tolist())
                            # cada diente con SU línea: no llega hasta el vecino (deja un hueco) y remata en un
                            # punto en cada extremo, para que se lea diente por diente y no como una sola línea
                            largo_md = max(float(np.linalg.norm(b - a)), 1e-6)
                            k0 = min(0.2, 0.95 / largo_md)
                            corta = [self._p3(jaw, *(a + (b - a) * k0), 0.7), self._p3(jaw, *(a + (b - a) * (1 - k0)), 0.7)]
                            md_act = self._linea(jaw, corta, VERDE_MD, 5)
                            try:  # misma línea de siempre; solo se asegura que quede sobre la curva de la arcada
                                mm_ = md_act.GetMapper()
                                mm_.SetResolveCoincidentTopologyToPolygonOffset()
                                mm_.SetRelativeCoincidentTopologyLineOffsetParameters(0.0, -66000.0 * 2.2)
                            except Exception:  # noqa: BLE001
                                pass
                            self._puntos(jaw, [corta[0], corta[-1]], None, MD_PUNTO, 0.42)
                            if self.panel.diente_sel == (jaw, t):  # el diente elegido: sus dos puntos, para moverlos
                                self._puntos(jaw, [pts[0], pts[-1]], None, "#1995AD", 0.5)  # sin letreros: no saturar
                                # el diente elegido lleva su medida junto a su línea (aunque el ratón ya no esté encima)
                                u = np.array(pts[-1]) - np.array(pts[0])
                                fuera = np.array(pts[len(pts) // 2], float)
                                nor = np.array([-u[1], u[0]]) / max(float(np.hypot(u[0], u[1])), 1e-6)
                                centro_arco = np.mean([v[:2] for v in P["centros"][jaw].values()], axis=0)
                                if nor @ (fuera[:2] - centro_arco) < 0:
                                    nor = -nor
                                fuera[:2] += nor * 6.0
                                self._valor(jaw, fuera.tolist(), f"{AN.ancho(caso.anchos, t) or md[t]['ancho']:.1f} mm")
                if clave == "espacio" and caso.dientes(jaw) is None:  # sin separación de dientes: los anchos van escritos sobre cada uno
                    cen = P["centros"][jaw]
                    dientes = [t for t in cen if AN.ancho(caso.anchos, t)]
                    if dientes:
                        self._textos([self._p3(jaw, *cen[t], 1.0) for t in dientes],
                                     [f"{AN.ancho(caso.anchos, t):.1f}" for t in dientes], "#2f6f86", jaw)
        elif clave == "moyers":
            mo = res["moyers"]
            if mo:
                for q, c in mo["cuadrantes"].items():
                    jaw = c["jaw"]
                    C, s = caso.curvas[jaw]
                    dientes = AN.LADO[(jaw, c["lado"])]
                    cen = P["centros"][jaw]
                    w2 = AN.ancho(caso.anchos, dientes[1]) or AN.PROMEDIO["2"][0 if jaw == "sup" else 1]
                    w6 = AN.ancho(caso.anchos, dientes[5]) or AN.PROMEDIO["6"][0 if jaw == "sup" else 1]
                    sg = -1 if c["lado"] == "der" else 1
                    s2 = sg * (abs(AN.s_de(C, s, cen[dientes[1]])) + w2 / 2)
                    s6 = sg * (abs(AN.s_de(C, s, cen[dientes[5]])) - w6 / 2)
                    ss = np.linspace(s2, s6, 40)
                    col = VERDE if c["discrepancia"] >= 0 else ROJO
                    pts = self._sobre(jaw, [AN.en_s(C, s, v) for v in ss], 0.6)
                    self._linea(jaw, pts, col, 6)
                    self._puntos(jaw, [pts[0], pts[-1]], None, col, 0.6)
                    self._textos([pts[len(pts) // 2]], [f"{c['disponible']:.1f} mm"], col, jaw)
        elif clave == "dientes":
            for jaw in ("sup", "inf"):
                lab = caso.dientes(jaw)
                if lab is None:
                    continue
                V = caso.U if jaw == "sup" else caso.L
                nums = [int(t) for t in np.unique(lab) if t]
                # como MetronTrack: el número va FUERA de la arcada, unido a su diente con una línea fina
                cen = {t: V[lab == t] for t in nums}
                if not cen:
                    continue
                centro = np.mean([Vt[:, :2].mean(0) for Vt in cen.values()], axis=0)
                pts = []
                for t in nums:
                    Vt = cen[t]
                    c = Vt[:, :2].mean(0)
                    u = c - centro
                    u = u / max(np.linalg.norm(u), 1e-6)
                    grosor = float(np.percentile((Vt[:, :2] - c) @ u, 98))  # hasta dónde llega la corona hacia afuera
                    z = float(Vt[:, 2].min() - 0.8) if jaw == "sup" else float(Vt[:, 2].max() + 0.8)
                    borde = c + u * grosor
                    fuera = c + u * (grosor + 5.5)
                    pts.append([float(fuera[0]), float(fuera[1]), z])
                    self._linea(jaw, [[float(borde[0]), float(borde[1]), z], pts[-1]], "#8fb4e8", 2)
                a = self._plotter.add_point_labels(self._a_pantalla(jaw, pts), [str(t) for t in nums], font_size=14,
                                                   text_color="#1995AD", shape="rounded_rect", shape_color="white",
                                                   shape_opacity=1.0, bold=True, show_points=False,
                                                   always_visible=True, margin=4, reset_camera=False)
                self._anotar(a, jaw)
        elif clave in ("simetria", "longitud"):
            colores = {"anterior": AMBAR, "media": ROJO, "posterior": VERDE}
            for jaw in ("sup", "inf"):
                sim = (res.get("simetria") or {}).get(jaw) or {}
                lon = (res.get("longitud") or {}).get(jaw) or {}
                if not sim or "frente" not in lon:
                    continue
                y0 = lon["frente"]
                y1 = max(x["p_der"][1] for x in sim.values()) + 4
                if clave == "simetria":  # el plano medio, translúcido (como MetronTrack)
                    zm = float(np.mean([self._p3(jaw, 0.0, y, 0.0)[2] for y in np.linspace(y0, y1, 6)]))
                    self._plano(jaw, 0.0, (y0 - 3.0, y1 + 2.0), (zm - 7.0, zm + 7.0), MT_PLANO, 0.30)
                else:
                    self._linea(jaw, self._sobre(jaw, [(0.0, y) for y in np.linspace(y0 - 2, y1, 30)], 1.2), "#5b6570", 3)  # eje medio
                for nivel, x in sim.items():
                    col = colores[nivel]
                    pd, pi = x["p_der"], x["p_izq"]
                    if clave == "simetria":  # de cada diente al plano medio
                        for q, valor in ((pd, x["der"]), (pi, x["izq"])):
                            a, b = self._p3(jaw, q[0], q[1], 1.0), self._p3(jaw, 0.0, q[1], 1.0)
                            b[2] = a[2]
                            self._linea(jaw, [a, b], MT_LINEA, 3)
                            self._puntos(jaw, [a], None, MT_PUNTO, 0.5)
                            self._valor(jaw, [q[0] / 2, q[1] - 1.6, a[2]], f"{valor:.1f}mm")
                    elif nivel in lon:  # profundidad sobre el eje, desde el borde incisal
                        ym = (pd[1] + pi[1]) / 2
                        a, b = self._p3(jaw, pd[0], pd[1], 1.0), self._p3(jaw, pi[0], pi[1], 1.0)
                        self._linea(jaw, [a, b], col, 3)
                        self._puntos(jaw, [a, b], None, col, 0.5)
                        self._textos([self._p3(jaw, 0.0, ym, 1.6)], [f"{lon[nivel]:.1f} mm"], col, jaw)
                if clave == "longitud":
                    self._puntos(jaw, [self._p3(jaw, 0.0, y0, 1.2)], ["borde incisal"], "#5b6570", 0.5)
        elif clave == "forma":
            md = res.get("md") or {}
            for jaw in ("sup", "inf"):
                C, s = caso.curvas[jaw]
                # la FORMA del arco, no el recorrido cúspide por cúspide: una curva lisa ajustada a la arcada
                # (polinomio de grado 6 sobre la longitud), para que no serpentee entre diente y diente
                try:
                    u = 2.0 * (s - s[0]) / max(1e-6, s[-1] - s[0]) - 1.0
                    C = np.c_[np.polyval(np.polyfit(u, C[:, 0], 6), u), np.polyval(np.polyfit(u, C[:, 1], 6), u)]
                except Exception:  # noqa: BLE001  (si no ajusta, la curva de siempre)
                    pass
                paso = max(1, len(C) // 120)
                self._curva_arcada(jaw, self._sobre(jaw, C[::paso], 0.5))
                nudos = [md[t]["m"][:2] for t in AN.ORDEN_ARCADA[jaw] if t in md and t[1] in "1357"]
                if not nudos:
                    nudos = [P["centros"][jaw][t] for t in AN.ORDEN_ARCADA[jaw] if t in P["centros"][jaw] and t[1] in "1357"]
                proy = [AN.en_s(C, s, AN.s_de(C, s, q)) for q in nudos]  # sobre la curva
                self._puntos(jaw, [self._p3(jaw, q[0], q[1], 0.7) for q in proy], None, "#1995AD", 0.6)
        elif clave in ("molar", "canina"):
            self._rel = {}
            for lado, x in ((res.get("clases") or {}).get(clave) or {}).items():
                if "cuspide" not in x or x.get("clase") == "No valorable":
                    continue  # fijada a criterio del doctor sin medición, o no valorable
                sx = -1.0 if lado == "der" else 1.0
                cusp = np.array(x["cuspide"])
                ref = np.array(x["surco"] if clave == "molar" else x["tronera"])
                # como MetronTrack: punto azul en la cúspide superior con su línea hacia la encía; en el inferior, las
                # cúspides de referencia (grises en el molar, verdes en la canina) con su línea, y el punto verde de
                # la referencia (surco / tronera). Los puntos azul y verde se arrastran con el mouse.
                sup_d, inf_d = ((16, 46) if lado == "der" else (26, 36)) if clave == "molar" else \
                    ((13, 43) if lado == "der" else (23, 33))
                inf_dientes = [inf_d] if clave == "molar" else [inf_d, inf_d + 1]
                hacia = (sx, 0.0)
                rel = {"sup": [sup_d], "inf": inf_dientes, "rectas": [], "puntos": [], "asas": []}
                recta = self._sobre_diente("sup", [sup_d], cusp, hacia, 6.0)
                rel["rectas"].append(("sup", recta, COLOR_REL_SUP))
                rel["asas"].append(("sup", ("sup", "aj", f"{clave}_{lado}_sup"), recta[0], COLOR_REL_SUP))
                col_ref = "#3d4753" if clave == "molar" else COLOR_REL_INF
                for k, q in enumerate(x.get("cuspides_inf") or []):
                    diente = inf_d if clave == "molar" else inf_d + k
                    recta = self._sobre_diente("inf", [diente], q, hacia, 5.0)
                    rel["rectas"].append(("inf", recta, col_ref))
                    rel["puntos"].append(("inf", recta[0], col_ref))
                # el punto de referencia inferior (surco / tronera), sobre la cara visible de sus dientes
                en_diente = self._sobre_diente("inf", inf_dientes, ref, hacia, 1.2)[0]
                rel["asas"].append(("inf", ("inf", "aj", f"{clave}_{lado}_inf"), en_diente, COLOR_REL_INF))
                lineas = [self._linea(jaw, recta, col, 6) for jaw, recta, col in rel["rectas"]]
                for jaw, pos, col in rel["puntos"]:
                    self._puntos(jaw, [pos], None, col, 0.5)
                for k, (jaw, punto, pos, col) in enumerate(rel["asas"]):
                    self._asa(jaw, punto, pos, col, sigue=lineas[:1] if k == 0 else None)  # la cúspide lleva su línea
                self._rel[lado] = rel
            self._mini_mostrar(clave)
        elif clave == "lmedia" and res["linea_media"].get("valorable", True):
            lm = res["linea_media"]
            U, L = caso.U, caso.L
            zs = float(U[np.abs(U[:, 0] - lm["sup"]) < 3][:, 2].min())   # borde incisal superior
            zi = float(L[np.abs(L[:, 0] - lm["inf"]) < 3][:, 2].max())   # borde incisal inferior
            ys = float(U[(np.abs(U[:, 0] - lm["sup"]) < 1.5) & (U[:, 2] < zs + 3)][:, 1].min())
            yi = float(L[(np.abs(L[:, 0] - lm["inf"]) < 1.5) & (L[:, 2] > zi - 3)][:, 1].min())
            # como MetronTrack: un plano vertical translúcido por cada línea media (azul la superior, verde la
            # inferior), con su punto. De frente se ven como dos líneas finas; de lado, como dos láminas.
            yf = min(ys, yi) - 1.2
            for jaw, x, z_pt, col in (("sup", lm["sup"], zs + 2.5, COLOR_REL_SUP), ("inf", lm["inf"], zi - 2.5, COLOR_REL_INF)):
                plano = self._plano(jaw, x, (yf - 4.0, yf + 8.0), (min(zs, zi) - 9.0, max(zs, zi) + 9.0), col)
                self._asa(jaw, (jaw, "aj", f"lm_{jaw}"), [x, yf - 2.0, z_pt], col, 0.6, sigue=plano, solo_x=True)
            txt = f"{lm['mm']:.1f} mm a la {lm['direccion']}" if lm["direccion"] != "centrada" else "coinciden"
            self._textos([[lm["sup"], yf - 4.0, max(zs, zi) + 10.5]], ["Línea media superior"], COLOR_REL_SUP, "sup")
            self._textos([[lm["inf"], yf - 4.0, min(zs, zi) - 10.5]], [f"Línea media inferior · {txt}"], COLOR_REL_INF,
                         "inf")
        elif clave == "arcada":
            cen = P["centros"]
            for jaw, pares in (("sup", (("13", "23", AMBAR), ("14", "24", ROJO), ("16", "26", VERDE))),
                               ("inf", (("43", "33", AMBAR), ("44", "34", ROJO), ("46", "36", VERDE)))):
                for a, b, col in pares:
                    if a in cen[jaw] and b in cen[jaw]:
                        pa, pb = self._p3(jaw, *cen[jaw][a], 1.0), self._p3(jaw, *cen[jaw][b], 1.0)
                        self._linea(jaw, [pa, pb], MT_LINEA, 3)
                        self._puntos(jaw, [pa, pb], None, MT_PUNTO, 0.5)
                        d = float(np.hypot(pa[0] - pb[0], pa[1] - pb[1]))
                        self._valor(jaw, [(pa[0] + pb[0]) / 2, (pa[1] + pb[1]) / 2 - 1.6, pa[2]], f"{d:.1f}mm")
        if clave == "corte":
            if not self._corte_activo:
                self._camara_analisis("frente", redibujar=False)
                self.poner_corte()
        elif clave == "contactos" and self._corte_contactos:
            if not self._corte_activo:
                self.poner_corte()
        elif mover_camara:
            vista = ("frente" if clave in ("overjet", "resumen", "lmedia") else
                     ("derecha" if self._mini_lado == "der" else "izquierda") if clave in ("molar", "canina")
                     else "separadas")
            self._camara_analisis(vista, redibujar=False)
            if clave in ("molar", "canina"):
                self._acercar_relacion(clave, res)
        self._plotter.render()

    def _acercar_relacion(self, clave, res):
        """Acerca la cámara a los dientes de la relación del lado elegido."""
        x = ((res.get("clases") or {}).get(clave) or {}).get(self._mini_lado) or {}
        if "cuspide" in x:
            f = np.array(x["cuspide"], float)
            sx = -1.0 if self._mini_lado == "der" else 1.0
            self._plotter.camera_position = [tuple(f + [sx * 75.0, 0.0, 0.0]), tuple(f), (0, 0, 1)]
            self._plotter.renderer.ResetCameraClippingRange()

    # ------------------------------------------------------------------ recuadro de la relación (molar / canina)
    def _submalla(self, jaw, dientes):
        """Solo las coronas de esos dientes (o sus temporales), en el marco del análisis."""
        import pyvista as pv

        lab = self.an.dientes(jaw)
        if lab is None:
            return None
        V = self.an.U if jaw == "sup" else self.an.L
        F = self.an.FU if jaw == "sup" else self.an.FL
        caras = F[np.isin(lab[F], list(dientes) + [d + 40 for d in dientes]).all(1)]
        if not len(caras):
            return None
        return pv.PolyData(V, np.hstack([np.full((len(caras), 1), 3), caras]).astype(np.int64))

    def _mini_ocultar(self):
        self._rel = {}
        if self._mini_visible:
            self._mini_visible = False
            self.flot_mini.hide()

    def _mini_mostrar(self, clave):
        """El recuadro: los dientes de la relación en gris, con sus líneas y sus puntos (los mismos del modelo)."""
        import pyvista as pv

        if not self._rel or not self.an.etiquetas:
            self._mini_ocultar()
            return
        if self._mini_lado not in self._rel:
            self._mini_lado = next(iter(self._rel))
        lado = self._mini_lado
        if self._mini is None:
            from pyvistaqt import QtInteractor

            self._mini = QtInteractor(self.mini_hueco)
            self._mini.set_background("#f4f6f8")
            self._mini.enable_anti_aliasing("ssaa")
            self._mini.interactor.setAcceptDrops(False)
            self._mini.interactor.setMouseTracking(True)
            self._mini.interactor.installEventFilter(self)
            self._raton_metron(self._mini)
            self.mini_hueco.layout().addWidget(self._mini.interactor)
        pl = self._mini
        for a in self._mini_actores:
            pl.remove_actor(a)
        self._mini_actores, self._mini_asas, self._mini_act = [], [], {"sup": [], "inf": []}
        self._mini_arrastre = None
        rel = self._rel[lado]
        todos = []
        for jaw in ("sup", "inf"):
            m = self._submalla(jaw, rel[jaw])
            if m is not None:
                a = pl.add_mesh(m, color="#dde1e6", smooth_shading=True, specular=0.35, specular_power=18,
                                reset_camera=False)
                self._mini_act[jaw].append(a)
                self._mini_actores.append(a)
                usados = np.unique(np.asarray(m.faces).reshape(-1, 4)[:, 1:])
                todos.append(np.asarray(m.points)[usados])
        lineas = []
        for jaw, recta, col in rel["rectas"]:
            lineas.append(pl.add_mesh(pv.lines_from_points(np.asarray(recta, float)), color=col, line_width=4,
                                      render_lines_as_tubes=True, reset_camera=False, pickable=False))
        self._mini_actores += lineas
        for jaw, pos, col in rel["puntos"]:
            self._mini_actores.append(pl.add_mesh(pv.Sphere(radius=0.42, center=pos), color=col, reset_camera=False,
                                                  pickable=False))
        for jaw, punto, pos, col in rel["asas"]:
            a = pl.add_mesh(pv.Sphere(radius=0.55, center=(0, 0, 0)), color=col, reset_camera=False, pickable=False,
                            specular=0.4)
            a.SetPosition(*pos)
            self._mini_actores.append(a)
            self._mini_asas.append({"jaw": jaw, "punto": punto, "pos": np.array(pos, float),
                                    "pos0": np.array(pos, float), "actor": a,
                                    "sigue": lineas[:1] if not self._mini_asas else []})
        if (clave, lado) != self._mini_clave and todos:  # la cámara solo se acomoda al cambiar de relación o de lado
            P = np.vstack(todos)
            c = (P.min(0) + P.max(0)) / 2
            sx = -1.0 if lado == "der" else 1.0
            pl.camera_position = [tuple(c + [sx * 80.0, 0.0, 0.0]), tuple(c), (0, 0, 1)]
            pl.camera.parallel_projection = True
            pl.camera.parallel_scale = float(max(P[:, 1].max() - P[:, 1].min(), P[:, 2].max() - P[:, 2].min()) * 0.62)
            pl.renderer.ResetCameraClippingRange()
            self._mini_clave = (clave, lado)
        self.l_mini.setText("<br>".join(
            f"<span style='color:{col};font-size:12pt;'>●</span> {nombre_punto(punto[2])}"
            for _jaw, punto, _pos, col in rel["asas"])
            + ("<br><span style='color:#3d4753;font-size:12pt;'>●</span> Cúspides vestibulares del molar inferior "
               "(referencia)" if clave == "molar" and rel["puntos"] else ""))
        for k in ("der", "izq"):
            self.b_mini[k].setChecked(k == lado)
            self.b_mini[k].setEnabled(k in self._rel)
        self._mini_visible = True
        self._colocar_flotantes()
        pl.render()

    def _mini_elegir(self, lado):
        if lado not in self._rel or self.an is None:
            return
        self._mini_lado = lado
        self._mini_mostrar(self.panel.vista)
        self._camara_analisis("derecha" if lado == "der" else "izquierda", redibujar=False)
        self._acercar_relacion(self.panel.vista, self.panel.res)
        self._plotter.render()

    def _mini_agrandar(self):
        grande = self.mini_hueco.width() < 400
        self.mini_hueco.setFixedSize(*((520, 400) if grande else (330, 250)))
        self._colocar_flotantes()

    def _mini_evento(self, obj, ev):
        """Arrastre de un punto dentro del recuadro. True si el evento era del arrastre (los dientes no giran)."""
        from vtkmodules.vtkRenderingCore import vtkCellPicker

        r = obj.devicePixelRatioF()
        pos = ev.position()
        x, y = int(pos.x() * r), int((obj.height() - pos.y() - 1) * r)
        tipo = ev.type()
        if tipo == QtCore.QEvent.MouseButtonPress:
            if ev.button() != Qt.LeftButton:
                return False
            asa = self._asa_bajo(x, y, asas=self._mini_asas, plotter=self._mini)
            if asa is None:
                return False
            self._mini_arrastre = asa
            obj.setCursor(Qt.ClosedHandCursor)
            return True
        if self._mini_arrastre is None:
            if tipo == QtCore.QEvent.MouseMove and not ev.buttons():
                bajo = self._asa_bajo(x, y, asas=self._mini_asas, plotter=self._mini)
                obj.setCursor(Qt.OpenHandCursor if bajo is not None else Qt.ArrowCursor)
                self._decir_punto(obj, bajo)
            return False
        asa = self._mini_arrastre
        pk = vtkCellPicker()
        pk.SetTolerance(0.0005)
        pk.PickFromListOn()
        for a in self._mini_act[asa["jaw"]]:  # el punto se desliza sobre su propio diente
            pk.AddPickList(a)
        if pk.Pick(x, y, 0, self._mini.renderer):
            self._mover_asa(asa, pk.GetPickPosition())
            self._mini.render()
        if tipo == QtCore.QEvent.MouseButtonRelease:
            self._mini_arrastre = None
            obj.setCursor(Qt.ArrowCursor)
            punto, q = asa["punto"], asa["pos"].copy()

            def aplicar():
                self.panel.punto_activo = punto
                self.panel.mover_punto(punto[0], q[0], q[1], q[2])
                self.panel.punto_activo = None
            QtCore.QTimer.singleShot(0, aplicar)
        return True

    def _dibujar_kork(self, jaw, a, b, m1, m2, tip, n, largo, nombres):
        a, b, m1, m2 = (np.asarray(p, float) for p in (a, b, m1, m2))
        pa, pb, p1, p2 = (self._p3(jaw, *p) for p in (a, b, m1, m2))
        self._linea(jaw, [pa, pb], ROJO, 5)
        self._linea(jaw, [p1, p2], VERDE, 5)
        self._puntos(jaw, [pa, pb], [nombres[0], nombres[1]], ROJO)
        self._puntos(jaw, [p1, p2], [nombres[2], nombres[3]], VERDE)
        if tip is not None and largo is not None:
            # Miriam: «importante que estas líneas no salgan volando». Antes iban a la altura de los premolares (y la
            # punta del incisivo, en el borde de la malla, a veces a z = 0). Ahora cada extremo va pegado al modelo:
            # el pie, sobre la línea de premolares; la punta, sobre el incisivo. Las dos líneas son RECTAS (Miriam:
            # siguiendo la superficie «salen deformes»): la tangente va horizontal a la altura de la punta.
            tip = np.asarray(tip, float)
            n = np.asarray(n, float)
            pie = tip - n * largo
            dd = (b - a) / np.linalg.norm(b - a)
            t = float(np.clip((pie - a) @ dd / np.linalg.norm(b - a), 0.0, 1.0))
            z_pie = pa[2] + (pb[2] - pa[2]) * t  # sobre la línea roja, donde cae la perpendicular
            z_tip = self._p3(jaw, *tip)[2]
            self._linea(jaw, [[*pie, z_pie], [*tip, z_tip]], AZUL, 4)
            self._linea(jaw, [[*(tip - dd * 10), z_tip], [*(tip + dd * 10), z_tip]], AZUL, 3)
            mid = (pie + tip) / 2
            self._textos([[*mid, (z_pie + z_tip) / 2]], [f"{largo:.1f} mm"], AZUL, jaw)
        self._textos([[*((a + b) / 2), pa[2]]], [f"{np.linalg.norm(b - a):.1f} mm"], ROJO, jaw)
        self._textos([[*((m1 + m2) / 2), p1[2]]], [f"{np.linalg.norm(m2 - m1):.1f} mm"], VERDE, jaw)

    def _camara_analisis(self, vista, redibujar=True):
        quiere = "separadas" if vista == "separadas" else "junto"
        if self.panel.vista == "corte" and quiere == "separadas":
            self.aviso("En «Corte» las arcadas se ven en oclusión.")
            return
        if self._corte_contactos and quiere == "separadas":  # el corte es con las arcadas cerradas: se quita
            self._corte_contactos = False
            self._quitar_corte()
        if vista in ("oclusal_sup", "oclusal_inf"):
            self._poner_capas(vista == "oclusal_sup", vista == "oclusal_inf")
        else:
            self._poner_capas(True, True)
        movidas = any(not np.allclose(m, np.eye(4)) for m in self._acomodo.values())
        self._acomodo = {"sup": np.eye(4), "inf": np.eye(4)}
        self._acom = None
        if self.disp != quiere or movidas:
            self.disp = quiere
            if redibujar:
                self.panel.mostrar(self.panel.actual, mover_camara=False)
        self._mostrar_an(True, contacto=self.panel.actual == "contactos")
        self._marcar_vista(vista)
        pos, up = {"separadas": ((0, 0, 300), (0, 1, 0)), "frente": ((0, -300, 0), (0, 0, 1)),
                   "atras": ((0, 300, 0), (0, 0, 1)),
                   "derecha": ((-300, 0, 0), (0, 0, 1)), "izquierda": ((300, 0, 0), (0, 0, 1)),
                   "oclusal_sup": ((0, 0, -300), (0, -1, 0)), "oclusal_inf": ((0, 0, 300), (0, 1, 0))}[vista]
        # las dos arcadas lado a lado se ven sin perspectiva: cada una de frente, no «desde el centro»
        self._plotter.camera.parallel_projection = vista == "separadas"
        self._plotter.camera_position = [pos, (0, 0, 0), up]
        self._plotter.reset_camera()
        self._plotter.camera.zoom({"separadas": 1.05, "derecha": 1.0, "izquierda": 1.0}.get(vista, 1.2)
                                  * (0.85 if self.panel.vista == "corte" else 1.0))
        self._plotter.render()
        if self.panel.vista == "contactos":
            self.panel.contactos_marcar()

    # ------------------------------------------------------------------ corte de oclusión (plano que se arrastra)
    def _corte_rango(self, modo):
        """(mínimo, máximo, inicial) de la posición del corte en cada modo."""
        U = self.an.U[::40]
        if modo == "diente":
            P, s = self.an.curvas["sup"]
            c11 = self.an.P["centros"]["sup"].get("11")
            return float(s[0]), float(s[-1]), (AN.s_de(P, s, c11) if c11 else 0.0)
        if modo == "sagital":
            return float(U[:, 0].min()), float(U[:, 0].max()), float(self.an.P["incisivos"].get("11", 0.0))
        ys = [self.an.P["centros"]["sup"][t][1] for t in ("16", "26") if t in self.an.P["centros"]["sup"]]
        return float(U[:, 1].min()), float(U[:, 1].max()), float(np.mean(ys)) if ys else 0.0

    def poner_corte(self, modo=None, valor=None):
        """Coloca el corte. modo: «diente» (a través del diente, perpendicular a la arcada), «sagital» o
        «transversal»; valor: su posición (a lo largo de la arcada, en x o en y). Sin valor, la inicial del modo."""
        import pyvista as pv

        if self.an is None or self._plotter is None:
            return
        if modo not in ("diente", "sagital", "transversal"):
            modo = self._corte_plano if self._corte_plano in ("diente", "sagital", "transversal") else "diente"
        lo, hi, inicial = self._corte_rango(modo)
        if valor is None:
            valor = inicial if (modo != self._corte_plano or not self._corte_activo or self._corte_valor is None) \
                else self._corte_valor
        valor = float(np.clip(valor, lo, hi))
        if not self._corte_activo:
            self._corte_mallas = {}  # los números de diente pueden haber cambiado
        self._corte_plano, self._corte_valor = modo, valor
        U = self.an.U[::40]
        if modo == "diente":
            P, s = self.an.curvas["sup"]
            o = np.r_[AN.en_s(P, s, valor), 0.0]
            tg = AN.en_s(P, s, min(valor + 1.0, hi)) - AN.en_s(P, s, max(valor - 1.0, lo))
            n = np.r_[tg / max(np.linalg.norm(tg), 1e-9), 0.0]
            medio = 11.0
        elif modo == "sagital":
            o = np.array([valor, float((U[:, 1].min() + U[:, 1].max()) / 2), 0.0])
            n = np.array([1.0, 0.0, 0.0])
            medio = float((U[:, 1].max() - U[:, 1].min()) / 2 + 3)
        else:
            o = np.array([0.0, valor, 0.0])
            n = np.array([0.0, 1.0, 0.0])
            medio = float(np.abs(U[:, 0]).max() + 3)
        # el plano, a la vista en el modelo
        for a in self._corte_act:
            self._plotter.remove_actor(a)
        u = np.array([-n[1], n[0], 0.0])
        z = np.array([0.0, 0.0, 12.0])
        esquinas = np.array([o - u * medio - z, o + u * medio - z, o + u * medio + z, o - u * medio + z])
        self._corte_act = [
            self._plotter.add_mesh(pv.PolyData(esquinas, np.array([4, 0, 1, 2, 3])), color="#1995AD", opacity=0.35,
                                   lighting=False, reset_camera=False, pickable=False),
            self._plotter.add_mesh(pv.lines_from_points(np.vstack([esquinas, esquinas[:1]])), color="#1995AD",
                                   line_width=3, reset_camera=False, pickable=False)]
        self._corte_activo = True
        for k in ("diente", "sagital", "transversal"):
            self.b_corte[k].setChecked(k == modo)
        self.sl_corte.blockSignals(True)
        self.sl_corte.setValue(int(round((valor - lo) / max(hi - lo, 1e-9) * 1000)))
        self.sl_corte.blockSignals(False)
        # título: por qué diente pasa
        titulo = {"sagital": "Corte sagital", "transversal": "Corte transversal"}.get(modo, "Corte")
        if modo == "diente":
            cen = self.an.P["centros"]["sup"]
            cerca = min(cen, key=lambda t: np.hypot(cen[t][0] - o[0], cen[t][1] - o[1])) if cen else None
            if cerca and np.hypot(cen[cerca][0] - o[0], cen[cerca][1] - o[1]) < 5.5:
                titulo = f"Corte por el diente {cerca} y su antagonista"
        self.l_corte.setText(titulo)
        self._plotter.camera.SetWindowCenter(-0.38, 0.0)  # el modelo, a la derecha de la gráfica
        self._colocar_flotantes()
        self._corte_movido(n, o)
        self._plotter.render()

    def _corte_barra(self, v):
        if self._corte_activo and self.an is not None:
            lo, hi, _ = self._corte_rango(self._corte_plano)
            self.poner_corte(self._corte_plano, lo + v / 1000.0 * (hi - lo))

    def _corte_en(self, p):
        """Clic en el modelo: el corte pasa por ese punto (p, en el marco del análisis)."""
        if self._corte_plano == "diente":
            P, s = self.an.curvas["sup"]
            valor = AN.s_de(P, s, p[:2])
        else:
            valor = float(p[0] if self._corte_plano == "sagital" else p[1])
        self.poner_corte(self._corte_plano, valor)

    def _malla_corte(self, jaw):
        """Lo que corta el plano: solo los dientes (con la separación de dientes); sin ella, la arcada completa."""
        import pyvista as pv

        if jaw not in self._corte_mallas:
            m = self._an_malla.get(jaw)
            lab = self.an.dientes(jaw) if self.an is not None else None
            if m is not None and lab is not None:
                F = self.an.FU if jaw == "sup" else self.an.FL
                caras = F[(lab[F] > 0).all(1)]
                if len(caras):
                    m = pv.PolyData(np.asarray(m.points), np.hstack([np.full((len(caras), 1), 3), caras]).astype(np.int64))
            self._corte_mallas[jaw] = m
        return self._corte_mallas[jaw]

    def _quitar_corte(self):
        if self._plotter is not None:
            for a in self._corte_act:
                self._plotter.remove_actor(a)
        self._corte_act = []
        if self._corte_activo and self._plotter is not None:
            self._plotter.camera.SetWindowCenter(0.0, 0.0)
        self._corte_activo = False
        if hasattr(self, "flot_corte"):
            self.flot_corte.hide()

    def _corte_movido(self, normal, origen):
        g = self.grafica
        if self.an is None:
            return
        self._corte_ultimo = (tuple(normal), tuple(origen))
        n = np.asarray(normal, float)
        n /= max(np.linalg.norm(n), 1e-9)
        o = np.asarray(origen, float)
        arriba = np.array([0.0, 0.0, 1.0])
        v = arriba - (arriba @ n) * n
        if np.linalg.norm(v) < 0.2:  # plano casi horizontal: «arriba» es hacia atrás
            v = np.array([0.0, 1.0, 0.0]) - n[1] * n
        v /= np.linalg.norm(v)
        u = np.cross(v, n)
        segs = {}
        for jaw in ("sup", "inf"):
            m = self._malla_corte(jaw)
            segs[jaw] = None
            if m is None or not self.vis[jaw]:
                continue
            c = m.slice(normal=n, origin=o)
            if c.n_points == 0 or c.n_cells == 0 or c.lines.size % 3:
                continue
            lin = np.asarray(c.lines).reshape(-1, 3)[:, 1:]
            pz = np.asarray(c.points)[:, 2]
            alto = 16 if self.an.dientes(jaw) is not None else 9   # sin separación de dientes: solo la zona de coronas
            lin = lin[(np.abs(pz[lin]) < alto).all(1)]
            if not len(lin):
                continue
            Q = np.asarray(c.points, float) - o
            if self._corte_plano == "diente":
                cerca = np.abs(Q @ u) < 11.0
                lin = lin[cerca[lin].all(1)]
                if not len(lin):
                    continue
            segs[jaw] = np.c_[Q @ u, Q @ v][lin]
        if self._corte_plano == "sagital":
            rotulos = ("anterior", "posterior")
        elif self._corte_plano == "transversal":
            rotulos = ("izquierda", "derecha") if u[0] < 0 else ("derecha", "izquierda")
        else:  # a través del diente: ¿hacia dónde queda vestibular?
            P, _s = self.an.curvas["sup"]
            fuera = float(u[:2] @ (o[:2] - P.mean(0)))
            rotulos = ("lingual", "vestibular") if fuera > 0 else ("vestibular", "lingual")
        g.poner(segs["sup"], segs["inf"], rotulos)

    # ------------------------------------------------------------------ resaltar el diente bajo el mouse
    def _al_mover(self, obj, _ev):
        self._mov = obj.GetEventPosition()
        if not self._t_hover.isActive():
            self._t_hover.start()

    def _al_pasar(self):
        if (self.modo != 1 or self.an is None or self._clic is not None or self._press is not None
                or self.panel.actual not in ("espacio", "bolton", "moyers", "dientes") or not self.an.etiquetas
                or self._mov is None):
            if self._hover:
                self._resaltar(None)
            return
        jaw, _, pid = self._picar(*self._mov)
        fdi = 0
        if jaw is not None and pid >= 0:
            lab = self.an.dientes(jaw)
            fdi = int(lab[pid]) if lab is not None else 0
        self._resaltar((jaw, fdi) if fdi else None)

    def _picar(self, x, y, solo=None):
        """(arcada, punto, vértice) bajo el cursor. Con `solo`, únicamente esa arcada (aunque la otra esté delante)."""
        from vtkmodules.vtkRenderingCore import vtkCellPicker

        pk = vtkCellPicker()
        pk.SetTolerance(0.0005)
        pk.PickFromListOn()
        for j, a in self._an_act.items():
            if solo is None or j == solo:
                pk.AddPickList(a)
        if not pk.Pick(x, y, 0, self._plotter.renderer):
            return None, None, -1
        act = pk.GetActor()
        jaw = next((j for j, a in self._an_act.items() if a is act), None)
        return jaw, np.array(pk.GetPickPosition()), pk.GetPointId()

    def _ref_mostrar(self, cual):
        """El recuadro de referencia: el diente elegido, solo y ampliado por oclusal, con su línea mesiodistal y su
        ancho. `cual` = (arcada, diente) o None para esconderlo."""
        ver = bool(cual) and self.an is not None and self.panel.actual in ("espacio", "bolton")
        if ver:
            try:
                ver = self._ref_dibujar(*cual)
            except Exception:  # noqa: BLE001  (sin el recuadro el análisis sigue igual)
                ver = False
        if ver != self._ref_visible:
            self._ref_visible = ver
            self._colocar_flotantes()

    def _ref_dibujar(self, jaw, fdi) -> bool:
        import pyvista as pv

        lab = self.an.dientes(jaw)
        V = self.an.U if jaw == "sup" else self.an.L
        F = np.asarray(self.an.FU if jaw == "sup" else self.an.FL)
        m = lab == fdi
        if m.sum() < 60:
            return False
        local = np.full(len(V), -1, np.int64)
        local[m] = np.arange(int(m.sum()))
        Fl = local[F]
        Fl = Fl[(Fl >= 0).all(1)]
        if not len(Fl):
            return False
        Vt = V[m].astype(np.float64)
        nombre = str(fdi)
        if nombre[0] in "5678":
            nombre = str(int(nombre[0]) - 4) + nombre[1]
        md = ((self.panel.res or {}).get("md") or {}).get(nombre)
        w = AN.ancho(self.an.anchos, nombre) or (md or {}).get("ancho", 0)
        if self._ref_pl is None:
            self._ref_pl = pv.Plotter(off_screen=True, window_size=(460, 344), lighting="none")
            self._ref_pl.set_background("#f4f6f8")
            luz = pv.Light(light_type="camera light", position=(-0.6, 0.8, 1.0), intensity=1.0)  # de lado: da relieve
            self._ref_pl.add_light(luz)
            self._ref_pl.add_light(pv.Light(light_type="headlight", intensity=0.35))
        pl = self._ref_pl
        pl.clear_actors()
        diente = pv.PolyData(Vt, np.hstack([np.full((len(Fl), 1), 3), Fl]).astype(np.int64))
        diente = diente.compute_normals(auto_orient_normals=True, split_vertices=False)
        pl.add_mesh(diente, color="#d8d0c0", smooth_shading=True, ambient=0.18, diffuse=0.85, specular=0.35,
                    specular_power=18)
        signo = -1.0 if jaw == "sup" else 1.0  # desde dónde se mira la cara oclusal
        eje = np.array([1.0, 0.0])
        if md:
            a2, b2 = np.array(md["m"][:2], float), np.array(md["d"][:2], float)
            tope = float(Vt[:, 2].min() - 0.6) if jaw == "sup" else float(Vt[:, 2].max() + 0.6)
            a3, b3 = np.r_[a2, tope], np.r_[b2, tope]
            pl.add_mesh(pv.Line(a3, b3), color=VERDE_MD, line_width=5, render_lines_as_tubes=True)
            for q in (a3, b3):
                pl.add_mesh(pv.Sphere(radius=0.28, center=q), color="#1995AD")
            if np.linalg.norm(b2 - a2) > 1e-6:
                eje = (b2 - a2) / np.linalg.norm(b2 - a2)
        c = Vt.mean(0)
        arriba = np.array([-eje[1], eje[0], 0.0])  # la línea mesiodistal queda horizontal
        pl.camera.parallel_projection = True
        pl.camera_position = [tuple(c + np.array([0, 0, signo * 60.0])), tuple(c), tuple(arriba)]
        pl.reset_camera()
        pl.camera.zoom(1.25)
        img = np.ascontiguousarray(pl.screenshot(return_img=True)[:, :, :3])
        qi = QtGui.QImage(img.data, img.shape[1], img.shape[0], 3 * img.shape[1], QtGui.QImage.Format_RGB888).copy()
        self.l_ref_img.setPixmap(QtGui.QPixmap.fromImage(qi).scaled(self.l_ref_img.size(), Qt.KeepAspectRatio,
                                                                    Qt.SmoothTransformation))
        self.l_ref_t.setText(f"Diente {fdi}")
        self.l_ref_w.setText(f"Ancho mesiodistal: <b>{w:.1f} mm</b>" if w else "Sin ancho medido")
        return True

    def resaltar_diente(self, jaw, t):
        """Resalta en el modelo el diente elegido en el odontograma (el permanente o su temporal)."""
        lab = self.an.dientes(jaw) if self.an is not None else None
        if lab is None:
            return
        fdi = int(t) if (lab == int(t)).any() else int(t) + 40
        if (lab == fdi).any():
            self._resaltar((jaw, fdi))

    def _resaltar(self, cual):
        if cual == self._hover or self._plotter is None:
            return
        self._ref_mostrar(cual)
        if self._hover and self._hover[0] in self._an_base and self._hover[0] in self._an_malla:
            self._pintar(self._hover[0], self._an_base[self._hover[0]])
        if self._hover_act is not None:
            self._plotter.remove_actor(self._hover_act)
            self._hover_act = None
        self._hover = cual
        if cual and self.an is not None:
            jaw, fdi = cual
            m = self.an.dientes(jaw) == fdi
            rgb = self._an_base[jaw].copy()
            rgb[m] = (0.18 * rgb[m] + 0.82 * np.array([72, 205, 208])).astype(np.uint8)  # turquesa, como MetronTrack
            self._pintar(jaw, rgb)
            Vj = self.an.U if jaw == "sup" else self.an.L
            V = Vj[m]
            z = float(V[:, 2].min() - 1.5) if jaw == "sup" else float(V[:, 2].max() + 1.5)
            lab = self.an.dientes(jaw)
            c = V[:, :2].mean(0)
            u = c - Vj[lab > 0][:, :2].mean(0)
            u = u / max(float(np.linalg.norm(u)), 1e-6)
            fuera = c + u * (float(np.percentile((V[:, :2] - c) @ u, 98)) + (11.0 if self.panel.actual == "dientes" else 5.0))
            centro = [float(fuera[0]), float(fuera[1]), z]
            nombre = str(fdi)
            if nombre[0] in "5678":
                nombre = str(int(nombre[0]) - 4) + nombre[1]
            w = AN.ancho(self.an.anchos, nombre) or ((self.panel.res or {}).get("md") or {}).get(nombre, {}).get("ancho", 0)
            # sobre el modelo, solo la MEDIDA del diente (sin su número, que saturaba: ese sale en el odontograma
            # del panel al hacer clic)
            if w and self.panel.actual in ("espacio", "bolton", "moyers"):
                self._hover_act = self._plotter.add_point_labels(
                    self._a_pantalla(jaw, centro), [f"{w:.1f} mm"], font_size=15, text_color="#1f2933",
                    shape="rounded_rect", shape_color="white", shape_opacity=0.97, bold=True, show_points=False,
                    always_visible=True, margin=5, reset_camera=False)
            self.l_aviso.setText(f"Diente {fdi}: ancho mesiodistal {w:.1f} mm" if w else f"Diente {fdi}")
        self._plotter.render()

    # ------------------------------------------------------------------ clics: «Medir» y mover puntos
    def modo_clic(self, modo):
        self._clic = modo
        if modo != "medir" and self.b_medir.isChecked():
            self.b_medir.blockSignals(True)
            self.b_medir.setChecked(False)
            self.b_medir.blockSignals(False)
        if modo == "medir":
            self._limpiar_regla()
            self.aviso("Medir: haz clic en el primer punto del modelo y luego en el segundo.", 8000)
        elif modo == "punto":
            self.aviso("Haz clic en el modelo donde va el punto.", 8000)
        if self._plotter is not None:
            self._plotter.interactor.setCursor(Qt.CrossCursor if modo else Qt.ArrowCursor)

    def _soltar(self, x, y):
        press, self._press = self._press, None
        if press is None:
            return
        if abs(x - press[0]) + abs(y - press[1]) > 4:  # fue un giro, no un clic
            return
        if self._clic is None and self.modo == 1 and self.an is not None and (
                self.panel.vista == "corte" or (self.panel.vista == "contactos" and self._corte_contactos)):
            jaw, p, _ = self._picar(x, y)
            if jaw is not None:
                q = AN.inversa(self._D(jaw)) @ np.r_[p, 1.0]
                QtCore.QTimer.singleShot(0, lambda: self._corte_en(q[:3]))
            return
        if self._clic is None:
            if (self.modo == 1 and self.an is not None and self.an.etiquetas
                    and self.panel.actual in ("espacio", "bolton", "dientes")):
                jaw, p, pid = self._picar(x, y)
                lab = self.an.dientes(jaw) if jaw else None
                fdi = int(lab[pid]) if lab is not None and pid >= 0 else 0
                # en la vista de las dos arcadas se espera un instante: puede ser el primer clic de un doble clic
                espera = (QtWidgets.QApplication.doubleClickInterval() + 30
                          if self.disp == "separadas" or self.panel.actual == "dientes" else 0)
                self._clic_gen = gen = getattr(self, "_clic_gen", 0) + 1
                if fdi and self.panel.actual == "dientes":
                    q = AN.inversa(self._D(jaw)) @ np.r_[p, 1.0]
                    QtCore.QTimer.singleShot(espera, lambda: gen == self._clic_gen and (
                        self.panel.marcar_clic(jaw, fdi) or self._menu_numero(jaw, fdi, (float(q[0]), float(q[1])))))
                elif fdi:
                    QtCore.QTimer.singleShot(espera, lambda: gen == self._clic_gen and self.panel.elegir_diente(jaw, fdi))
            return
        if self._clic == "medir":
            from vtkmodules.vtkRenderingCore import vtkCellPicker

            pk = vtkCellPicker()
            pk.SetTolerance(0.0005)
            if pk.Pick(x, y, 0, self._plotter.renderer):
                self._clic_regla(np.array(pk.GetPickPosition()))
        elif self._clic == "punto":
            jaw, p, _ = self._picar(x, y)
            if jaw is None:
                return
            q = AN.inversa(self._D(jaw)) @ np.r_[p, 1.0]
            self.panel.mover_punto(jaw, q[0], q[1], q[2])

    def _menu_numero(self, jaw, fdi, donde=None):
        """Clic en un diente en «Dientes»: el doctor corrige su número, lo divide en dos o lo une con otro."""
        menu = QtWidgets.QMenu(self)
        t = menu.addAction(f"Diente {fdi}")
        t.setEnabled(False)
        menu.addSeparator()
        if donde is not None:
            a = menu.addAction("Dividir aquí en dos dientes")
            a.setData(("dividir",))
        lab = self.an.dientes(jaw)
        V = self.an.U if jaw == "sup" else self.an.L
        yo = V[lab == fdi][:, :2].mean(0)
        cerca = sorted((float(np.linalg.norm(V[lab == t][:, :2].mean(0) - yo)), int(t))
                       for t in np.unique(lab) if t and t != fdi)
        cerca = [t for d, t in cerca if d < 14][:3]
        if cerca:
            unir = menu.addMenu("Unir con (es el mismo diente)…")
            for t in cerca:
                a = unir.addAction(f"el pedazo {t}")
                a.setData(("unir", t))
        num = menu.addMenu("Cambiar su número a…")
        for n in AN.ORDEN_ARCADA[jaw]:
            a = num.addAction(n)
            a.setData(int(n))
            a.setEnabled(int(n) != fdi)
        temp = num.addMenu("Temporal (de leche)")
        for q in ((5, 6) if jaw == "sup" else (8, 7)):
            for k in (range(5, 0, -1) if q in (5, 8) else range(1, 6)):
                a = temp.addAction(f"{q}{k}")
                a.setData(q * 10 + k)
        menu.addSeparator()
        a = menu.addAction("No es un diente")
        a.setData(0)
        elegido = menu.exec(QtGui.QCursor.pos())
        if elegido is None or elegido.data() is None:
            return
        d = elegido.data()
        if isinstance(d, tuple) and d[0] == "dividir":
            self.panel.dividir(jaw, fdi, donde[0], donde[1])
        elif isinstance(d, tuple) and d[0] == "unir":
            self.panel.unir(jaw, fdi, d[1])
        else:
            self.panel.renumerar(jaw, fdi, int(d))

    def _limpiar_regla(self):
        for a in self._regla[1:] if self._regla else []:
            self._plotter.remove_actor(a)
        self._regla = []

    def _clic_regla(self, p):
        import pyvista as pv

        if len(self._regla) == 0 or (self._regla and self._regla[0] is not None and len(self._regla[0]) == 2):
            self._limpiar_regla()
            self._regla = [[]]
        pts = self._regla[0]
        pts.append(p)
        a = self._plotter.add_mesh(pv.Sphere(radius=0.35, center=p), color=AMBAR, reset_camera=False, pickable=False)
        self._regla.append(a)
        if len(pts) == 2:
            d = float(np.linalg.norm(pts[1] - pts[0]))
            self._regla.append(self._plotter.add_mesh(pv.Line(pts[0], pts[1]), color=AMBAR, line_width=4,
                                                      render_lines_as_tubes=True, reset_camera=False, pickable=False))
            self._regla.append(self._plotter.add_point_labels([(pts[0] + pts[1]) / 2], [f"{d:.2f} mm"], font_size=15,
                                                              text_color="black", shape_color="#f2c14e",
                                                              show_points=False, always_visible=True,
                                                              reset_camera=False))
            self.aviso(f"Distancia: {d:.2f} mm. Otro clic empieza una medida nueva.", 10000)
        self._plotter.render()

    # ------------------------------------------------------------------ la Dra.
    def vista_previa(self):
        carpeta = QtWidgets.QFileDialog.getExistingDirectory(self, "Carpeta del escaneo del paciente",
                                                             os.path.expanduser("~"))
        if carpeta:
            self._previa(carpeta)

    def _previa(self, carpeta):
        """Abre un caso directo de su carpeta. Si la carpeta soltada no trae los modelos (p. ej. «STL» o «PLY»
        sueltas), prueba con la de arriba, que es la del caso."""
        carpeta = carpeta.rstrip("\\/")
        arriba = os.path.dirname(carpeta)
        det = PQ.detectar(carpeta)
        if arriba and not ({"superior_sin_zocalo", "superior_con_zocalo"} & set(det)
                           and {"inferior_sin_zocalo", "inferior_con_zocalo"} & set(det)):
            det_arriba = PQ.detectar(arriba)
            if len(det_arriba) > len(det) and len(os.listdir(arriba)) < 40:
                carpeta = arriba
        QtWidgets.QApplication.setOverrideCursor(Qt.WaitCursor)
        self.titulo.setText("Abriendo el caso…")
        QtWidgets.QApplication.processEvents()
        try:
            # el nombre del paciente: la primera carpeta hacia arriba que no sea «STL», «PLY» ni la de la orden
            nombre, ruta = os.path.basename(carpeta), carpeta
            for _ in range(4):
                if not (nombre.lower() in ("stl", "ply", "accudesignapp", "upperandlower", "maxymand")
                        or nombre[:4].isdigit() and nombre[4:5] == "-"):
                    break
                ruta = os.path.dirname(ruta)
                nombre = os.path.basename(ruta) or nombre
            caso = self._esperar(lambda: PQ.desde_carpeta(carpeta, {"paciente": nombre + "  (vista previa)"}),
                                 "Leyendo los modelos del escaneo")
        except Exception as exc:  # noqa: BLE001
            QtWidgets.QApplication.restoreOverrideCursor()
            QtWidgets.QMessageBox.warning(self, "Análisis de modelos", f"No pude leer la carpeta:\n{exc}")
            return
        QtWidgets.QApplication.restoreOverrideCursor()
        if not caso["modelos"]:
            self.cargando_fin()
            QtWidgets.QMessageBox.information(self, "Análisis de modelos", "No encontré modelos (UpperJaw / LowerJaw) en esa carpeta.")
            return
        self.ruta_caso = None
        self.id_caso = None
        self.cargando("Preparando los modelos")
        QtWidgets.QApplication.processEvents()
        self.mostrar_caso(caso)
        if getattr(self, "_hilo", None) is None:
            self.cargando_fin()

    def enviar(self):
        from .enviar import DialogoEnviar

        DialogoEnviar(self).exec()
