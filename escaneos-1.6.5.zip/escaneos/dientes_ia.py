"""Identificación de dientes con IA (solo en la PC de la Dra.): PROPONE el número FDI de cada diente de un escaneo
que no pasó por MetronTrack. Es una propuesta: el doctor la revisa en «Dientes» antes de usar el análisis (medida
contra 20 casos revisados por la Dra.: 86 % de los dientes con el número correcto, 5 casos sin ningún error).

Usa el modelo CrossTooth (Point Transformer) que la Dra. tiene en su Escritorio (carpeta «CrossTooth_CVPR2025») y
PyTorch; no se distribuye con la app. La pieza compilada «pointops» del modelo se sustituye aquí por PyTorch puro.
"""
from __future__ import annotations

import os
import sys
import types

import numpy as np

_MODELO = None
# orientación con la que el modelo acierta más, medida en el marco del análisis (oclusión en z = 0, anterior −y)
_GIRO = {"sup": np.array([[0, 0, 1], [-1, 0, 0], [0, -1, 0]], float), "inf": np.eye(3)}
_IZQ_PRIMERO = {"sup": False, "inf": True}  # qué lado son las clases 1–8 del modelo


def carpeta_modelo():
    for base in (os.environ.get("ORTHOLAB_CROSSTOOTH"),
                 os.path.join(os.path.expanduser("~"), "OneDrive", "Escritorio", "CrossTooth_CVPR2025"),
                 os.path.join(os.path.expanduser("~"), "Desktop", "CrossTooth_CVPR2025")):
        if base and os.path.exists(os.path.join(base, "models", "PTv1", "point_best_model.pth")):
            return base
    return None


def disponible() -> bool:
    if carpeta_modelo() is None:
        return False
    from importlib.util import find_spec

    try:  # sin importarlos: PyTorch tarda en cargar y esto se pregunta al pintar la tarjeta
        return find_spec("torch") is not None and find_spec("einops") is not None
    except Exception:  # noqa: BLE001
        return False


# ----------------------------------------------------------------------------- «pointops» en PyTorch puro
def _pointops():
    import torch

    def knn(xyz, new_xyz, k, bloque=2048):
        idx = []
        for i in range(0, len(new_xyz), bloque):
            idx.append(torch.cdist(new_xyz[i:i + bloque], xyz).topk(k, dim=1, largest=False).indices)
        return torch.cat(idx, 0)

    def queryandgroup(feat, xyz, offset, new_xyz, new_offset, nsample, use_xyz=True, idx=None):
        if new_xyz is None:
            new_xyz = xyz
        if idx is None:
            idx = knn(xyz, new_xyz, nsample)
        grupo_xyz = xyz[idx] - new_xyz.unsqueeze(1)
        grupo = feat[idx]
        return (torch.cat([grupo_xyz, grupo], -1) if use_xyz else grupo), idx

    def furthestsampling(xyz, offset, new_offset):
        n, m = int(offset[-1]), int(new_offset[-1])
        dist = torch.full((n,), 1e10, dtype=xyz.dtype)
        elegidos = torch.zeros(m, dtype=torch.long)
        actual = 0
        for i in range(m):
            elegidos[i] = actual
            dist = torch.minimum(dist, ((xyz - xyz[actual]) ** 2).sum(1))
            actual = int(torch.argmax(dist))
        return elegidos

    def interpolation(xyz, new_xyz, feat, offset, new_offset, k=3):
        idx = knn(xyz, new_xyz, k)
        w = 1.0 / ((xyz[idx] - new_xyz.unsqueeze(1)).norm(dim=2) + 1e-8)
        w = w / w.sum(1, keepdim=True)
        return (feat[idx] * w.unsqueeze(-1)).sum(1)

    m = types.SimpleNamespace(queryandgroup=queryandgroup, furthestsampling=furthestsampling, interpolation=interpolation)
    return m


def _modelo():
    global _MODELO
    if _MODELO is None:
        import torch

        base = carpeta_modelo()
        if base is None:
            raise RuntimeError("No encuentro la carpeta «CrossTooth_CVPR2025» con el modelo.")
        ruta = "models.PointTransformer.libs.pointops.functions"
        partes = ruta.split(".")
        for i in range(1, len(partes) + 1):
            sys.modules.setdefault(".".join(partes[:i]), types.ModuleType(".".join(partes[:i])))
        sys.modules[ruta].pointops = _pointops()
        with open(os.path.join(base, "models", "PTv1", "point_transformer_seg.py"), encoding="utf-8") as f:
            codigo = f.read().split("if __name__ ==")[0].replace("torch.cuda.IntTensor(n_o)",
                                                                 "torch.tensor(n_o, dtype=torch.int32)")
        mod = types.ModuleType("ortholab_pt_seg")
        exec(compile(codigo, "point_transformer_seg.py", "exec"), mod.__dict__)  # noqa: S102  (código local de la Dra.)
        torch.set_num_threads(max(1, min(4, os.cpu_count() or 1)))
        red = mod.PointTransformerSeg38(in_channels=6, num_classes=19, pretrain=False, add_cbl=False, enable_pic_feat=False)
        red.load_state_dict(torch.load(os.path.join(base, "models", "PTv1", "point_best_model.pth"), map_location="cpu"))
        red.eval()
        _MODELO = red
    return _MODELO


def _a_fdi(clase, jaw):
    out = np.zeros(len(clase), np.uint8)
    for c in range(1, 17):
        n = c if c <= 8 else c - 8
        izq = (c <= 8) == _IZQ_PRIMERO[jaw]
        cuad = (2 if izq else 1) if jaw == "sup" else (3 if izq else 4)
        out[clase == c] = cuad * 10 + n
    return out


def crudo(V, F, jaw, pasadas=2, progreso=None):
    """Lo que dice la red, sin ordenar: FDI por vértice (uint8, 0 = encía) de una arcada ya alineada."""
    import torch
    from scipy.spatial import cKDTree

    red = _modelo()
    V = np.asarray(V, np.float64)
    F = np.asarray(F, np.int64)
    cen = V[F].mean(1)
    nor = np.cross(V[F[:, 1]] - V[F[:, 0]], V[F[:, 2]] - V[F[:, 0]])
    nor /= np.maximum(np.linalg.norm(nor, axis=1, keepdims=True), 1e-12)
    R = _GIRO[jaw]
    puntos, clases = [], []
    for k in range(pasadas):
        if progreso:
            progreso(f"Identificando los dientes de la arcada {'superior' if jaw == 'sup' else 'inferior'}… ({k + 1}/{pasadas})")
        idx = np.random.default_rng(k).choice(len(cen), 16000, replace=len(cen) < 16000)
        p = cen[idx] @ R.T
        p = p - p.mean(0)
        p = p / np.sqrt((p ** 2).sum(1)).max()
        x = torch.from_numpy(np.c_[p, nor[idx] @ R.T].astype(np.float32)).T.unsqueeze(0)
        with torch.no_grad():
            seg, _ = red(x)
        puntos.append(cen[idx])
        clases.append(_a_fdi(seg[0].argmax(0).numpy(), jaw))
    puntos, clases = np.vstack(puntos), np.concatenate(clases)
    # a cada vértice, la etiqueta más votada entre las 5 caras clasificadas más cercanas
    _, vec = cKDTree(puntos).query(V, k=5)
    votos = clases[vec]
    lab = np.array([np.bincount(v, minlength=50).argmax() for v in votos], np.uint8)
    return lab


def identificar(V, F, jaw, pasadas=2, progreso=None):
    """FDI por vértice (uint8, 0 = encía) de una arcada ya alineada (marco del análisis). `jaw`: «sup» o «inf»."""
    return ordenar(V, crudo(V, F, jaw, pasadas, progreso), jaw)


# anchos mesiodistales promedio (mm) por posición 1–8: (superior, inferior)
_ANCHO = {1: (8.6, 5.3), 2: (6.6, 5.9), 3: (7.6, 6.8), 4: (7.0, 7.0), 5: (6.6, 7.2), 6: (10.2, 11.1), 7: (9.3, 10.4),
          8: (8.8, 10.2)}


def _casillas(jaw):
    """Los 16 lugares de la arcada, de la derecha del paciente a la izquierda: [(FDI, posición 1–8)]."""
    der, izq = (1, 2) if jaw == "sup" else (4, 3)
    return [(der * 10 + n, n) for n in range(8, 0, -1)] + [(izq * 10 + n, n) for n in range(1, 9)]


def _arco(V, T):
    """Posición de cada vértice a lo largo de la arcada (mm; − = derecha del paciente, 0 = frente) y distancia
    al centro (para medir el grosor vestíbulo-lingual)."""
    from scipy.ndimage import gaussian_filter1d

    yc = float(np.percentile(V[T, 1], 85))
    th = np.degrees(np.arctan2(V[:, 0], -(V[:, 1] - yc)))
    rad = np.hypot(V[:, 0], V[:, 1] - yc)
    bins = np.arange(-150.0, 151.0, 2.0)
    r = np.full(len(bins), np.nan)
    for i, b in enumerate(bins):
        m = T & (th >= b - 2) & (th < b + 2)
        if m.sum() >= 25:
            r[i] = np.median(rad[m])
    ok = ~np.isnan(r)
    if ok.sum() < 6:
        return th * 0.45, rad
    ct = bins[ok]
    rs = gaussian_filter1d(np.interp(ct, ct, r[ok]), 4, mode="nearest")  # línea media de las coronas, suavizada
    cx, cy = rs * np.sin(np.radians(ct)), yc - rs * np.cos(np.radians(ct))
    largo = np.r_[0.0, np.cumsum(np.hypot(np.diff(cx), np.diff(cy)))]
    largo -= np.interp(0.0, ct, largo)
    pend = (largo[-1] - largo[0]) / max(ct[-1] - ct[0], 1e-6)
    sv = np.interp(th, ct, largo)
    sv = np.where(th < ct[0], largo[0] + (th - ct[0]) * pend, sv)
    sv = np.where(th > ct[-1], largo[-1] + (th - ct[-1]) * pend, sv)
    return sv, rad


def _corte(sv, h, rad, a, b):
    """Dónde se tocan dos dientes entre a y b (mm sobre la arcada): donde la corona es más baja y más delgada."""
    bordes = np.arange(a, b + 0.3, 0.3)
    if len(bordes) < 4:
        return 0.5 * (a + b)
    alto, grosor = [], []
    for x in bordes:
        m = (sv >= x - 0.3) & (sv < x + 0.3)
        if m.sum() < 8:
            alto.append(np.nan); grosor.append(np.nan)
            continue
        hm = h[m]
        tope = np.percentile(hm, 95)
        alto.append(tope)
        oclusal = rad[m][hm > tope - 2.5]
        grosor.append(np.percentile(oclusal, 95) - np.percentile(oclusal, 5) if len(oclusal) > 4 else np.nan)
    alto, grosor = np.array(alto), np.array(grosor)
    if np.isnan(alto).all():
        return 0.5 * (a + b)

    def norma(x):
        x = np.where(np.isnan(x), np.nanmin(x), x)
        return (x - x.min()) / max(np.ptp(x), 1e-6)
    return float(bordes[int(np.argmin(norma(alto) + norma(grosor)))])


def ordenar(V, lab, jaw):
    """Deja la propuesta de la red como dientes enteros, uno por número y en orden a lo largo de la arcada:
    separa los que la red unió, junta los pedazos de un mismo diente y numera en secuencia (un molar no puede
    llamarse premolar aunque falte un diente: cuenta el ancho de cada corona y los huecos)."""
    from scipy.spatial import cKDTree

    V = np.asarray(V, np.float64)
    lab = np.array(lab, np.uint8)
    # pedacitos con otro número (dentro de un diente o en el borde del escaneo): toman lo que tienen alrededor
    nums, cuenta = np.unique(lab[lab > 0], return_counts=True)
    if not len(nums):
        return lab
    minimo = max(150, 0.25 * float(np.median(cuenta)))
    resto = np.isin(lab, nums[cuenta < minimo])
    if resto.any() and (~resto).any():
        _, vec = cKDTree(V[~resto]).query(V[resto], k=7)
        lab[resto] = [np.bincount(v, minlength=50).argmax() for v in lab[~resto][vec]]
    T = lab > 0
    if T.sum() < 300:
        return lab
    k_jaw = 0 if jaw == "sup" else 1
    sv, rad = _arco(V, T)
    h = -V[:, 2] if jaw == "sup" else V[:, 2]
    # 1) piezas: cada número de la red, partido donde deja un hueco a lo largo de la arcada
    piezas = []
    for t in np.unique(lab[T]):
        idx = np.flatnonzero(lab == t)
        idx = idx[np.argsort(sv[idx])]
        cortes = np.flatnonzero(np.diff(sv[idx]) > 1.2)
        for parte in np.split(idx, cortes + 1):
            if len(parte) >= 120:
                piezas.append(parte)

    def tramo(idx):
        return float(np.percentile(sv[idx], 2)), float(np.percentile(sv[idx], 98))

    # 2) dos dientes que la red pintó como uno: la pieza mide mucho más que un diente → se corta donde se tocan
    finales = []
    for p in piezas:
        a, b = tramo(p)
        clase = int(np.bincount(lab[p], minlength=50).argmax()) % 10
        e = _ANCHO.get(clase, (8.0, 8.0))[k_jaw]
        ancho = b - a
        n = 1
        tope = 1.35 * e if clase in (1, 2) else max(1.4 * e, e + 3.2)
        if ancho > tope:
            n = int(max(2, round(ancho / max(e, 6.0))))
        if n == 1:
            # apiñados, dos dientes se enciman a lo largo de la arcada y no «miden» de más sobre ella: se mira
            # también su largo real en planta, y se cortan a lo largo de su propio eje
            q = V[p, :2] - V[p, :2].mean(0)
            eje = np.linalg.svd(q[:: max(1, len(q) // 2000)], full_matrices=False)[2][0]
            t = q @ eje
            t0, t1 = np.percentile(t, [2, 98])
            if t1 - t0 > max(1.35 * e, e + 3.0):
                medio = 0.5 * (t0 + t1)
                c = _corte(t, h[p], rad[p], medio - 0.22 * (t1 - t0), medio + 0.22 * (t1 - t0))
                partes = [p[t < c], p[t >= c]]
                if min(len(x) for x in partes) >= 120:
                    finales.extend(partes)
                    continue
            finales.append(p)
            continue
        cortes = []
        for j in range(1, n):
            medio = a + ancho * j / n
            cortes.append(_corte(sv[p], h[p], rad[p], medio - 0.22 * ancho / n * 2, medio + 0.22 * ancho / n * 2))
        lim = [-np.inf] + cortes + [np.inf]
        for j in range(n):
            parte = p[(sv[p] >= lim[j]) & (sv[p] < lim[j + 1])]
            if len(parte) >= 120:
                finales.append(parte)
    piezas = finales
    # 3) pedazos de un mismo diente: dos piezas que ocupan el mismo tramo de la arcada, o una muy angosta
    cambio = True
    while cambio and len(piezas) > 1:
        cambio = False
        piezas.sort(key=lambda p: np.median(sv[p]))
        tr = [tramo(p) for p in piezas]
        for i in range(len(piezas) - 1):
            (a0, a1), (b0, b1) = tr[i], tr[i + 1]
            chico = min(a1 - a0, b1 - b0)
            junto = max(a1, b1) - min(a0, b0)
            # dos pedazos de un mismo diente tienen el centro casi en el mismo sitio; dos dientes apiñados no
            cabe = min(_ANCHO.get(int(np.bincount(lab[q], minlength=50).argmax()) % 10, (8.0, 8.0))[k_jaw]
                       for q in (piezas[i], piezas[i + 1]))
            dc = float(np.linalg.norm(V[piezas[i], :2].mean(0) - V[piezas[i + 1], :2].mean(0)))
            comun = min(a1, b1) - max(a0, b0)
            if dc < 0.5 * cabe or comun > 0.6 * chico or (chico < 2.6 and junto <= 12.5):
                piezas[i] = np.concatenate([piezas[i], piezas[i + 1]])
                del piezas[i + 1]
                cambio = True
                break
    # pedacitos en el borde del escaneo (mucho más chicos que los dientes): no son un diente
    if len(piezas) > 2:
        mediana = float(np.median([len(p) for p in piezas]))
        piezas = [p for p in piezas if len(p) >= 0.3 * mediana]
    while len(piezas) > 16:  # no caben más de 16 dientes: se juntan las dos piezas con el centro más cercano
        cen = [V[p, :2].mean(0) for p in piezas]
        i = int(np.argmin([np.linalg.norm(cen[k] - cen[k + 1]) for k in range(len(piezas) - 1)]))
        piezas[i] = np.concatenate([piezas[i], piezas[i + 1]])
        del piezas[i + 1]
    # 4) numerar en secuencia: a cada pieza un lugar de la arcada, siempre avanzando de derecha a izquierda
    cas = _casillas(jaw)
    n, m = len(piezas), len(cas)
    tr = [tramo(p) for p in piezas]
    xc = [float(np.median(V[p, 0])) for p in piezas]
    pts = np.full((n, m), -1e9)
    for i, p in enumerate(piezas):
        votos = np.bincount(lab[p], minlength=50) / len(p)
        ancho = tr[i][1] - tr[i][0]
        for j, (fdi, pos) in enumerate(cas):
            e = _ANCHO[pos][k_jaw]
            v = votos[fdi] + 0.35 * sum(votos[q * 10 + pos] for q in (1, 2, 3, 4) if q * 10 + pos != fdi)
            v -= 0.9 * min(1.0, abs(ancho - e) / e)
            if not 0.6 * e <= ancho <= 1.45 * e:  # ese ancho no es de ese diente
                v -= 1.0
            lado_der = j < 8
            if (lado_der and xc[i] > 3.0) or (not lado_der and xc[i] < -3.0):
                v -= 0.6
            if pos == 8:
                v -= 0.25
            pts[i, j] = v
    mejor = np.full((n, m), -1e9)
    antes = np.zeros((n, m), int)
    mejor[0] = pts[0]
    for i in range(1, n):
        hueco = max(0.0, tr[i][0] - tr[i - 1][1])
        faltan = int(round(hueco / 7.5))
        for j in range(m):
            for q in range(j):
                salto = j - q - 1
                valor = mejor[i - 1, q] - 0.45 * abs(salto - faltan)
                if valor > mejor[i, j] - pts[i, j]:
                    mejor[i, j] = valor + pts[i, j]
                    antes[i, j] = q
    j = int(np.argmax(mejor[n - 1]))
    out = np.zeros(len(lab), np.uint8)
    for i in range(n - 1, -1, -1):
        out[piezas[i]] = cas[j][0]
        j = antes[i, j]
    return out
