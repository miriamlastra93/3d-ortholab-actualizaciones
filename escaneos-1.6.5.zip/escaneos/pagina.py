"""Módulo «Análisis de modelos» (exclusivo 3D OrthoLab): los escaneos intraorales de los pacientes del doctor.

- El doctor recibe un Paquete 3D OrthoLab (.3dol) por WhatsApp, correo o Drive: lo arrastra aquí (o «Abrir
  paquete…») y queda en su biblioteca. Solo abren paquetes firmados por 3D OrthoLab y hechos para esta computadora;
  no hay «Abrir STL»: los escaneos de otros escáneres no entran.
- Tres pestañas: «Modelos», «Análisis» (lo calcula esta app en la computadora del doctor) e «Informe PDF».
- Sobre el visor, como en MetronTrack: el panel «Modelos» (mostrar u ocultar cada arcada, transparencia, zócalo,
  color real, apertura) y, abajo, las vistas rápidas con íconos.
- En «Análisis»: overjet/overbite, corte de oclusión con un plano que se arrastra, contactos, Korkhaus, espacio y
  Bolton, Moyers y arcada. Con la separación de dientes del escáner, cada diente se pinta al pasar el mouse y
  muestra su número y su ancho.
- «Medir»: regla de dos clics sobre el modelo.
- En la PC de la Dra. (donde está su llave de firma) aparecen además «Enviar al doctor…» y «Vista previa de una
  carpeta…».
"""
from __future__ import annotations

import json
import os
import shutil
import time

import numpy as np
from PySide6 import QtCore, QtGui, QtWidgets
from PySide6.QtCore import Qt

from . import analisis as AN
from . import orientacion as O
from . import paquete as PQ
from .panel_analisis import GraficaCorte, PanelAnalisis, Trabajador

TURQ = "#1995AD"
BIBLIOTECA = os.path.join(os.path.expanduser("~"), "Documents", "3D OrthoLab Studio", "Escaneos")
COLOR_SUP, COLOR_INF = "#F1ECE2", "#E9E2D4"
ROJO, VERDE, AZUL, AMBAR = "#e5534b", "#2f9e4f", "#2f7fd6", "#d99a1a"
VERDE_MD = "#35b558"


def _palomita() -> str:
    """Imagen de la palomita de las casillas (los estilos de Qt la piden como archivo)."""
    import tempfile

    ruta = os.path.join(tempfile.gettempdir(), "ortholab-palomita.png")
    if not os.path.exists(ruta):
        pm = QtGui.QPixmap(36, 36)
        pm.fill(Qt.transparent)
        q = QtGui.QPainter(pm)
        q.setRenderHint(QtGui.QPainter.Antialiasing)
        q.setPen(QtGui.QPen(QtGui.QColor("white"), 5, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        q.drawPolyline([QtCore.QPointF(8, 19), QtCore.QPointF(15, 26), QtCore.QPointF(28, 10)])
        q.end()
        pm.save(ruta)
    return ruta.replace("\\", "/")


def _estilo_flotante() -> str:
    return ("QFrame#flot{background:#f4f6f8;border:1px solid #d5dbe1;border-radius:12px;}"
            "QFrame#flot QLabel{color:#2b3440;background:transparent;}"
            "QFrame#flot QCheckBox{color:#2b3440;background:transparent;spacing:8px;}"
            "QFrame#flot QCheckBox::indicator{width:18px;height:18px;border-radius:4px;border:2px solid #9aa5b1;"
            "background:#ffffff;}"
            f"QFrame#flot QCheckBox::indicator:checked{{background:#1677ff;border-color:#1677ff;image:url({_palomita()});}}"
            "QFrame#flot QCheckBox::indicator:disabled{background:#e4e8ec;border-color:#c9d1d9;}"
            "QFrame#flot QSlider::groove:horizontal{height:4px;background:#a9cdf6;border-radius:2px;}"
            "QFrame#flot QSlider::sub-page:horizontal{background:#1677ff;border-radius:2px;}"
            "QFrame#flot QSlider::add-page:horizontal{background:#c9d3dc;border-radius:2px;}"
            "QFrame#flot QSlider::handle:horizontal{width:14px;height:14px;margin:-7px 0;border-radius:9px;"
            "background:#ffffff;border:3px solid #5b6570;}"
            "QFrame#flot QToolButton{border:none;border-radius:8px;background:transparent;color:#2b3440;padding:4px 8px;}"
            "QFrame#flot QToolButton:hover{background:#e3eef2;}QFrame#flot QToolButton:pressed{background:#c9e3ea;}"
            "QFrame#flot QToolButton:checked{background:#1677ff;color:white;}")


def _icono_arcada(jaw, n=44):
    """Miniatura de la arcada (la que controla cada renglón del panel «Modelos»)."""
    pm = QtGui.QPixmap(n, int(n * 0.72))
    pm.fill(Qt.transparent)
    q = QtGui.QPainter(pm)
    q.setRenderHint(QtGui.QPainter.Antialiasing)
    h = pm.height()
    for cual, y, curva in (("sup", h * 0.30, 5), ("inf", h * 0.66, 5)):
        activo = cual == jaw
        q.setPen(QtGui.QPen(QtGui.QColor("#f08a8a" if activo else "#d7dce1"), 9 if activo else 7, Qt.SolidLine, Qt.RoundCap))
        cam = QtGui.QPainterPath()
        cam.moveTo(6, y)
        cam.quadTo(n / 2, y + curva, n - 6, y)
        q.drawPath(cam)
        q.setPen(QtGui.QPen(QtGui.QColor("#ffffff" if activo else "#eef1f4"), 4, Qt.DotLine, Qt.RoundCap))
        cam2 = QtGui.QPainterPath()
        cam2.moveTo(8, y + (2 if cual == "sup" else -2))
        cam2.quadTo(n / 2, y + curva + (2 if cual == "sup" else -2), n - 8, y + (2 if cual == "sup" else -2))
        q.drawPath(cam2)
    q.end()
    return pm


def _muted(t):
    lb = QtWidgets.QLabel(t)
    lb.setWordWrap(True)
    lb.setStyleSheet("color:#8b949e;font-size:9pt;")
    return lb


def _segmentado(nombres, al_elegir, inicial=0):
    w = QtWidgets.QWidget()
    h = QtWidgets.QHBoxLayout(w)
    h.setContentsMargins(0, 0, 0, 0)
    h.setSpacing(4)
    g = QtWidgets.QButtonGroup(w)
    for i, n in enumerate(nombres):
        b = QtWidgets.QPushButton(n)
        b.setCheckable(True)
        b.setStyleSheet(f"QPushButton{{padding:4px 12px;border-radius:12px;}}"
                        f"QPushButton:checked{{background:{TURQ};border:none;color:white;font-weight:600;}}")
        g.addButton(b, i)
        h.addWidget(b)
    g.button(inicial).setChecked(True)
    g.idClicked.connect(al_elegir)
    w.grupo = g
    return w


def puede_enviar() -> bool:
    """¿Está aquí la llave de firma de la Dra.? (solo en su computadora)."""
    return os.path.exists(os.path.join(os.path.expanduser("~"), ".ortholab-studio", "llave_privada.pem"))


def _traslacion(x=0.0, y=0.0, z=0.0):
    T = np.eye(4)
    T[:3, 3] = (x, y, z)
    return T


ROT_X180 = np.diag([1.0, -1.0, -1.0, 1.0])
NIVEL_COLOR = {0: "#2e9e5b", 1: "#d39b1c", 2: "#e07b22", 3: "#d64541"}
# colores propios de las relaciones oclusales: superior coral, inferior violeta (los dientes, en turquesa)
COLOR_REL_SUP, COLOR_REL_INF = "#f2643d", "#6c5ce7"
# dientes que se pintan en cada relación oclusal (como MetronTrack)
DIENTES_RELACION = {"molar": {"sup": (16, 26), "inf": (46, 36)},
                    "canina": {"sup": (13, 23), "inf": (43, 33, 44, 34)},
                    }
# color de cada diente en «Dientes» según su posición (1 central … 8 tercer molar), como en MetronTrack
COLOR_DIENTE = {1: (236, 190, 212), 2: (128, 45, 98), 3: (240, 205, 60), 4: (196, 222, 214), 5: (28, 120, 128),
                6: (190, 205, 222), 7: (90, 125, 200), 8: (150, 150, 160)}


# vistas que sirven en cada análisis; las demás se bloquean (como en MetronTrack)
_OCLUSALES = ("separadas", "oclusal_sup", "oclusal_inf")
_LATERALES = ("frente", "derecha", "izquierda")
VISTAS_DE = {"overjet": _LATERALES, "lmedia": _LATERALES, "molar": ("derecha", "izquierda"),
             "canina": ("derecha", "izquierda"), "corte": _LATERALES + ("atras", "oclusal_sup", "oclusal_inf"),
             "contactos": _OCLUSALES, "korkhaus": _OCLUSALES, "espacio": _OCLUSALES, "bolton": _OCLUSALES,
             "moyers": _OCLUSALES, "arcada": _OCLUSALES, "forma": _OCLUSALES, "longitud": _OCLUSALES,
             "simetria": _OCLUSALES, "dientes": _OCLUSALES}


def nombre_punto(nombre: str) -> str:
    """Qué es anatómicamente cada punto que se arrastra (p. ej. «molar_der_sup»)."""
    partes = nombre.split("_")
    if partes[0] == "lm":
        return "Línea media superior (entre 11 y 21)" if partes[1] == "sup" else "Línea media inferior (entre 41 y 31)"
    cual, lado, arc = partes
    der = lado == "der"
    if cual == "molar":
        return (f"Cúspide mesiovestibular del primer molar superior ({16 if der else 26})" if arc == "sup" else
                f"Surco mesiovestibular del primer molar inferior ({46 if der else 36})")
    return (f"Cúspide del canino superior ({13 if der else 23})" if arc == "sup" else
            f"Tronera entre el canino y el primer premolar inferiores ({'43 y 44' if der else '33 y 34'})")


def _icono_vista(vista):
    ic = QtGui.QIcon()
    ic.addPixmap(_dibujo_vista(vista, "#3d4753"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
    ic.addPixmap(_dibujo_vista(vista, "#ffffff"), QtGui.QIcon.Normal, QtGui.QIcon.On)
    ic.addPixmap(_dibujo_vista(vista, "#c9d0d7"), QtGui.QIcon.Disabled, QtGui.QIcon.Off)
    return ic


def _dibujo_vista(vista, color="#3d4753", n=56):
    """Íconos de las vistas rápidas (arcadas dibujadas, como en MetronTrack)."""
    pm = QtGui.QPixmap(n, n)
    pm.fill(Qt.transparent)
    p = QtGui.QPainter(pm)
    p.setRenderHint(QtGui.QPainter.Antialiasing)
    c = QtGui.QColor(color)
    gruesa = QtGui.QPen(c, 7, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
    p.setPen(gruesa)

    def u(cx, cy, rx, ry, abajo=True):  # arcada por oclusal
        cam = QtGui.QPainterPath()
        s = 1 if abajo else -1
        cam.moveTo(cx - rx, cy - s * ry)
        cam.cubicTo(cx - rx, cy + s * ry * 1.7, cx + rx, cy + s * ry * 1.7, cx + rx, cy - s * ry)
        p.drawPath(cam)

    def banda(y, curva):  # arcada vista de frente
        cam = QtGui.QPainterPath()
        cam.moveTo(8, y)
        cam.quadTo(28, y + curva, 48, y)
        p.drawPath(cam)

    if vista == "frente":
        banda(20, 6)
        banda(36, 6)
    elif vista == "atras":
        banda(22, -6)
        banda(38, -6)
    elif vista in ("derecha", "izquierda"):
        if vista == "izquierda":
            p.translate(n, 0)
            p.scale(-1, 1)
        for y in (20, 36):
            cam = QtGui.QPainterPath()
            cam.moveTo(10, y + 4)
            cam.quadTo(14, y - 3, 30, y - 1)
            cam.lineTo(48, y)
            p.drawPath(cam)
    elif vista == "separadas":
        p.setPen(QtGui.QPen(c, 5, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        u(15, 28, 9, 9, abajo=False)
        u(41, 28, 9, 9, abajo=True)
    elif vista == "oclusal_sup":
        u(28, 30, 17, 12, abajo=False)
    elif vista == "oclusal_inf":
        u(28, 26, 17, 12, abajo=True)
    p.end()
    return pm


class AnalisisModelos(QtWidgets.QWidget):
    volver = QtCore.Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.caso = None          # {"info", "modelos", "informe", "datos"}
        self.ruta_caso = None     # el .3dol en la biblioteca (para guardar las correcciones del doctor)
        self.id_caso = None
        self.marco = None
        self._actores = {}
        self._mallas = {}
        self._v0 = {}
        self._plotter = None
        self._pdf_buf = None
        self.vis = {"sup": True, "inf": True}     # arcadas visibles
        self.opac = {"sup": 1.0, "inf": 1.0}      # transparencia de cada arcada
        self.modo = 0             # 0 Modelos · 1 Análisis · 2 Informe
        # análisis
        self.an = None            # analisis.Caso cuando termina el cálculo
        self._an_roles = None     # {"sup": rol, "inf": rol} de las mallas analizadas
        self._an_act = {}
        self._an_malla = {}
        self._an_base = {}        # color de cada vértice sin resaltar
        self._trazos = []
        self._asas = []           # puntos que se arrastran con el mouse
        self._arrastre = None
        # recuadro con solo los dientes de la relación (clase molar / canina), para acomodar sus puntos
        self._rel = {}            # lo dibujado por lado: dientes, rectas, puntos y asas
        self._mini = None         # su visor 3D (se crea la primera vez)
        self._mini_lado = "der"
        self._mini_clave = None
        self._mini_actores = []
        self._mini_act = {"sup": [], "inf": []}
        self._mini_asas = []
        self._mini_arrastre = None
        self._mini_visible = False
        self._regla = []          # puntos y actores de «Medir»
        self.disp = "junto"       # junto · separadas
        self._acomodo = {"sup": np.eye(4), "inf": np.eye(4)}  # cómo acomodó el doctor cada arcada (vista separada)
        self._acom = None         # arcada que se está acomodando sola (doble clic sobre ella)
        self._acom_pos = None
        self._pose_cache = {}
        self._clic = None         # None · "medir" · "punto"
        self._press = None
        self._mov = None
        self._gen = 0             # para descartar análisis de un caso que ya se cerró
        self._hilo = None
        self._hover = None        # (arcada, FDI) resaltado
        self._hover_act = None
        self._corte_activo = False
        self._corte_plano = "diente"   # diente (a través del diente, perpendicular a la arcada) · sagital · transversal
        self._corte_valor = None
        self._corte_act = []
        self._corte_mallas = {}
        self._corte_ultimo = None
        self._armar()
        self._cargar_biblioteca()

    # ------------------------------------------------------------------ interfaz
    def _armar(self):
        v = QtWidgets.QVBoxLayout(self)
        v.setContentsMargins(18, 12, 18, 10)
        top = QtWidgets.QHBoxLayout()
        b = QtWidgets.QPushButton("← Inicio")
        b.clicked.connect(self.volver.emit)
        top.addWidget(b)
        t = QtWidgets.QLabel("Análisis de modelos")
        t.setStyleSheet("font-size:17pt;font-weight:700;")
        top.addSpacing(10)
        top.addWidget(t)
        sub = QtWidgets.QLabel("escaneos de tus pacientes · exclusivo 3D OrthoLab")
        sub.setStyleSheet(f"color:{TURQ};font-size:10pt;")
        top.addWidget(sub, 0, Qt.AlignBottom)
        top.addStretch(1)
        if puede_enviar():
            b_prev = QtWidgets.QPushButton("Vista previa de una carpeta…")
            b_prev.setToolTip("Ver un caso directo de su carpeta (solo en tu computadora)")
            b_prev.clicked.connect(self.vista_previa)
            top.addWidget(b_prev)
            b_env = QtWidgets.QPushButton("Enviar al doctor…")
            b_env.setObjectName("primary")
            b_env.clicked.connect(self.enviar)
            top.addWidget(b_env)
        b_abrir = QtWidgets.QPushButton("Abrir paquete…")
        b_abrir.clicked.connect(self.abrir_dialogo)
        top.addWidget(b_abrir)
        v.addLayout(top)

        cuerpo = QtWidgets.QHBoxLayout()
        # izquierda: código del equipo y biblioteca
        self.izq = izq = QtWidgets.QFrame()
        izq.setFixedWidth(300)
        izq.setStyleSheet("QFrame#izq{background:#1b1f25;border-radius:12px;}")
        izq.setObjectName("izq")
        iv = QtWidgets.QVBoxLayout(izq)
        iv.setContentsMargins(14, 12, 14, 12)
        h = QtWidgets.QLabel("Código de este equipo")
        h.setStyleSheet("font-weight:700;")
        iv.addWidget(h)
        iv.addWidget(_muted("Mándaselo a 3D OrthoLab una sola vez: tus casos llegarán hechos para esta computadora."))
        self.e_codigo = QtWidgets.QLineEdit()
        self.e_codigo.setReadOnly(True)
        self.e_codigo.setStyleSheet("font-family:Consolas;font-size:9pt;")
        try:
            self.e_codigo.setText(PQ.codigo_equipo())
        except Exception as exc:  # noqa: BLE001
            self.e_codigo.setText(f"(no disponible: {exc})")
            try:  # que quede el detalle en el registro de la app, para poder arreglarlo
                import sys
                import traceback

                from ..ortholab import reparar

                reparar.anotar("Análisis de modelos: no se pudo generar el código de equipo",
                               traceback.format_exc() + "\nejecutable: " + sys.executable + "\nsys.path:\n  "
                               + "\n  ".join(sys.path))
            except Exception:  # noqa: BLE001
                pass
            self.e_codigo.setToolTip("A esta instalación le falta un componente. Reinstala 3D OrthoLab Studio con su "
                                     "instalador más reciente." if isinstance(exc, ImportError) else str(exc))
        iv.addWidget(self.e_codigo)
        b_cp = QtWidgets.QPushButton("Copiar código")
        b_cp.clicked.connect(lambda: (QtGui.QGuiApplication.clipboard().setText(self.e_codigo.text()),
                                      b_cp.setText("Copiado ✓")))
        iv.addWidget(b_cp)
        iv.addSpacing(12)
        h = QtWidgets.QLabel("Mis casos")
        h.setStyleSheet("font-weight:700;")
        iv.addWidget(h)
        self.lista = QtWidgets.QListWidget()
        self.lista.setStyleSheet("QListWidget{background:#11161c;border:none;border-radius:8px;}"
                                 "QListWidget::item{padding:8px;border-bottom:1px solid #222a33;}")
        self.lista.itemClicked.connect(lambda it: self.abrir_archivo(it.data(Qt.UserRole)))
        iv.addWidget(self.lista, 1)
        iv.addWidget(_muted("Arrastra aquí el archivo .3dol que te mandó 3D OrthoLab."))
        cuerpo.addWidget(izq)

        # derecha: título, pestañas, visor / informe
        der = QtWidgets.QVBoxLayout()
        fila = QtWidgets.QHBoxLayout()
        self.titulo = QtWidgets.QLabel("Abre un caso para verlo en 3D")
        self.titulo.setStyleSheet("font-size:14pt;font-weight:600;")
        fila.addWidget(self.titulo, 1)
        self.b_medir = QtWidgets.QPushButton("📏 Medir")
        self.b_medir.setCheckable(True)
        self.b_medir.setToolTip("Haz clic en dos puntos del modelo para medir la distancia en mm")
        self.b_medir.setStyleSheet(f"QPushButton:checked{{background:{TURQ};color:white;}}")
        self.b_medir.toggled.connect(lambda on: self.modo_clic("medir" if on else None))
        fila.addWidget(self.b_medir)
        fila.addSpacing(10)
        self.seg_modo = _segmentado(["Modelos", "Análisis", "Informe PDF"], self._elegir_modo, 0)
        fila.addWidget(self.seg_modo)
        der.addLayout(fila)
        self.pila = QtWidgets.QStackedWidget()
        w3d = QtWidgets.QWidget()
        v3 = QtWidgets.QVBoxLayout(w3d)
        v3.setContentsMargins(0, 6, 0, 0)
        zona = QtWidgets.QHBoxLayout()
        zona.setSpacing(0)  # la barra de análisis va pegada al visor
        self.caja3d = QtWidgets.QVBoxLayout()
        self.vacio = QtWidgets.QLabel("Aquí verás los modelos del escaneo\n\nArrastra aquí el paquete .3dol"
                                      + ("\no la carpeta del escaneo (o sus STL / PLY)" if puede_enviar() else ""))
        self.vacio.setAlignment(Qt.AlignCenter)
        self.vacio.setStyleSheet("color:#8b949e;font-size:13pt;border:2px dashed #3a414b;border-radius:14px;")
        self.caja3d.addWidget(self.vacio, 1)
        zona.addLayout(self.caja3d, 1)
        self.panel = PanelAnalisis(self)
        self.panel.setVisible(False)
        zona.addWidget(self.panel)
        v3.addLayout(zona, 1)
        pie = QtWidgets.QHBoxLayout()
        self.l_aviso = QtWidgets.QLabel("")
        self.l_aviso.setStyleSheet("color:#e3b341;font-size:9pt;")
        pie.addWidget(self.l_aviso, 1)
        marca = QtWidgets.QLabel("Escaneado por 3D OrthoLab · Dra. Miriam Lastra")
        marca.setStyleSheet(f"color:{TURQ};font-size:9pt;")
        pie.addWidget(marca)
        v3.addLayout(pie)
        self.pila.addWidget(w3d)
        try:  # el visor de PDF de Qt (las apps instaladas antes de este módulo pueden no traerlo)
            from PySide6.QtPdf import QPdfDocument
            from PySide6.QtPdfWidgets import QPdfView

            self.pdf = QPdfDocument(self)
            self.pdf_view = QPdfView()
            self.pdf_view.setDocument(self.pdf)
            self.pdf_view.setPageMode(QPdfView.PageMode.MultiPage)
            self.pdf_view.setZoomMode(QPdfView.ZoomMode.FitToWidth)
            self.pila.addWidget(self.pdf_view)
        except ImportError:
            self.pdf = None
            aviso = QtWidgets.QLabel("Para ver aquí el informe, actualiza 3D OrthoLab Studio con su instalador más reciente.")
            aviso.setAlignment(Qt.AlignCenter)
            aviso.setWordWrap(True)
            aviso.setStyleSheet("color:#8b949e;font-size:12pt;")
            self.pila.addWidget(aviso)
        der.addWidget(self.pila, 1)
        cuerpo.addLayout(der, 1)
        v.addLayout(cuerpo, 1)
        self._armar_flotantes(w3d)
        self._ajustar_controles()

    def _armar_flotantes(self, padre):
        """Panel «Modelos» y barra de vistas, flotando sobre el visor (se colocan en _colocar_flotantes)."""
        self.capas = c = QtWidgets.QFrame(padre)
        c.setObjectName("flot")
        c.setStyleSheet(_estilo_flotante())
        c.setAttribute(Qt.WA_NativeWindow)  # ventana propia: el 3D no la tapa
        cv = QtWidgets.QVBoxLayout(c)
        cv.setContentsMargins(12, 10, 12, 10)
        cv.setSpacing(6)
        cab = QtWidgets.QHBoxLayout()
        t = QtWidgets.QLabel("Modelos")
        t.setStyleSheet("font-weight:700;font-size:10pt;")
        cab.addWidget(t, 1)
        self.b_plegar = QtWidgets.QToolButton()
        self.b_plegar.setText("▴")
        self.b_plegar.clicked.connect(self._plegar_capas)
        cab.addWidget(self.b_plegar)
        cv.addLayout(cab)
        self.capas_cuerpo = cuerpo = QtWidgets.QWidget()
        cuerpo.setStyleSheet("background:transparent;")
        g = QtWidgets.QGridLayout(cuerpo)
        g.setContentsMargins(0, 0, 0, 0)
        g.setVerticalSpacing(6)
        self.cb_arc, self.sl_arc = {}, {}
        for i, (jaw, nombre) in enumerate((("sup", "Superior"), ("inf", "Inferior"))):
            cb = QtWidgets.QCheckBox(nombre)
            cb.setChecked(True)
            cb.toggled.connect(lambda on, jaw=jaw: self._capa_cambiada(jaw, on))
            sl = QtWidgets.QSlider(Qt.Horizontal)
            sl.setRange(10, 100)
            sl.setValue(100)
            sl.setFixedWidth(110)
            sl.setToolTip(f"Transparencia de la arcada {nombre.lower()}")
            sl.valueChanged.connect(lambda val, jaw=jaw: self._opacidad_cambiada(jaw, val))
            mini = QtWidgets.QLabel()
            mini.setPixmap(_icono_arcada(jaw))
            g.addWidget(cb, i, 0)
            g.addWidget(mini, i, 1)
            g.addWidget(sl, i, 2)
            self.cb_arc[jaw], self.sl_arc[jaw] = cb, sl
        self.cb_zocalo = QtWidgets.QCheckBox("Con zócalo")
        self.cb_zocalo.setToolTip("Modelo de estudio con zócalo, o el escaneo tal cual (a color)")
        self.cb_zocalo.toggled.connect(self._zocalo_cambiado)
        g.addWidget(self.cb_zocalo, 2, 0, 1, 2)
        self.cb_color = QtWidgets.QCheckBox("Color real")
        self.cb_color.setChecked(True)
        self.cb_color.toggled.connect(self._color_cambiado)
        g.addWidget(self.cb_color, 2, 2)
        self.l_ap = QtWidgets.QLabel("Abrir la boca")
        g.addWidget(self.l_ap, 3, 0, 1, 2)
        self.sl_ap = QtWidgets.QSlider(Qt.Horizontal)
        self.sl_ap.setRange(0, 30)
        self.sl_ap.setFixedWidth(110)
        self.sl_ap.setToolTip("Abre la boca girando la arcada inferior en bisagra")
        self.sl_ap.valueChanged.connect(lambda _: self._aplicar_apertura())
        g.addWidget(self.sl_ap, 3, 2)
        cv.addWidget(cuerpo)
        c.hide()

        self.barra_vistas = bvw = QtWidgets.QFrame(padre)
        bvw.setObjectName("flot")
        bvw.setStyleSheet(_estilo_flotante() + "QFrame#flot{border-radius:24px;}")
        bvw.setAttribute(Qt.WA_NativeWindow)
        bh = QtWidgets.QHBoxLayout(bvw)
        bh.setContentsMargins(14, 5, 14, 5)
        bh.setSpacing(4)
        self.vistas = {}
        self.g_vistas = QtWidgets.QButtonGroup(bvw)
        for nombre, vista in (("Desde atrás (lingual)", "atras"), ("Oclusal superior", "oclusal_sup"),
                              ("Derecha del paciente", "derecha"), ("Frente", "frente"),
                              ("Izquierda del paciente", "izquierda"), ("Oclusal inferior", "oclusal_inf"),
                              ("Las dos arcadas por oclusal, lado a lado", "separadas")):
            b = QtWidgets.QToolButton()
            b.setIcon(_icono_vista(vista))
            b.setIconSize(QtCore.QSize(30, 30))
            b.setToolTip(nombre)
            b.setCursor(Qt.PointingHandCursor)
            b.setFixedSize(40, 38)
            b.setCheckable(True)
            self.g_vistas.addButton(b)
            b.clicked.connect(lambda _=False, vista=vista: self.camara(vista))
            bh.addWidget(b)
            self.vistas[vista] = b
        bvw.hide()

        # gráfica del corte de oclusión, a la izquierda del modelo (como «Visualización de la oclusión»)
        self.flot_corte = fc = QtWidgets.QFrame(padre)
        fc.setObjectName("flot")
        fc.setStyleSheet(_estilo_flotante())
        fc.setAttribute(Qt.WA_NativeWindow)
        fv = QtWidgets.QVBoxLayout(fc)
        fv.setContentsMargins(8, 6, 8, 8)
        fv.setSpacing(4)
        self.l_corte = QtWidgets.QLabel("Corte")
        self.l_corte.setStyleSheet("font-weight:700;font-size:10pt;")
        fv.addWidget(self.l_corte)
        barra = QtWidgets.QHBoxLayout()
        barra.setSpacing(2)
        self.b_corte = {}
        for clave, texto, ayuda in (("diente", "Por el diente", "Corta a través del diente (de vestibular a lingual)"),
                                    ("sagital", "Sagital", "Corte de adelante hacia atrás"),
                                    ("transversal", "Transversal", "Corte de lado a lado"),
                                    ("grande", "⤢", "Agrandar o achicar la gráfica")):
            b = QtWidgets.QToolButton()
            b.setText(texto)
            b.setToolTip(ayuda)
            b.setCursor(Qt.PointingHandCursor)
            if clave == "grande":
                b.clicked.connect(self._agrandar_corte)
                barra.addStretch(1)
            else:
                b.setCheckable(True)
                b.clicked.connect(lambda _=False, clave=clave: self.poner_corte(clave))
            barra.addWidget(b)
            self.b_corte[clave] = b
        fv.addLayout(barra)
        self.grafica = GraficaCorte()
        self.grafica.setMinimumHeight(0)
        self.grafica.setFixedSize(350, 290)
        fv.addWidget(self.grafica)
        fila = QtWidgets.QHBoxLayout()
        fila.addWidget(QtWidgets.QLabel("Mover"))
        self.sl_corte = QtWidgets.QSlider(Qt.Horizontal)
        self.sl_corte.setRange(0, 1000)
        self.sl_corte.setToolTip("Recorre el corte a lo largo de la arcada")
        self.sl_corte.valueChanged.connect(self._corte_barra)
        fila.addWidget(self.sl_corte, 1)
        fv.addLayout(fila)
        ayuda = QtWidgets.QLabel("Haz clic en un diente del modelo y el corte pasa por ahí.")
        ayuda.setWordWrap(True)
        ayuda.setStyleSheet("color:#5b6570;font-size:8pt;")
        fv.addWidget(ayuda)
        fc.hide()

        # recuadro de la relación: solo los dientes, en gris, con sus puntos (como el de MetronTrack)
        self.flot_mini = fm = QtWidgets.QFrame(padre)
        fm.setObjectName("flot")
        fm.setStyleSheet(_estilo_flotante())
        fm.setAttribute(Qt.WA_NativeWindow)
        self.mini_caja = mv = QtWidgets.QVBoxLayout(fm)
        mv.setContentsMargins(8, 6, 8, 8)
        mv.setSpacing(4)
        cab = QtWidgets.QHBoxLayout()
        cab.setSpacing(2)
        t = QtWidgets.QLabel("Acomodar puntos")
        t.setStyleSheet("font-weight:700;font-size:10pt;")
        cab.addWidget(t)
        cab.addStretch(1)
        self.b_mini = {}
        for clave, texto, ayuda in (("der", "Derecha", "Lado derecho del paciente"),
                                    ("izq", "Izquierda", "Lado izquierdo del paciente"),
                                    ("auto", "⟲", "Regresar los puntos a lo automático"),
                                    ("grande", "⤢", "Agrandar o achicar el recuadro")):
            b = QtWidgets.QToolButton()
            b.setText(texto)
            b.setToolTip(ayuda)
            b.setCursor(Qt.PointingHandCursor)
            if clave in ("der", "izq"):
                b.setCheckable(True)
                b.clicked.connect(lambda _=False, lado=clave: self._mini_elegir(lado))
            elif clave == "auto":
                b.clicked.connect(lambda: self.panel._restablecer())
            else:
                b.clicked.connect(self._mini_agrandar)
            cab.addWidget(b)
            self.b_mini[clave] = b
        mv.addLayout(cab)
        self.mini_hueco = QtWidgets.QWidget()
        self.mini_hueco.setFixedSize(330, 250)
        hl = QtWidgets.QVBoxLayout(self.mini_hueco)
        hl.setContentsMargins(0, 0, 0, 0)
        mv.addWidget(self.mini_hueco)
        self.l_mini = QtWidgets.QLabel("")
        self.l_mini.setWordWrap(True)
        self.l_mini.setTextFormat(Qt.RichText)
        self.l_mini.setStyleSheet("font-size:9pt;")
        self.l_mini.setFixedWidth(330)
        mv.addWidget(self.l_mini)
        ayuda = QtWidgets.QLabel("Arrastra el punto coral o el violeta. Con la rueda acercas; arrastrando fuera de los "
                                 "puntos giras los dientes.")
        ayuda.setWordWrap(True)
        ayuda.setStyleSheet("color:#5b6570;font-size:8pt;")
        ayuda.setFixedWidth(330)
        mv.addWidget(ayuda)
        fm.hide()
        padre.installEventFilter(self)
        self._padre3d = padre

    @staticmethod
    def _raton_metron(pl):
        """El modelo se mueve como en MetronTrack: girar con el botón izquierdo o el derecho, desplazar con el
        central (o izquierdo + derecho a la vez, ver eventFilter) y acercar con la rueda."""
        try:
            pl.enable_custom_trackball_style(left="rotate", middle="pan", right="rotate")
        except Exception:  # noqa: BLE001  (versión de pyvista sin este estilo: queda el de siempre)
            pass

    def _dos_botones(self, obj, ev):
        """Izquierdo + derecho a la vez = desplazar el modelo (como MetronTrack). True si el evento era de eso."""
        pl = self._plotter if obj is self._plotter.interactor else self._mini
        try:
            estilo = pl.iren.interactor.GetInteractorStyle()
        except Exception:  # noqa: BLE001
            return False
        ambos = Qt.LeftButton | Qt.RightButton
        tipo = ev.type()
        if tipo == QtCore.QEvent.MouseButtonPress and (ev.buttons() & ambos) == ambos:
            estilo.EndRotate()
            estilo.StartPan()
            self._pan2 = obj
            self._press = None  # no es un clic
            return True
        if getattr(self, "_pan2", None) is obj and tipo == QtCore.QEvent.MouseButtonRelease:
            estilo.EndPan()
            if not (ev.buttons() & ambos):
                self._pan2 = None
            return True
        return False

    def eventFilter(self, obj, ev):
        if obj is getattr(self, "_padre3d", None) and ev.type() in (QtCore.QEvent.Resize, QtCore.QEvent.Show):
            QtCore.QTimer.singleShot(0, self._colocar_flotantes)
        elif (self._plotter is not None and obj is self._plotter.interactor
              and ev.type() in (QtCore.QEvent.MouseButtonDblClick, QtCore.QEvent.MouseButtonPress,
                                QtCore.QEvent.MouseMove, QtCore.QEvent.MouseButtonRelease)
              and (self._acom is not None or ev.type() == QtCore.QEvent.MouseButtonDblClick)
              and self._acomodar_evento(obj, ev)):
            return True
        elif (self._plotter is not None and ev.type() in (QtCore.QEvent.MouseButtonPress, QtCore.QEvent.MouseButtonRelease)
              and (obj is self._plotter.interactor or (self._mini is not None and obj is self._mini.interactor))
              and self._arrastre is None and self._dos_botones(obj, ev)):
            return True
        elif (self._mini is not None and obj is self._mini.interactor
              and ev.type() in (QtCore.QEvent.MouseButtonPress, QtCore.QEvent.MouseMove, QtCore.QEvent.MouseButtonRelease)):
            if self._mini_evento(obj, ev):
                return True
        elif (self._plotter is not None and obj is self._plotter.interactor and self._asas and self._clic is None
              and ev.type() in (QtCore.QEvent.MouseButtonPress, QtCore.QEvent.MouseMove, QtCore.QEvent.MouseButtonRelease)
              and self._arrastrar(obj, ev)):
            return True  # se está arrastrando un punto: la cámara no gira
        elif (self._plotter is not None and obj is self._plotter.interactor
              and ev.type() == QtCore.QEvent.MouseMove and not ev.buttons()):
            # el mouse pasa sobre el modelo (a nivel de Qt: no depende de los eventos de VTK)
            r = obj.devicePixelRatioF()
            pos = ev.position()
            self._mov = (int(pos.x() * r), int((obj.height() - pos.y() - 1) * r))
            if not self._t_hover.isActive():
                self._t_hover.start()
        elif (self._plotter is not None and obj is self._plotter.interactor and ev.button() == Qt.LeftButton
              if ev.type() in (QtCore.QEvent.MouseButtonPress, QtCore.QEvent.MouseButtonRelease) else False):
            # clics sobre el modelo, también a nivel de Qt (no se consumen: la cámara sigue girando)
            r = obj.devicePixelRatioF()
            pos = ev.position()
            x, y = int(pos.x() * r), int((obj.height() - pos.y() - 1) * r)
            if ev.type() == QtCore.QEvent.MouseButtonPress:
                self._press = (x, y)
            else:
                self._soltar(x, y)
        return super().eventFilter(obj, ev)

    def _arrastrar(self, obj, ev):
        """Arrastre de un punto (asa) sobre el diente. Devuelve True si el evento era del arrastre."""
        r = obj.devicePixelRatioF()
        pos = ev.position()
        x, y = int(pos.x() * r), int((obj.height() - pos.y() - 1) * r)
        tipo = ev.type()
        if tipo == QtCore.QEvent.MouseButtonPress:
            if ev.button() != Qt.LeftButton:
                return False
            asa = self._asa_bajo(x, y)
            if asa is None:
                return False
            self._arrastre = asa
            self._press = None
            obj.setCursor(Qt.ClosedHandCursor)
            return True
        if self._arrastre is None:
            if tipo == QtCore.QEvent.MouseMove and not ev.buttons():  # avisar que el punto se puede agarrar
                bajo = self._asa_bajo(x, y)
                obj.setCursor(Qt.OpenHandCursor if bajo is not None else Qt.ArrowCursor)
                self._decir_punto(obj, bajo)
            return False
        asa = self._arrastre
        if asa.get("solo_x"):  # la línea media sigue al cursor de lado, con su plano (sin depender del modelo)
            ren = self._plotter.renderer
            ren.SetWorldPoint(asa["pos"][0], asa["pos"][1], asa["pos"][2], 1.0)
            ren.WorldToDisplay()
            ren.SetDisplayPoint(float(x), float(y), ren.GetDisplayPoint()[2])
            ren.DisplayToWorld()
            wx, _wy, _wz, ww = ren.GetWorldPoint()
            self._mover_asa(asa, [wx / (ww or 1.0), 0.0, 0.0])
            self._plotter.render()
        else:
            jaw, p, _ = self._picar(x, y, solo=asa["jaw"])  # se desliza sobre su propia arcada
            if jaw == asa["jaw"] and p is not None:
                self._mover_asa(asa, p)
                self._plotter.render()
        if tipo == QtCore.QEvent.MouseButtonRelease:
            self._arrastre = None
            obj.setCursor(Qt.ArrowCursor)
            q = AN.inversa(self._D(asa["jaw"])) @ np.r_[asa["pos"], 1.0]
            punto = asa["punto"]

            def aplicar():
                self.panel.punto_activo = punto
                self.panel.mover_punto(punto[0], q[0], q[1], q[2])
                self.panel.punto_activo = None
            QtCore.QTimer.singleShot(0, aplicar)
        return True

    def _decir_punto(self, obj, asa):
        """Al pasar el mouse sobre un punto: su nombre anatómico (en un globo y en la línea de avisos)."""
        nombre = nombre_punto(asa["punto"][2]) if asa is not None and asa["punto"][1] == "aj" else ""
        if nombre != getattr(self, "_punto_dicho", ""):
            self._punto_dicho = nombre
            if nombre:
                QtWidgets.QToolTip.showText(QtGui.QCursor.pos(), nombre + ". Arrástralo para acomodarlo.", obj)
                self.l_aviso.setText(nombre)
            else:
                QtWidgets.QToolTip.hideText()
                self.l_aviso.setText("")

    def _colocar_flotantes(self):
        if self._plotter is None:
            return
        g = self._plotter.interactor.geometry()
        org = self._plotter.interactor.mapTo(self._padre3d, QtCore.QPoint(0, 0))
        self.capas.adjustSize()
        self.capas.move(org.x() + 14, org.y() + 14)
        self.barra_vistas.adjustSize()
        libre = g.width() - (self.flot_mini.width() + 14 if self._mini_visible and self.modo == 1 else 0)
        self.barra_vistas.move(org.x() + max(8, (libre - self.barra_vistas.width()) // 2),
                               org.y() + g.height() - self.barra_vistas.height() - 14)  # sin tapar el recuadro
        self.flot_corte.adjustSize()
        self.flot_corte.move(org.x() + 14, min(self.capas.y() + self.capas.height() + 10,
                                               max(org.y() + 14, org.y() + g.height() - self.flot_corte.height() - 14)))
        hay = self.caso is not None and self.modo != 2
        self.flot_mini.adjustSize()
        self.flot_mini.move(org.x() + g.width() - self.flot_mini.width() - 14,
                            org.y() + g.height() - self.flot_mini.height() - 14)
        for w, radio, ver in ((self.capas, 12, hay), (self.barra_vistas, 24, hay),
                              (self.flot_corte, 12, hay and self._corte_activo),
                              (self.flot_mini, 12, hay and self.modo == 1 and self._mini_visible)):
            cam = QtGui.QPainterPath()  # esquinas redondas de verdad (son ventanas propias sobre el 3D)
            cam.addRoundedRect(QtCore.QRectF(w.rect()), radio, radio)
            w.setMask(QtGui.QRegion(cam.toFillPolygon().toPolygon()))
            w.setVisible(ver)
            w.raise_()

    def _agrandar_corte(self):
        grande = self.grafica.width() < 400
        self.grafica.setFixedSize(*((560, 470) if grande else (350, 290)))
        self._colocar_flotantes()

    def _plegar_capas(self):
        ver = not self.capas_cuerpo.isVisible()
        self.capas_cuerpo.setVisible(ver)
        self.b_plegar.setText("▴" if ver else "▾")
        self._colocar_flotantes()

    def aviso(self, texto, ms=6000):
        self.l_aviso.setText(texto)
        QtCore.QTimer.singleShot(ms, lambda t=texto: self.l_aviso.text() == t and self.l_aviso.setText(""))

    # ------------------------------------------------------------------ pestañas
    def _elegir_modo(self, i):
        self.modo = i
        self.pila.setCurrentIndex(1 if i == 2 else 0)
        self.modo_clic(None)
        self._ajustar_controles()
        if i != 1:
            self._mini_ocultar()
        if i == 0:
            self._quitar_corte()
            self._limpiar_trazos()
            self._resaltar(None)
            self._mostrar_an(False)
            self.disp = "junto"
            self._mostrar_mallas()
            self.camara("frente")
        elif i == 1:
            self.sl_ap.setValue(0)
            if self.an is not None:
                self._mostrar_mallas()  # oculta los actores de «Modelos»
                self.panel.mostrar(self.panel.actual)
            elif self.caso is not None and self._hilo is None and self._an_roles is None:
                self.panel.esperando("Este caso no tiene los dos modelos (superior e inferior) para analizar.")
        QtCore.QTimer.singleShot(0, self._colocar_flotantes)

    def _vistas_disponibles(self):
        """Bloquea las vistas que no sirven en lo que se está viendo (como MetronTrack)."""
        if self.modo == 1 and self.an is not None:
            ok = VISTAS_DE.get(self.panel.vista)
            if not self.an.etiquetas and self.panel.actual != "corte":
                ok = _LATERALES + ("atras", "oclusal_sup", "oclusal_inf")
        else:
            ok = _LATERALES + ("atras", "oclusal_sup", "oclusal_inf")  # «Modelos»: todo menos «separadas»
        for vista, b in self.vistas.items():
            b.setEnabled(ok is None or vista in ok)

    def _marcar_vista(self, vista):
        b = self.vistas.get(vista)
        if b is not None:
            b.setChecked(True)

    def _ajustar_controles(self):
        an = self.modo == 1
        self.panel.setVisible(an)
        self.izq.setVisible(not an)  # más espacio para el modelo y la tarjeta
        self._vistas_disponibles()
        for w in (self.l_ap, self.sl_ap):
            w.setVisible(not an)
        self.b_medir.setVisible(self.modo != 2)

    # ------------------------------------------------------------------ biblioteca
    def _indice(self) -> dict:
        try:
            with open(os.path.join(BIBLIOTECA, "indice.json"), encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            return {}

    def _guardar_indice(self, d):
        os.makedirs(BIBLIOTECA, exist_ok=True)
        with open(os.path.join(BIBLIOTECA, "indice.json"), "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=1)

    def _cargar_biblioteca(self):
        self.lista.clear()
        idx = self._indice()
        if not os.path.isdir(BIBLIOTECA):
            return
        archivos = sorted((f for f in os.listdir(BIBLIOTECA) if f.lower().endswith(PQ.EXT)),
                          key=lambda f: -os.path.getmtime(os.path.join(BIBLIOTECA, f)))
        for f in archivos:
            info = idx.get(f, {})
            texto = info.get("paciente") or os.path.splitext(f)[0]
            extra = " · ".join(x for x in (info.get("fecha_escaneo"), info.get("doctor")) if x)
            it = QtWidgets.QListWidgetItem(texto + (f"\n{extra}" if extra else ""))
            it.setData(Qt.UserRole, os.path.join(BIBLIOTECA, f))
            self.lista.addItem(it)

    def _ruta_de(self, mime):
        """Lo que se puede soltar aquí: un paquete .3dol (cualquiera) o, solo en la PC de la Dra., la carpeta del
        escaneo o sus archivos STL/PLY (se abre la vista previa de su carpeta)."""
        rutas = [u.toLocalFile() for u in mime.urls()] if mime.hasUrls() else []
        for r in rutas:
            if r and r.lower().endswith(PQ.EXT) and os.path.isfile(r):
                return r
        if puede_enviar():
            for r in rutas:
                if r and os.path.isdir(r):
                    return r
            for r in rutas:
                if r and os.path.isfile(r) and r.lower().endswith((".stl", ".ply")):
                    return os.path.dirname(r)
        return None

    def dragEnterEvent(self, e):
        if self._ruta_de(e.mimeData()):
            e.acceptProposedAction()

    def dragMoveEvent(self, e):
        if self._ruta_de(e.mimeData()):
            e.acceptProposedAction()

    def dropEvent(self, e):
        r = self._ruta_de(e.mimeData())
        if r:
            e.acceptProposedAction()
            if os.path.isdir(r):  # carpeta del escaneo (solo la Dra.): vista previa
                QtCore.QTimer.singleShot(0, lambda: self._previa(r))
            else:
                self.importar(r)

    def abrir_dialogo(self):
        r, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Abrir paquete 3D OrthoLab", os.path.expanduser("~"),
                                                     "Paquete 3D OrthoLab (*.3dol)")
        if r:
            self.importar(r)

    def importar(self, ruta):
        """Abre el paquete (si es válido y para este equipo) y lo guarda en la biblioteca."""
        if not self.abrir_archivo(ruta):
            return
        os.makedirs(BIBLIOTECA, exist_ok=True)
        destino = os.path.join(BIBLIOTECA, os.path.basename(ruta))
        if os.path.abspath(destino) != os.path.abspath(ruta):
            shutil.copy2(ruta, destino)
        self.ruta_caso = destino
        idx = self._indice()
        info = dict(self.caso.get("info") or {})
        info["recibido"] = time.strftime("%Y-%m-%d")
        idx[os.path.basename(destino)] = info
        self._guardar_indice(idx)
        self._cargar_biblioteca()

    def abrir_archivo(self, ruta) -> bool:
        QtWidgets.QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            with open(ruta, "rb") as f:
                datos = f.read()
            caso = PQ.abrir(datos)
            id_caso = str(PQ.encabezado(datos).get("caso_id") or "")[:32]
        except PQ.ErrorPaquete as exc:
            QtWidgets.QApplication.restoreOverrideCursor()
            QtWidgets.QMessageBox.warning(self, "Análisis de modelos", str(exc))
            return False
        except Exception as exc:  # noqa: BLE001
            QtWidgets.QApplication.restoreOverrideCursor()
            QtWidgets.QMessageBox.warning(self, "Análisis de modelos", f"No se pudo abrir el paquete:\n{exc}")
            return False
        QtWidgets.QApplication.restoreOverrideCursor()
        self.ruta_caso = ruta if os.path.dirname(os.path.abspath(ruta)) == os.path.abspath(BIBLIOTECA) else None
        self.id_caso = "".join(ch for ch in id_caso if ch.isalnum()) or None
        self.mostrar_caso(caso)
        return True

    # ------------------------------------------------------------------ visor
    def mostrar_caso(self, caso: dict):
        self.caso = caso
        info = caso.get("info") or {}
        partes = [info.get("paciente") or "Caso"]
        if info.get("fecha_escaneo"):
            partes.append(info["fecha_escaneo"])
        if info.get("doctor"):
            partes.append(info["doctor"])
        self.titulo.setText(" · ".join(partes))
        mods = caso.get("modelos") or {}
        tiene_sin = any(r.endswith("sin_zocalo") for r in mods)
        tiene_con = any(r.endswith("con_zocalo") for r in mods)
        self.cb_zocalo.setEnabled(tiene_sin and tiene_con)
        self.cb_zocalo.blockSignals(True)
        # si el caso trae el escaneo a color, abre con él (luce más); si solo trae los zocalados, con esos
        con_color = any(c is not None for r, (_, _, c) in mods.items() if r.endswith("sin_zocalo"))
        self.cb_zocalo.setChecked(tiene_con and not (tiene_sin and con_color))
        self.cb_zocalo.blockSignals(False)
        self.cb_color.setEnabled(any(c is not None for _, _, c in mods.values()))
        ref = {r: v for r, (v, _, _) in mods.items()}
        sup = ref.get("superior_sin_zocalo", ref.get("superior_con_zocalo"))
        inf = ref.get("inferior_sin_zocalo", ref.get("inferior_con_zocalo"))
        self.marco = O.marco(sup, inf)
        self._v0 = {r: v for r, (v, _, _) in mods.items()}
        self.sl_ap.blockSignals(True)
        self.sl_ap.setValue(0)
        self.sl_ap.blockSignals(False)
        self._preparar_plotter()
        self._quitar_analisis()
        self._poner_capas(True, True)
        for jaw in ("sup", "inf"):
            self.sl_arc[jaw].setValue(100)
        self._mostrar_mallas(nueva=True)
        self.disp = "junto"
        self.camara("frente")
        self._pdf_buf = None
        if self.pdf is None:
            self.seg_modo.grupo.button(2).setEnabled(bool(caso.get("informe")))
        elif caso.get("informe"):
            self._pdf_buf = QtCore.QBuffer(self)
            self._pdf_buf.setData(QtCore.QByteArray(caso["informe"]))
            self._pdf_buf.open(QtCore.QIODevice.ReadOnly)
            self.pdf.load(self._pdf_buf)
            self.seg_modo.grupo.button(2).setEnabled(True)
        else:
            self.pdf.close()
            self.seg_modo.grupo.button(2).setEnabled(False)
        if self.modo == 2 and not caso.get("informe"):
            self.seg_modo.grupo.button(0).click()
        self._analizar()
        QtCore.QTimer.singleShot(0, self._colocar_flotantes)

    def _preparar_plotter(self):
        if self._plotter is not None:
            return
        from pyvistaqt import QtInteractor

        self.vacio.hide()
        self._plotter = QtInteractor(self)
        self._plotter.set_background("#dfe5ea", top="#fbfcfd")  # claro, como MetronTrack
        self._plotter.enable_anti_aliasing("ssaa")
        self._plotter.interactor.setAcceptDrops(False)  # lo que se suelte sobre el 3D lo recibe esta página
        self.caja3d.addWidget(self._plotter.interactor, 1)
        # clics (sin arrastrar) para «Medir» y mover puntos; movimiento para resaltar el diente bajo el mouse
        self._t_hover = QtCore.QTimer(self)
        self._t_hover.setSingleShot(True)
        self._t_hover.setInterval(45)
        self._t_hover.timeout.connect(self._al_pasar)
        it = self._plotter.iren.interactor
        it.AddObserver("MouseMoveEvent", self._al_mover, 1.0)
        self._plotter.interactor.setMouseTracking(True)
        self._plotter.interactor.installEventFilter(self)
        self._raton_metron(self._plotter)

    # --- capas: qué arcada se ve y con cuánta transparencia
    def _poner_capas(self, sup, inf):
        for jaw, on in (("sup", sup), ("inf", inf)):
            self.vis[jaw] = on
            self.cb_arc[jaw].blockSignals(True)
            self.cb_arc[jaw].setChecked(on)
            self.cb_arc[jaw].blockSignals(False)

    def _capa_cambiada(self, jaw, on):
        self.vis[jaw] = on
        self._aplicar_capas()

    def _opacidad_cambiada(self, jaw, val):
        self.opac[jaw] = val / 100.0
        self._aplicar_capas()

    def _aplicar_capas(self):
        if self._plotter is None:
            return
        if self.modo == 1 and self.an is not None:
            for jaw, a in self._an_act.items():
                a.SetVisibility(self.vis[jaw])
                a.GetProperty().SetOpacity(self.opac[jaw])
            self._ver_trazos()
            if self._corte_activo and self._corte_ultimo:  # la gráfica del corte solo muestra las arcadas visibles
                self._corte_movido(*self._corte_ultimo)
            self._plotter.render()
        else:
            self._mostrar_mallas()

    def _zocalo_cambiado(self, _):
        self._mostrar_mallas()
        if self.caso is not None and self._plotter is not None:  # el análisis se hace sobre el modelo que se ve
            self._quitar_analisis()
            self._analizar()

    def _color_cambiado(self, _):
        if self.modo == 1 and self.an is not None:
            self._resaltar(None)
            self._mostrar_an(True, contacto=self.panel.actual == "contactos")
            self._plotter.render()
        else:
            self._mostrar_mallas()

    def _mostrar_mallas(self, nueva=False):
        import pyvista as pv

        if self._plotter is None or not self.caso:
            return
        mods = self.caso["modelos"]
        if nueva:
            for a in self._actores.values():
                self._plotter.remove_actor(a)
            self._actores, self._mallas = {}, {}
        con = self.cb_zocalo.isChecked()
        for rol, (v, f, col) in mods.items():
            arc = "superior" if rol.startswith("superior") else "inferior"
            jaw = "sup" if arc == "superior" else "inf"
            visible = (rol.endswith("con_zocalo") == con) and self.vis[jaw]
            if rol.endswith("con_zocalo") and f"{arc}_sin_zocalo" not in mods:
                visible = self.vis[jaw]
            if self.modo == 1 and self.an is not None:
                visible = False  # en «Análisis» se ven las mallas analizadas, en el marco del análisis
            usar_color = col is not None and self.cb_color.isChecked()
            clave = (rol, usar_color)
            if rol not in self._mallas:
                self._mallas[rol] = pv.PolyData(np.asarray(v, np.float32),
                                                np.hstack([np.full((len(f), 1), 3), f]).astype(np.int64))
                if col is not None:
                    self._mallas[rol]["rgb"] = np.asarray(col, np.uint8)
            if rol in self._actores and getattr(self._actores[rol], "_clave", None) != clave:
                self._plotter.remove_actor(self._actores.pop(rol))
            if rol not in self._actores:
                if usar_color:
                    a = self._plotter.add_mesh(self._mallas[rol], scalars="rgb", rgb=True, smooth_shading=True,
                                               specular=0.25, specular_power=20, reset_camera=False)
                else:
                    a = self._plotter.add_mesh(self._mallas[rol], color=COLOR_SUP if arc == "superior" else COLOR_INF,
                                               smooth_shading=True, specular=0.35, specular_power=25,
                                               reset_camera=False)
                a._clave = clave
                self._actores[rol] = a
            self._actores[rol].SetVisibility(visible)
            self._actores[rol].GetProperty().SetOpacity(self.opac[jaw])
        self._aplicar_apertura()

    def _aplicar_apertura(self):
        if not self._mallas or self.marco is None:
            return
        g = float(self.sl_ap.value())
        inf_ref = self._v0.get("inferior_sin_zocalo", self._v0.get("inferior_con_zocalo"))
        if inf_ref is None:
            return
        punto, eje = O.bisagra(self.marco, inf_ref)
        # sentido: que los incisivos inferiores bajen al abrir
        frente = inf_ref[np.argmax((inf_ref - self.marco["centro"]) @ self.marco["adel"])]
        prueba = O.rotar(frente[None], punto, eje, 5.0)[0]
        signo = -1.0 if np.dot(prueba - frente, self.marco["arriba"]) > 0 else 1.0
        for rol, malla in self._mallas.items():
            if rol.startswith("inferior"):
                malla.points = self._v0[rol] if g == 0 else O.rotar(self._v0[rol], punto, eje, signo * g)
        self._plotter.render()

    def camara(self, vista):
        if self._plotter is None:
            return
        if self.modo == 1 and self.an is not None:
            if self.panel.vista in ("molar", "canina") and vista in ("derecha", "izquierda")                     and ("der" if vista == "derecha" else "izq") in self._rel:
                self._mini_elegir("der" if vista == "derecha" else "izq")  # cambia de lado y se acerca
                return
            self._camara_analisis(vista)
            return
        if self.marco is None:
            return
        m = self.marco
        c = m["centro"]
        if vista == "separadas":
            vista = "oclusal_sup"
        self._marcar_vista(vista)
        d, up = {"frente": (m["adel"], m["arriba"]), "atras": (-m["adel"], m["arriba"]),
                 "derecha": (m["der"], m["arriba"]),
                 "izquierda": (-m["der"], m["arriba"]), "oclusal_sup": (-m["arriba"], m["adel"]),
                 "oclusal_inf": (m["arriba"], m["adel"])}[vista]
        # por oclusal se ve una sola arcada; en las demás vistas, las dos
        self._poner_capas(vista != "oclusal_inf", vista != "oclusal_sup")
        self._mostrar_mallas()
        self._plotter.camera.parallel_projection = False
        self._plotter.camera_position = [tuple(c + d * 200), tuple(c), tuple(up)]
        self._plotter.reset_camera()
        self._plotter.camera.zoom(1.15)
        self._plotter.render()

    # ------------------------------------------------------------------ análisis: cálculo
    def _quitar_analisis(self):
        self._gen += 1
        self._mini_ocultar()
        self._mini_clave = None
        self._quitar_corte()
        self._resaltar(None)
        self.an = None
        self._an_roles = None
        self._limpiar_trazos()
        self._limpiar_regla()
        for a in self._an_act.values():
            self._plotter.remove_actor(a)
        self._an_act, self._an_malla, self._an_base = {}, {}, {}

    def _analizar(self):
        mods = self.caso.get("modelos") or {}
        roles = None
        orden = ("con_zocalo", "sin_zocalo") if self.cb_zocalo.isChecked() else ("sin_zocalo", "con_zocalo")
        for tipo in orden:  # el modelo que el doctor está viendo
            if f"superior_{tipo}" in mods and f"inferior_{tipo}" in mods:
                roles = {"sup": f"superior_{tipo}", "inf": f"inferior_{tipo}"}
                break
        if roles is None:
            self.panel.esperando("Este caso no tiene los dos modelos (superior e inferior) para analizar.")
            return
        self._an_roles = roles
        self._an_tipo = "z" if roles["sup"].endswith("con_zocalo") else "c"
        datos = self.caso.get("datos") or {}
        AD = datos.get("accudesign") or {}
        dientes = PQ.leer_dientes(datos, mods)
        etiquetas = {jaw: dientes.get(rol) for jaw, rol in roles.items()}
        self._dientes_locales = False
        if puede_enviar():
            # la numeración que la Dra. identificó con IA y revisó en esta computadora (si no hay de MetronTrack)
            loc = {jaw: PQ.dientes_locales(mods[rol][0]) for jaw, rol in roles.items()}
            if all(e is not None for e in loc.values()) and all(
                    etiquetas[j] is None or np.array_equal(etiquetas[j], loc[j]) for j in loc):
                etiquetas, self._dientes_locales = loc, True
        sup = mods[roles["sup"]][:2]
        inf = mods[roles["inf"]][:2]
        self.panel.esperando("Analizando el caso… (unos segundos)")
        hilo = QtCore.QThread(self)
        trab = Trabajador(sup, inf, AD.get("anchos"), AD, self._gen, etiquetas)
        trab.moveToThread(hilo)
        hilo.started.connect(trab.correr)
        # métodos de este widget: Qt los llama en el hilo de la interfaz
        trab.progreso.connect(self._an_progreso)
        trab.listo.connect(self._analisis_listo)
        trab.fallo.connect(self._an_fallo)
        trab.listo.connect(hilo.quit)
        trab.fallo.connect(hilo.quit)
        hilo.finished.connect(trab.deleteLater)
        hilo.finished.connect(hilo.deleteLater)
        self._hilo = hilo
        self._trabajadores = getattr(self, "_trabajadores", [])[-3:] + [trab]  # que no los recoja el recolector
        hilo.start()

    def _an_progreso(self, texto, gen):
        if gen == self._gen:
            self.panel.esperando(texto)

    def _an_fallo(self, texto, gen):
        if gen == self._gen:
            self._hilo = None
            self.panel.esperando(texto)

    def _analisis_listo(self, caso, gen):
        if gen != self._gen:
            return
        self._hilo = None
        self.an = caso
        self._cargar_ediciones()
        self.panel.poner_caso(caso)
        if self.modo == 1:
            self._mostrar_mallas()
        else:  # el panel dibujó su primer análisis: se guarda hasta que el doctor entre a «Análisis»
            self._quitar_corte()
            self._limpiar_trazos()
            self._mostrar_an(False)
            self._plotter.render()

    # ------------------------------------------------------------------ identificar los dientes con IA (la Dra.)
    def identificar_ia(self):
        from .panel_analisis import TrabajadorIA

        if self.an is None or getattr(self, "_hilo", None) is not None:
            return
        self.panel.esperando("Preparando la identificación de dientes…")
        hilo = QtCore.QThread(self)
        trab = TrabajadorIA(self.an, self._gen)
        trab.moveToThread(hilo)
        hilo.started.connect(trab.correr)
        trab.progreso.connect(self._an_progreso)
        trab.listo.connect(self._ia_lista)
        trab.fallo.connect(self._ia_fallo)
        trab.listo.connect(hilo.quit)
        trab.fallo.connect(hilo.quit)
        hilo.finished.connect(trab.deleteLater)
        hilo.finished.connect(hilo.deleteLater)
        self._hilo = hilo
        self._trabajadores = getattr(self, "_trabajadores", [])[-3:] + [trab]
        hilo.start()

    def _ia_fallo(self, texto, gen):
        if gen != self._gen:
            return
        self._hilo = None
        self.panel.poner_caso(self.an)
        QtWidgets.QMessageBox.warning(self, "Análisis de modelos", texto)

    def _ia_lista(self, etiquetas, gen):
        if gen != self._gen:
            return
        self._hilo = None
        if not any((e > 0).any() for e in etiquetas.values()):
            self._ia_fallo("La IA no encontró dientes en este escaneo.", gen)
            return
        self.an.etiquetas = {j: np.array(e, np.uint8) for j, e in etiquetas.items()}
        self.an._etiquetas0 = {j: e.copy() for j, e in self.an.etiquetas.items()}
        self.an.renombres = []
        self.an.reproponer()
        derecho = AN.realinear(self.an)  # con los dientes ya se puede enderezar un escaneo que quedó girado
        if derecho is not self.an:
            for a in self._an_act.values():
                self._plotter.remove_actor(a)
            self._an_act, self._an_malla, self._an_base = {}, {}, {}
            self._limpiar_trazos()
            self.an = derecho
        self._dientes_locales = True
        self.guardar_dientes()
        self.guardar_ediciones()
        self.panel.actual = "dientes"
        self.panel.poner_caso(self.an)
        if self.modo == 1:
            self._mostrar_mallas()

    def guardar_dientes(self):
        """La numeración identificada con IA (y lo que la Dra. le corrige) se guarda con el modelo, en esta PC:
        así sigue ahí al volver a abrir el caso y viaja en el paquete para el doctor."""
        if not getattr(self, "_dientes_locales", False) or self.an is None:
            return
        try:
            mods = self.caso.get("modelos") or {}
            for jaw, rol in self._an_roles.items():
                if jaw in self.an.etiquetas:
                    PQ.guardar_dientes_locales(mods[rol][0], self.an.etiquetas[jaw])
            self.an.renombres = []  # ya van dentro de la numeración guardada
        except Exception:  # noqa: BLE001
            pass

    # correcciones del doctor (puntos y anchos), guardadas cifradas con la protección de Windows
    def _ruta_ediciones(self):
        if not self.ruta_caso or not self.id_caso:
            return None
        return os.path.join(BIBLIOTECA, "analisis", f"{self.id_caso}-{getattr(self, '_an_tipo', 'z')}.bin")

    def guardar_ediciones(self):
        r = self._ruta_ediciones()
        if not r or self.an is None:
            return
        try:
            os.makedirs(os.path.dirname(r), exist_ok=True)
            d = json.dumps({"P": self.an.P, "anchos": self.an.anchos, "fuente": self.an.anchos_fuente,
                            "criterio": self.an.criterio, "renombres": self.an.renombres}).encode()
            with open(r, "wb") as f:
                f.write(PQ._dpapi(d, True))
        except Exception:  # noqa: BLE001  (si no se puede guardar, el análisis sigue funcionando)
            pass

    def _cargar_ediciones(self):
        r = self._ruta_ediciones()
        if not r or not os.path.exists(r):
            return
        try:
            with open(r, "rb") as f:
                d = json.loads(PQ._dpapi(f.read(), False))
            for cambio in d.get("renombres") or []:  # correcciones del doctor a la separación de dientes
                self.an.aplicar_cambio(cambio)
            self.an.renombres = [list(x) for x in d.get("renombres") or []]
            self.an.criterio = dict(d.get("criterio") or {})
            self.an.P = d["P"]
            self.an.P.setdefault("ajustes", {})
            self.an.P.setdefault("md", {})
            self.an.anchos = {k: float(v) for k, v in d["anchos"].items()}
            self.an.anchos_fuente = d.get("fuente", self.an.anchos_fuente)
        except Exception:  # noqa: BLE001
            pass

    # ------------------------------------------------------------------ análisis: dibujo
    def _pose(self, jaw):
        """(P, medio ancho): la arcada sola y derecha — su cara oclusal de frente, su línea media vertical y
        centrada en sus dientes — para la vista de las dos arcadas lado a lado. No cambia ninguna medida."""
        an = self.an
        lab = an.etiquetas.get(jaw)
        clave = (id(an), jaw, id(lab))
        if clave in self._pose_cache:
            return self._pose_cache[clave]
        V = (an.U if jaw == "sup" else an.L).astype(np.float64)
        R, c = np.eye(3), None
        tips = {}
        if lab is not None:
            for t in np.unique(lab):
                Vt = V[lab == t]
                if not t or len(Vt) < 150:
                    continue
                z = Vt[:, 2]
                mesa = Vt[z < z.min() + 2.0] if jaw == "sup" else Vt[z > z.max() - 2.0]
                n = int(t) - (40 if t > 50 else 0)
                tips[n] = mesa.mean(0)
        if len(tips) >= 4:
            Pt = np.array(list(tips.values()))
            if len(Pt) >= 5:
                _, sv, vt = np.linalg.svd(Pt - Pt.mean(0), full_matrices=False)
                n = vt[2] if vt[2][2] > 0 else -vt[2]
                if sv[1] > 12.0 and n[2] > 0.8:  # su propio plano oclusal, de frente
                    v = np.cross(n, [0, 0, 1.0])
                    vx = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
                    R = np.eye(3) + vx + vx @ vx / (1 + n[2])
            der, izq = (1, 2) if jaw == "sup" else (4, 3)
            pares = [(tips[der * 10 + k], tips[izq * 10 + k]) for k in range(1, 8)
                     if der * 10 + k in tips and izq * 10 + k in tips]
            if len(pares) >= 2:  # los dientes homólogos quedan a la misma altura: la arcada, derecha
                d = np.array([(R @ b - R @ a)[:2] for a, b in pares])
                d = d[np.linalg.norm(d, axis=1) > 4.0]
                if len(d) >= 2:
                    u = (d / np.linalg.norm(d, axis=1, keepdims=True)).mean(0)
                    g = np.arctan2(u[1], u[0])
                    if abs(g) < np.radians(45):
                        R = np.array([[np.cos(-g), -np.sin(-g), 0], [np.sin(-g), np.cos(-g), 0], [0, 0, 1.0]]) @ R
            Q = Pt @ R.T
            x0 = (float(np.mean([0.5 * (R @ a + R @ b)[0] for a, b in pares])) if pares
                  else 0.5 * float(Q[:, 0].min() + Q[:, 0].max()))
            c = np.array([x0, 0.5 * float(Q[:, 1].min() + Q[:, 1].max()), float(Q[:, 2].mean())])
        else:  # sin los dientes identificados: centrada en sus coronas
            corona = V[np.abs(V[:, 2]) < 8.0][::10]
            if len(corona) < 50:
                corona = V[::10]
            c = np.array([0.5 * float(corona[:, 0].min() + corona[:, 0].max()),
                          0.5 * float(corona[:, 1].min() + corona[:, 1].max()), 0.0])
        # en pantalla se centra el modelo entero (su contorno), no solo sus dientes: así las dos arcadas quedan a
        # la misma altura y a la misma distancia del centro aunque una traiga mucho paladar o aletas largas
        W = V[::15] @ R.T
        x0, x1 = np.percentile(W[:, 0], [0.5, 99.5])
        y0, y1 = np.percentile(W[:, 1], [0.5, 99.5])
        c = np.array([0.5 * (x0 + x1), 0.5 * (y0 + y1), c[2]])
        P = np.eye(4)
        P[:3, :3] = R
        P[:3, 3] = -c
        medio = 0.5 * float(x1 - x0)
        self._pose_cache = {k: v for k, v in self._pose_cache.items() if k[0] == id(an)}
        self._pose_cache[clave] = (P, medio)
        return P, medio

    def _D(self, jaw):
        """Transformación de presentación (marco del análisis → pantalla) de cada arcada."""
        if self.disp != "separadas" or self.an is None:
            return np.eye(4)
        P, _ = self._pose(jaw)
        dx = max(self._pose("sup")[1], self._pose("inf")[1]) + 4.0
        base = _traslacion(-dx) @ ROT_X180 @ P if jaw == "sup" else _traslacion(dx) @ P
        return self._acomodo[jaw] @ base

    # ------------------------------------------------------------------ acomodar una arcada sola (doble clic)
    def _acomodar_evento(self, obj, ev):
        """En la vista de las dos arcadas: doble clic sobre una la deja «agarrada» y el ratón la mueve solo a
        ella (girar: izquierdo o derecho; mover: central o los dos botones). Doble clic fuera, terminar."""
        tipo = ev.type()
        r = obj.devicePixelRatioF()
        pos = ev.position()
        x, y = pos.x() * r, pos.y() * r
        if tipo == QtCore.QEvent.MouseButtonDblClick:
            if ev.button() != Qt.LeftButton or self.modo != 1 or self.an is None:
                return False
            self._clic_gen = getattr(self, "_clic_gen", 0) + 1  # el primer clic no era para elegir un diente
            jaw = self._picar(int(x), int(obj.height() * r - y - 1))[0]
            if jaw is not None and self.disp != "separadas":
                self.aviso("Para acomodar una arcada sola, usa la vista de las dos arcadas por oclusal "
                           "(último botón de vistas).")
                return True
            self._acom = jaw
            self._acom_pos = None
            self._press = None
            if jaw is None:
                self.aviso("Listo: las arcadas quedan como las acomodaste.", 3000)
            else:
                self.aviso(f"Acomodando la arcada {'superior' if jaw == 'sup' else 'inferior'}: arrástrala para "
                           "girarla; con el botón central (o los dos botones) la mueves. La otra no se mueve. "
                           "Doble clic fuera del modelo para terminar.", 20000)
            return True
        if self._acom is None or self.disp != "separadas" or self.an is None:
            self._acom = None
            return False
        jaw = self._acom
        if tipo == QtCore.QEvent.MouseButtonPress:
            self._acom_pos = (x, y)
            self._press = None
            for a in self._trazos:  # sus trazos se vuelven a dibujar al soltar
                if getattr(a, "_jaw", None) == jaw:
                    a.SetVisibility(False)
            self._resaltar(None)
            return True
        if tipo == QtCore.QEvent.MouseMove:
            if self._acom_pos is None or not ev.buttons():
                return bool(ev.buttons())
            dx, dy = x - self._acom_pos[0], y - self._acom_pos[1]
            self._acom_pos = (x, y)
            cam = self._plotter.camera
            p, f = np.array(cam.position), np.array(cam.focal_point)
            v = (f - p) / max(np.linalg.norm(f - p), 1e-9)
            der = np.cross(v, np.array(cam.up))
            der /= max(np.linalg.norm(der), 1e-9)
            arr = np.cross(der, v)
            b = ev.buttons()
            ambos = Qt.LeftButton | Qt.RightButton
            if (b & Qt.MiddleButton) or (b & ambos) == ambos:  # mover
                alto = (2.0 * cam.parallel_scale if cam.parallel_projection
                        else 2.0 * np.linalg.norm(f - p) * np.tan(np.radians(cam.view_angle) / 2))
                mm = alto / max(obj.height() * r, 1)
                M = _traslacion(*((der * dx - arr * dy) * mm))
            else:  # girar alrededor del centro de sus dientes
                def giro(eje, grados):
                    t = np.radians(grados)
                    K = np.array([[0, -eje[2], eje[1]], [eje[2], 0, -eje[0]], [-eje[1], eje[0], 0]])
                    return np.eye(3) + np.sin(t) * K + (1 - np.cos(t)) * K @ K
                Rm = np.eye(4)
                Rm[:3, :3] = giro(arr, dx * 0.35) @ giro(der, dy * 0.35)
                c = (self._D(jaw) @ AN.inversa(self._pose(jaw)[0]))[:3, 3]
                M = _traslacion(*c) @ Rm @ _traslacion(*(-c))
            self._acomodo[jaw] = M @ self._acomodo[jaw]
            if jaw in self._an_act:
                self._an_act[jaw].user_matrix = self._D(jaw)
            self._plotter.render()
            return True
        if tipo == QtCore.QEvent.MouseButtonRelease:
            if not ev.buttons():
                self._acom_pos = None
                self.panel.mostrar(self.panel.actual, mover_camara=False)  # los trazos, en su nuevo lugar
            return True
        return False

    def _a_pantalla(self, jaw, P):
        P = np.atleast_2d(np.asarray(P, np.float64))
        D = self._D(jaw)
        return P @ D[:3, :3].T + D[:3, 3]

    def _mostrar_an(self, si, contacto=False):
        """Las mallas analizadas (una por arcada), coloreadas por vértice: contactos, color real o marfil."""
        import pyvista as pv

        if self.an is None or self._plotter is None:
            return
        mods = self.caso["modelos"]
        for jaw in ("sup", "inf"):
            rol = self._an_roles[jaw]
            col = mods[rol][2]
            modo = "contacto" if contacto else ("color" if col is not None and self.cb_color.isChecked() else "liso")
            if modo != "contacto" and self.modo == 1 and self.panel.vista == "dientes":
                modo = "dientes-" + modo
            elif modo != "contacto" and self.modo == 1 and self.panel.vista in DIENTES_RELACION:
                modo = f"relacion-{self.panel.vista}-{modo}"
            V = self.an.U if jaw == "sup" else self.an.L
            if jaw not in self._an_act:
                if not si:
                    continue
                F = self.an.FU if jaw == "sup" else self.an.FL
                m = pv.PolyData(V, np.hstack([np.full((len(F), 1), 3), F]).astype(np.int64))
                m["rgb"] = np.zeros((len(V), 3), np.uint8)
                a = self._plotter.add_mesh(m, scalars="rgb", rgb=True, smooth_shading=True, specular=0.3,
                                           specular_power=22, reset_camera=False, pickable=True)
                a._modo = None
                self._an_act[jaw], self._an_malla[jaw] = a, m
            a = self._an_act[jaw]
            if a._modo != modo:
                if modo == "contacto":
                    C = self.an.contactos()[jaw]
                    base = AN.colores_contacto(C["d"], C["occl"])
                elif modo.endswith("color"):
                    base = np.asarray(col, np.uint8)
                else:
                    c = QtGui.QColor(COLOR_SUP if jaw == "sup" else COLOR_INF)
                    base = np.tile(np.array([c.red(), c.green(), c.blue()], np.uint8), (len(V), 1))
                lab = self.an.dientes(jaw)
                if modo.startswith("relacion") and lab is not None:  # los dientes de la relación, pintados
                    base = base.copy()
                    tinte = np.array((25, 149, 173))  # el turquesa de 3D OrthoLab
                    for t in DIENTES_RELACION[self.panel.vista][jaw]:
                        m = (lab == t) | (lab == t + 40)  # o su temporal
                        base[m] = (0.3 * base[m] + 0.7 * tinte).astype(np.uint8)
                if modo.startswith("dientes") and lab is not None:  # cada diente con su color
                    base = base.copy()
                    for t in np.unique(lab):
                        if t:
                            m = lab == t
                            base[m] = (0.22 * base[m] + 0.78 * np.array(COLOR_DIENTE.get(int(t) % 10, (150, 150, 160)))
                                       ).astype(np.uint8)
                self._an_base[jaw] = base
                self._pintar(jaw, base)
                a._modo = modo
            a.user_matrix = self._D(jaw)
            a.SetVisibility(si and self.vis[jaw])
            a.GetProperty().SetOpacity(self.opac[jaw])
        self._ver_trazos()

    def _pintar(self, jaw, rgb):
        m = self._an_malla[jaw]
        m.point_data["rgb"] = rgb
        m.Modified()

    def _anotar(self, actor, jaw):
        """Cada trazo (línea, punto, etiqueta) pertenece a una arcada: se oculta junto con ella."""
        actor._jaw = jaw
        actor.SetVisibility(self.vis.get(jaw, True))
        self._trazos.append(actor)

    def _ver_trazos(self):
        for a in self._trazos:
            jaw = getattr(a, "_jaw", None)
            if jaw in self.vis:
                a.SetVisibility(self.vis[jaw])
        if self._hover and not self.vis.get(self._hover[0], True):
            self._resaltar(None)

    def _limpiar_trazos(self):
        for a in self._trazos:
            self._plotter.remove_actor(a)
        self._trazos = []
        self._asas = []
        self._arrastre = None

    def _linea(self, jaw, pts, color, ancho=4):
        import pyvista as pv

        P = self._a_pantalla(jaw, pts)
        if len(P) < 2:
            return
        a = self._plotter.add_mesh(pv.lines_from_points(P), color=color, line_width=ancho, render_lines_as_tubes=True,
                                   reset_camera=False, pickable=False)
        self._anotar(a, jaw)
        return a

    def _punteada(self, jaw, pts, color, ancho=4, raya=1.1, hueco=0.8):
        """Línea punteada (como las de MetronTrack) a lo largo de la polilínea."""
        import pyvista as pv

        P = self._a_pantalla(jaw, pts)
        if len(P) < 2:
            return
        largo = np.r_[0, np.cumsum(np.linalg.norm(np.diff(P, axis=0), axis=1))]
        if largo[-1] < 0.2:
            return
        tramos = []
        t = 0.0
        while t < largo[-1]:
            fin = min(t + raya, largo[-1])
            for u in np.linspace(t, fin, 4)[:-1]:
                du = (fin - t) / 3
                tramos += [[np.interp(u, largo, P[:, k]) for k in range(3)],
                           [np.interp(u + du, largo, P[:, k]) for k in range(3)]]
            t = fin + hueco
        a = self._plotter.add_mesh(pv.line_segments_from_points(np.array(tramos)), color=color, line_width=ancho,
                                   render_lines_as_tubes=True, reset_camera=False, pickable=False)
        self._anotar(a, jaw)

    def _puntos(self, jaw, pts, etiquetas, color, tam=0.7):
        import pyvista as pv

        P = self._a_pantalla(jaw, pts)
        for p in P:
            a = self._plotter.add_mesh(pv.Sphere(radius=tam, center=p), color=color, reset_camera=False,
                                       pickable=False)
            self._anotar(a, jaw)
        if etiquetas:
            self._textos(P, etiquetas, color, jaw, ya_en_pantalla=True)

    def _plano(self, jaw, x, ys, zs, color, opacidad=0.45, frontal=False):
        """Plano vertical translúcido con su borde. Sagital en x (de y0 a y1 y de z0 a z1); con `frontal`, el plano
        es transversal: `x` es su posición en y, y `ys` su extensión en x."""
        import pyvista as pv

        if frontal:
            esquinas = np.array([[ys[0], x, zs[0]], [ys[1], x, zs[0]], [ys[1], x, zs[1]], [ys[0], x, zs[1]]], float)
        else:
            esquinas = np.array([[x, ys[0], zs[0]], [x, ys[1], zs[0]], [x, ys[1], zs[1]], [x, ys[0], zs[1]]], float)
        P = self._a_pantalla(jaw, esquinas)
        cuadro = pv.PolyData(P, np.array([4, 0, 1, 2, 3]))
        a = self._plotter.add_mesh(cuadro, color=color, opacity=opacidad, lighting=False, reset_camera=False,
                                   pickable=False)
        self._anotar(a, jaw)
        b = self._plotter.add_mesh(pv.lines_from_points(np.vstack([P, P[:1]])), color=color, line_width=2,
                                   reset_camera=False, pickable=False)
        self._anotar(b, jaw)
        return [a, b]

    @staticmethod
    def _mover_asa(asa, p):
        """Mueve el punto y, con él, lo que lleva pegado (su plano o su línea): no se desprenden."""
        p = np.array(p, float)
        if asa.get("solo_x"):  # línea media: solo se desliza de lado
            p = np.array([p[0], asa["pos0"][1], asa["pos0"][2]])
        asa["pos"] = p
        asa["actor"].SetPosition(*p)
        for a in asa.get("sigue") or []:
            a.SetPosition(*(p - asa["pos0"]))

    def _asa(self, jaw, punto, pos, color, tam=0.62, sigue=None, solo_x=False):
        """Punto que el doctor puede arrastrar con el mouse sobre el diente. `punto`: (arcada, dónde, nombre), como
        los de «Ajustar puntos»; `pos`: dónde está, en el marco del análisis."""
        import pyvista as pv

        P = self._a_pantalla(jaw, pos)[0]
        a = self._plotter.add_mesh(pv.Sphere(radius=tam, center=(0, 0, 0)), color=color, reset_camera=False,
                                   pickable=False, specular=0.4)
        a.SetPosition(*P)
        self._anotar(a, jaw)
        self._asas.append({"jaw": jaw, "punto": punto, "pos": np.array(P, float), "pos0": np.array(P, float),
                           "actor": a, "sigue": [x for x in (sigue or []) if x is not None], "solo_x": solo_x})

    def _asa_bajo(self, x, y, radio=16, asas=None, plotter=None):
        """La asa (punto arrastrable) que está bajo el cursor, o None. (x, y) en píxeles de VTK."""
        plotter = plotter or self._plotter
        ren = plotter.renderer
        mejor, dmin = None, radio * plotter.interactor.devicePixelRatioF()
        for asa in (self._asas if asas is None else asas):
            if asas is None and not self.vis.get(asa["jaw"], True):
                continue
            ren.SetWorldPoint(asa["pos"][0], asa["pos"][1], asa["pos"][2], 1.0)
            ren.WorldToDisplay()
            dx, dy, _ = ren.GetDisplayPoint()
            d = float(np.hypot(dx - x, dy - y))
            if d < dmin:
                mejor, dmin = asa, d
        return mejor

    def _recta_diente(self, jaw, dientes, punto, hacia, largo):
        """Los dos extremos de la línea recta vertical que pasa por `punto`, justo por delante de lo más saliente
        de la corona de los `dientes` vista desde `hacia` (dirección x, y)."""
        p = np.asarray(punto, float)
        d = np.asarray(hacia, float)
        d /= max(np.linalg.norm(d), 1e-9)
        t = np.array([-d[1], d[0]])
        lab = self.an.dientes(jaw)
        V = self.an.U if jaw == "sup" else self.an.L
        sg = 1.0 if jaw == "sup" else -1.0  # hacia la encía
        fuera = None
        if lab is not None:
            Vt = V[np.isin(lab, list(dientes) + [x + 40 for x in dientes])]
            franja = Vt[np.abs((Vt[:, :2] - p[:2]) @ t) < 0.45]
            alto = (franja[:, 2] - p[2]) * sg
            en = franja[(alto >= -0.6) & (alto < largo)]
            if len(en) > 5:
                fuera = float((en[:, :2] @ d).max()) + 0.3
        base = p[:2] + d * ((fuera - float(p[:2] @ d)) if fuera is not None else 0.4)
        return [[float(base[0]), float(base[1]), float(p[2])], [float(base[0]), float(base[1]), float(p[2] + sg * largo)]]

    def _linea_en_diente(self, jaw, dientes, punto, hacia, color, largo=6.5, ancho=5, punto_visible=True):
        """Línea vertical dibujada sobre la cara visible de la corona (no flotando): pasa por `punto` y sigue la
        superficie de los `dientes` hacia la encía. `hacia`: dirección (x, y) desde la que se mira. Devuelve su
        extremo gingival (para la etiqueta)."""
        pts = self._recta_diente(jaw, dientes, punto, hacia, largo)
        self._linea(jaw, pts, color, ancho)
        if punto_visible:
            self._puntos(jaw, [pts[0]], None, color, 0.45)
        return pts[0]  # donde empieza la línea (ahí va su punto)

    def _textos(self, P, etiquetas, color, jaw=None, ya_en_pantalla=False, siempre=True):
        if not ya_en_pantalla:
            P = self._a_pantalla(jaw, P)
        a = self._plotter.add_point_labels(P, etiquetas, font_size=13, text_color="white", shape_color=color,
                                           shape_opacity=0.9, point_size=1, show_points=False, always_visible=siempre,
                                           margin=2, reset_camera=False)
        self._anotar(a, jaw)
        return a

    def _p3(self, jaw, x, y, alto=0.5):
        """Punto (x, y) del análisis sobre la cara oclusal de la arcada (un poco hacia el observador)."""
        z = self.an.z(jaw, x, y)
        return [x, y, z - alto if jaw == "sup" else z + alto]

    def dibujar_analisis(self, clave, caso, res, mover_camara=True):
        """Lo llama el panel: acomoda la vista y dibuja los trazos de cada análisis (como MetronTrack)."""
        if self._plotter is None or self.an is None:
            return
        separadas = clave in ("contactos", "korkhaus", "espacio", "bolton", "moyers", "arcada", "forma", "longitud",
                              "simetria", "dientes")
        if clave == "bloqueado":  # sin dientes identificados: solo los modelos, de frente
            self._quitar_corte()
            self._mini_ocultar()
            self._limpiar_trazos()
            self._limpiar_regla()
            self._resaltar(None)
            self._mostrar_an(True)
            self._vistas_disponibles()
            if mover_camara:
                self._camara_analisis("frente", redibujar=False)
            self._plotter.render()
            return
        if clave == "dientes":
            for a in self._an_act.values():
                a._modo = None  # los números pueden haber cambiado: volver a colorear
        if mover_camara:
            self.disp = "separadas" if separadas else "junto"
            self._poner_capas(True, True)
        if clave == "corte":
            self.disp = "junto"
        else:
            self._quitar_corte()
        if clave not in ("molar", "canina"):
            self._mini_ocultar()
        self._vistas_disponibles()
        self._limpiar_trazos()
        self._limpiar_regla()
        self._resaltar(None)
        self._mostrar_an(True, contacto=(clave == "contactos"))
        P = caso.P
        if clave == "overjet":
            for t, r in res["overjet"].items():
                for jaw, x, col, z0, z1 in (("sup", r["x"], ROJO, r["z_up"] - 1.5, r["z_up"] + 9),
                                            ("inf", r["xl"], AZUL, r["z_lo"] - 9, r["z_lo"] + 1.5)):
                    y = (r["y_up"] if jaw == "sup" else r["y_lo"]) - 1.2
                    self._linea(jaw, [[x, y, z0], [x, y, z1]], col, 3)
                self._textos([[r["x"], r["y_up"] - 1.5, r["z_up"] + 9.5]], [r["par"]], ROJO, "sup")
        elif clave == "korkhaus":
            K = res["korkhaus"]
            if K:
                up, lo = P["sup"], P["inf"]
                self._dibujar_kork("sup", up["14"], up["24"], up["16"], up["26"], K.get("Pu"), K["nu"], K["Lo"],
                                   ("14", "24", "16", "26"))
                self._dibujar_kork("inf", lo["c44/45"], lo["c34/35"], lo["46"], lo["36"], K.get("Pl"), K["nl"],
                                   K["Lu"], ("44/45", "34/35", "46", "36"))
        elif clave in ("espacio", "bolton"):
            md = res.get("md") or {}
            n = AN.SEGMENTOS[self.panel.sub["espacio"]] if clave == "espacio" else 6
            for jaw in ("sup", "inf"):
                C, s = caso.curvas[jaw]
                paso = max(1, len(C) // 120)
                if clave == "espacio":
                    self._linea(jaw, [self._p3(jaw, x, y, 0.3) for x, y in C[::paso]], "#2b2b2b", 3)
                # la línea mesiodistal de cada diente del segmento (sigue su angulación), como en MetronTrack
                for lado in ("der", "izq"):
                    for t in AN.LADO[(jaw, lado)][:n]:
                        if t in md:
                            a, b = np.array(md[t]["m"][:2]), np.array(md[t]["d"][:2])
                            pts = [self._p3(jaw, *(a + (b - a) * k), 0.7) for k in np.linspace(0, 1, 7)]
                            self._punteada(jaw, pts, VERDE_MD, 5)
                            if self.panel.diente_sel == (jaw, t):  # el diente elegido: sus dos puntos, para moverlos
                                self._puntos(jaw, [pts[0], pts[-1]], ["mesial", "distal"], "#1677ff", 0.5)
                if clave == "espacio" and caso.dientes(jaw) is None:  # sin separación de dientes: los anchos van escritos sobre cada uno
                    cen = P["centros"][jaw]
                    dientes = [t for t in cen if AN.ancho(caso.anchos, t)]
                    if dientes:
                        self._textos([self._p3(jaw, *cen[t], 1.0) for t in dientes],
                                     [f"{AN.ancho(caso.anchos, t):.1f}" for t in dientes], "#2f6f86", jaw)
        elif clave == "moyers":
            mo = res["moyers"]
            if mo:
                for q, c in mo["cuadrantes"].items():
                    jaw = c["jaw"]
                    C, s = caso.curvas[jaw]
                    dientes = AN.LADO[(jaw, c["lado"])]
                    cen = P["centros"][jaw]
                    w2 = AN.ancho(caso.anchos, dientes[1]) or AN.PROMEDIO["2"][0 if jaw == "sup" else 1]
                    w6 = AN.ancho(caso.anchos, dientes[5]) or AN.PROMEDIO["6"][0 if jaw == "sup" else 1]
                    sg = -1 if c["lado"] == "der" else 1
                    s2 = sg * (abs(AN.s_de(C, s, cen[dientes[1]])) + w2 / 2)
                    s6 = sg * (abs(AN.s_de(C, s, cen[dientes[5]])) - w6 / 2)
                    ss = np.linspace(s2, s6, 40)
                    col = VERDE if c["discrepancia"] >= 0 else ROJO
                    pts = [self._p3(jaw, *AN.en_s(C, s, v), 0.6) for v in ss]
                    self._linea(jaw, pts, col, 6)
                    self._puntos(jaw, [pts[0], pts[-1]], None, col, 0.6)
                    self._textos([pts[len(pts) // 2]], [f"{c['disponible']:.1f} mm"], col, jaw)
        elif clave == "dientes":
            for jaw in ("sup", "inf"):
                lab = caso.dientes(jaw)
                if lab is None:
                    continue
                V = caso.U if jaw == "sup" else caso.L
                nums = [int(t) for t in np.unique(lab) if t]
                pts = []
                for t in nums:
                    Vt = V[lab == t]
                    z = float(Vt[:, 2].min() - 0.8) if jaw == "sup" else float(Vt[:, 2].max() + 0.8)
                    pts.append([float(Vt[:, 0].mean()), float(Vt[:, 1].mean()), z])
                if pts:
                    a = self._plotter.add_point_labels(self._a_pantalla(jaw, pts), [str(t) for t in nums], font_size=15,
                                                       text_color="#1677ff", shape_color="white", shape_opacity=0.95,
                                                       bold=True, show_points=False, always_visible=True, margin=3,
                                                       reset_camera=False)
                    self._anotar(a, jaw)
        elif clave in ("simetria", "longitud"):
            colores = {"anterior": AMBAR, "media": ROJO, "posterior": VERDE}
            for jaw in ("sup", "inf"):
                sim = (res.get("simetria") or {}).get(jaw) or {}
                lon = (res.get("longitud") or {}).get(jaw) or {}
                if not sim or "frente" not in lon:
                    continue
                y0 = lon["frente"]
                y1 = max(x["p_der"][1] for x in sim.values()) + 4
                self._linea(jaw, [self._p3(jaw, 0.0, y, 1.2) for y in np.linspace(y0 - 2, y1, 30)], "#5b6570", 3)  # eje medio
                for nivel, x in sim.items():
                    col = colores[nivel]
                    pd, pi = x["p_der"], x["p_izq"]
                    if clave == "simetria":  # de cada diente al eje
                        for q, valor in ((pd, x["der"]), (pi, x["izq"])):
                            a, b = self._p3(jaw, q[0], q[1], 1.0), self._p3(jaw, 0.0, q[1], 1.0)
                            b[2] = a[2]
                            self._linea(jaw, [a, b], col, 4)
                            self._puntos(jaw, [a], None, col, 0.55)
                            self._textos([[q[0] / 2, q[1], a[2]]], [f"{valor:.1f} mm"], col, jaw)
                    elif nivel in lon:  # profundidad sobre el eje, desde el borde incisal
                        ym = (pd[1] + pi[1]) / 2
                        a, b = self._p3(jaw, pd[0], pd[1], 1.0), self._p3(jaw, pi[0], pi[1], 1.0)
                        self._linea(jaw, [a, b], col, 3)
                        self._puntos(jaw, [a, b], None, col, 0.5)
                        self._textos([self._p3(jaw, 0.0, ym, 1.6)], [f"{lon[nivel]:.1f} mm"], col, jaw)
                if clave == "longitud":
                    self._puntos(jaw, [self._p3(jaw, 0.0, y0, 1.2)], ["borde incisal"], "#5b6570", 0.5)
        elif clave == "forma":
            md = res.get("md") or {}
            for jaw in ("sup", "inf"):
                C, s = caso.curvas[jaw]
                paso = max(1, len(C) // 120)
                self._linea(jaw, [self._p3(jaw, x, y, 0.5) for x, y in C[::paso]], "#5b6570", 4)
                nudos = [md[t]["m"][:2] for t in AN.ORDEN_ARCADA[jaw] if t in md and t[1] in "1357"]
                if not nudos:
                    nudos = [P["centros"][jaw][t] for t in AN.ORDEN_ARCADA[jaw] if t in P["centros"][jaw] and t[1] in "1357"]
                proy = [AN.en_s(C, s, AN.s_de(C, s, q)) for q in nudos]  # sobre la curva
                self._puntos(jaw, [self._p3(jaw, q[0], q[1], 0.7) for q in proy], None, "#1677ff", 0.6)
        elif clave in ("molar", "canina"):
            self._rel = {}
            for lado, x in ((res.get("clases") or {}).get(clave) or {}).items():
                if "cuspide" not in x or x.get("clase") == "No valorable":
                    continue  # fijada a criterio del doctor sin medición, o no valorable
                sx = -1.0 if lado == "der" else 1.0
                cusp = np.array(x["cuspide"])
                ref = np.array(x["surco"] if clave == "molar" else x["tronera"])
                # como MetronTrack: punto azul en la cúspide superior con su línea hacia la encía; en el inferior, las
                # cúspides de referencia (grises en el molar, verdes en la canina) con su línea, y el punto verde de
                # la referencia (surco / tronera). Los puntos azul y verde se arrastran con el mouse.
                sup_d, inf_d = ((16, 46) if lado == "der" else (26, 36)) if clave == "molar" else \
                    ((13, 43) if lado == "der" else (23, 33))
                inf_dientes = [inf_d] if clave == "molar" else [inf_d, inf_d + 1]
                hacia = (sx, 0.0)
                rel = {"sup": [sup_d], "inf": inf_dientes, "rectas": [], "puntos": [], "asas": []}
                recta = self._recta_diente("sup", [sup_d], cusp, hacia, 6.0)
                rel["rectas"].append(("sup", recta, COLOR_REL_SUP))
                rel["asas"].append(("sup", ("sup", "aj", f"{clave}_{lado}_sup"), recta[0], COLOR_REL_SUP))
                col_ref = "#3d4753" if clave == "molar" else COLOR_REL_INF
                for k, q in enumerate(x.get("cuspides_inf") or []):
                    diente = inf_d if clave == "molar" else inf_d + k
                    recta = self._recta_diente("inf", [diente], q, hacia, 5.0)
                    rel["rectas"].append(("inf", recta, col_ref))
                    rel["puntos"].append(("inf", recta[0], col_ref))
                fuera = 0.4 if clave == "molar" else 3.2  # la tronera queda hundida, detrás del canino superior
                rel["asas"].append(("inf", ("inf", "aj", f"{clave}_{lado}_inf"),
                                    [float(ref[0] + sx * fuera), float(ref[1]), float(ref[2])], COLOR_REL_INF))
                lineas = [self._linea(jaw, recta, col, 4) for jaw, recta, col in rel["rectas"]]
                for jaw, pos, col in rel["puntos"]:
                    self._puntos(jaw, [pos], None, col, 0.5)
                for k, (jaw, punto, pos, col) in enumerate(rel["asas"]):
                    self._asa(jaw, punto, pos, col, sigue=lineas[:1] if k == 0 else None)  # la cúspide lleva su línea
                self._rel[lado] = rel
            self._mini_mostrar(clave)
        elif clave == "lmedia" and res["linea_media"].get("valorable", True):
            lm = res["linea_media"]
            U, L = caso.U, caso.L
            zs = float(U[np.abs(U[:, 0] - lm["sup"]) < 3][:, 2].min())   # borde incisal superior
            zi = float(L[np.abs(L[:, 0] - lm["inf"]) < 3][:, 2].max())   # borde incisal inferior
            ys = float(U[(np.abs(U[:, 0] - lm["sup"]) < 1.5) & (U[:, 2] < zs + 3)][:, 1].min())
            yi = float(L[(np.abs(L[:, 0] - lm["inf"]) < 1.5) & (L[:, 2] > zi - 3)][:, 1].min())
            # como MetronTrack: un plano vertical translúcido por cada línea media (azul la superior, verde la
            # inferior), con su punto. De frente se ven como dos líneas finas; de lado, como dos láminas.
            yf = min(ys, yi) - 1.2
            for jaw, x, z_pt, col in (("sup", lm["sup"], zs + 2.5, COLOR_REL_SUP), ("inf", lm["inf"], zi - 2.5, COLOR_REL_INF)):
                plano = self._plano(jaw, x, (yf - 4.0, yf + 8.0), (min(zs, zi) - 9.0, max(zs, zi) + 9.0), col)
                self._asa(jaw, (jaw, "aj", f"lm_{jaw}"), [x, yf - 2.0, z_pt], col, 0.6, sigue=plano, solo_x=True)
            txt = f"{lm['mm']:.1f} mm a la {lm['direccion']}" if lm["direccion"] != "centrada" else "coinciden"
            self._textos([[lm["sup"], yf - 4.0, max(zs, zi) + 10.5]], ["Línea media superior"], COLOR_REL_SUP, "sup")
            self._textos([[lm["inf"], yf - 4.0, min(zs, zi) - 10.5]], [f"Línea media inferior · {txt}"], COLOR_REL_INF,
                         "inf")
        elif clave == "arcada":
            cen = P["centros"]
            for jaw, pares in (("sup", (("13", "23", AMBAR), ("14", "24", ROJO), ("16", "26", VERDE))),
                               ("inf", (("43", "33", AMBAR), ("44", "34", ROJO), ("46", "36", VERDE)))):
                for a, b, col in pares:
                    if a in cen[jaw] and b in cen[jaw]:
                        pa, pb = self._p3(jaw, *cen[jaw][a], 1.0), self._p3(jaw, *cen[jaw][b], 1.0)
                        self._linea(jaw, [pa, pb], col, 4)
                        self._puntos(jaw, [pa, pb], None, col, 0.6)
                        d = float(np.hypot(pa[0] - pb[0], pa[1] - pb[1]))
                        self._textos([[(pa[0] + pb[0]) / 2, (pa[1] + pb[1]) / 2, pa[2]]], [f"{d:.1f} mm"], col, jaw)
        if clave == "corte":
            if not self._corte_activo:
                self._camara_analisis("frente", redibujar=False)
                self.poner_corte()
        elif mover_camara:
            vista = ("frente" if clave in ("overjet", "resumen", "lmedia") else
                     ("derecha" if self._mini_lado == "der" else "izquierda") if clave in ("molar", "canina")
                     else "separadas")
            self._camara_analisis(vista, redibujar=False)
            if clave in ("molar", "canina"):
                self._acercar_relacion(clave, res)
        self._plotter.render()

    def _acercar_relacion(self, clave, res):
        """Acerca la cámara a los dientes de la relación del lado elegido."""
        x = ((res.get("clases") or {}).get(clave) or {}).get(self._mini_lado) or {}
        if "cuspide" in x:
            f = np.array(x["cuspide"], float)
            sx = -1.0 if self._mini_lado == "der" else 1.0
            self._plotter.camera_position = [tuple(f + [sx * 75.0, 0.0, 0.0]), tuple(f), (0, 0, 1)]
            self._plotter.renderer.ResetCameraClippingRange()

    # ------------------------------------------------------------------ recuadro de la relación (molar / canina)
    def _submalla(self, jaw, dientes):
        """Solo las coronas de esos dientes (o sus temporales), en el marco del análisis."""
        import pyvista as pv

        lab = self.an.dientes(jaw)
        if lab is None:
            return None
        V = self.an.U if jaw == "sup" else self.an.L
        F = self.an.FU if jaw == "sup" else self.an.FL
        caras = F[np.isin(lab[F], list(dientes) + [d + 40 for d in dientes]).all(1)]
        if not len(caras):
            return None
        return pv.PolyData(V, np.hstack([np.full((len(caras), 1), 3), caras]).astype(np.int64))

    def _mini_ocultar(self):
        self._rel = {}
        if self._mini_visible:
            self._mini_visible = False
            self.flot_mini.hide()

    def _mini_mostrar(self, clave):
        """El recuadro: los dientes de la relación en gris, con sus líneas y sus puntos (los mismos del modelo)."""
        import pyvista as pv

        if not self._rel or not self.an.etiquetas:
            self._mini_ocultar()
            return
        if self._mini_lado not in self._rel:
            self._mini_lado = next(iter(self._rel))
        lado = self._mini_lado
        if self._mini is None:
            from pyvistaqt import QtInteractor

            self._mini = QtInteractor(self.mini_hueco)
            self._mini.set_background("#f4f6f8")
            self._mini.enable_anti_aliasing("ssaa")
            self._mini.interactor.setAcceptDrops(False)
            self._mini.interactor.setMouseTracking(True)
            self._mini.interactor.installEventFilter(self)
            self._raton_metron(self._mini)
            self.mini_hueco.layout().addWidget(self._mini.interactor)
        pl = self._mini
        for a in self._mini_actores:
            pl.remove_actor(a)
        self._mini_actores, self._mini_asas, self._mini_act = [], [], {"sup": [], "inf": []}
        self._mini_arrastre = None
        rel = self._rel[lado]
        todos = []
        for jaw in ("sup", "inf"):
            m = self._submalla(jaw, rel[jaw])
            if m is not None:
                a = pl.add_mesh(m, color="#dde1e6", smooth_shading=True, specular=0.35, specular_power=18,
                                reset_camera=False)
                self._mini_act[jaw].append(a)
                self._mini_actores.append(a)
                usados = np.unique(np.asarray(m.faces).reshape(-1, 4)[:, 1:])
                todos.append(np.asarray(m.points)[usados])
        lineas = []
        for jaw, recta, col in rel["rectas"]:
            lineas.append(pl.add_mesh(pv.Line(recta[0], recta[1]), color=col, line_width=4,
                                      render_lines_as_tubes=True, reset_camera=False, pickable=False))
        self._mini_actores += lineas
        for jaw, pos, col in rel["puntos"]:
            self._mini_actores.append(pl.add_mesh(pv.Sphere(radius=0.42, center=pos), color=col, reset_camera=False,
                                                  pickable=False))
        for jaw, punto, pos, col in rel["asas"]:
            a = pl.add_mesh(pv.Sphere(radius=0.55, center=(0, 0, 0)), color=col, reset_camera=False, pickable=False,
                            specular=0.4)
            a.SetPosition(*pos)
            self._mini_actores.append(a)
            self._mini_asas.append({"jaw": jaw, "punto": punto, "pos": np.array(pos, float),
                                    "pos0": np.array(pos, float), "actor": a,
                                    "sigue": lineas[:1] if not self._mini_asas else []})
        if (clave, lado) != self._mini_clave and todos:  # la cámara solo se acomoda al cambiar de relación o de lado
            P = np.vstack(todos)
            c = (P.min(0) + P.max(0)) / 2
            sx = -1.0 if lado == "der" else 1.0
            pl.camera_position = [tuple(c + [sx * 80.0, 0.0, 0.0]), tuple(c), (0, 0, 1)]
            pl.camera.parallel_projection = True
            pl.camera.parallel_scale = float(max(P[:, 1].max() - P[:, 1].min(), P[:, 2].max() - P[:, 2].min()) * 0.62)
            pl.renderer.ResetCameraClippingRange()
            self._mini_clave = (clave, lado)
        self.l_mini.setText("<br>".join(
            f"<span style='color:{col};font-size:12pt;'>●</span> {nombre_punto(punto[2])}"
            for _jaw, punto, _pos, col in rel["asas"])
            + ("<br><span style='color:#3d4753;font-size:12pt;'>●</span> Cúspides vestibulares del molar inferior "
               "(referencia)" if clave == "molar" and rel["puntos"] else ""))
        for k in ("der", "izq"):
            self.b_mini[k].setChecked(k == lado)
            self.b_mini[k].setEnabled(k in self._rel)
        self._mini_visible = True
        self._colocar_flotantes()
        pl.render()

    def _mini_elegir(self, lado):
        if lado not in self._rel or self.an is None:
            return
        self._mini_lado = lado
        self._mini_mostrar(self.panel.vista)
        self._camara_analisis("derecha" if lado == "der" else "izquierda", redibujar=False)
        self._acercar_relacion(self.panel.vista, self.panel.res)
        self._plotter.render()

    def _mini_agrandar(self):
        grande = self.mini_hueco.width() < 400
        self.mini_hueco.setFixedSize(*((520, 400) if grande else (330, 250)))
        self._colocar_flotantes()

    def _mini_evento(self, obj, ev):
        """Arrastre de un punto dentro del recuadro. True si el evento era del arrastre (los dientes no giran)."""
        from vtkmodules.vtkRenderingCore import vtkCellPicker

        r = obj.devicePixelRatioF()
        pos = ev.position()
        x, y = int(pos.x() * r), int((obj.height() - pos.y() - 1) * r)
        tipo = ev.type()
        if tipo == QtCore.QEvent.MouseButtonPress:
            if ev.button() != Qt.LeftButton:
                return False
            asa = self._asa_bajo(x, y, asas=self._mini_asas, plotter=self._mini)
            if asa is None:
                return False
            self._mini_arrastre = asa
            obj.setCursor(Qt.ClosedHandCursor)
            return True
        if self._mini_arrastre is None:
            if tipo == QtCore.QEvent.MouseMove and not ev.buttons():
                bajo = self._asa_bajo(x, y, asas=self._mini_asas, plotter=self._mini)
                obj.setCursor(Qt.OpenHandCursor if bajo is not None else Qt.ArrowCursor)
                self._decir_punto(obj, bajo)
            return False
        asa = self._mini_arrastre
        pk = vtkCellPicker()
        pk.SetTolerance(0.0005)
        pk.PickFromListOn()
        for a in self._mini_act[asa["jaw"]]:  # el punto se desliza sobre su propio diente
            pk.AddPickList(a)
        if pk.Pick(x, y, 0, self._mini.renderer):
            self._mover_asa(asa, pk.GetPickPosition())
            self._mini.render()
        if tipo == QtCore.QEvent.MouseButtonRelease:
            self._mini_arrastre = None
            obj.setCursor(Qt.ArrowCursor)
            punto, q = asa["punto"], asa["pos"].copy()

            def aplicar():
                self.panel.punto_activo = punto
                self.panel.mover_punto(punto[0], q[0], q[1], q[2])
                self.panel.punto_activo = None
            QtCore.QTimer.singleShot(0, aplicar)
        return True

    def _dibujar_kork(self, jaw, a, b, m1, m2, tip, n, largo, nombres):
        a, b, m1, m2 = (np.asarray(p, float) for p in (a, b, m1, m2))
        pa, pb, p1, p2 = (self._p3(jaw, *p) for p in (a, b, m1, m2))
        self._linea(jaw, [pa, pb], ROJO, 5)
        self._linea(jaw, [p1, p2], VERDE, 5)
        self._puntos(jaw, [pa, pb], [nombres[0], nombres[1]], ROJO)
        self._puntos(jaw, [p1, p2], [nombres[2], nombres[3]], VERDE)
        if tip is not None and largo is not None:
            tip = np.asarray(tip, float)
            n = np.asarray(n, float)
            pie = tip - n * largo
            z = (pa[2] + pb[2]) / 2
            self._linea(jaw, [[*pie, z], [*tip, z]], AZUL, 4)
            dd = (b - a) / np.linalg.norm(b - a)
            self._linea(jaw, [[*(tip - dd * 10), z], [*(tip + dd * 10), z]], AZUL, 3)
            self._textos([[*(pie + tip) / 2, z]], [f"{largo:.1f} mm"], AZUL, jaw)
        self._textos([[*((a + b) / 2), pa[2]]], [f"{np.linalg.norm(b - a):.1f} mm"], ROJO, jaw)
        self._textos([[*((m1 + m2) / 2), p1[2]]], [f"{np.linalg.norm(m2 - m1):.1f} mm"], VERDE, jaw)

    def _camara_analisis(self, vista, redibujar=True):
        quiere = "separadas" if vista == "separadas" else "junto"
        if self.panel.actual == "corte" and quiere == "separadas":
            self.aviso("En «Corte» las arcadas se ven en oclusión.")
            return
        if vista in ("oclusal_sup", "oclusal_inf"):
            self._poner_capas(vista == "oclusal_sup", vista == "oclusal_inf")
        else:
            self._poner_capas(True, True)
        movidas = any(not np.allclose(m, np.eye(4)) for m in self._acomodo.values())
        self._acomodo = {"sup": np.eye(4), "inf": np.eye(4)}
        self._acom = None
        if self.disp != quiere or movidas:
            self.disp = quiere
            if redibujar:
                self.panel.mostrar(self.panel.actual, mover_camara=False)
        self._mostrar_an(True, contacto=self.panel.actual == "contactos")
        self._marcar_vista(vista)
        pos, up = {"separadas": ((0, 0, 300), (0, 1, 0)), "frente": ((0, -300, 0), (0, 0, 1)),
                   "atras": ((0, 300, 0), (0, 0, 1)),
                   "derecha": ((-300, 0, 0), (0, 0, 1)), "izquierda": ((300, 0, 0), (0, 0, 1)),
                   "oclusal_sup": ((0, 0, -300), (0, -1, 0)), "oclusal_inf": ((0, 0, 300), (0, 1, 0))}[vista]
        # las dos arcadas lado a lado se ven sin perspectiva: cada una de frente, no «desde el centro»
        self._plotter.camera.parallel_projection = vista == "separadas"
        self._plotter.camera_position = [pos, (0, 0, 0), up]
        self._plotter.reset_camera()
        self._plotter.camera.zoom({"separadas": 1.05, "derecha": 1.0, "izquierda": 1.0}.get(vista, 1.2)
                                  * (0.85 if self.panel.actual == "corte" else 1.0))
        self._plotter.render()

    # ------------------------------------------------------------------ corte de oclusión (plano que se arrastra)
    def _corte_rango(self, modo):
        """(mínimo, máximo, inicial) de la posición del corte en cada modo."""
        U = self.an.U[::40]
        if modo == "diente":
            P, s = self.an.curvas["sup"]
            c11 = self.an.P["centros"]["sup"].get("11")
            return float(s[0]), float(s[-1]), (AN.s_de(P, s, c11) if c11 else 0.0)
        if modo == "sagital":
            return float(U[:, 0].min()), float(U[:, 0].max()), float(self.an.P["incisivos"].get("11", 0.0))
        ys = [self.an.P["centros"]["sup"][t][1] for t in ("16", "26") if t in self.an.P["centros"]["sup"]]
        return float(U[:, 1].min()), float(U[:, 1].max()), float(np.mean(ys)) if ys else 0.0

    def poner_corte(self, modo=None, valor=None):
        """Coloca el corte. modo: «diente» (a través del diente, perpendicular a la arcada), «sagital» o
        «transversal»; valor: su posición (a lo largo de la arcada, en x o en y). Sin valor, la inicial del modo."""
        import pyvista as pv

        if self.an is None or self._plotter is None:
            return
        if modo not in ("diente", "sagital", "transversal"):
            modo = self._corte_plano if self._corte_plano in ("diente", "sagital", "transversal") else "diente"
        lo, hi, inicial = self._corte_rango(modo)
        if valor is None:
            valor = inicial if (modo != self._corte_plano or not self._corte_activo or self._corte_valor is None) \
                else self._corte_valor
        valor = float(np.clip(valor, lo, hi))
        if not self._corte_activo:
            self._corte_mallas = {}  # los números de diente pueden haber cambiado
        self._corte_plano, self._corte_valor = modo, valor
        U = self.an.U[::40]
        if modo == "diente":
            P, s = self.an.curvas["sup"]
            o = np.r_[AN.en_s(P, s, valor), 0.0]
            tg = AN.en_s(P, s, min(valor + 1.0, hi)) - AN.en_s(P, s, max(valor - 1.0, lo))
            n = np.r_[tg / max(np.linalg.norm(tg), 1e-9), 0.0]
            medio = 11.0
        elif modo == "sagital":
            o = np.array([valor, float((U[:, 1].min() + U[:, 1].max()) / 2), 0.0])
            n = np.array([1.0, 0.0, 0.0])
            medio = float((U[:, 1].max() - U[:, 1].min()) / 2 + 3)
        else:
            o = np.array([0.0, valor, 0.0])
            n = np.array([0.0, 1.0, 0.0])
            medio = float(np.abs(U[:, 0]).max() + 3)
        # el plano, a la vista en el modelo
        for a in self._corte_act:
            self._plotter.remove_actor(a)
        u = np.array([-n[1], n[0], 0.0])
        z = np.array([0.0, 0.0, 12.0])
        esquinas = np.array([o - u * medio - z, o + u * medio - z, o + u * medio + z, o - u * medio + z])
        self._corte_act = [
            self._plotter.add_mesh(pv.PolyData(esquinas, np.array([4, 0, 1, 2, 3])), color="#1677ff", opacity=0.35,
                                   lighting=False, reset_camera=False, pickable=False),
            self._plotter.add_mesh(pv.lines_from_points(np.vstack([esquinas, esquinas[:1]])), color="#1677ff",
                                   line_width=3, reset_camera=False, pickable=False)]
        self._corte_activo = True
        for k in ("diente", "sagital", "transversal"):
            self.b_corte[k].setChecked(k == modo)
        self.sl_corte.blockSignals(True)
        self.sl_corte.setValue(int(round((valor - lo) / max(hi - lo, 1e-9) * 1000)))
        self.sl_corte.blockSignals(False)
        # título: por qué diente pasa
        titulo = {"sagital": "Corte sagital", "transversal": "Corte transversal"}.get(modo, "Corte")
        if modo == "diente":
            cen = self.an.P["centros"]["sup"]
            cerca = min(cen, key=lambda t: np.hypot(cen[t][0] - o[0], cen[t][1] - o[1])) if cen else None
            if cerca and np.hypot(cen[cerca][0] - o[0], cen[cerca][1] - o[1]) < 5.5:
                titulo = f"Corte por el diente {cerca} y su antagonista"
        self.l_corte.setText(titulo)
        self._plotter.camera.SetWindowCenter(-0.38, 0.0)  # el modelo, a la derecha de la gráfica
        self._colocar_flotantes()
        self._corte_movido(n, o)
        self._plotter.render()

    def _corte_barra(self, v):
        if self._corte_activo and self.an is not None:
            lo, hi, _ = self._corte_rango(self._corte_plano)
            self.poner_corte(self._corte_plano, lo + v / 1000.0 * (hi - lo))

    def _corte_en(self, p):
        """Clic en el modelo: el corte pasa por ese punto (p, en el marco del análisis)."""
        if self._corte_plano == "diente":
            P, s = self.an.curvas["sup"]
            valor = AN.s_de(P, s, p[:2])
        else:
            valor = float(p[0] if self._corte_plano == "sagital" else p[1])
        self.poner_corte(self._corte_plano, valor)

    def _malla_corte(self, jaw):
        """Lo que corta el plano: solo los dientes (con la separación de dientes); sin ella, la arcada completa."""
        import pyvista as pv

        if jaw not in self._corte_mallas:
            m = self._an_malla.get(jaw)
            lab = self.an.dientes(jaw) if self.an is not None else None
            if m is not None and lab is not None:
                F = self.an.FU if jaw == "sup" else self.an.FL
                caras = F[(lab[F] > 0).all(1)]
                if len(caras):
                    m = pv.PolyData(np.asarray(m.points), np.hstack([np.full((len(caras), 1), 3), caras]).astype(np.int64))
            self._corte_mallas[jaw] = m
        return self._corte_mallas[jaw]

    def _quitar_corte(self):
        if self._plotter is not None:
            for a in self._corte_act:
                self._plotter.remove_actor(a)
        self._corte_act = []
        if self._corte_activo and self._plotter is not None:
            self._plotter.camera.SetWindowCenter(0.0, 0.0)
        self._corte_activo = False
        if hasattr(self, "flot_corte"):
            self.flot_corte.hide()

    def _corte_movido(self, normal, origen):
        g = self.grafica
        if self.an is None:
            return
        self._corte_ultimo = (tuple(normal), tuple(origen))
        n = np.asarray(normal, float)
        n /= max(np.linalg.norm(n), 1e-9)
        o = np.asarray(origen, float)
        arriba = np.array([0.0, 0.0, 1.0])
        v = arriba - (arriba @ n) * n
        if np.linalg.norm(v) < 0.2:  # plano casi horizontal: «arriba» es hacia atrás
            v = np.array([0.0, 1.0, 0.0]) - n[1] * n
        v /= np.linalg.norm(v)
        u = np.cross(v, n)
        segs = {}
        for jaw in ("sup", "inf"):
            m = self._malla_corte(jaw)
            segs[jaw] = None
            if m is None or not self.vis[jaw]:
                continue
            c = m.slice(normal=n, origin=o)
            if c.n_points == 0 or c.n_cells == 0 or c.lines.size % 3:
                continue
            lin = np.asarray(c.lines).reshape(-1, 3)[:, 1:]
            pz = np.asarray(c.points)[:, 2]
            alto = 16 if self.an.dientes(jaw) is not None else 9   # sin separación de dientes: solo la zona de coronas
            lin = lin[(np.abs(pz[lin]) < alto).all(1)]
            if not len(lin):
                continue
            Q = np.asarray(c.points, float) - o
            if self._corte_plano == "diente":
                cerca = np.abs(Q @ u) < 11.0
                lin = lin[cerca[lin].all(1)]
                if not len(lin):
                    continue
            segs[jaw] = np.c_[Q @ u, Q @ v][lin]
        if self._corte_plano == "sagital":
            rotulos = ("anterior", "posterior")
        elif self._corte_plano == "transversal":
            rotulos = ("izquierda", "derecha") if u[0] < 0 else ("derecha", "izquierda")
        else:  # a través del diente: ¿hacia dónde queda vestibular?
            P, _s = self.an.curvas["sup"]
            fuera = float(u[:2] @ (o[:2] - P.mean(0)))
            rotulos = ("lingual", "vestibular") if fuera > 0 else ("vestibular", "lingual")
        g.poner(segs["sup"], segs["inf"], rotulos)

    # ------------------------------------------------------------------ resaltar el diente bajo el mouse
    def _al_mover(self, obj, _ev):
        self._mov = obj.GetEventPosition()
        if not self._t_hover.isActive():
            self._t_hover.start()

    def _al_pasar(self):
        if (self.modo != 1 or self.an is None or self._clic is not None or self._press is not None
                or self.panel.actual not in ("espacio", "bolton", "moyers", "dientes") or not self.an.etiquetas
                or self._mov is None):
            if self._hover:
                self._resaltar(None)
            return
        jaw, _, pid = self._picar(*self._mov)
        fdi = 0
        if jaw is not None and pid >= 0:
            lab = self.an.dientes(jaw)
            fdi = int(lab[pid]) if lab is not None else 0
        self._resaltar((jaw, fdi) if fdi else None)

    def _picar(self, x, y, solo=None):
        """(arcada, punto, vértice) bajo el cursor. Con `solo`, únicamente esa arcada (aunque la otra esté delante)."""
        from vtkmodules.vtkRenderingCore import vtkCellPicker

        pk = vtkCellPicker()
        pk.SetTolerance(0.0005)
        pk.PickFromListOn()
        for j, a in self._an_act.items():
            if solo is None or j == solo:
                pk.AddPickList(a)
        if not pk.Pick(x, y, 0, self._plotter.renderer):
            return None, None, -1
        act = pk.GetActor()
        jaw = next((j for j, a in self._an_act.items() if a is act), None)
        return jaw, np.array(pk.GetPickPosition()), pk.GetPointId()

    def _resaltar(self, cual):
        if cual == self._hover or self._plotter is None:
            return
        if self._hover and self._hover[0] in self._an_base and self._hover[0] in self._an_malla:
            self._pintar(self._hover[0], self._an_base[self._hover[0]])
        if self._hover_act is not None:
            self._plotter.remove_actor(self._hover_act)
            self._hover_act = None
        self._hover = cual
        if cual and self.an is not None:
            jaw, fdi = cual
            m = self.an.dientes(jaw) == fdi
            rgb = self._an_base[jaw].copy()
            rgb[m] = (0.25 * rgb[m] + 0.75 * np.array([120, 208, 240])).astype(np.uint8)
            self._pintar(jaw, rgb)
            V = (self.an.U if jaw == "sup" else self.an.L)[m]
            z = float(V[:, 2].min() - 1.5) if jaw == "sup" else float(V[:, 2].max() + 1.5)
            centro = [float(V[:, 0].mean()), float(V[:, 1].mean()), z]
            nombre = str(fdi)
            if nombre[0] in "5678":
                nombre = str(int(nombre[0]) - 4) + nombre[1]
            w = AN.ancho(self.an.anchos, nombre) or ((self.panel.res or {}).get("md") or {}).get(nombre, {}).get("ancho", 0)
            self._hover_act = self._plotter.add_point_labels(
                self._a_pantalla(jaw, centro), [f"{fdi}  ·  {w:.1f} mm" if w else f"{fdi}"], font_size=16,
                text_color="#1f2933", shape_color="white", shape_opacity=0.97, show_points=False, always_visible=True,
                margin=4, reset_camera=False)
            self.l_aviso.setText(f"Diente {fdi}: ancho mesiodistal {w:.1f} mm" if w else f"Diente {fdi}")
        self._plotter.render()

    # ------------------------------------------------------------------ clics: «Medir» y mover puntos
    def modo_clic(self, modo):
        self._clic = modo
        if modo != "medir" and self.b_medir.isChecked():
            self.b_medir.blockSignals(True)
            self.b_medir.setChecked(False)
            self.b_medir.blockSignals(False)
        if modo == "medir":
            self._limpiar_regla()
            self.aviso("Medir: haz clic en el primer punto del modelo y luego en el segundo.", 8000)
        elif modo == "punto":
            self.aviso("Haz clic en el modelo donde va el punto.", 8000)
        if self._plotter is not None:
            self._plotter.interactor.setCursor(Qt.CrossCursor if modo else Qt.ArrowCursor)

    def _soltar(self, x, y):
        press, self._press = self._press, None
        if press is None:
            return
        if abs(x - press[0]) + abs(y - press[1]) > 4:  # fue un giro, no un clic
            return
        if self._clic is None and self.modo == 1 and self.an is not None and self.panel.actual == "corte":
            jaw, p, _ = self._picar(x, y)
            if jaw is not None:
                q = AN.inversa(self._D(jaw)) @ np.r_[p, 1.0]
                QtCore.QTimer.singleShot(0, lambda: self._corte_en(q[:3]))
            return
        if self._clic is None:
            if (self.modo == 1 and self.an is not None and self.an.etiquetas
                    and self.panel.actual in ("espacio", "bolton", "dientes")):
                jaw, p, pid = self._picar(x, y)
                lab = self.an.dientes(jaw) if jaw else None
                fdi = int(lab[pid]) if lab is not None and pid >= 0 else 0
                # en la vista de las dos arcadas se espera un instante: puede ser el primer clic de un doble clic
                espera = QtWidgets.QApplication.doubleClickInterval() + 30 if self.disp == "separadas" else 0
                self._clic_gen = gen = getattr(self, "_clic_gen", 0) + 1
                if fdi and self.panel.actual == "dientes":
                    q = AN.inversa(self._D(jaw)) @ np.r_[p, 1.0]
                    QtCore.QTimer.singleShot(espera, lambda: gen == self._clic_gen and self._menu_numero(
                        jaw, fdi, (float(q[0]), float(q[1]))))
                elif fdi:
                    QtCore.QTimer.singleShot(espera, lambda: gen == self._clic_gen and self.panel.elegir_diente(jaw, fdi))
            return
        if self._clic == "medir":
            from vtkmodules.vtkRenderingCore import vtkCellPicker

            pk = vtkCellPicker()
            pk.SetTolerance(0.0005)
            if pk.Pick(x, y, 0, self._plotter.renderer):
                self._clic_regla(np.array(pk.GetPickPosition()))
        elif self._clic == "punto":
            jaw, p, _ = self._picar(x, y)
            if jaw is None:
                return
            q = AN.inversa(self._D(jaw)) @ np.r_[p, 1.0]
            self.panel.mover_punto(jaw, q[0], q[1], q[2])

    def _menu_numero(self, jaw, fdi, donde=None):
        """Clic en un diente en «Dientes»: el doctor corrige su número, lo divide en dos o lo une con otro."""
        menu = QtWidgets.QMenu(self)
        t = menu.addAction(f"Diente {fdi}")
        t.setEnabled(False)
        menu.addSeparator()
        if donde is not None:
            a = menu.addAction("Dividir aquí en dos dientes")
            a.setData(("dividir",))
        lab = self.an.dientes(jaw)
        V = self.an.U if jaw == "sup" else self.an.L
        yo = V[lab == fdi][:, :2].mean(0)
        cerca = sorted((float(np.linalg.norm(V[lab == t][:, :2].mean(0) - yo)), int(t))
                       for t in np.unique(lab) if t and t != fdi)
        cerca = [t for d, t in cerca if d < 14][:3]
        if cerca:
            unir = menu.addMenu("Unir con (es el mismo diente)…")
            for t in cerca:
                a = unir.addAction(f"el pedazo {t}")
                a.setData(("unir", t))
        num = menu.addMenu("Cambiar su número a…")
        for n in AN.ORDEN_ARCADA[jaw]:
            a = num.addAction(n)
            a.setData(int(n))
            a.setEnabled(int(n) != fdi)
        temp = num.addMenu("Temporal (de leche)")
        for q in ((5, 6) if jaw == "sup" else (8, 7)):
            for k in (range(5, 0, -1) if q in (5, 8) else range(1, 6)):
                a = temp.addAction(f"{q}{k}")
                a.setData(q * 10 + k)
        menu.addSeparator()
        a = menu.addAction("No es un diente")
        a.setData(0)
        elegido = menu.exec(QtGui.QCursor.pos())
        if elegido is None or elegido.data() is None:
            return
        d = elegido.data()
        if isinstance(d, tuple) and d[0] == "dividir":
            self.panel.dividir(jaw, fdi, donde[0], donde[1])
        elif isinstance(d, tuple) and d[0] == "unir":
            self.panel.unir(jaw, fdi, d[1])
        else:
            self.panel.renumerar(jaw, fdi, int(d))

    def _limpiar_regla(self):
        for a in self._regla[1:] if self._regla else []:
            self._plotter.remove_actor(a)
        self._regla = []

    def _clic_regla(self, p):
        import pyvista as pv

        if len(self._regla) == 0 or (self._regla and self._regla[0] is not None and len(self._regla[0]) == 2):
            self._limpiar_regla()
            self._regla = [[]]
        pts = self._regla[0]
        pts.append(p)
        a = self._plotter.add_mesh(pv.Sphere(radius=0.35, center=p), color=AMBAR, reset_camera=False, pickable=False)
        self._regla.append(a)
        if len(pts) == 2:
            d = float(np.linalg.norm(pts[1] - pts[0]))
            self._regla.append(self._plotter.add_mesh(pv.Line(pts[0], pts[1]), color=AMBAR, line_width=4,
                                                      render_lines_as_tubes=True, reset_camera=False, pickable=False))
            self._regla.append(self._plotter.add_point_labels([(pts[0] + pts[1]) / 2], [f"{d:.2f} mm"], font_size=15,
                                                              text_color="black", shape_color="#f2c14e",
                                                              show_points=False, always_visible=True,
                                                              reset_camera=False))
            self.aviso(f"Distancia: {d:.2f} mm. Otro clic empieza una medida nueva.", 10000)
        self._plotter.render()

    # ------------------------------------------------------------------ la Dra.
    def vista_previa(self):
        carpeta = QtWidgets.QFileDialog.getExistingDirectory(self, "Carpeta del escaneo del paciente",
                                                             os.path.expanduser("~"))
        if carpeta:
            self._previa(carpeta)

    def _previa(self, carpeta):
        """Abre un caso directo de su carpeta. Si la carpeta soltada no trae los modelos (p. ej. «STL» o «PLY»
        sueltas), prueba con la de arriba, que es la del caso."""
        carpeta = carpeta.rstrip("\\/")
        arriba = os.path.dirname(carpeta)
        det = PQ.detectar(carpeta)
        if arriba and not ({"superior_sin_zocalo", "superior_con_zocalo"} & set(det)
                           and {"inferior_sin_zocalo", "inferior_con_zocalo"} & set(det)):
            det_arriba = PQ.detectar(arriba)
            if len(det_arriba) > len(det) and len(os.listdir(arriba)) < 40:
                carpeta = arriba
        QtWidgets.QApplication.setOverrideCursor(Qt.WaitCursor)
        self.titulo.setText("Abriendo el caso…")
        QtWidgets.QApplication.processEvents()
        try:
            # el nombre del paciente: la primera carpeta hacia arriba que no sea «STL», «PLY» ni la de la orden
            nombre, ruta = os.path.basename(carpeta), carpeta
            for _ in range(4):
                if not (nombre.lower() in ("stl", "ply", "accudesignapp", "upperandlower", "maxymand")
                        or nombre[:4].isdigit() and nombre[4:5] == "-"):
                    break
                ruta = os.path.dirname(ruta)
                nombre = os.path.basename(ruta) or nombre
            caso = PQ.desde_carpeta(carpeta, {"paciente": nombre + "  (vista previa)"})
        except Exception as exc:  # noqa: BLE001
            QtWidgets.QApplication.restoreOverrideCursor()
            QtWidgets.QMessageBox.warning(self, "Análisis de modelos", f"No pude leer la carpeta:\n{exc}")
            return
        QtWidgets.QApplication.restoreOverrideCursor()
        if not caso["modelos"]:
            QtWidgets.QMessageBox.information(self, "Análisis de modelos", "No encontré modelos (UpperJaw / LowerJaw) en esa carpeta.")
            return
        self.ruta_caso = None
        self.id_caso = None
        self.mostrar_caso(caso)

    def enviar(self):
        from .enviar import DialogoEnviar

        DialogoEnviar(self).exec()
