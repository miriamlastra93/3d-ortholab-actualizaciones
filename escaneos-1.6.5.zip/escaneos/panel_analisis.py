"""Pestaña «Análisis» del visor (inspirada en MetronTrack): barra de análisis a la derecha, tarjeta con la tabla,
la norma y «Qué mide», y los trazos dibujados sobre el modelo 3D. El análisis lo hace esta app (analisis.py) en la
computadora del doctor; el doctor puede mover los puntos y corregir los anchos dentarios, y todo se vuelve a medir.
"""
from __future__ import annotations

import numpy as np
from PySide6 import QtCore, QtGui, QtWidgets
from PySide6.QtCore import Qt

from . import analisis as A

TURQ = "#1995AD"
NIVEL = {0: ("#2e9e5b", "normal"), 1: ("#d39b1c", "leve"), 2: ("#e07b22", "moderado"), 3: ("#d64541", "marcado"),
         9: ("#8b949e", "")}

ANALISIS = [  # clave, título de la tarjeta, etiqueta corta bajo el ícono
    ("resumen", "Resumen", "Resumen"),
    ("dientes", "Dientes y numeración", "Dientes"),
    ("espacio", "Medición de apiñamiento dental", "Apiñamiento"),
    ("bolton", "Medición de la relación de Bolton", "Bolton"),
    ("moyers", "Moyers (dentición mixta)", "Moyers"),
    ("oclusion", "Relación oclusal", "Oclusión"),
    ("corte", "Corte de oclusión", "Corte"),
    ("contactos", "Contactos oclusales", "Contactos"),
    ("korkhaus", "Korkhaus", "Korkhaus"),
    ("arcada", "Medición de la arcada dental", "Arcada"),
]
SUBS = {  # análisis con pestañas, como en MetronTrack
    "oclusion": [("overjet", "Sobremordida y resalte"), ("molar", "Relación molar"), ("canina", "Relación canina"),
                 ("lmedia", "Línea media")],
    "espacio": [("3-3", "3-3"), ("5-5", "5-5"), ("6-6", "6-6"), ("7-7", "7-7")],
    "bolton": [("arcada", "Medición de la arcada dental"), ("ancho", "Medición del ancho del diente")],
    "arcada": [("ancho", "Ancho del arco dental"), ("longitud", "Longitud del arco dental"),
               ("simetria", "Simetría de arcada dental"), ("forma", "Análisis de forma de arco")],
}
DE_SUB = {sub: clave for clave, subs in SUBS.items() if clave == "oclusion" for sub, _ in subs}


def _arco(p, cx, cy, rx, ry):
    """Arcada vista por oclusal: una U con el frente arriba."""
    camino = QtGui.QPainterPath()
    camino.moveTo(cx - rx, cy + ry)
    camino.cubicTo(cx - rx, cy - ry * 1.6, cx + rx, cy - ry * 1.6, cx + rx, cy + ry)
    p.drawPath(camino)
    return camino


def _dibujar_icono(clave, color, n=64):
    """Íconos propios, dibujados (se entienden sin leer): n×n px."""
    pm = QtGui.QPixmap(n, n)
    pm.fill(Qt.transparent)
    p = QtGui.QPainter(pm)
    p.setRenderHint(QtGui.QPainter.Antialiasing)
    c = QtGui.QColor(color)
    pluma = QtGui.QPen(c, 4.5, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
    fina = QtGui.QPen(c, 3, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
    p.setPen(pluma)
    p.setBrush(Qt.NoBrush)
    if clave == "resumen":  # lista con palomitas
        for k, y in enumerate((16, 32, 48)):
            p.setPen(fina)
            p.drawPolyline([QtCore.QPointF(8, y), QtCore.QPointF(12, y + 4), QtCore.QPointF(19, y - 5)])
            p.setPen(pluma)
            p.drawLine(28, y, 56, y)
    elif clave == "oclusion":  # incisivo superior por delante del inferior, de perfil, con la cota
        sup = QtGui.QPainterPath()
        sup.moveTo(30, 4)
        sup.cubicTo(14, 8, 8, 26, 14, 40)
        sup.cubicTo(22, 30, 34, 22, 40, 6)
        sup.closeSubpath()
        inf = QtGui.QPainterPath()
        inf.moveTo(34, 30)
        inf.cubicTo(30, 40, 34, 52, 42, 60)
        inf.cubicTo(50, 52, 48, 38, 34, 30)
        inf.closeSubpath()
        p.setBrush(c)
        p.setPen(Qt.NoPen)
        p.setOpacity(0.95)
        p.drawPath(sup)
        p.setOpacity(0.55)
        p.drawPath(inf)
        p.setOpacity(1)
        p.setPen(fina)
        p.drawLine(14, 50, 32, 50)
        p.drawLine(14, 45, 14, 55)
        p.drawLine(32, 45, 32, 55)
    elif clave == "dientes":  # diente con su número
        cam = QtGui.QPainterPath()
        cam.moveTo(14, 30)
        cam.cubicTo(8, 10, 26, 6, 32, 14)
        cam.cubicTo(38, 6, 56, 10, 50, 30)
        cam.cubicTo(48, 44, 44, 58, 40, 58)
        cam.cubicTo(36, 58, 36, 42, 32, 42)
        cam.cubicTo(28, 42, 28, 58, 24, 58)
        cam.cubicTo(20, 58, 16, 44, 14, 30)
        p.drawPath(cam)
        f = p.font()
        f.setPixelSize(17)
        f.setBold(True)
        p.setFont(f)
        p.drawText(QtCore.QRectF(14, 12, 36, 24), Qt.AlignCenter, "11")
    elif clave == "corte":  # dientes en oclusión atravesados por el plano de corte
        p.setPen(fina)
        for x in (6, 24, 42):
            p.drawRoundedRect(QtCore.QRectF(x, 12, 16, 18), 5, 5)
            p.drawRoundedRect(QtCore.QRectF(x, 34, 16, 18), 5, 5)
        p.setPen(QtGui.QPen(c, 5, Qt.SolidLine, Qt.RoundCap))
        p.drawLine(32, 3, 32, 61)
    elif clave == "contactos":  # molar por oclusal con puntos de contacto
        p.drawRoundedRect(QtCore.QRectF(9, 11, 46, 42), 15, 15)
        p.setPen(fina)
        p.drawLine(32, 20, 32, 44)
        p.drawLine(20, 32, 44, 32)
        p.setPen(Qt.NoPen)
        p.setBrush(c)
        for x, y in ((22, 23), (43, 24), (23, 42), (42, 41)):
            p.drawEllipse(QtCore.QPointF(x, y), 4.5, 4.5)
    elif clave == "korkhaus":  # arcada con los anchos transversales
        _arco(p, 32, 34, 22, 20)
        p.setPen(fina)
        for y, dx in ((30, 15), (48, 20)):
            p.drawLine(32 - dx, y, 32 + dx, y)
            for sx in (-1, 1):
                x = 32 + sx * dx
                p.drawPolyline([QtCore.QPointF(x - sx * 5, y - 4), QtCore.QPointF(x, y), QtCore.QPointF(x - sx * 5, y + 4)])
    elif clave == "espacio":  # dientes encimados sobre la curva de la arcada
        p.setPen(fina)
        _arco(p, 32, 40, 24, 16)
        p.setBrush(QtGui.QBrush(QtGui.QColor(color)))
        for x, y, g in ((16, 24, -24), (28, 15, 14), (40, 17, -16), (50, 27, 30)):
            p.save()
            p.translate(x, y)
            p.rotate(g)
            p.setOpacity(0.9)
            p.drawRoundedRect(QtCore.QRectF(-6, -8, 12, 16), 4, 4)
            p.restore()
    elif clave == "bolton":  # tres dientes con la cota mesiodistal de uno
        p.setPen(fina)
        for x, w in ((5, 15), (23, 18), (44, 15)):
            p.drawRoundedRect(QtCore.QRectF(x, 10, w, 26), 6, 6)
        p.setPen(pluma)
        p.drawLine(23, 50, 41, 50)
        p.setPen(fina)
        p.drawLine(23, 43, 23, 57)
        p.drawLine(41, 43, 41, 57)
    elif clave == "moyers":  # arcada con el tramo 3-4-5 marcado y el germen por erupcionar
        p.setOpacity(0.45)
        camino = _arco(p, 32, 34, 22, 20)
        p.setOpacity(1)
        tramo = QtGui.QPainterPath()
        for k, t in enumerate(np.linspace(0.08, 0.36, 12)):
            q = camino.pointAtPercent(t)
            tramo.moveTo(q) if k == 0 else tramo.lineTo(q)
        p.setPen(QtGui.QPen(c, 8, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        p.drawPath(tramo)
        p.setPen(fina)
        p.drawLine(46, 34, 46, 52)
        p.drawPolyline([QtCore.QPointF(40, 40), QtCore.QPointF(46, 33), QtCore.QPointF(52, 40)])
    elif clave == "arcada":  # la curva de la arcada con sus dientes
        camino = _arco(p, 32, 34, 22, 20)
        p.setPen(Qt.NoPen)
        p.setBrush(c)
        for t in np.linspace(0.02, 0.98, 9):
            p.drawEllipse(camino.pointAtPercent(t), 5, 5)
    p.end()
    return pm


def icono(clave):
    ic = QtGui.QIcon()
    ic.addPixmap(_dibujar_icono(clave, "#4a5560"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
    ic.addPixmap(_dibujar_icono(clave, "#ffffff"), QtGui.QIcon.Normal, QtGui.QIcon.On)
    ic.addPixmap(_dibujar_icono(clave, "#b8c0c8"), QtGui.QIcon.Disabled, QtGui.QIcon.Off)
    return ic

QUE_MIDE = {
    "resumen": "Lo principal del caso de un vistazo. Toca una línea para ver el análisis.",
    "dientes": "Cada diente separado y numerado (FDI). Si un número está mal, haz clic en el diente y corrígelo: "
               "todo el análisis se vuelve a medir.",
    "forma": "La curva de la arcada y su forma.",
    "longitud": "Profundidad de cada arcada sobre su eje medio, desde el borde de los incisivos hasta caninos, "
                "premolares y molares. También la curva de Spee y la altura del paladar.",
    "simetria": "Qué tan lejos queda cada lado (caninos, premolares y molares) del eje medio de la arcada.",
    "overjet": "Resalte (overjet) y sobremordida (overbite) en un corte sagital por el centro de cada central superior.",
    "molar": "Dónde cae la cúspide mesiovestibular del primer molar superior respecto al surco mesiovestibular del "
             "primer molar inferior.",
    "canina": "Dónde cae la cúspide del canino superior respecto a la tronera entre el canino y el primer premolar "
              "inferiores.",
    "lmedia": "Línea media superior (entre 11 y 21) e inferior (entre 41 y 31): cuánto se desvían entre sí y "
              "respecto al eje de la arcada.",
    "corte": "El perfil de los dientes en el lugar que elijas, en mm.",
    "contactos": "Qué tan cerca quedan las arcadas en oclusión, diente por diente. Rojo = contacto firme.",
    "korkhaus": "Ancho de la arcada en premolares y molares, y largo anterior, frente a lo ideal para el tamaño "
                "de los incisivos superiores (SI).",
    "espacio": "Tamaño de los dientes frente al tamaño de la arcada, por segmentos. La línea verde de cada diente "
               "es su ancho mesiodistal.",
    "bolton": "Proporción entre el tamaño de los dientes inferiores y superiores.",
    "moyers": "Para pacientes en crecimiento: cuánto medirán canino y premolares (3-4-5) que aún no erupcionan, "
              "frente al espacio que hay de distal del lateral a mesial del primer molar.",
    "arcada": "Forma, anchura y simetría de las arcadas, y curva de Spee.",
}

NORMA = {
    "overjet": "Overjet: 0–3 mm normal · 3–5 aumentado leve · 5–8 aumentado · >8 muy aumentado · ≤0 borde a borde "
               "o cruzada.<br>Overbite: 0–3 mm (≈ 1/3 de la corona) · 3–5 profunda leve · >5 profunda · <0 mordida "
               "abierta.<br>Con incisivos rotados el valor cambia a lo ancho de la corona: mueve el corte con "
               "«Ajustar cortes».",
    "molar": "Medida en vista lateral. Clase I (neutra): la cúspide cae en el surco (±2.5 mm, un cuarto de cúspide). Clase II: la cúspide "
             "superior queda por delante (mesial) del surco. Clase III: queda por detrás (distal).",
    "canina": "Medida a lo largo de la arcada. Clase I (neutra): la cúspide cae en la tronera (±3 mm). Clase II: queda "
              "por delante (mesial). Clase III: queda por detrás (distal).",
    "lmedia": "Desviación entre líneas medias: hasta 2 mm se considera aceptable.",
    "contactos": "Distancia entre arcadas en las caras oclusales: <0.1 mm contacto firme · 0.1–0.3 casi en contacto "
                 "· 0.3–0.6 cercano. Áreas en mm². Confirmar en clínica con papel de articular.",
    "korkhaus": "Ideal (Pont/Korkhaus) con SI = 12+11+21+22: premolar = SI×100/85 · molar = SI×100/65 · largo anterior "
                "superior Lo = SI×100/160 · inferior Lu = Lo − 2.<br>Diferencia <1 mm normal · 1–2 leve · 2–3 "
                "moderada · >3 marcada (negativo = compresión).",
    "espacio": "Apiñamiento = tamaño de los dientes − tamaño de la arcada: hasta 4 mm leve · 4–8 moderado · >8 severo. "
               "Negativo = sobra espacio (diastemas).",
    "bolton": "Relación anterior 78.8 ± 1.72 % (6 dientes) · relación general 91.5 ± 1.51 % (12 dientes).",
    "moyers": "Moyers al 75 % (tabla clásica) con la suma de los 4 incisivos inferiores; Tanaka-Johnston como "
              "segunda opinión (superior SI/2 + 11 mm, inferior SI/2 + 10.5 mm). Discrepancia = espacio disponible "
              "− espacio necesario por cuadrante (negativo = faltará espacio).",
    "arcada": "Los anchos se miden entre los centros de las coronas (caninos, primeros premolares y primeros molares).",
    "longitud": "Curva de Spee 2 ± 0.7 mm, medida con la cúspide de cada diente inferior.",
    "simetria": "Hasta 2 mm de diferencia entre el lado derecho y el izquierdo se considera simétrico.",
}

# puntos que el doctor puede mover: clave → (arcada, dónde vive en caso.P, nombre)
PUNTOS = {
    "overjet": [("sup", "inc", "11"), ("sup", "inc", "21"), ("inf", "inc", "41"), ("inf", "inc", "31")],
    "korkhaus": [("sup", "sup", "14"), ("sup", "sup", "24"), ("sup", "sup", "16"), ("sup", "sup", "26"),
                 ("inf", "inf", "c44/45"), ("inf", "inf", "c34/35"), ("inf", "inf", "46"), ("inf", "inf", "36")],
    "moyers": [("sup", "cen", "12"), ("sup", "cen", "22"), ("sup", "cen", "16"), ("sup", "cen", "26"),
               ("inf", "cen", "42"), ("inf", "cen", "32"), ("inf", "cen", "46"), ("inf", "cen", "36")],
    "molar": [("sup", "aj", "molar_der_sup", "Cúspide MV del 16"), ("inf", "aj", "molar_der_inf", "Surco MV del 46"),
              ("sup", "aj", "molar_izq_sup", "Cúspide MV del 26"), ("inf", "aj", "molar_izq_inf", "Surco MV del 36")],
    "canina": [("sup", "aj", "canina_der_sup", "Cúspide del 13"), ("inf", "aj", "canina_der_inf", "Tronera 43/44"),
               ("sup", "aj", "canina_izq_sup", "Cúspide del 23"), ("inf", "aj", "canina_izq_inf", "Tronera 33/34")],
    "lmedia": [("sup", "aj", "lm_sup", "Línea media superior"), ("inf", "aj", "lm_inf", "Línea media inferior")],
    "arcada": [("sup", "cen", "13"), ("sup", "cen", "23"), ("sup", "cen", "14"), ("sup", "cen", "24"),
               ("sup", "cen", "16"), ("sup", "cen", "26"), ("inf", "cen", "43"), ("inf", "cen", "33"),
               ("inf", "cen", "44"), ("inf", "cen", "34"), ("inf", "cen", "46"), ("inf", "cen", "36")],
}


PUNTOS["simetria"] = PUNTOS["longitud"] = PUNTOS["arcada"]  # los mismos centros de caninos, premolares y molares


SIN_DIENTES = ("dientes", "corte")  # lo único que se puede usar sin los dientes identificados


def texto_punto(pt):
    return pt[3] if len(pt) > 3 else pt[2].lstrip("c")


CLASES = ["Clase I", "Clase II", "Clase III", "No valorable"]
FORMAS = ["Oval", "Redondo puntiagudo", "Cuadrado redondeado", "Puntiagudo", "Cuadrado"]


def chip(texto, nivel):
    c = NIVEL.get(nivel, NIVEL[9])[0]
    return f'<span style="background:{c};color:white;">&nbsp;{texto}&nbsp;</span>'


def mm(v, d=1):
    return "—" if v is None else f"{v:.{d}f}"


def tabla(enc, filas):
    h = ['<table cellspacing="0" cellpadding="3" width="100%" style="border-collapse:collapse;font-size:9pt;">',
         "<tr>" + "".join(f'<td style="color:#3d4753;background:#eef1f4;border-bottom:1px solid #cfd6dd;">{e}</td>' for e in enc) + "</tr>"]
    for f in filas:
        h.append("<tr>" + "".join(f'<td style="border-bottom:1px solid #e1e6ea;">{c}</td>' for c in f) + "</tr>")
    h.append("</table>")
    return "".join(h)


def etiqueta(html, muted=False):
    lb = QtWidgets.QLabel(html)
    lb.setWordWrap(True)
    lb.setTextFormat(Qt.RichText)
    if muted:
        lb.setStyleSheet("color:#6b7682;font-size:9pt;")
    return lb


# ----------------------------------------------------------------------------- el corte sagital en 2D
class CorteSagital(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(230)
        self.sup = self.inf = None
        self.r = None

    def poner(self, sup, inf, r):
        self.sup, self.inf, self.r = sup, inf, r
        self.update()

    def paintEvent(self, _):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        p.fillRect(self.rect(), QtGui.QColor("#f3f5f7"))
        if self.r is None or self.sup is None:
            p.setPen(QtGui.QColor("#8b949e"))
            p.drawText(self.rect(), Qt.AlignCenter, "Sin corte")
            return
        r = self.r
        # encuadre: los dos bordes incisales y espacio para las cotas (con overjet grande se aleja)
        yc = (r["y_up"] + r["y_lo"]) / 2 + 1.5
        zc = (r["z_up"] + r["z_lo"]) / 2
        half = max(8.0, abs(r["y_lo"] - r["y_up"]) / 2 + 6.0, abs(r["z_lo"] - r["z_up"]) / 2 + 7.0)
        W, H = self.width(), self.height()
        esc = min(W, H) / (2 * half)

        def px(y, z):  # anterior a la izquierda, arriba = +z
            return QtCore.QPointF(W / 2 + (y - yc) * esc, H / 2 - (z - zc) * esc)

        for pts, col in ((self.sup, "#58b947"), (self.inf, "#f26a1b")):
            p.setPen(Qt.NoPen)
            p.setBrush(QtGui.QColor(col))
            for y, z in pts[::max(1, len(pts) // 2500)]:
                q = px(y, z)
                if 0 <= q.x() <= W and 0 <= q.y() <= H:
                    p.drawEllipse(q, 1.3, 1.3)
        roj, ver = QtGui.QColor("#d64541"), QtGui.QColor("#1f7a8c")
        pen = QtGui.QPen(roj, 1.4, Qt.DashLine)
        p.setPen(pen)
        yu, yl, zu, zl = r["y_up"], r["y_lo"], r["z_up"], r["z_lo"]
        zb = min(zu, zl) - 2.5
        p.drawLine(px(yu, zu + 0.6), px(yu, zb))
        p.drawLine(px(yl, zl), px(yl, zb))
        p.setPen(QtGui.QPen(roj, 2))
        p.drawLine(px(yu, zb), px(yl, zb))
        f = p.font()
        f.setBold(True)
        f.setPointSize(9)
        p.setFont(f)
        p.drawText(px(min(yu, yl), zb - 0.6) + QtCore.QPointF(0, 14), f"Overjet {r['overjet']:.1f} mm")
        xo = max(yu, yl) + 3.0
        p.setPen(QtGui.QPen(ver, 1.4, Qt.DashLine))
        p.drawLine(px(min(yu, yl) - 0.5, zu), px(xo + 0.4, zu))
        p.drawLine(px(min(yu, yl) - 0.5, zl), px(xo + 0.4, zl))
        p.setPen(QtGui.QPen(ver, 2))
        p.drawLine(px(xo, zu), px(xo, zl))
        p.drawText(px(xo + 0.5, (zu + zl) / 2) + QtCore.QPointF(2, 4), f"Overbite {r['overbite']:.1f} mm")
        p.setPen(QtGui.QColor("#8b949e"))
        f.setBold(False)
        f.setPointSize(8)
        p.setFont(f)
        p.drawText(QtCore.QRectF(6, H - 20, W - 12, 16), Qt.AlignLeft, "← anterior")
        p.drawText(QtCore.QRectF(6, H - 20, W - 12, 16), Qt.AlignRight, "superior verde · inferior naranja")


class GraficaCorte(QtWidgets.QWidget):
    """Perfil del corte libre (como «Visualización de la oclusión» de MetronTrack): cuadrícula en mm,
    superior en verde e inferior en naranja."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(330)
        self.sup = self.inf = None

    def poner(self, sup, inf, rotulos=None):
        """sup / inf: segmentos (n, 2, 2) en mm sobre el plano (horizontal, vertical). rotulos: qué hay a la
        izquierda y a la derecha de la gráfica (p. ej. «lingual», «vestibular»)."""
        self.sup, self.inf, self.rotulos = sup, inf, rotulos
        self.update()

    def paintEvent(self, _):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        W, H = self.width(), self.height()
        p.fillRect(self.rect(), QtGui.QColor("#f3f5f7"))
        todos = [s.reshape(-1, 2) for s in (self.sup, self.inf) if s is not None and len(s)]
        if not todos:
            p.setPen(QtGui.QColor("#6b7682"))
            p.drawText(self.rect(), Qt.AlignCenter, "El plano no corta los modelos")
            return
        P = np.vstack(todos)
        c = (P.min(0) + P.max(0)) / 2
        medio = max(float((P.max(0) - P.min(0)).max()) / 2 * 1.12, 6.0)
        m = 30  # margen para los números
        esc = (min(W, H) - 2 * m) / (2 * medio)

        def px(q):
            return QtCore.QPointF(W / 2 + (q[0] - c[0]) * esc, H / 2 - (q[1] - c[1]) * esc)

        paso = 5 if medio < 30 else 10
        f = p.font()
        f.setPointSize(8)
        p.setFont(f)
        for k in range(int(np.floor((c[0] - medio) / paso)), int(np.ceil((c[0] + medio) / paso)) + 1):
            x = px((k * paso, 0)).x()
            if m <= x <= W - 6:
                p.setPen(QtGui.QPen(QtGui.QColor("#d5dbe1"), 1))
                p.drawLine(QtCore.QPointF(x, 6), QtCore.QPointF(x, H - m + 8))
                p.setPen(QtGui.QColor("#5b6570"))
                p.drawText(QtCore.QRectF(x - 20, H - m + 10, 40, 14), Qt.AlignCenter, str(k * paso))
        for k in range(int(np.floor((c[1] - medio) / paso)), int(np.ceil((c[1] + medio) / paso)) + 1):
            y = px((0, k * paso)).y()
            if 6 <= y <= H - m + 8:
                p.setPen(QtGui.QPen(QtGui.QColor("#d5dbe1"), 1))
                p.drawLine(QtCore.QPointF(m, y), QtCore.QPointF(W - 6, y))
                p.setPen(QtGui.QColor("#5b6570"))
                p.drawText(QtCore.QRectF(0, y - 7, m - 4, 14), Qt.AlignRight | Qt.AlignVCenter, str(k * paso))
        for segs, col in ((self.sup, "#58b947"), (self.inf, "#f26a1b")):
            if segs is None:
                continue
            p.setPen(QtGui.QPen(QtGui.QColor(col), 2.2, Qt.SolidLine, Qt.RoundCap))
            for a, b in segs:
                p.drawLine(px(a), px(b))
        if getattr(self, "rotulos", None):
            p.setPen(QtGui.QColor("#3d4753"))
            p.drawText(QtCore.QRectF(m + 4, H - m - 8, 120, 14), Qt.AlignLeft, "← " + self.rotulos[0])
            p.drawText(QtCore.QRectF(W - 130, H - m - 8, 124, 14), Qt.AlignRight, self.rotulos[1] + " →")
        p.setPen(QtGui.QColor("#58b947"))
        p.drawText(QtCore.QRectF(m + 4, 6, 120, 14), Qt.AlignLeft, "— superior")
        p.setPen(QtGui.QColor("#f26a1b"))
        p.drawText(QtCore.QRectF(m + 84, 6, 120, 14), Qt.AlignLeft, "— inferior")


# ----------------------------------------------------------------------------- el cálculo, en segundo plano
class Trabajador(QtCore.QObject):
    listo = QtCore.Signal(object, int)
    fallo = QtCore.Signal(str, int)
    progreso = QtCore.Signal(str, int)

    def __init__(self, sup, inf, anchos, AD, gen, etiquetas=None):
        super().__init__()
        self.args = (sup, inf, anchos, AD, etiquetas)
        self.gen = gen

    @QtCore.Slot()
    def correr(self):
        try:
            sup, inf, anchos, AD, etiquetas = self.args
            caso = A.preparar(sup, inf, anchos, AD, progreso=lambda t: self.progreso.emit(t, self.gen),
                              etiquetas=etiquetas)
            self.progreso.emit("Midiendo…", self.gen)
            caso.contactos()
            self.listo.emit(caso, self.gen)
        except A.ErrorAnalisis as exc:
            self.fallo.emit(str(exc), self.gen)
        except Exception as exc:  # noqa: BLE001
            self.fallo.emit(f"No se pudo analizar el caso: {exc}", self.gen)


class TrabajadorIA(QtCore.QObject):
    """Identifica los dientes de las dos arcadas con IA (solo en la PC de la Dra.)."""
    listo = QtCore.Signal(object, int)
    fallo = QtCore.Signal(str, int)
    progreso = QtCore.Signal(str, int)

    def __init__(self, caso, gen):
        super().__init__()
        self.caso, self.gen = caso, gen

    @QtCore.Slot()
    def correr(self):
        try:
            from . import dientes_ia

            self.progreso.emit("Preparando la identificación de dientes…", self.gen)
            c = self.caso
            avisar = lambda t: self.progreso.emit(t, self.gen)  # noqa: E731
            out = {"sup": dientes_ia.identificar(c.U, c.FU, "sup", progreso=avisar),
                   "inf": dientes_ia.identificar(c.L, c.FL, "inf", progreso=avisar)}
            self.listo.emit(out, self.gen)
        except Exception as exc:  # noqa: BLE001
            self.fallo.emit(f"No se pudieron identificar los dientes: {exc}", self.gen)


# ----------------------------------------------------------------------------- el panel
class PanelAnalisis(QtWidgets.QFrame):
    """Tarjeta + barra de análisis. `pagina` dibuja los trazos y maneja la cámara."""

    def __init__(self, pagina):
        super().__init__()
        self.pagina = pagina
        self.caso = None
        self.res = None
        self.actual = "resumen"
        self.sub = {clave: subs[0][0] for clave, subs in SUBS.items()}
        self.sub["espacio"] = "6-6"
        self.diente_sel = None  # (arcada, diente) elegido con un clic en Apiñamiento / Bolton
        self.punto_activo = None  # (arcada, dónde, nombre) a mover con el siguiente clic
        self.setObjectName("panelan")
        self.setStyleSheet(
            "QFrame#panelan{background:#ffffff;border-radius:12px;}"
            "QFrame#panelan QPushButton{background:#eef1f4;color:#1f2933;border:1px solid #cfd6dd;border-radius:8px;"
            "padding:5px 8px;}"
            "QFrame#panelan QPushButton:hover{background:#e3eef2;border-color:#1995AD;}"
            "QFrame#panelan QPushButton:checked{background:#1995AD;color:white;border-color:#1995AD;font-weight:600;}"
            "QFrame#panelan QPushButton#pestana{border-radius:14px;font-size:9pt;}"
            "QFrame#panelan QScrollBar:vertical{background:#eef1f4;width:10px;}"
            "QFrame#panelan QScrollBar::handle:vertical{background:#c3ccd4;border-radius:5px;min-height:30px;}")
        h = QtWidgets.QHBoxLayout(self)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(0)
        # barra de análisis, pegada al visor (como MetronTrack): ícono dibujado + nombre
        barra = QtWidgets.QFrame()
        barra.setFixedWidth(84)
        barra.setStyleSheet("QFrame{background:#eef1f4;border-top-left-radius:12px;border-bottom-left-radius:12px;}")
        bv = QtWidgets.QVBoxLayout(barra)
        bv.setContentsMargins(5, 6, 5, 6)
        bv.setSpacing(2)
        self.grupo = QtWidgets.QButtonGroup(self)
        for i, (clave, texto, corto) in enumerate(ANALISIS):
            b = QtWidgets.QToolButton()
            b.setIcon(icono(clave))
            b.setIconSize(QtCore.QSize(26, 26))
            b.setText(corto)
            b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
            b.setToolTip(texto)
            b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor)
            b.setFixedSize(74, 52)
            b.setStyleSheet(f"QToolButton{{border:none;border-radius:10px;font-size:8pt;background:transparent;"
                            f"color:#4a5560;padding:2px 0;}}"
                            f"QToolButton:hover{{background:#dfe6eb;}}"
                            f"QToolButton:checked{{background:{TURQ};color:white;font-weight:600;}}"
                            f"QToolButton:disabled{{color:#b8c0c8;}}")
            self.grupo.addButton(b, i)
            bv.addWidget(b, 0, Qt.AlignHCenter)
        bv.addStretch(1)
        self.grupo.idClicked.connect(lambda i: self.mostrar(ANALISIS[i][0]))
        h.addWidget(barra)
        # tarjeta
        tarjeta = QtWidgets.QWidget()
        tarjeta.setFixedWidth(430)
        tv = QtWidgets.QVBoxLayout(tarjeta)
        tv.setContentsMargins(14, 12, 10, 12)
        self.t_titulo = QtWidgets.QLabel("Análisis")
        self.t_titulo.setStyleSheet("font-size:13pt;font-weight:700;color:#1f2933;")
        tv.addWidget(self.t_titulo)
        self.t_que = etiqueta("", muted=True)
        tv.addWidget(self.t_que)
        self.scroll = QtWidgets.QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.scroll.setStyleSheet("QScrollArea{background:transparent;border:none;}")
        self.scroll.viewport().setObjectName("vp")
        self.scroll.viewport().setStyleSheet("QWidget#vp{background:transparent;}")
        tv.addWidget(self.scroll, 1)
        self.b_norma = QtWidgets.QToolButton()
        self.b_norma.setText("Valor de referencia ▾")
        self.b_norma.setCheckable(True)
        self.b_norma.setStyleSheet("QToolButton{border:none;color:#3d4753;font-weight:600;background:transparent;}")
        self.b_norma.toggled.connect(lambda on: (self.l_norma.setVisible(on),
                                                 self.b_norma.setText("Valor de referencia " + ("▴" if on else "▾"))))
        tv.addWidget(self.b_norma)
        self.l_norma = etiqueta("", muted=True)
        self.l_norma.setVisible(False)
        tv.addWidget(self.l_norma)
        tv.addWidget(etiqueta("Úselo junto con las condiciones clínicas.", muted=True))
        h.addWidget(tarjeta)
        self.esperando("Abre un caso para analizarlo.")

    # ------------------------------------------------------------------ estados
    def _contenido(self, w):
        w.setObjectName("contenido")
        w.setStyleSheet("QWidget#contenido{background:transparent;} QLabel{color:#1f2933;}")
        old = self.scroll.takeWidget()
        if old is not None:
            old.deleteLater()
        self.scroll.setWidget(w)

    def esperando(self, texto):
        self.caso = self.res = None
        self.t_titulo.setText("Análisis")
        self.t_que.setText("")
        self.l_norma.setText("")
        w = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(w)
        lb = etiqueta(texto)
        lb.setStyleSheet("color:#3d4753;font-size:11pt;")
        v.addWidget(lb)
        v.addStretch(1)
        self._contenido(w)
        for b in self.grupo.buttons():
            b.setEnabled(False)

    def poner_caso(self, caso):
        self.caso = caso
        for b in self.grupo.buttons():
            b.setEnabled(True)
        self.remedir(redibujar=False)
        self.mostrar(self.actual)

    def remedir(self, redibujar=True):
        self.res = A.medir(self.caso)
        if redibujar:
            self.mostrar(self.actual, mover_camara=False)

    # ------------------------------------------------------------------ mostrar un análisis
    @property
    def vista(self):
        """Lo que se dibuja en el modelo: el análisis o, en «Relación oclusal», su pestaña."""
        if self.actual == "arcada":
            return {"ancho": "arcada"}.get(self.sub["arcada"], self.sub["arcada"])
        return self.sub["oclusion"] if self.actual == "oclusion" else self.actual

    def mostrar(self, clave, mover_camara=True):
        if clave in DE_SUB:  # p. ej. «molar» → Relación oclusal, pestaña Relación molar
            self.sub[DE_SUB[clave]] = clave
            clave = DE_SUB[clave]
        self.actual = clave
        self.punto_activo = None
        if self.pagina._clic == "punto":
            self.pagina.modo_clic(None)
        self.grupo.button([k for k, _, _ in ANALISIS].index(clave)).setChecked(True)
        self.t_titulo.setText(dict((k, t) for k, t, _ in ANALISIS)[clave])
        ayuda = self.vista
        self.t_que.setText(QUE_MIDE[ayuda])
        self.l_norma.setText(NORMA.get(ayuda, ""))
        self.b_norma.setVisible(ayuda in NORMA)
        self.l_norma.setVisible(self.b_norma.isChecked() and ayuda in NORMA)
        if self.res is None:
            return
        w = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(w)
        v.setContentsMargins(0, 4, 4, 4)
        if not self.caso.etiquetas and clave not in SIN_DIENTES:
            # sin los dientes identificados no se analiza: los números saldrían de dientes equivocados
            self._card_faltan_dientes(v)
            v.addStretch(1)
            self._contenido(w)
            self.pagina.dibujar_analisis("bloqueado", self.caso, self.res, mover_camara)
            return
        if clave in SUBS:
            v.addWidget(self._pestanas(clave))
        getattr(self, "_card_" + (self.vista if clave == "oclusion" else clave))(v)
        if clave in ("espacio", "bolton") and self.caso.etiquetas:
            v.addWidget(self._ajuste_diente())
        if self.vista in PUNTOS and (self.vista not in ("molar", "canina") or self.caso.etiquetas):
            v.addWidget(self._ajustar(self.vista))
        v.addStretch(1)
        self._contenido(w)
        self.pagina.dibujar_analisis(self.vista, self.caso, self.res, mover_camara)

    def _pestanas(self, clave):
        w = QtWidgets.QWidget()
        g = QtWidgets.QGridLayout(w)
        g.setContentsMargins(0, 0, 0, 4)
        g.setSpacing(4)
        grupo = QtWidgets.QButtonGroup(w)
        subs = SUBS[clave]
        por_fila = 4 if clave == "espacio" else 2
        for i, (sub, texto) in enumerate(subs):
            b = QtWidgets.QPushButton(texto)
            b.setCheckable(True)
            b.setChecked(self.sub[clave] == sub)
            b.setObjectName("pestana")
            grupo.addButton(b, i)
            g.addWidget(b, i // por_fila, i % por_fila)
        grupo.idClicked.connect(lambda i, clave=clave: self._elegir_sub(clave, SUBS[clave][i][0]))
        return w

    def _elegir_sub(self, clave, sub):
        self.sub[clave] = sub
        self.mostrar(clave, mover_camara=(clave in ("oclusion", "arcada")))

    def _ajustar(self, clave):
        caja = QtWidgets.QGroupBox("Ajustar puntos" if clave != "overjet" else "Ajustar cortes")
        caja.setStyleSheet("QGroupBox{color:#3d4753;font-weight:600;border:1px solid #d5dbe1;border-radius:8px;"
                           "margin-top:10px;padding-top:12px;}")
        g = QtWidgets.QGridLayout(caja)
        g.addWidget(etiqueta("Elige un punto y haz clic en el modelo donde debe ir. Se vuelve a medir solo.",
                             muted=True), 0, 0, 1, 4)
        self._bpuntos = QtWidgets.QButtonGroup(caja)
        self._bpuntos.setExclusive(True)
        por_fila = 2 if len(PUNTOS[clave][0]) > 3 else 4
        for i, pt in enumerate(PUNTOS[clave]):
            b = QtWidgets.QPushButton(texto_punto(pt))
            b.setCheckable(True)
            b.setStyleSheet(f"QPushButton:checked{{background:{TURQ};color:white;}}")
            b.toggled.connect(lambda on, pt=pt: self._elegir_punto(pt if on else None))
            self._bpuntos.addButton(b)
            g.addWidget(b, 1 + i // por_fila, (i % por_fila) * (4 // por_fila), 1, 4 // por_fila)
        b_res = QtWidgets.QPushButton("Restablecer automático")
        b_res.clicked.connect(self._restablecer)
        g.addWidget(b_res, 10, 0, 1, 4)
        return caja

    def _elegir_punto(self, pt):
        self.punto_activo = pt
        self.pagina.modo_clic("punto" if pt else None)

    def mover_punto(self, jaw, x, y, z=0.0):
        """El doctor hizo clic en el modelo con un punto elegido: (x, y, z) en el marco del análisis."""
        if not self.punto_activo or self.caso is None:
            return False
        pj, donde, nombre = self.punto_activo[:3]
        if pj != jaw:
            self.pagina.aviso(f"Ese punto va en la arcada {'superior' if pj == 'sup' else 'inferior'}.")
            return True
        P = self.caso.P
        xyz = [round(float(x), 2), round(float(y), 2), round(float(z), 2)]
        if donde == "inc":
            P["incisivos"][nombre] = xyz[0]
        elif donde == "cen":
            P["centros"][jaw][nombre] = xyz[:2]
            if nombre in P[jaw]:
                P[jaw][nombre] = P["centros"][jaw][nombre]
        elif donde == "aj":  # clase molar / canina (punto 3D) y líneas medias (solo x)
            P.setdefault("ajustes", {})[nombre] = xyz[0] if nombre.startswith("lm_") else xyz
        elif donde == "md":  # punto mesial o distal de un diente: cambia su ancho
            diente, extremo = nombre
            P.setdefault("md", {}).setdefault(diente, {})[extremo] = xyz
            md = A.mesiodistal(self.caso).get(diente)
            if md:
                self.caso.anchos[diente] = round(md["ancho"], 1)
                self.caso.anchos_fuente = "doctor"
        else:
            P[jaw][nombre] = xyz[:2]
            if nombre in P["centros"][jaw]:
                P["centros"][jaw][nombre] = P[jaw][nombre]
        activo = self.punto_activo
        self.pagina.guardar_ediciones()
        self.remedir()
        # dejar elegido el siguiente punto de la lista (más rápido para ajustar varios)
        lista = PUNTOS.get(self.vista, [])
        if activo in lista and len(lista) > 2:
            sig = lista[(lista.index(activo) + 1) % len(lista)]
            for b in self._bpuntos.buttons():
                if b.text() == texto_punto(sig):
                    b.setChecked(True)
        return True

    # --- ajustes a criterio del doctor
    def elegir_diente(self, jaw, fdi):
        """Clic en un diente del modelo (Apiñamiento / Bolton): queda elegido para mover sus puntos mesial y distal."""
        nombre = str(fdi)
        if nombre[0] in "5678":
            nombre = str(int(nombre[0]) - 4) + nombre[1]
        self.diente_sel = (jaw, nombre)
        self.mostrar(self.actual, mover_camara=False)

    def _ajuste_diente(self):
        caja = QtWidgets.QGroupBox("Ajustar un diente")
        caja.setStyleSheet("QGroupBox{color:#3d4753;font-weight:600;border:1px solid #d5dbe1;border-radius:8px;"
                           "margin-top:10px;padding-top:12px;}")
        g = QtWidgets.QGridLayout(caja)
        if not self.diente_sel:
            g.addWidget(etiqueta("Haz clic en un diente del modelo para mover su punto mesial o distal "
                                 "(la línea verde) y corregir su ancho.", True), 0, 0, 1, 2)
            return caja
        jaw, t = self.diente_sel
        md = (self.res.get("md") or {}).get(t)
        ancho = A.ancho(self.caso.anchos, t) or (md or {}).get("ancho", 0)
        g.addWidget(etiqueta(f"<b>Diente {t}</b> · ancho mesiodistal {ancho:.1f} mm"), 0, 0, 1, 2)
        g.addWidget(etiqueta("Elige el punto y haz clic en el modelo donde debe ir.", True), 1, 0, 1, 2)
        self._bpuntos = QtWidgets.QButtonGroup(caja)
        for i, (extremo, texto) in enumerate((("m", "Mover punto mesial"), ("d", "Mover punto distal"))):
            b = QtWidgets.QPushButton(texto)
            b.setCheckable(True)
            b.toggled.connect(lambda on, e=extremo: self._elegir_punto((jaw, "md", (t, e)) if on else None))
            self._bpuntos.addButton(b)
            g.addWidget(b, 2, i)
        if (self.caso.P.get("md") or {}).get(t):
            b = QtWidgets.QPushButton("Regresar este diente a lo automático")
            b.clicked.connect(lambda: self._soltar_diente(t))
            g.addWidget(b, 3, 0, 1, 2)
        return caja

    def _soltar_diente(self, t):
        (self.caso.P.get("md") or {}).pop(t, None)
        md = A.mesiodistal(self.caso).get(t)
        escaner = ((self.caso.AD or {}).get("anchos") or {}).get(t)
        if escaner or md:
            self.caso.anchos[t] = escaner or round(md["ancho"], 1)
        self.pagina.guardar_ediciones()
        self.remedir()

    def _combo_criterio(self, clave, opciones, calculado=""):
        """Lista para que el doctor fije un valor a su criterio («Automático» = lo calculado)."""
        cb = QtWidgets.QComboBox()
        cb.setStyleSheet("QComboBox{background:#ffffff;color:#1f2933;border:1px solid #cfd6dd;border-radius:6px;"
                         "padding:3px 8px;}QComboBox QAbstractItemView{background:#ffffff;color:#1f2933;"
                         "selection-background-color:#1995AD;selection-color:white;}")
        cb.addItem("Automático" + (f" ({calculado})" if calculado else ""), "")
        for o in opciones:
            cb.addItem(o, o)
        fijo = self.caso.criterio.get(clave, "")
        cb.setCurrentIndex(max(0, cb.findData(fijo)))
        cb.currentIndexChanged.connect(lambda _i, cb=cb: self._fijar_criterio(clave, cb.currentData()))
        return cb

    def _fijar_criterio(self, clave, valor):
        if valor:
            self.caso.criterio[clave] = valor
        else:
            self.caso.criterio.pop(clave, None)
        self.pagina.guardar_ediciones()
        QtCore.QTimer.singleShot(0, self.remedir)  # la lista se destruye al redibujar: después de este evento

    def _fila_criterio(self, v, titulo, combos):
        caja = QtWidgets.QGroupBox(titulo)
        caja.setStyleSheet("QGroupBox{color:#3d4753;font-weight:600;border:1px solid #d5dbe1;border-radius:8px;"
                           "margin-top:10px;padding-top:12px;}")
        f = QtWidgets.QFormLayout(caja)
        for texto, combo in combos:
            lb = QtWidgets.QLabel(texto)
            lb.setStyleSheet("color:#1f2933;")
            f.addRow(lb, combo)
        v.addWidget(caja)

    def _card_faltan_dientes(self, v):
        from .pagina import puede_enviar

        aviso = etiqueta("<b>Primero hay que identificar los dientes.</b>")
        aviso.setStyleSheet("color:#b3541e;font-size:11pt;")
        v.addWidget(aviso)
        v.addWidget(etiqueta("Este caso no trae la separación de dientes (cada diente con su número). Sin ella el "
                             "análisis mediría dientes equivocados, así que no se muestra."))
        if puede_enviar():
            from . import dientes_ia

            if dientes_ia.disponible():
                b = QtWidgets.QPushButton("Identificar los dientes con IA")
                b.setCursor(Qt.PointingHandCursor)
                b.setStyleSheet(f"QPushButton{{background:{TURQ};color:white;border:none;border-radius:8px;"
                                f"padding:9px 12px;font-weight:600;font-size:10pt;}}"
                                f"QPushButton:hover{{background:#147a8f;}}")
                b.clicked.connect(self.pagina.identificar_ia)
                v.addWidget(b)
                v.addWidget(etiqueta("Tarda cerca de medio minuto. Es una <b>propuesta</b>: al terminar revisa en "
                                     "«Dientes» que cada número sea el correcto (clic en un diente para corregirlo) "
                                     "antes de usar el análisis.", True))
                v.addWidget(etiqueta("<b>O con MetronTrack</b> (la numeración que tú revisas ahí):"))
            v.addWidget(etiqueta("<b>Cómo se identifica</b><br>"
                                 "1. Abre este caso en IntraoralScan → MetronTrack → <b>Marcar diente</b>.<br>"
                                 "2. Revisa que cada diente tenga su número y corrige el que esté mal.<br>"
                                 "3. Entra a «Análisis de medidas» para que se guarde, y cierra MetronTrack.<br>"
                                 "4. Vuelve a abrir aquí la carpeta del caso."))
        else:
            v.addWidget(etiqueta("Pide a 3D OrthoLab que te vuelva a mandar el caso con los dientes identificados."))
        v.addWidget(etiqueta("Mientras tanto puedes ver los modelos, usar «Corte» y medir con «Medir».", True))

    def _card_dientes(self, v):
        if not self.caso.etiquetas:
            self._card_faltan_dientes(v)
            return
        filas = []
        for jaw, nombre in (("sup", "Superior"), ("inf", "Inferior")):
            lab = self.caso.dientes(jaw)
            nums = sorted(int(t) for t in set(lab.tolist()) if t) if lab is not None else []
            filas.append([nombre, str(len(nums)), " ".join(str(n) for n in nums)])
        if getattr(self.pagina, "_dientes_locales", False):
            aviso = etiqueta("<b>Numeración propuesta por la IA: revísala.</b> Puede equivocarse de número, sobre todo "
                             "si faltan dientes. Recorre los dientes con el ratón y corrige el que esté mal.")
            aviso.setStyleSheet("color:#b3541e;")
            v.addWidget(aviso)
        v.addWidget(etiqueta(tabla(["Arcada", "Dientes", "Números (FDI)"], filas)))
        v.addWidget(etiqueta("<b>Para corregir</b>, haz clic en el diente:<br>"
                             "· <b>Cambiar su número</b> (si ya lo tenía otro diente, se intercambian).<br>"
                             "· <b>Dividir aquí</b>: si pintó dos dientes como uno, haz clic justo donde se tocan.<br>"
                             "· <b>Unir con…</b>: si partió un diente en dos pedazos."))
        self._aviso_dudosos_dientes(v)
        if getattr(self.pagina, "_dientes_locales", False):
            from . import dientes_ia

            if dientes_ia.disponible():
                b = QtWidgets.QPushButton("Volver a identificar con IA")
                b.clicked.connect(self.pagina.identificar_ia)
                v.addWidget(b)
        elif self.caso.renombres:
            v.addWidget(etiqueta(f"Has hecho {len(self.caso.renombres)} corrección(es) a los dientes.", True))
            b = QtWidgets.QPushButton("Deshacer mis correcciones de dientes")
            b.clicked.connect(self._deshacer_renombres)
            v.addWidget(b)

    def _deshacer_renombres(self):
        self.caso.restaurar_dientes()
        self.pagina.guardar_ediciones()
        self.remedir()

    def dividir(self, jaw, fdi, x, y):
        nuevo = self.caso.dividir(jaw, fdi, x, y)
        if nuevo is None:
            self.pagina.aviso("No pude dividirlo ahí: haz clic justo donde se tocan los dos dientes.")
            return
        self.pagina.guardar_dientes()
        self.pagina.guardar_ediciones()
        self.remedir()
        self.pagina.aviso(f"Dividido: quedaron el {fdi} y el {nuevo}. Si algún número no es el correcto, haz clic "
                          "en el diente y cámbialo.")

    def unir(self, jaw, a, b):
        self.caso.unir(jaw, a, b)
        self.pagina.guardar_dientes()
        self.pagina.guardar_ediciones()
        self.remedir()

    def renumerar(self, jaw, antes, ahora):
        self.caso.renumerar(jaw, antes, ahora)
        self.pagina.guardar_dientes()
        self.pagina.guardar_ediciones()
        self.remedir()

    def _restablecer(self):
        if self.caso is None:
            return
        self.caso.reproponer()
        self.pagina.guardar_ediciones()
        self.remedir()

    # ------------------------------------------------------------------ tarjetas
    def _card_resumen(self, v):
        for nivel, titulo, texto, destino in self.res["resumen"]:
            b = QtWidgets.QPushButton()
            b.setCursor(Qt.PointingHandCursor)
            b.setStyleSheet("QPushButton{text-align:left;padding:8px;border:1px solid #d5dbe1;border-radius:8px;"
                            "background:#f7f9fa;}QPushButton:hover{border-color:#1995AD;background:#eef6f8;}")
            lay = QtWidgets.QHBoxLayout(b)
            punto = QtWidgets.QLabel("●")
            punto.setStyleSheet(f"color:{NIVEL[nivel][0]};font-size:14pt;")
            lay.addWidget(punto, 0, Qt.AlignTop)
            lb = etiqueta(f"<b>{titulo}</b><br><span style='color:#3d4753;'>{texto}</span>")
            lb.setAttribute(Qt.WA_TransparentForMouseEvents)
            lay.addWidget(lb, 1)
            b.setMinimumHeight(lb.sizeHint().height() + 22)
            b.clicked.connect(lambda _=False, d=destino: self.mostrar(d))
            v.addWidget(b)
        if self.res["anchos_fuente"] == "medido":
            v.addWidget(etiqueta("Este caso no trae los anchos dentarios del escáner: se midieron aquí, sobre la línea "
                                 "mesiodistal de cada diente.", True))
        if self.res["anchos_fuente"] == "promedio":
            v.addWidget(etiqueta("Este caso no trae los anchos dentarios del escáner: Korkhaus, Bolton y Moyers usan "
                                 "anchos promedio hasta que los midas («Espacio y Bolton» → tabla de anchos).", True))
        if self.caso.P.get("revisar"):
            v.addWidget(etiqueta("Revisa la ubicación automática de: " + ", ".join(self.caso.P["revisar"]) +
                                 " (puedes moverlos en cada análisis).", True))

    def _card_overjet(self, v):
        oj = self.res["overjet"]
        ad = (self.caso.AD or {}).get("oclusion") or {}
        filas = []
        for t, r in oj.items():
            n1, t1 = A.nivel_overjet(r["overjet"])
            n2, t2 = A.nivel_overbite(r["overbite"])
            fila = [r["par"], f"{r['overjet']:.1f} {chip(t1, n1)}", f"{r['overbite']:.1f} {chip(t2, n2)}"]
            filas.append(fila)
        v.addWidget(etiqueta(tabla(["Par", "Overjet (mm)", "Overbite (mm)"], filas)))
        if ad:
            fs = [[k, mm(x.get("overjet")), mm(x.get("overbite"))] for k, x in ad.items()]
            v.addWidget(etiqueta("<b>Software del escáner</b> (todos los pares)", True))
            v.addWidget(etiqueta(tabla(["Par", "Overjet", "Overbite"], fs)))
        fila = QtWidgets.QHBoxLayout()
        fila.addWidget(etiqueta("<b>Corte sagital</b>"))
        fila.addStretch(1)
        self._seg_corte = QtWidgets.QButtonGroup(v.parentWidget())
        for i, t in enumerate(("11", "21")):
            b = QtWidgets.QPushButton(t)
            b.setCheckable(True)
            b.setFixedWidth(44)
            b.setStyleSheet(f"QPushButton:checked{{background:{TURQ};color:white;}}")
            self._seg_corte.addButton(b, i)
            fila.addWidget(b)
        v.addLayout(fila)
        self.corte = CorteSagital()
        v.addWidget(self.corte)
        self._seg_corte.idClicked.connect(lambda i: self._poner_corte(("11", "21")[i]))
        self._seg_corte.button(0).setChecked(True)
        self._poner_corte("11")

    def _poner_corte(self, t):
        r = self.res["overjet"].get(t)
        if r is None:
            self.corte.poner(None, None, None)
            return
        self.corte.poner(A.corte(self.caso, "sup", r["x"]), A.corte(self.caso, "inf", r["xl"]), r)

    def _card_corte(self, v):
        v.addWidget(etiqueta("<b>1. Haz clic en un diente</b> del modelo: el corte (el plano azul) pasa por ahí."))
        v.addWidget(etiqueta("<b>2. Mira la gráfica</b>, a la izquierda del modelo: el perfil del diente superior en "
                             "verde y del inferior en naranja, sobre una cuadrícula en mm."))
        v.addWidget(etiqueta("<b>3. Afina</b> con la barra «Mover», que recorre el corte por la arcada."))
        v.addWidget(etiqueta("<b>Tipos de corte</b><br>"
                             "<b>Por el diente</b>: atraviesa el diente de vestibular a lingual (en los incisivos es el "
                             "corte del overjet).<br>"
                             "<b>Sagital</b>: de adelante hacia atrás.<br>"
                             "<b>Transversal</b>: de lado a lado, para ver las dos hemiarcadas."))
        v.addWidget(etiqueta("Con ⤢ agrandas la gráfica.", True))

    def _card_molar(self, v):
        self._card_clase(v, "molar", "relacion_molar")

    def _card_canina(self, v):
        self._card_clase(v, "canina", "relacion_canina")

    def _card_clase(self, v, cual, clave_ad):
        cl = (self.res.get("clases") or {}).get(cual) or {}
        ad = (self.caso.AD or {}).get(clave_ad) or {}
        filas = []
        for lado, nombre in (("der", "Derecha"), ("izq", "Izquierda")):
            x = cl.get(lado)
            if x:
                sentido = "en posición" if abs(x["d"]) < 0.25 else ("hacia mesial" if x["d"] > 0 else "hacia distal")
                detalle = ("a criterio del doctor" if x.get("criterio") else
                           x.get("motivo") or "falta alguno de los dientes de esta relación" if x.get("falta") else
                           f"{abs(x['d']):.1f} mm {sentido}")
                aqui = f"{chip(x['clase'], x['nivel'])}<br><span style='color:#6b7682;'>{detalle}</span>"
            else:
                aqui = "—"
            filas.append([nombre, aqui, ad.get(lado, "—")])
        v.addWidget(etiqueta(tabla(["Lado", "Medido aquí", "Escáner"], filas)))
        self._fila_criterio(v, "A tu criterio", [
            (nombre, self._combo_criterio(f"{cual}_{lado}", CLASES))
            for lado, nombre in (("der", "Derecha"), ("izq", "Izquierda"))])
        if not cl:
            v.addWidget(etiqueta("Para medirla aquí hace falta la separación de dientes del escáner; se muestra "
                                 "lo que midió el escáner.", True))
        else:
            if cual == "molar":
                arriba, abajo = ("cúspide mesiovestibular del primer molar superior",
                                 "surco mesiovestibular del primer molar inferior (entre las dos cúspides grises)")
            else:
                arriba, abajo = ("cúspide del canino superior",
                                 "tronera entre el canino y el primer premolar inferiores")
            v.addWidget(etiqueta(f"<span style='color:#f2643d;'>●</span> <b>Punto coral</b>: {arriba}.<br>"
                                 f"<span style='color:#6c5ce7;'>●</span> <b>Punto violeta</b>: {abajo}."))
            v.addWidget(etiqueta("<b>Arrastra el punto coral o el violeta</b> sobre el diente para acomodarlo; se vuelve a "
                                 "medir al soltar. Usa las vistas de abajo para ver el otro lado.", True))

    def _card_lmedia(self, v):
        lm = self.res["linea_media"]
        ad = (self.caso.AD or {}).get("linea_media") or {}
        if not lm.get("valorable", True):
            v.addWidget(etiqueta(chip("No valorable", 9) + " Falta un incisivo central (" + ", ".join(lm.get("faltan", []))
                                 + "): no hay línea media que medir en esa arcada."))
            return

        def lado(x):
            return "centrada" if abs(x) < 0.05 else f"{abs(x):.1f} mm a la {'izquierda' if x > 0 else 'derecha'}"
        n = 0 if lm["mm"] <= 2 else 1 if lm["mm"] <= 4 else 2
        filas = [["Superior respecto al eje de la arcada", lado(lm["sup"])],
                 ["Inferior respecto al eje de la arcada", lado(lm["inf"])],
                 ["<b>Inferior respecto a la superior</b>",
                  f"<b>{lado(lm['inf'] - lm['sup'])}</b> {chip('aceptable' if n == 0 else 'desviada', n)}"]]
        if ad.get("mm") is not None:
            filas.append(["Escáner (inferior respecto a superior)",
                          f"{ad['mm']:.1f} mm" + (f" a la {ad['direccion'].lower()}" if ad.get("direccion") and ad["mm"] else "")])
        v.addWidget(etiqueta(tabla(["Línea media", "Desviación"], filas)))
        v.addWidget(etiqueta("<span style='color:#f2643d;'>●</span> Arcada superior &nbsp;&nbsp; "
                             "<span style='color:#6c5ce7;'>●</span> Arcada inferior"))
        v.addWidget(etiqueta("Derecha e izquierda son las del paciente. <b>Arrastra el punto</b> coral o el violeta para mover "
                             "su línea media. De lado, cada línea se ve como un plano.", True))

    def _card_contactos(self, v):
        ley = "".join(f'<span style="color:{c};">■</span> {t}&nbsp;&nbsp; ' for c, t in
                      zip(A.CONTACTO_COLORES, ("<0.1 firme", "0.1–0.3", "0.3–0.6", "0.6–1", "1–2 mm")))
        v.addWidget(etiqueta(ley))
        ct = self.res["contactos"]["sup"]
        nombres = {"ant": "Anterior", "prem": "Premolares", "mol": "Molares"}
        filas = []
        for z in ("ant", "prem", "mol"):
            d, i = ct[f"{z}_der"], ct[f"{z}_izq"]
            filas.append([nombres[z], f"{d['c01']:.1f} <span style='color:#6b7682;'>({d['c03']:.1f})</span>",
                          f"{i['c01']:.1f} <span style='color:#6b7682;'>({i['c03']:.1f})</span>"])
        tot_d = sum(ct[f"{z}_der"]["c01"] for z in nombres)
        tot_i = sum(ct[f"{z}_izq"]["c01"] for z in nombres)
        filas.append(["<b>Total</b>", f"<b>{tot_d:.1f}</b>", f"<b>{tot_i:.1f}</b>"])
        v.addWidget(etiqueta(tabla(["Zona (mm²)", "Derecha", "Izquierda"], filas)))
        v.addWidget(etiqueta("Firme = a menos de 0.1 mm; entre paréntesis, a menos de 0.3 mm.", True))

    def _card_korkhaus(self, v):
        K = self.res["korkhaus"]
        if not K:
            v.addWidget(etiqueta("No se pudo medir: faltan los cortes de los incisivos."))
            return
        if not K.get("prem_id"):
            v.addWidget(etiqueta("Faltan los anchos de 12, 11, 21 y 22 para calcular lo ideal. Escríbelos en "
                                 "«Espacio y Bolton»."))
        filas = []

        def fila(nombre, med, ideal):
            if med is None:
                return [nombre, "—", "—", ""]
            if ideal is None:
                return [nombre, f"{med:.1f}", "—", ""]
            n, t = A.nivel_korkhaus(med, ideal)
            return [nombre, f"{med:.1f}", f"{ideal:.1f}", f"{med - ideal:+.1f} {chip(t, n)}"]
        filas.append(["<b>Superior</b>", "", "", ""])
        filas.append(fila("Premolar 14–24", K["prem_u"], K.get("prem_id")))
        filas.append(fila("Molar 16–26", K["mol_u"], K.get("mol_id")))
        filas.append(fila("Largo anterior Lo", K["Lo"], K.get("Lo_id")))
        filas.append(["<b>Inferior</b>", "", "", ""])
        filas.append(fila("Premolar 44/45–34/35", K["prem_l"], K.get("prem_id")))
        filas.append(fila("Molar 46–36", K["mol_l"], K.get("mol_id")))
        filas.append(fila("Largo anterior Lu", K["Lu"], K.get("Lu_id")))
        v.addWidget(etiqueta(tabla(["", "Medido", "Ideal", "Diferencia"], filas)))
        fuente = {"accudesign": "del escáner", "doctor": "corregidos por ti", "promedio": "promedio",
                  "medido": "medidos aquí"}
        v.addWidget(etiqueta(f"SI (12+11+21+22) = {K['SI']:.1f} mm · anchos {fuente.get(self.res['anchos_fuente'])}.",
                             True))
        if self.res["korkhaus"].get("Lo") and self.res["korkhaus"].get("Lu"):
            v.addWidget(etiqueta(f"Lo − Lu = {K['Lo'] - K['Lu']:.1f} mm (norma 2 mm).", True))

    def _card_espacio(self, v):
        seg = self.sub["espacio"]
        ap = self.res.get("apinamiento") or {}
        self._aviso_dudosos(v)
        celdas = {"dientes": [], "arcada": [], "ap": []}
        fuentes = set()
        for jaw in ("sup", "inf"):
            x = (ap.get(jaw) or {}).get(seg)
            if x:
                n, t = A.nivel_espacio(-x["apinamiento"])
                celdas["dientes"].append(f"{x['dientes']:.1f}")
                celdas["arcada"].append(f"{x['arcada']:.1f}")
                celdas["ap"].append(f"{x['apinamiento']:+.1f} {chip(t, n)}")
                fuentes.add(x["fuente"])
            else:
                for k in celdas:
                    celdas[k].append("—")
        v.addWidget(etiqueta(tabla(["Medición de datos", "Arcada superior", "Arcada inferior"],
                                   [["Tamaño de diente"] + celdas["dientes"], ["Tamaño de arcada"] + celdas["arcada"],
                                    ["Apiñamiento"] + celdas["ap"]])))
        if fuentes:
            v.addWidget(etiqueta(f"Medidas (mm) · {' y '.join(sorted(fuentes))} · de {seg[0]} a {seg[2]}.", True))
        else:
            v.addWidget(etiqueta("Faltan anchos dentarios para este segmento: escríbelos abajo.", True))
        if self.caso.etiquetas:
            v.addWidget(etiqueta("Pasa el mouse sobre un diente del modelo: se pinta y muestra su número y su ancho.",
                                 True))
        self._lista_anchos(v)

    def _aviso_dudosos_dientes(self, v):
        dud = self.res.get("dudosos") or []
        if dud:
            aviso = etiqueta(f"<b>Parece que el {', '.join(dud)} son dos dientes juntos</b> (mide demasiado). Haz clic "
                             "donde se tocan y elige «Dividir aquí».")
            aviso.setStyleSheet("color:#b3541e;")
            v.addWidget(aviso)

    def _aviso_dudosos(self, v):
        """Un «diente» demasiado ancho es una separación que cubre dos dientes: sin corregirla no se da la medida."""
        dud = self.res.get("dudosos") or []
        if not dud:
            return
        aviso = etiqueta(f"<b>Revisa la separación del diente {', '.join(dud)}.</b> Mide más de lo que puede medir "
                         "un diente: seguramente son dos dientes juntos. Hasta corregirlo en «Dientes» no se calcula "
                         "lo que depende de él.")
        aviso.setStyleSheet("color:#b3541e;")
        v.addWidget(aviso)
        b = QtWidgets.QPushButton("Ir a «Dientes» para corregirlo")
        b.clicked.connect(lambda: self.mostrar("dientes"))
        v.addWidget(b)

    def _lista_anchos(self, v):
        fuente = {"accudesign": "del escáner", "doctor": "corregidos por ti", "promedio": "sin medir",
                  "medido": "medidos aquí sobre la línea mesiodistal"}.get(self.res["anchos_fuente"], "")
        v.addWidget(etiqueta(f"<b>Lista de anchos de los dientes</b> (mm) · {fuente}"))
        v.addWidget(etiqueta("Doble clic en un valor para corregirlo.", True))
        v.addWidget(self._tabla_anchos())

    def _card_bolton(self, v):
        b = self.res["bolton"]
        self._aviso_dudosos(v)
        if self.sub["bolton"] == "ancho":
            self._lista_anchos(v)
            return
        filas = []
        for k, nombre, n_d in (("anterior", "anterior", 6), ("global", "general", 12)):
            x = b.get(k)
            if not x:
                filas.append([f"Relación {nombre}", "—"])
                continue
            n, t = A.nivel_bolton(x)
            filas.append([f"Suma de las {n_d} piezas inferiores", f"{x['inf']:.1f}"])
            filas.append([f"Suma de las {n_d} piezas superiores", f"{x['sup']:.1f}"])
            filas.append([f"<b>Relación {nombre}</b>", f"<b>{x['relacion']:.2f} %</b> {chip(t, n)}"])
        v.addWidget(etiqueta(tabla(["Medición de datos", "Medidas"], filas)))
        if not b:
            v.addWidget(etiqueta("Faltan anchos dentarios: escríbelos en la pestaña «Medición del ancho del diente».",
                                 True))
        v.addWidget(etiqueta("Medidas (mm). En el modelo, la línea verde de cada diente es su ancho mesiodistal.", True))

    def _tabla_anchos(self):
        filas = [["17", "16", "15", "14", "13", "12", "11"], ["21", "22", "23", "24", "25", "26", "27"],
                 ["47", "46", "45", "44", "43", "42", "41"], ["31", "32", "33", "34", "35", "36", "37"]]
        t = QtWidgets.QTableWidget(8, 7)
        t.horizontalHeader().setVisible(False)
        t.verticalHeader().setVisible(False)
        t.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        t.setStyleSheet("QTableWidget{background:#ffffff;gridline-color:#d5dbe1;font-size:9pt;color:#1f2933;border:1px solid #d5dbe1;}")
        an = self.caso.anchos
        for i, fila in enumerate(filas):
            for j, d in enumerate(fila):
                h = QtWidgets.QTableWidgetItem(d)
                h.setFlags(Qt.ItemIsEnabled)
                h.setForeground(QtGui.QColor("#6b7682"))
                h.setBackground(QtGui.QColor("#eef1f4"))
                h.setTextAlignment(Qt.AlignCenter)
                t.setItem(2 * i, j, h)
                w = A.ancho(an, d)
                it = QtWidgets.QTableWidgetItem(f"{w:.1f}" if w else "")
                it.setTextAlignment(Qt.AlignCenter)
                it.setForeground(QtGui.QColor("#1f2933"))
                it.setBackground(QtGui.QColor("#ffffff"))
                it.setToolTip(f"Ancho del {d} (doble clic para escribirlo)")
                it.setData(Qt.UserRole, d)
                t.setItem(2 * i + 1, j, it)
        t.resizeRowsToContents()
        t.setFixedHeight(sum(t.rowHeight(i) for i in range(8)) + 4)
        t.itemChanged.connect(self._ancho_cambiado)
        return t

    def _ancho_cambiado(self, it):
        d = it.data(Qt.UserRole)
        if not d:
            return
        try:
            w = float(it.text().replace(",", ".")) if it.text().strip() else 0.0
        except ValueError:
            return
        if w and not 2 <= w <= 15:
            self.pagina.aviso("Ese ancho no parece de un diente (2 a 15 mm).")
            return
        if w:
            self.caso.anchos[d] = w
        else:
            self.caso.anchos.pop(d, None)
        self.caso.anchos_fuente = "doctor"
        self.pagina.guardar_ediciones()
        self.res = A.medir(self.caso)  # sin redibujar la tarjeta (se está editando la tabla)

    def _card_moyers(self, v):
        mo = self.res["moyers"]
        if not mo:
            v.addWidget(etiqueta("Faltan los anchos de los incisivos inferiores (31, 32, 41, 42). Escríbelos en "
                                 "«Espacio y Bolton»."))
            return
        if not self.res.get("mixta", True):
            v.addWidget(etiqueta("Este caso tiene dentición permanente completa en caninos y premolares: Moyers es para "
                                 "dentición mixta y aquí solo es de referencia.", True))
        v.addWidget(etiqueta(f"Suma de incisivos inferiores: <b>{mo['SI']:.1f} mm</b>"))
        filas = [["Superior", f"{mo['sup_previsto']:.1f}", f"{mo['sup_tanaka']:.1f}"],
                 ["Inferior", f"{mo['inf_previsto']:.1f}", f"{mo['inf_tanaka']:.1f}"]]
        v.addWidget(etiqueta("<b>3-4-5 previsto</b> (mm por cuadrante)"))
        v.addWidget(etiqueta(tabla(["", "Moyers 75 %", "Tanaka-Johnston"], filas)))
        if mo["fuera_de_tabla"]:
            v.addWidget(etiqueta("La suma está fuera de la tabla de Moyers (19.5–29 mm): valor extrapolado.", True))
        filas = []
        nom = {"1": "Cuadrante 1 (sup. der.)", "2": "Cuadrante 2 (sup. izq.)", "3": "Cuadrante 3 (inf. izq.)",
               "4": "Cuadrante 4 (inf. der.)"}
        for q in ("1", "2", "3", "4"):
            c = mo["cuadrantes"].get(q)
            if c:
                n, t = A.nivel_espacio(c["discrepancia"])
                filas.append([nom[q], f"{c['disponible']:.1f}", f"{c['previsto']:.1f}",
                              f"{c['discrepancia']:+.1f} {chip(t, n)}"])
        v.addWidget(etiqueta("<b>Espacio por cuadrante</b> (de distal del 2 a mesial del 6)"))
        v.addWidget(etiqueta(tabla(["", "Disponible", "Necesario", "Discrepancia"], filas)))

    def _card_arcada(self, v):
        an = self.res["anchuras"]
        ad = self.caso.AD or {}
        sub = self.sub["arcada"]
        if sub == "forma":
            fa = self.res.get("forma") or {}
            esc = ad.get("forma_arco") or {}
            v.addWidget(etiqueta(tabla(["Medición de datos", "Medidas"],
                                       [["Arcada superior", fa.get("sup", "—")], ["Arcada inferior", fa.get("inf", "—")]])))
            self._fila_criterio(v, "A tu criterio", [
                (nombre, self._combo_criterio(f"forma_{jaw}", FORMAS, esc.get(jaw, "")))
                for jaw, nombre in (("sup", "Arcada superior"), ("inf", "Arcada inferior"))])
            v.addWidget(etiqueta("«Automático» es la forma que clasificó el escáner. En el modelo: la curva de cada "
                                 "arcada con los puntos de contacto entre dientes.", True))
            return
        if sub == "ancho":
            filas = []
            aa = ad.get("anchura_arco") or {}
            for k, kn, ka in (("canina", "Anterior (caninos)", "anterior"), ("premolar", "Media (premolares)", "media"),
                              ("molar", "Posterior (molares)", "posterior")):
                filas.append([kn] + [f"{an[j][k]:.1f}" if k in an.get(j, {}) else "—" for j in ("sup", "inf")]
                             + [mm((aa.get(j) or {}).get(ka)) for j in ("sup", "inf")])
            v.addWidget(etiqueta(tabla(["", "Sup. aquí", "Inf. aquí", "Sup. escáner", "Inf. escáner"], filas)))
            v.addWidget(etiqueta("Medidas (mm). «Aquí»: entre los centros de las coronas que ves en el modelo.", True))
            return
        if sub == "simetria":
            sim = self.res.get("simetria") or {}
            si = ad.get("simetria") or {}
            filas = []
            for j, nj in (("sup", "Superior"), ("inf", "Inferior")):
                for n in ("anterior", "media", "posterior"):
                    x = (sim.get(j) or {}).get(n)
                    e = (si.get(j) or {}).get(n)
                    if not x and not e:
                        continue
                    if x:
                        aqui = [f"{x['der']:.1f}", f"{x['izq']:.1f}",
                                f"{x['dif']:.1f} {chip('simétrica' if x['dif'] <= 2 else 'asimétrica', 0 if x['dif'] <= 2 else 1)}"]
                    else:
                        aqui = ["—", "—", "—"]
                    filas.append([f"{nj} {n}"] + aqui + [f"{e['der']:.1f} / {e['izq']:.1f}" if e else "—"])
            v.addWidget(etiqueta(tabla(["", "Derecha", "Izquierda", "Diferencia", "Escáner (der. / izq.)"], filas)))
            v.addWidget(etiqueta("Medidas (mm) al eje medio. En el modelo: la línea gris es el eje y cada línea de color va "
                                 "del diente al eje (amarillo caninos, rojo premolares, verde molares).", True))
            return
        lon = self.res.get("longitud") or {}
        la = ad.get("longitud_arco") or {}
        filas = []
        for n, texto in (("anterior", "Hasta caninos"), ("media", "Hasta primeros premolares"),
                         ("posterior", "Hasta primeros molares")):
            filas.append([texto] + [mm((lon.get(j) or {}).get(n)) for j in ("sup", "inf")])
        v.addWidget(etiqueta("<b>Longitud de la arcada</b> (mm, medida aquí desde el borde incisal)"))
        v.addWidget(etiqueta(tabla(["", "Superior", "Inferior"], filas)))
        if la.get("sup") or la.get("inf"):
            filas = [[n.capitalize()] + [mm((la.get(j) or {}).get(n)) for j in ("sup", "inf")]
                     for n in ("anterior", "media", "posterior", "total")]
            v.addWidget(etiqueta("<b>Longitud por tramos</b> (mm, escáner)"))
            v.addWidget(etiqueta(tabla(["", "Superior", "Inferior"], filas)))
        sp = self.res["spee"]
        sad = ad.get("spee") or {}
        filas = [["Derecha", mm(sp.get("der")), mm(sad.get("der"))], ["Izquierda", mm(sp.get("izq")), mm(sad.get("izq"))]]
        v.addWidget(etiqueta("<b>Curva de Spee</b> (mm)"))
        v.addWidget(etiqueta(tabla(["", "Medida aquí", "Escáner"], filas)))
        if ad.get("altura_palatina"):
            v.addWidget(etiqueta(f"<b>Altura palatina</b>: {ad['altura_palatina']:.1f} mm (escáner)"))
