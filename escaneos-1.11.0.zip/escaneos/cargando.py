"""Pantalla de espera del visor de modelos: mientras se leen los modelos, se identifican los dientes o se hace el
análisis, un «escáner» animado recorre una arcada y van pasando frases para el doctor. Solo dibuja; no calcula."""
from __future__ import annotations

import math
import random
import time

from PySide6 import QtCore, QtGui, QtWidgets
from PySide6.QtCore import Qt

try:
    from ..sistema import fuente_mono as _fuente_mono
except ImportError:  # app instalada antes de la versión para Mac (este plugin llegó como actualización)
    def _fuente_mono() -> str:
        return "Consolas"

TURQ = QtGui.QColor("#19c3dc")
FRASES = [
    "Mientras analizamos, tómate un cafecito ☕",
    "Contando dientes… sin saltarnos ninguno",
    "Midiendo cada diente al décimo de milímetro",
    "Alineando las arcadas con paciencia de ortodoncista",
    "Tú respira; las cuentas las hacemos nosotros",
    "Buscando la línea media (prometemos encontrarla)",
    "Calculando Bolton para que no tengas que sacar la calculadora",
    "Revisando la oclusión, contacto por contacto",
    "Un momento: estamos viendo el caso con lupa",
    "Estira las manos: ya casi está tu análisis",
    "Poniéndole número a cada diente",
    "Un sorbo más de café y terminamos",
]

# datos curiosos de los análisis que hace el visor: quién los propuso y en qué año
DATOS = [
    "El análisis de Bolton lo publicó Wayne A. Bolton en 1958: comparó el tamaño de los dientes de arriba y de abajo.",
    "La clasificación de la maloclusión (Clase I, II y III) es de Edward H. Angle, de 1899.",
    "La curva de Spee lleva el nombre del anatomista alemán Ferdinand Graf von Spee, que la describió en 1890.",
    "El análisis de dentición mixta de Moyers es de Robert E. Moyers, de la Universidad de Michigan.",
    "Tanaka y Johnston publicaron en 1974 su fórmula para predecir caninos y premolares sin tablas.",
    "El índice de Pont, la base del análisis de anchura de arcada, es de 1909.",
    "Gustav Korkhaus amplió en los años 30 el análisis de Pont con la longitud anterior de la arcada.",
    "El «espacio de deriva» (leeway space) lo describió Hays Nance en 1947.",
    "Las seis llaves de la oclusión normal son de Lawrence F. Andrews, de 1972.",
    "La numeración de dos dígitos de los dientes (11, 21, 36…) la adoptó la FDI en 1970.",
]


class PantallaCarga(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_NativeWindow)  # va encima del visor 3D, que es una ventana propia
        self.estado = ""
        self._t0 = time.time()
        self._frases = []
        self._barajar()
        self._reloj = QtCore.QTimer(self)
        self._reloj.setInterval(33)
        self._reloj.timeout.connect(self.update)
        rng = random.Random(7)
        self._chispas = [(rng.random(), rng.random(), rng.random() * 6.28, 0.4 + rng.random()) for _ in range(46)]
        self.hide()

    def empezar(self, estado=""):
        self.estado = estado or self.estado
        if not self.isVisible():
            self._t0 = time.time()
            self._barajar()
            self.show()
            self._reloj.start()
        self.raise_()
        self.update()

    def _barajar(self):
        """Las frases y los datos curiosos, todos revueltos al azar (en orden distinto cada vez)."""
        self._frases = [(False, x) for x in FRASES] + [(True, x) for x in DATOS]
        random.shuffle(self._frases)

    def terminar(self):
        self._reloj.stop()
        self.hide()

    # ------------------------------------------------------------------ dibujo
    def paintEvent(self, _ev):
        t = time.time() - self._t0
        w, h = self.width(), self.height()
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        fondo = QtGui.QLinearGradient(0, 0, 0, h)
        fondo.setColorAt(0, QtGui.QColor("#0a131b"))
        fondo.setColorAt(1, QtGui.QColor("#10242f"))
        p.fillRect(self.rect(), fondo)
        # cuadrícula tenue que se desliza
        p.setPen(QtGui.QPen(QtGui.QColor(25, 195, 220, 16), 1))
        paso, corr = 38, (t * 10) % 38
        for x in range(-paso, w + paso, paso):
            p.drawLine(int(x + corr), 0, int(x + corr), h)
        for y in range(-paso, h + paso, paso):
            p.drawLine(0, int(y + corr), w, int(y + corr))
        # chispas flotando
        for fx, fy, fase, vel in self._chispas:
            a = 60 + 60 * math.sin(t * vel + fase)
            p.setPen(Qt.NoPen)
            p.setBrush(QtGui.QColor(25, 195, 220, int(a * 0.55)))
            p.drawEllipse(QtCore.QPointF(fx * w, (fy * h - t * 9 * vel) % h), 1.4, 1.4)
        cx, cy = w / 2, h * 0.36
        R = min(w, h) * 0.17  # los anillos no llegan a la zona del texto
        # anillos girando
        for k, (radio, ancho, vel, largo) in enumerate(((1.42, 2.2, 38, 70), (1.62, 1.2, -24, 130), (1.80, 1.0, 14, 40))):
            p.setPen(QtGui.QPen(QtGui.QColor(25, 195, 220, 150 - 38 * k), ancho, Qt.SolidLine, Qt.RoundCap))
            p.setBrush(Qt.NoBrush)
            r = R * radio
            caja = QtCore.QRectF(cx - r, cy - r, 2 * r, 2 * r)
            for inicio in (0, 180):
                p.drawArc(caja, int((t * vel + inicio) * 16), int(largo * 16))
        p.setPen(QtGui.QPen(QtGui.QColor(25, 195, 220, 34), 1))
        p.drawEllipse(QtCore.QPointF(cx, cy), R * 1.42, R * 1.42)
        # la arcada: 14 dientes en U, que se encienden al pasar el haz del escáner
        barrido = (t * 0.55) % 1.0
        dientes = []
        for i in range(14):
            f = math.pi * (i + 0.5) / 14
            dientes.append((cx - R * 0.86 * math.cos(f), cy + R * 0.62 - R * 1.25 * math.sin(f), i))
        for x, y, i in dientes:
            d = abs((i + 0.5) / 14 - barrido)
            d = min(d, 1 - d)
            brillo = max(0.0, 1 - d * 7)
            tam = R * (0.085 if 4 <= i <= 9 else 0.11)
            p.setPen(QtGui.QPen(QtGui.QColor(25, 195, 220, int(110 + 145 * brillo)), 1.6))
            p.setBrush(QtGui.QColor(25, 195, 220, int(26 + 190 * brillo)))
            p.drawRoundedRect(QtCore.QRectF(x - tam, y - tam, 2 * tam, 2 * tam), tam * 0.55, tam * 0.55)
            if brillo > 0.05:
                halo = QtGui.QRadialGradient(x, y, tam * 3.2)
                halo.setColorAt(0, QtGui.QColor(25, 195, 220, int(90 * brillo)))
                halo.setColorAt(1, QtGui.QColor(25, 195, 220, 0))
                p.setPen(Qt.NoPen)
                p.setBrush(halo)
                p.drawEllipse(QtCore.QPointF(x, y), tam * 3.2, tam * 3.2)
        # haz del escáner, de arriba abajo
        yb = cy - R * 0.9 + (math.sin(t * 1.7) * 0.5 + 0.5) * R * 1.75
        haz = QtGui.QLinearGradient(cx - R * 1.25, 0, cx + R * 1.25, 0)
        haz.setColorAt(0, QtGui.QColor(25, 195, 220, 0))
        haz.setColorAt(0.5, QtGui.QColor(160, 240, 255, 210))
        haz.setColorAt(1, QtGui.QColor(25, 195, 220, 0))
        p.setPen(QtGui.QPen(QtGui.QBrush(haz), 2.0))
        p.drawLine(QtCore.QPointF(cx - R * 1.25, yb), QtCore.QPointF(cx + R * 1.25, yb))
        # frase que va cambiando (aparece y se desvanece)
        cada = 4.6
        k = int(t / cada) % len(self._frases)
        u = (t % cada) / cada
        alfa = max(0, int(255 * min(1.0, u / 0.10, (1 - u) / 0.10)))
        es_dato, texto = self._frases[k]
        f = p.font()
        if es_dato:  # dato curioso: un rótulo pequeño arriba y el texto un poco más chico (son más largos)
            f.setPointSizeF(8.5)
            f.setBold(True)
            f.setLetterSpacing(QtGui.QFont.AbsoluteSpacing, 2.0)
            p.setFont(f)
            p.setPen(QtGui.QColor(25, 195, 220, alfa))
            p.drawText(QtCore.QRectF(0, h * 0.70 - 26, w, 16), Qt.AlignHCenter, "¿SABÍAS QUE…?")
            f.setLetterSpacing(QtGui.QFont.AbsoluteSpacing, 0.0)
        f.setPointSizeF(max(11.5, min(15.5, w / 58)) if es_dato else max(13.0, min(19.0, w / 46)))
        f.setBold(True)
        p.setFont(f)
        p.setPen(QtGui.QColor(240, 248, 250, alfa))
        ancho_txt = min(w - 48, 760)
        p.drawText(QtCore.QRectF((w - ancho_txt) / 2, h * 0.70, ancho_txt, 60),
                   Qt.AlignHCenter | Qt.AlignVCenter | Qt.TextWordWrap, texto)
        # qué se está haciendo, en letra de consola, con sus puntos
        f.setBold(False)
        f.setPointSizeF(10)
        f.setFamily(_fuente_mono())
        p.setFont(f)
        p.setPen(QtGui.QColor(25, 195, 220, 230))
        estado = (self.estado or "Trabajando").rstrip(".… ")
        # centrado de verdad: los puntos que se animan ocupan siempre tres lugares (letra de ancho fijo) y la
        # flecha de la izquierda se compensa con el mismo ancho a la derecha, así el texto no «baila»
        puntos = "." * (1 + int(t * 2.5) % 3)
        ancho_estado = p.fontMetrics().horizontalAdvance(estado)
        x0 = (w - ancho_estado) / 2  # se centra el texto solo; la flecha y los puntos van a sus lados
        p.drawText(QtCore.QRectF(x0, h * 0.70 + 70, ancho_estado + 40, 20), Qt.AlignLeft, f"{estado}{puntos}")
        p.drawText(QtCore.QRectF(x0 - 40, h * 0.70 + 70, 32, 20), Qt.AlignRight, "›")
        # barra que va y viene
        bw, bx, by = min(360, w * 0.5), 0, h * 0.70 + 102
        bx = (w - bw) / 2
        p.setPen(Qt.NoPen)
        p.setBrush(QtGui.QColor(255, 255, 255, 22))
        p.drawRoundedRect(QtCore.QRectF(bx, by, bw, 4), 2, 2)
        tramo = bw * 0.28
        pos = (math.sin(t * 2.1) * 0.5 + 0.5) * (bw - tramo)
        brocha = QtGui.QLinearGradient(bx + pos, 0, bx + pos + tramo, 0)
        brocha.setColorAt(0, QtGui.QColor(25, 195, 220, 0))
        brocha.setColorAt(0.5, QtGui.QColor(120, 235, 250, 255))
        brocha.setColorAt(1, QtGui.QColor(25, 195, 220, 0))
        p.setBrush(brocha)
        p.drawRoundedRect(QtCore.QRectF(bx + pos, by, tramo, 4), 2, 2)
        f.setPointSizeF(8)
        p.setFont(f)
        p.setPen(QtGui.QColor(160, 190, 200, 120))
        p.drawText(QtCore.QRectF(0, h - 26, w, 16), Qt.AlignHCenter, "3D OrthoLab · análisis de modelos")
        p.end()
