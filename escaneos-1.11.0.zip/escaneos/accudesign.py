# -*- coding: utf-8 -*-
"""(Copia de la skill analisis-modelos-ortholab.) Lee el PDF «Informe de análisis del modelo» de AccuDesign / MetronTrack (Shining 3D) y lo pasa a JSON.

Uso:  python accudesign.py "<...Informe de análisis del modelo...pdf>" [salida.json]

Trabaja con las coordenadas de los bloques de texto (no con el orden del texto, que el PDF mezcla:
en la hoja de apiñamiento el orden de texto pone primero el inferior y la tabla primero el superior).
Lo que no encuentra queda en None; nunca inventa un valor.
"""
import re, sys, json

NUM = re.compile(r'^-?\d+(?:\.\d+)?$')
VAL = re.compile(r'^(-?\d+(?:\.\d+)?)\s*\((.*)\)$')


def blocks(page):
    out = []
    for b in page.get_text('blocks'):
        t = b[4].strip()
        if t:
            out.append(dict(x0=b[0], y0=b[1], x1=b[2], y1=b[3], yc=(b[1] + b[3]) / 2, t=t, lines=[l.strip() for l in t.split('\n') if l.strip()]))
    return sorted(out, key=lambda b: (round(b['yc']), b['x0']))


def fnum(s):
    try:
        return float(s)
    except Exception:
        return None


def section_of(b, labels):
    """labels: lista de (nombre, yc). Devuelve el nombre de la etiqueta más cercana en y."""
    return min(labels, key=lambda l: abs(l[1] - b['yc']))[0] if labels else None


def jaw_labels(bl):
    labs = []
    for b in bl:
        for ln in b['lines']:
            if ln.startswith('Mandíbula superior'): labs.append(('sup', b['yc']))
            elif ln.startswith('Mandíbula inferior'): labs.append(('inf', b['yc']))
    return labs


def parse(path):
    import fitz  # PyMuPDF: solo en la PC de la Dra. (el visor del doctor no lo necesita)

    doc = fitz.open(path)
    R = dict(archivo=path, paciente={}, anchos={}, apinamiento={'sup': {}, 'inf': {}}, bolton={}, spee={}, altura_palatina=None,
             oclusion={}, relacion_molar={}, relacion_canina={}, linea_media={}, anchura_arco={'sup': {}, 'inf': {}},
             longitud_arco={'sup': {}, 'inf': {}}, simetria={'sup': {}, 'inf': {}}, forma_arco={}, avisos=[])
    full = []
    for pi, page in enumerate(doc):
        bl = blocks(page)
        txt = ' | '.join(' | '.join(b['lines']) for b in bl)
        full.append(txt)

        # ---- datos del paciente
        if 'Información básica' in txt and not R['paciente']:
            toks = [l for b in bl for l in b['lines']]
            for key, lab in (('nombre', 'Nombre del paciente'), ('edad', 'Edad'), ('genero', 'Género'), ('doctor', 'Doctor'), ('fecha', 'Fecha del informe')):
                if lab in toks:
                    i = toks.index(lab)
                    if i + 1 < len(toks): R['paciente'][key] = toks[i + 1]

        # ---- anchos mesiodistales (filas: ids / anchos / ids / anchos)
        if 'Medidas (mm)' in txt and not R['anchos']:
            rows = [b['lines'] for b in bl if len(b['lines']) >= 8]
            for a, b in zip(rows, rows[1:]):
                if all(re.fullmatch(r'\d\d', x) for x in a) and all(NUM.match(x) for x in b) and len(a) == len(b):
                    for t, w in zip(a, b): R['anchos'][t] = float(w)
            if not R['anchos']:
                # respaldo: orden de texto
                toks = [l for b in bl for l in b['lines']]
                i = 0
                while i < len(toks):
                    j = i
                    while j < len(toks) and re.fullmatch(r'\d\d', toks[j]): j += 1
                    n = j - i
                    if n >= 8 and all(NUM.match(x) for x in toks[j:j + n]):
                        for t, w in zip(toks[i:j], toks[j:j + n]): R['anchos'][t] = float(w)
                        i = j + n
                    else:
                        i = max(j, i + 1)

        # ---- apiñamiento
        if 'Medición de apiñamiento dental' in txt:
            labs = jaw_labels(bl)
            segs = [b for b in bl if b['t'] in ('3-3', '5-5', '6-6', '7-7')]
            for s in segs:
                row = sorted([b for b in bl if abs(b['yc'] - s['yc']) < 4 and b['x0'] > s['x1']], key=lambda b: b['x0'])
                vals = [b['t'] for b in row]
                if len(vals) >= 3:
                    m = re.match(r'^(-?\d+(?:\.\d+)?)\s*\((.*)\)$', vals[2])
                    R['apinamiento'][section_of(s, labs)][s['t']] = dict(dientes=fnum(vals[0]), arcada=fnum(vals[1]),
                                                                         apinamiento=fnum(m.group(1)) if m else None, grado=m.group(2) if m else vals[2])

        # ---- Bolton
        if 'relación de Bolton' in txt:
            m = re.search(r'Relación general \| ([\d.]+)%', txt); R['bolton']['global'] = fnum(m.group(1)) if m else None
            m = re.search(r'Relación anterior \| ([\d.]+)%', txt); R['bolton']['anterior'] = fnum(m.group(1)) if m else None
            m = re.search(r'12 piezas maxilares[^|]*\| ([\d.]+)', txt); R['bolton']['suma12_sup'] = fnum(m.group(1)) if m else None
            m = re.search(r'12 piezas mandibulares[^|]*\| ([\d.]+)', txt); R['bolton']['suma12_inf'] = fnum(m.group(1)) if m else None
            m = re.search(r'6 piezas maxilar anterior[^|]*\| ([\d.]+)', txt); R['bolton']['suma6_sup'] = fnum(m.group(1)) if m else None
            m = re.search(r'6 piezas mandibular anterior[^|]*\| ([\d.]+)', txt); R['bolton']['suma6_inf'] = fnum(m.group(1)) if m else None

        # ---- Spee y altura palatina
        if 'Curva de Spee' in txt:
            m = re.search(r'Valor promedio \| (-?[\d.]+)', txt); R['spee']['promedio'] = fnum(m.group(1)) if m else None
            m = re.search(r'Derecha \| (-?[\d.]+)', txt); R['spee']['der'] = fnum(m.group(1)) if m else None
            m = re.search(r'Izquierda \| (-?[\d.]+)', txt); R['spee']['izq'] = fnum(m.group(1)) if m else None
        if 'Altura Palatina' in txt:
            m = re.search(r'Altura Palatina \| (-?[\d.]+)', txt); R['altura_palatina'] = fnum(m.group(1)) if m else None

        # ---- sobremordida y resalte (filas por y)
        if 'Medición de sobremordida y resalte' in txt:
            for b in bl:
                m = re.fullmatch(r'(\d\d) & (\d\d)', b['t'])
                if not m: continue
                row = sorted([c for c in bl if abs(c['yc'] - b['yc']) < 4 and c['x0'] > b['x1']], key=lambda c: c['x0'])
                vv = [VAL.match(c['t']) for c in row]
                vv = [v for v in vv if v]
                if len(vv) >= 2:
                    R['oclusion'][f'{m.group(1)}/{m.group(2)}'] = dict(overbite=float(vv[0].group(1)), overbite_grado=vv[0].group(2),
                                                                       overjet=float(vv[1].group(1)), overjet_grado=vv[1].group(2))

        # ---- relaciones molar y canina
        if 'relación molar' in txt or 'relaciones caninas' in txt:
            hdr = [(('molar' if 'molar' in b['t'] else 'canina'), b['yc']) for b in bl if b['t'].startswith('Medición de la relación molar') or b['t'].startswith('Medición de las relaciones caninas')]
            for b in bl:
                if len(b['lines']) == 2 and b['lines'][0] in ('Derecha', 'Izquierda') and b['lines'][1].startswith('Relación'):
                    above = [h for h in hdr if h[1] < b['yc']]
                    if not above: continue
                    sec = max(above, key=lambda h: h[1])[0]
                    R['relacion_' + sec]['der' if b['lines'][0] == 'Derecha' else 'izq'] = b['lines'][1]

        # ---- línea media
        if 'relación con la línea media' in txt:
            m = re.search(r'con la superior \| ([^|]+?) \| (-?[\d.]+)\s*mm', txt)
            if m: R['linea_media'] = dict(direccion=m.group(1).strip(), mm=float(m.group(2)))
            else:
                m = re.search(r'con la superior \| ([^|]+)', txt)
                R['linea_media'] = dict(direccion=m.group(1).strip() if m else None, mm=None)

        # ---- anchura / longitud / simetría / forma
        for key, title, names in (('anchura_arco', 'Medida de anchura del arco', ('anterior', 'media', 'posterior')),
                                  ('longitud_arco', 'Medida de Longitud de Arco', ('anterior', 'media', 'posterior', 'total')),
                                  ('simetria', 'Simetría de Arcada Dental', ('anterior', 'media', 'posterior'))):
            if title not in txt: continue
            labs = jaw_labels(bl)
            tb = [b for b in bl if b['t'] == title]
            ylim = None
            # en la hoja de simetría también va la forma de arco: limitar a lo que está entre este título y el siguiente
            if key == 'simetria':
                nxt = [b['yc'] for b in bl if b['t'] == 'Análisis de Forma de Arco']
                ylim = nxt[0] if nxt else None
            for b in bl:
                if b['t'].startswith('Anchura ') or b['t'].startswith('Longitud '):
                    if ylim and b['yc'] > ylim: continue
                    if tb and b['yc'] < tb[0]['yc']: continue
                    nm = b['t'].split(' ', 1)[1].lower()
                    row = sorted([c for c in bl if abs(c['yc'] - b['yc']) < 4 and c['x0'] > b['x1'] and NUM.match(c['t'])], key=lambda c: c['x0'])
                    if not row: continue
                    labs2 = [l for l in labs if (not ylim or l[1] < ylim)]
                    jaw = section_of(b, labs2)
                    if key == 'simetria':
                        R[key][jaw][nm] = dict(izq=float(row[0]['t']), der=float(row[1]['t'])) if len(row) >= 2 else None
                    else:
                        R[key][jaw][nm] = float(row[0]['t'])
        if 'Análisis de Forma de Arco' in txt:
            for b in bl:
                if len(b['lines']) == 2 and b['lines'][0] in ('Mandíbula superior', 'Mandíbula inferior'):
                    R['forma_arco']['sup' if 'superior' in b['lines'][0] else 'inf'] = b['lines'][1]

    # verificación de lo esencial
    for k in ('anchos', 'bolton', 'oclusion', 'spee'):
        if not R[k]: R['avisos'].append(f'No se encontró «{k}» en el PDF')
    for t in ('12', '11', '21', '22'):
        if not R['anchos'].get(t): R['avisos'].append(f'Falta el ancho del {t} (necesario para la SI de Korkhaus)')
    return R


if __name__ == '__main__':
    R = parse(sys.argv[1])
    s = json.dumps(R, ensure_ascii=False, indent=1)
    if len(sys.argv) > 2:
        open(sys.argv[2], 'w', encoding='utf-8').write(s)
    sys.stdout.reconfigure(encoding='utf-8')
    print(s)
