"""«Enviar al doctor» (solo en la computadora de la Dra.): arma el Paquete 3D OrthoLab de un paciente, firmado con su
llave y cifrado para la computadora del doctor que lo refiere."""
from __future__ import annotations

import json
import os
import re
import time

from PySide6 import QtCore, QtWidgets
from PySide6.QtCore import Qt

from . import dientes_mt as DM
from . import paquete as PQ

DOCTORES = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "3D OrthoLab Studio", "doctores.json")
SALIDA = os.path.join(os.path.expanduser("~"), "Desktop", "Paquetes para doctores")
LLAVE = os.path.join(os.path.expanduser("~"), ".ortholab-studio", "llave_privada.pem")
_CLAVE: list = []  # contraseña de la llave (solo en memoria mientras la app está abierta)


def doctores() -> dict:
    try:
        with open(DOCTORES, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def guardar_doctores(d: dict):
    os.makedirs(os.path.dirname(DOCTORES), exist_ok=True)
    with open(DOCTORES, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)


def llave_privada(parent=None):
    from cryptography.hazmat.primitives import serialization

    with open(LLAVE, "rb") as f:
        pem = f.read()
    if b"ENCRYPTED" not in pem:
        return serialization.load_pem_private_key(pem, password=None)
    for _ in range(3):
        if not _CLAVE:
            pw, ok = QtWidgets.QInputDialog.getText(parent, "Enviar al doctor", "Contraseña de tu llave de 3D OrthoLab:",
                                                    QtWidgets.QLineEdit.Password)
            if not ok or not pw:
                raise PQ.ErrorPaquete("Sin la contraseña no se pueden firmar paquetes.")
            _CLAVE.append(pw)
        try:
            return serialization.load_pem_private_key(pem, password=_CLAVE[0].encode("utf8"))
        except ValueError:
            _CLAVE.clear()
    raise PQ.ErrorPaquete("Contraseña incorrecta.")


class DialogoEnviar(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Enviar al doctor · Paquete 3D OrthoLab")
        self.setMinimumWidth(620)
        self.archivos = {}
        f = QtWidgets.QFormLayout(self)
        fila = QtWidgets.QHBoxLayout()
        self.e_carpeta = QtWidgets.QLineEdit()
        self.e_carpeta.setPlaceholderText("Carpeta del escaneo del paciente (la que exporta el escáner)")
        b = QtWidgets.QPushButton("Elegir…")
        b.clicked.connect(self._elegir)
        fila.addWidget(self.e_carpeta, 1)
        fila.addWidget(b)
        f.addRow("Escaneo", fila)
        self.l_det = QtWidgets.QLabel("")
        self.l_det.setWordWrap(True)
        self.l_det.setStyleSheet("color:#8b949e;font-size:9pt;")
        f.addRow("", self.l_det)
        self.e_pac = QtWidgets.QLineEdit()
        f.addRow("Paciente", self.e_pac)
        self.e_fecha = QtWidgets.QLineEdit(time.strftime("%d/%m/%Y"))
        f.addRow("Fecha del escaneo", self.e_fecha)
        # Moyers solo se activa en dentición mixta: automática = por los dientes de leche marcados
        self.cmb_dent = QtWidgets.QComboBox()
        self.cmb_dent.addItem("Automática (mixta si hay dientes de leche marcados)", "")
        self.cmb_dent.addItem("Permanente (sin Moyers)", "Permanente")
        self.cmb_dent.addItem("Mixta (con Moyers)", "Mixta")
        f.addRow("Dentición", self.cmb_dent)
        self.cmb_doc = QtWidgets.QComboBox()
        self._llenar_doctores()
        b_nuevo = QtWidgets.QPushButton("Nuevo doctor…")
        b_nuevo.clicked.connect(self._nuevo_doctor)
        fila = QtWidgets.QHBoxLayout()
        fila.addWidget(self.cmb_doc, 1)
        fila.addWidget(b_nuevo)
        f.addRow("Doctor", fila)
        self.cb_limpiar = QtWidgets.QCheckBox("Limpiar excedentes sueltos del escaneo (pedazos de malla separados de la arcada)")
        self.cb_limpiar.setChecked(True)
        f.addRow("", self.cb_limpiar)
        self.msg = QtWidgets.QLabel("")
        self.msg.setWordWrap(True)
        f.addRow(self.msg)
        botones = QtWidgets.QDialogButtonBox()
        self.b_ok = botones.addButton("Crear paquete", QtWidgets.QDialogButtonBox.AcceptRole)
        botones.addButton("Cerrar", QtWidgets.QDialogButtonBox.RejectRole)
        self.b_ok.clicked.connect(self._crear)
        botones.rejected.connect(self.reject)
        f.addRow(botones)

    def _llenar_doctores(self, elegir=None):
        self.cmb_doc.clear()
        for nombre in sorted(doctores()):
            self.cmb_doc.addItem(nombre)
        if elegir:
            self.cmb_doc.setCurrentText(elegir)

    def _nuevo_doctor(self):
        d = QtWidgets.QDialog(self)
        d.setWindowTitle("Nuevo doctor")
        f = QtWidgets.QFormLayout(d)
        e_n = QtWidgets.QLineEdit()
        e_c = QtWidgets.QLineEdit()
        e_c.setPlaceholderText("OLES1-… (lo ve el doctor en «Análisis de modelos» de su app)")
        f.addRow("Nombre", e_n)
        f.addRow("Código de equipo", e_c)
        bb = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        bb.accepted.connect(d.accept)
        bb.rejected.connect(d.reject)
        f.addRow(bb)
        if d.exec() != QtWidgets.QDialog.Accepted:
            return
        try:
            PQ.leer_codigo(e_c.text())
        except PQ.ErrorPaquete as exc:
            QtWidgets.QMessageBox.warning(self, "Nuevo doctor", str(exc))
            return
        nombre = e_n.text().strip() or "Doctor"
        ds = doctores()
        ds[nombre] = {"codigo": "".join(e_c.text().split()), "alta": time.strftime("%Y-%m-%d")}
        guardar_doctores(ds)
        self._llenar_doctores(nombre)

    def _elegir(self):
        c = QtWidgets.QFileDialog.getExistingDirectory(self, "Carpeta del escaneo", os.path.expanduser("~"))
        if not c:
            return
        self.e_carpeta.setText(c)
        self.archivos = PQ.detectar(c)
        nombres = {"superior_sin_zocalo": "superior", "inferior_sin_zocalo": "inferior",
                   "superior_con_zocalo": "superior con zócalo", "inferior_con_zocalo": "inferior con zócalo",
                   "informe": "informe PDF"}
        self.l_det.setText("Encontré: " + (", ".join(f"{nombres[r]} ({os.path.basename(p)})" for r, p in self.archivos.items())
                                           or "nada (busco UpperJaw, LowerJaw y el Informe PDF)")
                           + ("\nCon la separación de dientes de MetronTrack: el doctor verá cada diente con su número."
                              if DM.carpeta_orden(c) else
                              "\nSin separación de dientes: abre el caso en MetronTrack («Marcar diente») antes de enviar "
                              "para que el doctor vea cada diente con su número.")
                           + ("\nCon el informe de AccuDesign: el doctor tendrá Korkhaus, Bolton y Moyers con los anchos "
                              "medidos (el PDF no se envía: el doctor ve el informe de 3D OrthoLab Studio)."
                              if PQ.buscar_accudesign(c) else
                              "\nSin informe de AccuDesign: el doctor tendrá el análisis con anchos dentarios promedio "
                              "(los puede medir él en su visor)."))
        if not self.e_pac.text().strip():
            base = os.path.basename(c.rstrip("\\/"))
            if re.match(r"^\d{4}-\d{2}-\d{2}", base):  # carpeta del escáner: el paciente es la carpeta de arriba
                base = os.path.basename(os.path.dirname(c.rstrip("\\/")))
            self.e_pac.setText(base)

    def _crear(self):
        if not self.archivos:
            self.msg.setText("Elige la carpeta del escaneo.")
            return
        doc = self.cmb_doc.currentText()
        ds = doctores()
        if doc not in ds:
            self.msg.setText("Agrega al doctor con su código de equipo («Nuevo doctor…»).")
            return
        info = {"paciente": self.e_pac.text().strip(), "doctor": doc, "fecha_escaneo": self.e_fecha.text().strip()}
        if self.cmb_dent.currentData():
            info["denticion"] = self.cmb_dent.currentData()
        QtWidgets.QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            priv = llave_privada(self)
            # los anchos dentarios del informe de AccuDesign: con ellos el visor del doctor hace Korkhaus,
            # Bolton y Moyers (el análisis lo hace la app del doctor; aquí solo se leen los datos del PDF)
            ad = PQ.datos_escaner(self.e_carpeta.text())
            # la separación de dientes de MetronTrack (número de cada diente), para que el visor los pinte
            extra = {"accudesign": ad, "dientes": PQ.datos_dientes(self.e_carpeta.text(), self.archivos,
                                                                  limpiar=self.cb_limpiar.isChecked())}
            # el PDF de MetronTrack/AccuDesign ya NO viaja (Miriam, 2026-11-19: «ya no incluyas el de MetronTrack,
            # solo el propio»): sus datos van arriba en «accudesign» y el informe lo arma el visor del doctor
            modelos = {r: p for r, p in self.archivos.items() if r != "informe"}
            datos = PQ.empaquetar(modelos, info, ds[doc]["codigo"], priv, extra,
                                  limpiar=self.cb_limpiar.isChecked())
        except Exception as exc:  # noqa: BLE001
            QtWidgets.QApplication.restoreOverrideCursor()
            self.msg.setText(f"No se pudo crear: {exc}")
            return
        QtWidgets.QApplication.restoreOverrideCursor()
        os.makedirs(SALIDA, exist_ok=True)
        nombre = re.sub(r'[\\/:*?"<>|]', "", f"{info['paciente'] or 'Paciente'} - 3D OrthoLab{PQ.EXT}")
        ruta = os.path.join(SALIDA, nombre)
        with open(ruta, "wb") as f:
            f.write(datos)
        self.msg.setText(f"Listo: {nombre} ({len(datos) / 1e6:.1f} MB) en «Paquetes para doctores» de tu escritorio. "
                         f"Mándaselo a {doc} por WhatsApp, correo o Drive.")
        from PySide6 import QtGui

        QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(SALIDA))
