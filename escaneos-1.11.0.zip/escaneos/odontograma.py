"""Odontograma dibujado: las dos arcadas por oclusal con la silueta de cada diente (superior arriba, inferior abajo;
la derecha del paciente a la izquierda, como se mira al paciente). Sirve para elegir un diente con un clic en vez de
una cuadrícula de números: los dientes que se pueden elegir van de color, el resto tenue; el número solo sale al
pasar el ratón o al elegirlo, y el que ya se ajustó a mano lleva una marquita."""
from __future__ import annotations

import math

from PySide6 import QtCore, QtGui, QtWidgets
from PySide6.QtCore import Qt

TURQ = "#1995AD"
# tamaño de cada silueta (a lo largo de la arcada, vestíbulo-lingual) por posición 1–8
_TAM = {1: (17, 12), 2: (14, 11), 3: (15, 15), 4: (15, 17), 5: (15, 17), 6: (22, 21), 7: (21, 20), 8: (18, 18)}


def numeros(jaw: str) -> list[str]:
    """Los 16 dientes de una arcada, de la derecha del paciente a la izquierda."""
    der, izq = ("1", "2") if jaw == "sup" else ("4", "3")
    return [der + str(k) for k in range(8, 0, -1)] + [izq + str(k) for k in range(1, 9)]


def silueta(pos: int) -> tuple[QtGui.QPainterPath, QtGui.QPainterPath]:
    """(contorno, surcos) de un diente visto por oclusal, centrado en (0, 0): x a lo largo de la arcada, −y hacia
    vestibular."""
    w, h = _TAM[pos]
    c, s = QtGui.QPainterPath(), QtGui.QPainterPath()
    if pos <= 2:      # incisivos: una pala
        c.addRoundedRect(QtCore.QRectF(-w / 2, -h / 2, w, h), 4.5, 4.5)
        s.moveTo(-w / 2 + 3, -h / 2 + 3.2)
        s.lineTo(w / 2 - 3, -h / 2 + 3.2)  # el borde incisal
    elif pos == 3:    # canino: redondo con la cúspide hacia vestibular
        c.moveTo(0, -h / 2 - 1.5)
        c.cubicTo(w / 2 + 1, -h / 2 + 2, w / 2 + 1, h / 2, 0, h / 2)
        c.cubicTo(-w / 2 - 1, h / 2, -w / 2 - 1, -h / 2 + 2, 0, -h / 2 - 1.5)
        s.addEllipse(QtCore.QPointF(0, -1.5), 1.2, 1.2)
    elif pos <= 5:    # premolares: óvalo con su surco central
        c.addEllipse(QtCore.QRectF(-w / 2, -h / 2, w, h))
        s.moveTo(-w / 2 + 4, 0)
        s.lineTo(w / 2 - 4, 0)
    else:             # molares: cuadrado redondeado con los surcos en cruz
        c.addRoundedRect(QtCore.QRectF(-w / 2, -h / 2, w, h), 7, 7)
        s.moveTo(-w / 2 + 4.5, 0)
        s.lineTo(w / 2 - 4.5, 0)
        s.moveTo(0, -h / 2 + 4.5)
        s.lineTo(0, h / 2 - 4.5)
    return c, s


class Odontograma(QtWidgets.QWidget):
    """elegibles: dientes («16», «43»…) que se pueden elegir (None = todos). llenos: los que van de color aunque no
    se elijan (None = los elegibles). tocados: ajustados a mano. textos: {diente: lo que dice al pasar el ratón}."""
    elegido = QtCore.Signal(str)  # el diente, o "" al soltarlo

    def __init__(self, elegibles=None, llenos=None, tocados=(), textos=None, sel=None, parent=None):
        super().__init__(parent)
        todos = numeros("sup") + numeros("inf")
        self.elegibles = set(todos if elegibles is None else map(str, elegibles))
        self.llenos = set(self.elegibles if llenos is None else map(str, llenos))
        self.tocados = set(map(str, tocados))
        self.textos = dict(textos or {})
        self.sel = str(sel) if sel else None
        self._sobre = None
        self._k = 0.92  # el dibujo está hecho a 300 × 268 y se muestra un poco más chico
        self.setFixedSize(int(300 * self._k), int(268 * self._k))
        self.setMouseTracking(True)
        self._formas = {}
        # cada arcada es una U (media elipse con dos tramos rectos atrás); los dientes se reparten a lo largo de
        # ella según su tamaño, sin encimarse: los molares quedan en los tramos rectos, como en una arcada real
        # estrecha y alta, con la proporción de una arcada de verdad
        cx, rx, ry, recto, hueco = 150.0, 76.0, 74.0, 46.0, 2.2
        for jaw in ("sup", "inf"):
            sg = -1.0 if jaw == "sup" else 1.0          # la superior abre hacia abajo; la inferior, hacia arriba
            base = 128.0 if jaw == "sup" else 140.0     # donde terminan los últimos molares
            pts = [(cx - rx, base + sg * recto * k / 12) for k in range(13)]
            pts += [(cx - rx * math.cos(math.pi * k / 80), base + sg * (recto + ry * math.sin(math.pi * k / 80)))
                    for k in range(1, 80)]
            pts += [(cx + rx, base + sg * recto * (12 - k) / 12) for k in range(13)]
            largo = [0.0]
            for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
                largo.append(largo[-1] + math.hypot(x1 - x0, y1 - y0))
            nums = numeros(jaw)
            anchos = [_TAM[int(t[1])][0] + hueco for t in nums]
            s0 = (largo[-1] - sum(anchos)) / 2  # centrados en la línea media
            centro_arco = (cx, base + sg * recto)
            for t, w in zip(nums, anchos):
                s = s0 + w / 2
                s0 += w
                k = max(1, min(len(pts) - 1, next((i for i, v in enumerate(largo) if v >= s), len(pts) - 1)))
                u = (s - largo[k - 1]) / max(largo[k] - largo[k - 1], 1e-6)
                x = pts[k - 1][0] + u * (pts[k][0] - pts[k - 1][0])
                y = pts[k - 1][1] + u * (pts[k][1] - pts[k - 1][1])
                tx, ty = pts[k][0] - pts[k - 1][0], pts[k][1] - pts[k - 1][1]
                nx, ny = -ty, tx
                if nx * (x - centro_arco[0]) + ny * (y - centro_arco[1]) < 0:
                    nx, ny = -nx, -ny                    # hacia afuera de la arcada
                giro = math.degrees(math.atan2(nx, -ny))  # la silueta mira hacia afuera (vestibular = −y local)
                tr = QtGui.QTransform().translate(x, y).rotate(giro)
                c, sur = silueta(int(t[1]))
                self._formas[t] = (tr.map(c), tr.map(sur), QtCore.QPointF(x, y))

    # ------------------------------------------------------------------ interacción
    def _bajo(self, p):
        for t, (c, _s, _centro) in self._formas.items():
            if c.contains(QtCore.QPointF(p) / self._k):
                return t
        return None

    def mouseMoveEvent(self, ev):
        t = self._bajo(ev.position())
        if t != self._sobre:
            self._sobre = t
            self.setCursor(Qt.PointingHandCursor if t in self.elegibles else Qt.ArrowCursor)
            self.setToolTip(self.textos.get(t, f"Diente {t}") if t else "")
            self.update()

    def leaveEvent(self, _ev):
        self._sobre = None
        self.update()

    def mousePressEvent(self, ev):
        t = self._bajo(ev.position())
        if ev.button() != Qt.LeftButton or t not in self.elegibles:
            return
        self.sel = None if self.sel == t else t
        self.update()
        self.elegido.emit(self.sel or "")

    def elegir(self, t, avisar=True):
        self.sel = str(t) if t else None
        self.update()
        if avisar:
            self.elegido.emit(self.sel or "")

    # ------------------------------------------------------------------ dibujo
    def paintEvent(self, _ev):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        p.scale(self._k, self._k)
        for t, (c, s, centro) in self._formas.items():
            elegible, lleno = t in self.elegibles, t in self.llenos
            if t == self.sel:
                relleno, borde, surco = QtGui.QColor(TURQ), QtGui.QColor("#0f6a7c"), QtGui.QColor("#ffffff")
            elif lleno:
                relleno, borde, surco = QtGui.QColor("#cfeaf0"), QtGui.QColor(TURQ), QtGui.QColor("#6fb9c9")
            elif elegible:
                relleno, borde, surco = QtGui.QColor("#ffffff"), QtGui.QColor("#9fb3bd"), QtGui.QColor("#c9d5db")
            else:
                relleno, borde, surco = QtGui.QColor("#f3f5f7"), QtGui.QColor("#dde3e8"), QtGui.QColor("#e6ebef")
            if t == self._sobre and elegible and t != self.sel:
                relleno = QtGui.QColor("#a9dbe6")
            p.setPen(QtGui.QPen(borde, 1.4))
            p.setBrush(relleno)
            p.drawPath(c)
            p.setPen(QtGui.QPen(surco, 1.2, Qt.SolidLine, Qt.RoundCap))
            p.setBrush(Qt.NoBrush)
            p.drawPath(s)
            if t in self.tocados:  # ajustado a mano: una marquita naranja
                p.setPen(QtGui.QPen(QtGui.QColor("#ffffff"), 1.2))
                p.setBrush(QtGui.QColor("#f2643d"))
                p.drawEllipse(centro + QtCore.QPointF(5.5, -5.5), 3.4, 3.4)
        # en el centro, el diente elegido o el que está bajo el ratón (así no hay 32 números a la vista)
        t = self._sobre if (self._sobre and self._sobre in self.elegibles) else self.sel
        p.setPen(QtGui.QColor("#9aa4ae"))
        f = p.font()
        f.setPointSizeF(7.5)
        p.setFont(f)
        p.drawText(QtCore.QRectF(0, 127, 56, 14), Qt.AlignCenter, "derecha")
        p.drawText(QtCore.QRectF(244, 127, 56, 14), Qt.AlignCenter, "izquierda")
        if t:
            f.setPointSizeF(15)
            f.setBold(True)
            p.setFont(f)
            p.setPen(QtGui.QColor(TURQ if t == self.sel else "#3d4753"))
            sup = t[0] in "12"
            p.drawText(QtCore.QRectF(90, 62 if sup else 168, 120, 26), Qt.AlignCenter, t)
            texto = self.textos.get(t, "")
            if texto:
                f.setPointSizeF(8)
                f.setBold(False)
                p.setFont(f)
                p.setPen(QtGui.QColor("#5b6570"))
                p.drawText(QtCore.QRectF(96, 88 if sup else 194, 108, 28), Qt.AlignHCenter | Qt.AlignTop | Qt.TextWordWrap, texto)
        p.end()
