"""Informe de análisis del modelo de 3D OrthoLab, con el diseño del de MetronTrack (Miriam, 2026-11-19: «que se
inspire mucho al de MetronTrack, pero ya no incluyas el de MetronTrack, solo el propio»).

Dos partes:
- construir(): el PDF con el estilo (sin Qt): título, «01 Información básica», «02 Modelo de escaneo intraoral»
  (cinco vistas), «03 Medición de datos» (anchos dentarios) y luego cada análisis con su barra turquesa, su tabla
  gris y sus vistas con pie de foto. Recibe bloques genéricos, así lo usa también la skill del informe 3D OrthoLab
  (copia en sus scripts como informe_estilo.py).
- bloques_visor(): arma esos bloques con los resultados del análisis del visor (analisis.medir) y las capturas
  de cada vista.
"""
from __future__ import annotations

import datetime
import os
import sys

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (BaseDocTemplate, CondPageBreak, Frame, Image, KeepTogether, PageBreak, PageTemplate,
                                Paragraph, Spacer, Table, TableStyle)

AQUI = os.path.dirname(os.path.abspath(__file__))
LOGO = os.path.join(AQUI, "iconos", "logo_3dortholab_studio.png")  # logo con «Studio» (nombre del programa)
if not os.path.isfile(LOGO):
    LOGO = os.path.join(AQUI, "iconos", "logo_3dortholab.png")
ICONOS = os.path.join(AQUI, "iconos")

# ------------------------------------------------------------------ estilo (MetronTrack con la marca 3D OrthoLab)
TURQ = colors.HexColor("#1995AD")
TINTA = colors.HexColor("#2b2f33")
GRIS = colors.HexColor("#6f767d")
GRIS_CLARO = colors.HexColor("#9aa1a8")
CAB = colors.HexColor("#ececec")      # cabecera de tabla
ROTULO = colors.HexColor("#f2f2f2")   # columna de rótulos
LINEA = colors.HexColor("#d9d9d9")
CAJA = colors.HexColor("#f4f4f4")     # fondo de las vistas
NIVEL_COLOR = {0: "#2e9e5b", 1: "#c98f12", 2: "#e07b22", 3: "#d64541", 9: "#8b949e"}

# Miriam: «tenemos que adaptar también con nuestro nombre de software, 3D OrthoLab Studio»
SOFTWARE_CORTO = "3D OrthoLab Studio"
try:
    from ..version import VERSION as _V

    SOFTWARE = f"{SOFTWARE_CORTO} {_V}"
except Exception:  # noqa: BLE001  (copia de la skill: sin el paquete de la app)
    SOFTWARE = SOFTWARE_CORTO


def _fuentes():
    try:
        if sys.platform == "darwin":  # Mac: Arial del sistema (trae ≈, ±, ° y las tildes)
            base = "/System/Library/Fonts/Supplemental"
            normal, negrita = "Arial.ttf", "Arial Bold.ttf"
        else:
            base = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts")
            normal, negrita = "segoeui.ttf", "segoeuib.ttf"
        pdfmetrics.registerFont(TTFont("OL", os.path.join(base, normal)))
        pdfmetrics.registerFont(TTFont("OL-B", os.path.join(base, negrita)))
        from reportlab.pdfbase.pdfmetrics import registerFontFamily

        registerFontFamily("OL", normal="OL", bold="OL-B", italic="OL", boldItalic="OL-B")
        return "OL", "OL-B"
    except Exception:  # noqa: BLE001  (sin Segoe UI: las de PDF)
        return "Helvetica", "Helvetica-Bold"


F, FB = _fuentes()
W, H = A4
MX = 16 * mm
FW = W - 2 * MX

ST = {
    "titulo": ParagraphStyle("titulo", fontName=FB, fontSize=21, leading=26, textColor=TINTA, alignment=1),
    "sub": ParagraphStyle("sub", fontName=F, fontSize=9, leading=12, textColor=GRIS, alignment=1),
    "num": ParagraphStyle("num", fontName=FB, fontSize=12.5, leading=16, textColor=colors.HexColor("#4a5056")),
    "h1": ParagraphStyle("h1", fontName=FB, fontSize=11.5, leading=15, textColor=TINTA),
    "h2": ParagraphStyle("h2", fontName=FB, fontSize=9.6, leading=13, textColor=colors.HexColor("#3d4349")),
    "p": ParagraphStyle("p", fontName=F, fontSize=8.6, leading=12, textColor=TINTA),
    "nota": ParagraphStyle("nota", fontName=F, fontSize=7, leading=9.4, textColor=GRIS_CLARO),
    "pie": ParagraphStyle("pie", fontName=F, fontSize=7.2, leading=9.4, textColor=GRIS),
    "c": ParagraphStyle("c", fontName=F, fontSize=7.6, leading=10, textColor=TINTA),
    "cb": ParagraphStyle("cb", fontName=FB, fontSize=7.6, leading=10, textColor=TINTA),
    "ch": ParagraphStyle("ch", fontName=FB, fontSize=7.4, leading=9.6, textColor=colors.HexColor("#4a5056")),
    "dato": ParagraphStyle("dato", fontName=F, fontSize=8.2, leading=11, textColor=TINTA),
}


def nivel_txt(n, texto):
    """Lectura con su punto de color, como los «chips» del visor."""
    if not texto:
        return ""
    col = NIVEL_COLOR.get(n, "#8b949e")
    return f'<font color="{col}">●</font> <font color="{col}">{texto}</font>'


def _p(t, s="c"):
    return t if not isinstance(t, str) else Paragraph(t, ST[s])


def _img(ruta, ancho, alto_max=None):
    from PIL import Image as PI

    iw, ih = PI.open(ruta).size
    w, h = ancho, ancho * ih / iw
    if alto_max and h > alto_max:
        w, h = alto_max * iw / ih, alto_max
    return Image(ruta, width=w, height=h)


def _caja_vista(ruta, pie, ancho, alto):
    """La vista en su caja gris claro y su pie de foto, como MetronTrack."""
    contenido = _img(ruta, ancho - 6 * mm, alto - 6 * mm) if ruta and os.path.isfile(ruta) else _p("Sin vista", "nota")
    t = Table([[contenido], [_p(pie, "pie")]], colWidths=[ancho], rowHeights=[alto, None])
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (0, 0), CAJA), ("ALIGN", (0, 0), (0, 0), "CENTER"),
                           ("VALIGN", (0, 0), (0, 0), "MIDDLE"), ("LEFTPADDING", (0, 0), (-1, -1), 0),
                           ("RIGHTPADDING", (0, 0), (-1, -1), 0), ("TOPPADDING", (0, 1), (0, 1), 3)]))
    return t


def _vistas(imagenes, por_fila=2, alto=58 * mm):
    """Rejilla de vistas: [(ruta, pie)]; una sola va centrada y más grande."""
    imagenes = [x for x in imagenes if x and x[0]]
    if not imagenes:
        return []
    if len(imagenes) == 1:
        t = Table([[_caja_vista(imagenes[0][0], imagenes[0][1], FW, alto * 1.15)]], colWidths=[FW])
        t.setStyle(TableStyle([("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
                               ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
        return [t]
    gap = 5 * mm
    cw = (FW - gap * (por_fila - 1)) / por_fila
    filas = []
    for i in range(0, len(imagenes), por_fila):
        fila = []
        for j in range(por_fila):
            k = i + j
            fila.append(_caja_vista(imagenes[k][0], imagenes[k][1], cw, alto) if k < len(imagenes) else "")
            if j < por_fila - 1:
                fila.append("")
        filas.append(fila)
    anchos = []
    for j in range(por_fila):
        anchos.append(cw)
        if j < por_fila - 1:
            anchos.append(gap)
    t = Table(filas, colWidths=anchos)
    t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0),
                           ("RIGHTPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
    return [t]


def _tabla(cab, filas, anchos=None, agrupar=0, rotulo=1, nota=None):
    """Tabla gris de MetronTrack. agrupar: cuántas columnas de la izquierda se funden cuando se repiten (p. ej.
    «Mandíbula superior»). rotulo: cuántas columnas van con fondo gris de rótulo."""
    ncol = len(cab) if cab else len(filas[0])
    anchos = anchos or [1] * ncol
    tot = float(sum(anchos))
    cw = [FW * a / tot for a in anchos]
    datos = []
    if cab:
        datos.append([_p(x, "ch") for x in cab])
    for f in filas:
        datos.append([_p(x if x is not None else "—", "cb" if j < rotulo else "c") for j, x in enumerate(f)])
    sty = [("GRID", (0, 0), (-1, -1), 0.5, LINEA), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
           ("TOPPADDING", (0, 0), (-1, -1), 3.2), ("BOTTOMPADDING", (0, 0), (-1, -1), 3.2),
           ("LEFTPADDING", (0, 0), (-1, -1), 5)]
    off = 1 if cab else 0
    if cab:
        sty.append(("BACKGROUND", (0, 0), (-1, 0), CAB))
    if rotulo:
        sty.append(("BACKGROUND", (0, off), (rotulo - 1, -1), ROTULO))
    for col in range(agrupar):  # funde las celdas repetidas de esa columna (y las vacía)
        i = 0
        while i < len(filas):
            j = i
            while j + 1 < len(filas) and filas[j + 1][col] == filas[i][col] and all(
                    filas[j + 1][c] == filas[i][c] for c in range(col)):
                j += 1
            if j > i:
                sty.append(("SPAN", (col, i + off), (col, j + off)))
                for k in range(i + 1, j + 1):
                    datos[k + off][col] = ""
            i = j + 1
    t = Table(datos, colWidths=cw, repeatRows=1 if cab else 0)
    t.setStyle(TableStyle(sty))
    out = [t]
    if nota:
        out += [Spacer(1, 2), _p(nota, "nota")]
    return out


def _titulo_seccion(texto, icono=None, nivel=1):
    """Barra turquesa + ícono + título (nivel 1), o solo ícono + título (nivel 2), como MetronTrack."""
    ic = os.path.join(ICONOS, f"{icono}.png") if icono else None
    celdas, anchos = [], []
    if nivel == 1:
        celdas.append("")
        anchos.append(2.2 * mm)
    if ic and os.path.isfile(ic):
        celdas.append(_img(ic, 4.6 * mm, 4.6 * mm))
        anchos.append(6.5 * mm)
    celdas.append(_p(texto, "h1" if nivel == 1 else "h2"))
    anchos.append(FW - sum(anchos))
    t = Table([celdas], colWidths=anchos, rowHeights=[6.4 * mm])
    sty = [("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("LEFTPADDING", (0, 0), (-1, -1), 0),
           ("RIGHTPADDING", (0, 0), (-1, -1), 2), ("TOPPADDING", (0, 0), (-1, -1), 0),
           ("BOTTOMPADDING", (0, 0), (-1, -1), 0)]
    if nivel == 1:
        sty += [("BACKGROUND", (0, 0), (0, 0), TURQ), ("LEFTPADDING", (1, 0), (1, 0), 5)]
    t.setStyle(TableStyle(sty))
    return t


def _numerado(num, texto):
    """«01 Información básica», con su raya debajo."""
    t = Table([[_p(f'<font color="#9aa1a8">{num}</font>&nbsp;&nbsp;{texto}', "num")]], colWidths=[FW])
    t.setStyle(TableStyle([("LINEBELOW", (0, 0), (-1, -1), 0.6, LINEA), ("LEFTPADDING", (0, 0), (-1, -1), 0),
                           ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
    return t


# ------------------------------------------------------------------ PDF
def construir(destino: str, info: dict, bloques: list, titulo="Informe de análisis del modelo"):
    """info: paciente, edad, genero, doctor, fecha_informe, fecha_escaneo, denticion (lo que haya).
    bloques: [{"tipo": "seccion"|"subseccion"|"tabla"|"vistas"|"texto"|"nota"|"salto"|"numerado", …}]."""
    nombre = info.get("paciente") or "Paciente"
    software = info.get("software") or SOFTWARE

    def decorar(c, doc):
        c.saveState()
        c.setFillColor(TURQ)
        c.rect(0, H - 3 * mm, W, 3 * mm, fill=1, stroke=0)
        c.setFont(F, 7)
        c.setFillColor(GRIS_CLARO)
        c.drawString(MX, 9 * mm, f"{nombre} - {titulo} · {SOFTWARE_CORTO}")
        c.drawRightString(W - MX, 9 * mm, str(doc.page))
        if doc.page == 1 and os.path.isfile(LOGO):
            ir = ImageReader(LOGO)
            iw, ih = ir.getSize()
            lw = 17 * mm
            c.drawImage(ir, W - MX - lw, H - 9 * mm - lw * ih / iw, width=lw, height=lw * ih / iw, mask="auto")
        c.restoreState()

    doc = BaseDocTemplate(destino, pagesize=A4, leftMargin=MX, rightMargin=MX, topMargin=12 * mm,
                          bottomMargin=16 * mm, title=f"{titulo} - {nombre}", author="3D OrthoLab")
    doc.addPageTemplates([PageTemplate(id="p", frames=[Frame(MX, 16 * mm, FW, H - 28 * mm, 0, 0, 0, 0)],
                                       onPage=decorar)])
    E = [Spacer(1, 10 * mm), _p(titulo, "titulo"), Spacer(1, 1.5 * mm),
         _p(f'<font color="#1995AD"><b>{SOFTWARE_CORTO}</b></font> · análisis de modelos digitales', "sub"),
         Spacer(1, 7 * mm), _numerado("01", "Información básica"), Spacer(1, 4)]
    pares = [("Nombre del paciente", info.get("paciente")), ("Edad", info.get("edad")),
             ("Género", info.get("genero")), ("Doctor", info.get("doctor")),
             ("Fecha del informe", info.get("fecha_informe") or datetime.date.today().strftime("%Y-%m-%d")),
             ("Fecha del escaneo", info.get("fecha_escaneo")), ("Dentición", info.get("denticion")),
             ("Escaneado por", info.get("laboratorio", "3D OrthoLab")), ("Modelo", info.get("modelo")),
             ("Software", software)]
    pares = [(a, b) for a, b in pares if b]
    filas = []
    for i in range(0, len(pares), 2):
        f = []
        for a, b in pares[i:i + 2]:
            f += [_p(f"<b>{a}</b>", "dato"), _p(str(b), "dato")]
        while len(f) < 4:
            f.append("")
        filas.append(f)
    t = Table(filas, colWidths=[36 * mm, FW / 2 - 36 * mm, 30 * mm, FW / 2 - 30 * mm])
    t.setStyle(TableStyle([("LEFTPADDING", (0, 0), (-1, -1), 0), ("TOPPADDING", (0, 0), (-1, -1), 2.5),
                           ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5)]))
    E += [t, Spacer(1, 8)]
    # título + tabla + vistas van JUNTOS en la misma página (antes una tabla quedaba al final de una hoja y su vista
    # pasaba a la siguiente). «pend» junta el título y la tabla hasta que llega su vista.
    pend = []
    tiene_tabla = False

    def soltar():
        nonlocal pend, tiene_tabla
        if pend:
            E.append(KeepTogether(pend))
        pend, tiene_tabla = [], False

    for b in bloques:
        tipo = b.get("tipo")
        if tipo in ("seccion", "subseccion"):
            if tiene_tabla:  # la sección anterior no tenía vista: se cierra
                soltar()
            if not pend:
                E.append(CondPageBreak(b.get("espacio", 70 if tipo == "seccion" else 55) * mm))
            pend += [Spacer(1, 6 if tipo == "seccion" else 4),
                     _titulo_seccion(b["titulo"], b.get("icono"), 1 if tipo == "seccion" else 2),
                     Spacer(1, 4 if tipo == "seccion" else 3)]
            continue
        if tipo == "tabla":
            partes = _tabla(b.get("cab"), b["filas"], b.get("anchos"), b.get("agrupar", 0), b.get("rotulo", 1),
                            b.get("nota"))
            if len(b["filas"]) >= 22:  # tablas largas: pueden partirse entre hojas
                soltar()
                E += partes + [Spacer(1, 5)]
            else:
                pend += partes + [Spacer(1, 5)]
                tiene_tabla = True
            continue
        if tipo == "vistas":
            v = _vistas(b["imagenes"], b.get("por_fila", 2), b.get("alto", 58) * mm)
            if pend:
                pend += v
                soltar()
            else:
                E += v
            continue
        soltar()
        if tipo == "numerado":
            E += [Spacer(1, 4), _numerado(b["num"], b["titulo"]), Spacer(1, 5)]
        elif tipo == "texto":
            E += [_p(b["texto"], "p"), Spacer(1, 3)]
        elif tipo == "lista":
            E += [Paragraph(x, ST["p"], bulletText="•") for x in b["items"]] + [Spacer(1, 3)]
        elif tipo == "nota":
            E += [_p(b["texto"], "nota"), Spacer(1, 3)]
        elif tipo == "salto":
            E.append(PageBreak())
    soltar()
    doc.build(E)
    return destino


# ------------------------------------------------------------------ bloques con los resultados del visor
ORDEN_SUP = ["18", "17", "16", "15", "14", "13", "12", "11", "21", "22", "23", "24", "25", "26", "27", "28"]
ORDEN_INF = ["48", "47", "46", "45", "44", "43", "42", "41", "31", "32", "33", "34", "35", "36", "37", "38"]
ARC = {"sup": "Arcada superior", "inf": "Arcada inferior"}
NIVELES = (("anterior", "Anterior"), ("media", "Media"), ("posterior", "Posterior"))


def _f(v, d=1, unidad=""):
    if v is None:
        return "—"
    s = f"{v:.{d}f}".replace("-", "−")
    return f"{s} {unidad}".strip()


def bloques_visor(res: dict, cap: dict, AD=None) -> list:
    """res: analisis.medir(caso). cap: {nombre: ruta png} de las capturas del visor (ver pagina.capturas_informe)."""
    from . import analisis as A

    c = lambda k: cap.get(k)  # noqa: E731
    B = []
    # 02 vistas del modelo
    B.append({"tipo": "numerado", "num": "02", "titulo": "Modelo de escaneo intraoral"})
    B.append({"tipo": "vistas", "alto": 44, "imagenes": [
        (c("oclusal_sup"), "Plano oclusal / Arcada superior"), (c("oclusal_inf"), "Plano oclusal / Arcada inferior"),
        (c("izquierda"), "Vista izquierda / Arcadas en oclusión"), (c("derecha"), "Vista derecha / Arcadas en oclusión")]})
    B.append({"tipo": "vistas", "alto": 40, "imagenes": [(c("frente"), "Vista frontal / Arcadas en oclusión")]})
    B.append({"tipo": "nota", "texto": "*Este informe es un apoyo diagnóstico hecho sobre el modelo digital; "
                                      "el diagnóstico corresponde al doctor tratante."})
    B.append({"tipo": "salto"})
    # 03 anchos dentarios
    an = res.get("anchos") or {}
    fuente = {"accudesign": "del escáner", "doctor": "corregidos por el doctor", "promedio": "promedio",
              "medido": "medidos sobre el modelo"}.get(res.get("anchos_fuente"), "")
    B.append({"tipo": "numerado", "num": "03", "titulo": "Medición de datos"})
    den = res.get("denticion") or {}
    B.append({"tipo": "texto", "texto": f'<font color="#1995AD">●</font> <b>Dentición '
                                       f'{"mixta" if den.get("mixta") else "permanente"}</b> · anchos mesiodistales '
                                       f'{fuente} (mm)'})
    if any(an.get(t) for t in ORDEN_SUP + ORDEN_INF):
        filas = []
        for orden in (ORDEN_SUP, ORDEN_INF):
            filas.append([f"<b>{t}</b>" for t in orden])
            filas.append([_f(an.get(t)) if an.get(t) else "0.0" for t in orden])
        B.append({"tipo": "tabla", "cab": None, "filas": filas, "rotulo": 0})
    else:  # sin la separación de dientes no hay anchos: mejor decirlo que una tabla de ceros
        B.append({"tipo": "nota", "texto": "Este escaneo no trae los dientes identificados (separación de dientes), así que "
                                          "no hay anchos mesiodistales: Bolton, apiñamiento, Korkhaus ideal y las clases "
                                          "molar y canina no se pueden calcular."})
    # resumen
    rs = res.get("resumen") or []
    if rs:
        B.append({"tipo": "seccion", "titulo": "Resumen de hallazgos", "icono": "resumen"})
        B.append({"tipo": "tabla", "cab": ["Análisis", "Resultado"], "anchos": [1.2, 3.8],
                  "filas": [[t, nivel_txt(n, txt)] for n, t, txt, _ in rs]})
    # apiñamiento
    ap = res.get("apinamiento") or {}
    if any(ap.get(j) for j in ("sup", "inf")):
        B.append({"tipo": "seccion", "titulo": "Medición de apiñamiento dental", "icono": "espacio", "espacio": 110})
        filas = []
        for jaw in ("sup", "inf"):
            for seg in ("3-3", "5-5", "6-6", "7-7"):
                x = (ap.get(jaw) or {}).get(seg)
                if not x:
                    continue
                n, t = A.nivel_espacio(-x["apinamiento"])
                filas.append([ARC[jaw], seg, _f(x["dientes"]), _f(x["arcada"]), _f(x["apinamiento"]), nivel_txt(n, t)])
        B.append({"tipo": "tabla", "cab": ["Arcada", "Tipo", "Tamaño de los dientes", "Tamaño de la arcada",
                                           "Apiñamiento (mm)", "Lectura"],
                  "anchos": [1.4, 0.6, 1.1, 1.1, 1, 1.6], "agrupar": 1, "filas": filas,
                  "nota": "Apiñamiento = tamaño de los dientes − tamaño de la arcada (negativo = espacio). "
                          "Leve ≤4 mm · moderado 4–8 mm · severo >8 mm."})
        B.append({"tipo": "vistas", "imagenes": [(c("espacio"), "Plano oclusal / Arcadas superior e inferior")]})
    # Bolton
    bo = res.get("bolton") or {}
    if bo:
        B.append({"tipo": "seccion", "titulo": "Medición de la relación de Bolton", "icono": "bolton", "espacio": 100})
        filas = []
        for k, n6, nombre in (("anterior", "6", "Relación anterior"), ("global", "12", "Relación general")):
            x = bo.get(k)
            if not x:
                continue
            n, t = A.nivel_bolton(x)
            filas += [[f"Suma de las {n6} piezas inferiores (M-D)", _f(x["inf"]), ""],
                      [f"Suma de las {n6} piezas superiores (M-D)", _f(x["sup"]), ""],
                      [f"<b>{nombre}</b>", f"<b>{x['relacion']:.2f} %</b>", nivel_txt(n, t)]]
        B.append({"tipo": "tabla", "cab": ["Medición de datos", "Resultado", "Lectura"], "anchos": [2.4, 1, 1.6],
                  "filas": filas, "nota": "Relación anterior: 78.8 % ± 1.72 % · relación general: 91.5 % ± 1.51 % (Bolton)."})
        B.append({"tipo": "vistas", "imagenes": [(c("bolton"), "Plano oclusal / ancho mesiodistal de cada diente")]})
    # Moyers
    mo = res.get("moyers")
    if mo and mo.get("cuadrantes") and res.get("mixta"):
        B.append({"tipo": "seccion", "titulo": "Análisis de Moyers (dentición mixta)", "icono": "moyers"})
        filas = []
        for q, x in sorted(mo["cuadrantes"].items()):
            n, t = A.nivel_espacio(x["discrepancia"])
            filas.append([f"Cuadrante {q}", _f(x["disponible"]), _f(x["previsto"]), _f(x["discrepancia"]), nivel_txt(n, t)])
        B.append({"tipo": "tabla", "cab": ["Cuadrante", "Espacio disponible", "Previsto 3-4-5 (Moyers 75 %)",
                                           "Discrepancia", "Lectura"], "anchos": [1, 1, 1.4, 1, 1.4], "filas": filas,
                  "nota": f"Suma de incisivos inferiores = {_f(mo['SI'])} mm."})
        B.append({"tipo": "vistas", "imagenes": [(c("moyers"), "Plano oclusal / espacio para caninos y premolares")]})
    # Spee
    sp = res.get("spee") or {}
    if sp:
        B.append({"tipo": "seccion", "titulo": "Curva de Spee", "icono": "oclusion", "espacio": 45})
        filas = [[n, _f(sp.get(k), 2)] for k, n in (("izq", "Izquierda"), ("der", "Derecha"), ("promedio", "Valor promedio")) if k in sp]
        B.append({"tipo": "tabla", "cab": ["Medición de datos", "Resultado (mm)"], "anchos": [2, 3], "filas": filas,
                  "nota": "Profundidad de la curva de Spee: 2 ± 0.7 mm."})
        B.append({"tipo": "vistas", "alto": 50, "imagenes": [
            (c("spee_der"), "Vista lateral derecha / Arcada inferior: recta incisivo–último molar (rojo) y cúspides (azul)"),
            (c("spee_izq"), "Vista lateral izquierda / Arcada inferior")]})
    # oclusión
    oj = res.get("overjet") or {}
    if oj:
        B.append({"tipo": "seccion", "titulo": "Oclusión", "icono": "oclusion", "espacio": 120})
        B.append({"tipo": "subseccion", "titulo": "Medición de sobremordida y resalte"})
        filas = []
        for x in oj.values():
            n1, t1 = A.nivel_overbite(x["overbite"])
            n2, t2 = A.nivel_overjet(x["overjet"])
            filas.append([x["par"].replace("/", " & "), f"{_f(x['overbite'])} {nivel_txt(n1, t1)}",
                          f"{_f(x['overjet'])} {nivel_txt(n2, t2)}"])
        B.append({"tipo": "tabla", "cab": ["Posición del diente", "Sobremordida (mm)", "Resalte / overjet (mm)"],
                  "anchos": [1, 2, 2], "filas": filas,
                  "nota": "Resalte normal 0–3 mm; sobremordida normal hasta 3 mm (≈1/3 de la corona). "
                          "Negativo: mordida cruzada (resalte) o mordida abierta (sobremordida)."})
        B.append({"tipo": "vistas", "alto": 50, "imagenes": [
            (c(f"corte_{t}"), f"Corte sagital por el {t}: superior verde, inferior naranja")
            for t in ("11", "21") if c(f"corte_{t}")]})
        B.append({"tipo": "vistas", "imagenes": [(c("overjet_frente"), "Vista frontal / Arcadas en oclusión"),
                                                  (c("overjet_izquierda"), "Vista izquierda / Arcadas en oclusión"),
                                                  (c("overjet_derecha"), "Vista derecha / Arcadas en oclusión")]})
    cl = res.get("clases") or {}
    for cual, titulo in (("molar", "Medición de la relación molar"), ("canina", "Medición de la relación canina")):
        x = cl.get(cual) or {}
        if not x:
            continue
        B.append({"tipo": "subseccion", "titulo": titulo, "espacio": 105})
        filas = []
        for lado, nl in (("izq", "Izquierda"), ("der", "Derecha")):
            if lado in x:
                y = x[lado]
                det = "" if y.get("falta") or y.get("criterio") else f" ({_f(y.get('d'))} mm)"
                filas.append([nl, nivel_txt(y.get("nivel", 9), f"{y['clase']}{det}") +
                              (" · criterio del doctor" if y.get("criterio") else "")])
        B.append({"tipo": "tabla", "cab": ["Medición de datos", "Resultado de la medición"], "anchos": [1, 3],
                  "filas": filas})
        B.append({"tipo": "vistas", "imagenes": [(c(f"{cual}_izquierda"), "Vista izquierda / Arcadas en oclusión"),
                                                  (c(f"{cual}_derecha"), "Vista derecha / Arcadas en oclusión")]})
    lm = res.get("linea_media") or {}
    if lm:
        B.append({"tipo": "subseccion", "titulo": "Medición de la relación con la línea media", "espacio": 90})
        if lm.get("valorable", True):
            fila = ["Línea media inferior respecto a la superior", lm["direccion"].capitalize(), _f(lm["mm"], 1, "mm")]
        else:
            fila = ["Línea media inferior respecto a la superior", "No valorable", "—"]
        B.append({"tipo": "tabla", "cab": ["Medición de datos", "Dirección", "Resultado"], "anchos": [2, 1, 1],
                  "filas": [fila], "nota": "Tolerancia clínica habitual: hasta 2 mm."})
        B.append({"tipo": "vistas", "imagenes": [(c("lmedia"), "Vista frontal / Arcadas en oclusión")]})
    # contactos
    ct = res.get("contactos") or {}
    if ct.get("sup"):
        B.append({"tipo": "seccion", "titulo": "Contactos oclusales", "icono": "contactos", "espacio": 110})
        filas, T = [], [0.0] * 4
        for z, nz in (("ant", "Anterior"), ("prem", "Premolares"), ("mol", "Molares")):
            v = [(ct["sup"][f"{z}_{lado}"][k] + ct["inf"][f"{z}_{lado}"][k]) / 2
                 for lado in ("der", "izq") for k in ("c01", "c03")]
            T = [a + b for a, b in zip(T, v)]
            filas.append([nz] + [_f(x) for x in v])
        filas.append(["<b>Total</b>"] + [f"<b>{_f(x)}</b>" for x in T])
        B.append({"tipo": "tabla", "cab": ["Zona (mm²)", "Derecha: contacto", "Derecha: ≤0.3 mm", "Izquierda: contacto",
                                           "Izquierda: ≤0.3 mm"], "anchos": [1.2, 1, 1, 1, 1], "filas": filas,
                  "nota": "Contacto firme: distancia <0.1 mm entre las arcadas en oclusión; proximidad: hasta 0.3 mm. "
                          "Promedio de las dos arcadas. Confirmar con papel de articular."})
        B.append({"tipo": "vistas", "imagenes": [(c("contactos"), "Plano oclusal / mapa de contactos (rojo = contacto)")]})
    # Korkhaus
    K = res.get("korkhaus") or {}
    if K:
        B.append({"tipo": "seccion", "titulo": "Análisis de Korkhaus", "icono": "korkhaus", "espacio": 110})

        def fk(nombre, med, ideal):
            if med is None:
                return [nombre, "—", "—", "—", ""]
            if ideal is None:
                return [nombre, _f(med), "—", "—", ""]
            n, t = A.nivel_korkhaus(med, ideal)
            return [nombre, _f(med), _f(ideal), _f(med - ideal), nivel_txt(n, t)]
        filas = [["Arcada superior"] + fk("Premolar 14–24", K.get("prem_u"), K.get("prem_id")),
                 ["Arcada superior"] + fk("Molar 16–26", K.get("mol_u"), K.get("mol_id")),
                 ["Arcada superior"] + fk("Largo anterior Lo", K.get("Lo"), K.get("Lo_id")),
                 ["Arcada inferior"] + fk("Premolar 44/45–34/35", K.get("prem_l"), K.get("prem_id")),
                 ["Arcada inferior"] + fk("Molar 46–36", K.get("mol_l"), K.get("mol_id")),
                 ["Arcada inferior"] + fk("Largo anterior Lu", K.get("Lu"), K.get("Lu_id"))]
        B.append({"tipo": "tabla", "cab": ["Arcada", "Medida", "Medido (mm)", "Ideal (mm)", "Diferencia", "Lectura"],
                  "anchos": [1.2, 1.5, 0.9, 0.9, 0.9, 1.6], "agrupar": 1, "rotulo": 1, "filas": filas,
                  "nota": f"SI (12+11+21+22) = {_f(K.get('SI'))} mm. Ideal: premolar = SI×100/85; molar = SI×100/65; "
                          f"Lo = SI×100/160; Lu = Lo − 2 mm."})
        B.append({"tipo": "vistas", "imagenes": [(c("korkhaus"), "Plano oclusal / anchos (rojo y verde) y largo anterior (azul)")]})
    # arcada
    anch, lon, sim = res.get("anchuras") or {}, res.get("longitud") or {}, res.get("simetria") or {}
    if anch or lon or sim or res.get("forma"):
        B.append({"tipo": "seccion", "titulo": "Medición de la arcada dental", "icono": "arcada", "espacio": 130})
    if anch:
        B.append({"tipo": "subseccion", "titulo": "Medida de anchura del arco", "espacio": 115})
        nom = {"canina": "Anchura anterior", "premolar": "Anchura media", "molar": "Anchura posterior"}
        filas = [[ARC[j], nom[k], _f(v)] for j in ("sup", "inf") for k, v in (anch.get(j) or {}).items()]
        B.append({"tipo": "tabla", "cab": ["Medición de datos", "", "Resultado (mm)"], "anchos": [1.3, 1.3, 1.4],
                  "agrupar": 1, "rotulo": 2, "filas": filas,
                  "nota": "Entre los centros de caninos (anterior), primeros premolares (media) y primeros molares (posterior)."})
        B.append({"tipo": "vistas", "imagenes": [(c("ancho"), "Plano oclusal / anchura del arco")]})
    if lon:
        B.append({"tipo": "subseccion", "titulo": "Medida de longitud de arco", "espacio": 115})
        filas = []
        for j in ("sup", "inf"):
            x = lon.get(j) or {}
            for k, nk in NIVELES:
                if k in x:
                    filas.append([ARC[j], f"Longitud {nk.lower()}", _f(x[k])])
        B.append({"tipo": "tabla", "cab": ["Medición de datos", "", "Resultado (mm)"], "anchos": [1.3, 1.3, 1.4],
                  "agrupar": 1, "rotulo": 2, "filas": filas,
                  "nota": "Profundidad sobre el eje medio, del borde de los incisivos centrales a la línea de caninos "
                          "(anterior), primeros premolares (media) y primeros molares (posterior)."})
        B.append({"tipo": "vistas", "imagenes": [(c("longitud"), "Plano oclusal / longitud del arco")]})
    if sim:
        B.append({"tipo": "subseccion", "titulo": "Simetría de arcada dental", "espacio": 115})
        filas = []
        for j in ("sup", "inf"):
            for k, nk in NIVELES:
                x = (sim.get(j) or {}).get(k)
                if x:
                    filas.append([ARC[j], f"Anchura {nk.lower()}", _f(x["izq"]), _f(x["der"]), _f(x["dif"])])
        B.append({"tipo": "tabla", "cab": ["Medición de datos", "", "Izquierda (mm)", "Derecha (mm)", "Diferencia"],
                  "anchos": [1.3, 1.3, 1, 1, 1], "agrupar": 1, "rotulo": 2, "filas": filas,
                  "nota": "Distancia de cada diente al plano medio de la arcada."})
        B.append({"tipo": "vistas", "imagenes": [(c("simetria"), "Plano oclusal / plano medio de la arcada")]})
    fo = res.get("forma") or {}
    if fo:
        B.append({"tipo": "subseccion", "titulo": "Análisis de forma de arco", "espacio": 100})
        B.append({"tipo": "tabla", "cab": ["Medición de datos", "Resultado"], "anchos": [1, 2],
                  "filas": [[ARC[j], fo.get(j) or "—"] for j in ("sup", "inf")]})
        B.append({"tipo": "vistas", "imagenes": [(c("forma"), "Plano oclusal / forma del arco")]})
    B.append({"tipo": "nota", "texto": f"Mediciones hechas por {SOFTWARE} sobre el escaneo intraoral. Son un apoyo "
                                      "diagnóstico y deben interpretarse con la exploración clínica, las radiografías y el "
                                      "plan del doctor tratante."})
    return B


# ------------------------------------------------------------------ capturas
def recortar(img, margen=14, mascara=None):
    """Quita el fondo (degradado claro del visor) alrededor del modelo. img: array RGB. mascara: dónde hay modelo
    (p. ej. el mapa de profundidad del 3D); sin ella se adivina por el color, que confunde el zócalo marfil con
    el fondo claro."""
    import numpy as np

    if mascara is not None and np.asarray(mascara).any():
        m = np.asarray(mascara, bool)
    else:
        a = np.asarray(img)[..., :3].astype(np.int16)
        fondo = np.median(a[:, :6], axis=1, keepdims=True)  # el degradado va de arriba abajo: el fondo de cada fila
        m = np.abs(a - fondo).max(axis=2) > 18
    ys, xs = np.nonzero(m)
    if not len(ys):
        return img
    alto, ancho = np.asarray(img).shape[:2]
    y0, y1 = max(ys.min() - margen, 0), min(ys.max() + margen, alto)
    x0, x1 = max(xs.min() - margen, 0), min(xs.max() + margen, ancho)
    return np.asarray(img)[y0:y1, x0:x1]
