"""Separación de dientes de MetronTrack (solo en la PC de la Dra., al crear el paquete).

MetronTrack (Shining 3D) guarda en `C:\\DentalOrder\\<orden>\\metronTrackData\\teethSepSaveDirEdit\\` la separación
de dientes de cada caso (la que la Dra. revisa en «Marcar diente»): una malla OBJ por arcada y una etiqueta por cara
con el número de diente (numeración universal 1–32) y si es temporal. Aquí se lee, se pasa a FDI y se transfiere a
los modelos que van en el paquete (están en otro marco: se registran con ICP sobre las coronas).

    etiquetas = para_modelos(carpeta_orden, {rol: vértices})   # {rol: uint8 por vértice, 0 = encía; FDI 11–48, 51–85}
"""
from __future__ import annotations

import json
import os
import re
import zipfile

import numpy as np

ORDENES = r"C:\DentalOrder"


def a_fdi(universal: int, temporal: bool = False) -> int:
    """Numeración universal (1–16 superior de derecha a izquierda, 17–32 inferior de izquierda a derecha) → FDI."""
    u = int(universal)
    if 1 <= u <= 8:
        fdi = 10 + (9 - u)
    elif u <= 16:
        fdi = 20 + (u - 8)
    elif u <= 24:
        fdi = 30 + (25 - u)
    elif u <= 32:
        fdi = 40 + (u - 24)
    else:
        return 0
    return fdi + 40 if temporal and fdi % 10 <= 5 else fdi


def carpeta_orden(carpeta_caso: str):
    """La carpeta de la orden en C:\\DentalOrder para un caso exportado (su nombre trae <fecha>_<consultorio>_<orden>)."""
    nombres = [carpeta_caso]
    for raiz, dirs, archivos in os.walk(carpeta_caso):
        nombres += dirs + archivos
    arriba = os.path.dirname(carpeta_caso.rstrip("\\/"))
    nombres += [arriba, os.path.dirname(arriba)]
    for n in nombres:
        m = re.search(r"\d{4}-\d{2}-\d{2}_\d+_\d+", os.path.basename(str(n).rstrip("\\/")) or str(n))
        if m:
            r = os.path.join(ORDENES, m.group(0))
            if os.path.isdir(os.path.join(r, "metronTrackData")):
                return r
    return None


def leer(orden: str):
    """{"sup": (V, F, fdi_por_cara), "inf": (…)} de la separación guardada (la editada; si no, la automática)."""
    base = os.path.join(orden, "metronTrackData")
    z = None
    for n in ("teethSepSaveDirEdit", "teethSepSaveDirDefault"):
        r = os.path.join(base, n, n + ".zip")
        if os.path.exists(r):
            zz = zipfile.ZipFile(r)
            if any(x.endswith(".obj") for x in zz.namelist()):
                z = zz
                break
    if z is None:
        return None
    d = json.loads(next(z.read(n) for n in z.namelist() if n.endswith(".json")))["ai"]["dental"]
    out = {}
    for jaw, clave, obj in (("sup", "upperJaw", "sepAfterUpperJaw.obj"), ("inf", "lowerJaw", "sepAfterLowerJaw.obj")):
        if obj not in z.namelist() or clave not in d:
            continue
        V, F = [], []
        for linea in z.read(obj).decode("latin1").splitlines():
            if linea.startswith("v "):
                V.append(linea.split()[1:4])
            elif linea.startswith("f "):
                F.append([x.split("/")[0] for x in linea.split()[1:4]])
        V = np.array(V, np.float64)
        F = np.array(F, np.int64) - 1
        b = z.read(d[clave]["instanceSeg"])
        i = b.find(b"end_header\n") + 11
        lab = np.frombuffer(b, np.uint8, offset=i)
        if len(lab) != len(F):
            continue
        temporal = {int(t["idx"]): bool(t.get("isBaby")) for t in d[clave].get("toothNum", [])}
        tabla = np.zeros(256, np.uint8)
        for u in np.unique(lab):
            if u:
                tabla[u] = a_fdi(int(u), temporal.get(int(u), False))
        out[jaw] = (V, F, tabla[lab])
    return out or None


def _rigido(A, B):
    """Rotación y traslación que llevan A sobre B (Kabsch)."""
    ca, cb = A.mean(0), B.mean(0)
    U, _, Vt = np.linalg.svd((A - ca).T @ (B - cb))
    D = np.diag([1, 1, np.sign(np.linalg.det(Vt.T @ U.T))])
    R = Vt.T @ D @ U.T
    return R, cb - R @ ca


def registrar(origen, destino, iteraciones=300, inicio=None):
    """ICP recortado: (R, t, error mediano en mm) que lleva los puntos de `origen` (coronas) sobre `destino`.
    inicio: (R, t) de partida (si no, la identidad)."""
    from scipy.spatial import cKDTree

    rng = np.random.default_rng(0)
    P = origen[rng.choice(len(origen), min(len(origen), 12000), replace=False)]
    arbol = cKDTree(destino)
    R, t = (np.eye(3), np.zeros(3)) if inicio is None else (np.asarray(inicio[0], float), np.asarray(inicio[1], float))
    for k in range(iteraciones):
        Q = P @ R.T + t
        d, i = arbol.query(Q)
        ok = d <= np.percentile(d, 60 if k < 40 else 80 if k < 120 else 90)
        dR, dt = _rigido(Q[ok], destino[i[ok]])
        R, t = dR @ R, dR @ t + dt
        giro = np.arccos(np.clip((np.trace(dR) - 1) / 2, -1, 1))
        if k > 130 and np.linalg.norm(dt) < 1e-4 and giro < 1e-5:
            break
    d, _ = arbol.query(P @ R.T + t)
    return R, t, float(np.median(d))


def para_modelos(orden: str, modelos: dict, tolerancia=0.12) -> dict:
    """{rol: etiquetas FDI por vértice (uint8)} para cada modelo ({rol: vértices}) que se pudo registrar bien.
    Los modelos exportados (crudos y zocalados) están en marcos distintos al de MetronTrack: primero se prueba el ICP
    directo y, si no cae, se parte de la alineación anatómica de cada par (analisis.alinear) y se afina."""
    from scipy.spatial import cKDTree

    from . import analisis as A

    sep = leer(orden)
    out = {}
    if not sep:
        return out
    lab_v = {}
    for jaw, (Vm, Fm, fdi) in sep.items():  # etiqueta por vértice de la malla de MetronTrack
        lv = np.zeros(len(Vm), np.uint8)
        for k in range(3):
            lv[Fm[:, k]] = np.maximum(lv[Fm[:, k]], fdi)
        lab_v[jaw] = lv
    M_mt = None
    for tipo in ("sin_zocalo", "con_zocalo"):
        par = {jaw: np.asarray(modelos[f"{n}_{tipo}"], np.float64) for jaw, n in (("sup", "superior"), ("inf", "inferior"))
               if f"{n}_{tipo}" in modelos and jaw in sep}
        inicio = None
        for intento in (0, 1):
            listo = True
            for jaw, V in par.items():
                rol = ("superior_" if jaw == "sup" else "inferior_") + tipo
                if rol in out:
                    continue
                Vm = sep[jaw][0]
                coronas = Vm[lab_v[jaw] > 0]
                if len(coronas) < 500:
                    continue
                R, t, err = registrar(coronas, V, inicio=inicio)
                if err > tolerancia:
                    listo = False
                    continue
                d, i = cKDTree(Vm @ R.T + t).query(V, distance_upper_bound=0.4)
                lab = np.zeros(len(V), np.uint8)
                cerca = np.isfinite(d)
                lab[cerca] = lab_v[jaw][i[cerca]]
                out[rol] = lab
            if listo or len(par) < 2 or len(sep) < 2:
                break
            try:  # partir de la alineación anatómica de los dos pares
                if M_mt is None:
                    M_mt = A.alinear(sep["sup"][0], sep["inf"][0])[0]
                M = A.inversa(A.alinear(par["sup"], par["inf"])[0]) @ M_mt
                inicio = (M[:3, :3], M[:3, 3])
            except Exception:  # noqa: BLE001
                break
    return out


RELACION = {"1": "Relación neutra", "2": "Relación mesial", "3": "Relación distal"}
FORMA = {"1": "Redondo puntiagudo", "2": "Oval", "3": "Cuadrado redondeado"}  # comprobados con MetronTrack


def _num(v):
    try:
        return float(str(v).replace("%", "").strip())
    except (TypeError, ValueError):
        return None


def medidas(orden: str):
    """Las medidas que MetronTrack guardó del caso (metronTrackData/measureSaveDir/measureSave.json), con la misma
    forma que accudesign.parse(): sirve cuando no hay PDF. None si el caso no tiene medidas guardadas."""
    ruta = os.path.join(orden, "metronTrackData", "measureSaveDir", "measureSave.json")
    try:
        with open(ruta, encoding="utf-8") as f:
            datos = {x["key"]: x for x in json.load(f)["data"]}
    except (OSError, ValueError, KeyError, TypeError):
        return None

    def pares(clave):
        return {v["key"]: v for v in (datos.get(clave) or {}).get("value") or [] if isinstance(v, dict) and "key" in v}

    R = dict(paciente={}, anchos={}, apinamiento={"sup": {}, "inf": {}}, bolton={}, spee={}, altura_palatina=None,
             oclusion={}, relacion_molar={}, relacion_canina={}, linea_media={}, anchura_arco={"sup": {}, "inf": {}},
             longitud_arco={"sup": {}, "inf": {}}, simetria={"sup": {}, "inf": {}}, forma_arco={}, avisos=[],
             fuente="metrontrack")
    for t, v in pares("toothWidthInfo").items():
        w = _num(v.get("value"))
        if w:
            R["anchos"][t] = w
    for seg in (datos.get("crowding") or {}).get("children") or []:
        filas = {v["key"]: v for v in seg.get("value") or []}
        for jaw, k in (("sup", "upperJaw"), ("inf", "lowerJaw")):
            d, a, ap = (_num(filas.get(x, {}).get(k)) for x in ("toothMass", "boneMass", "crowding"))
            if d and a:
                R["apinamiento"][jaw][seg["key"]] = dict(dientes=d, arcada=a, apinamiento=ap if ap is not None else d - a,
                                                         grado="")
    b = pares("boltonData")
    for k, nombre in (("qianYaBi", "anterior"), ("quanYaBi", "global"), ("shangQuanYaHe", "suma12_sup"),
                      ("xiaQuanYaHe", "suma12_inf"), ("shangQianYaHe", "suma6_sup"), ("xiaQianYaHe", "suma6_inf")):
        if k in b and _num(b[k].get("value")) is not None:
            R["bolton"][nombre] = _num(b[k]["value"])
    sp = pares("speeData")
    for k, nombre in (("leftValue", "izq"), ("rightValue", "der"), ("avageValue", "promedio")):
        if k in sp and _num(sp[k].get("value")) is not None:
            R["spee"][nombre] = _num(sp[k]["value"])
    ap = pares("eGaiGaoDuData")
    if "hightValue" in ap:
        R["altura_palatina"] = _num(ap["hightValue"].get("value"))
    for k, v in pares("fuhefugaiData").items():
        oj, ob = _num(v.get("fuGaiValue")), _num(v.get("fuHeValue"))
        if oj is not None and ob is not None:
            R["oclusion"][k.replace("_", "/")] = dict(overjet=oj, overbite=ob, overjet_grado="", overbite_grado="")
    for clave, destino in (("moyaguanxiData", "relacion_molar"), ("jianYaguanxiData", "relacion_canina")):
        p = pares(clave)
        for k, lado in (("leftValue", "izq"), ("rightValue", "der")):
            if k in p and str(p[k].get("value")) in RELACION:
                R[destino][lado] = RELACION[str(p[k]["value"])]
    lm = pares("zhongXianGuanXiData")
    if "result" in lm and _num(lm["result"].get("value")) is not None:
        direccion = {"1": "Izquierda", "2": "Derecha"}.get(str((lm.get("direct") or {}).get("value")))
        R["linea_media"] = dict(direccion=direccion, mm=abs(_num(lm["result"]["value"])))
    for clave, destino, nombres in (("yaGonWidthData", "anchura_arco", ("Front", "Middle", "After")),
                                    ("yaGonLengthData", "longitud_arco", ("Front", "Middle", "After", "Total"))):
        p = pares(clave)
        for jaw, pre in (("sup", "upper"), ("inf", "lower")):
            for n, esp in zip(nombres, ("anterior", "media", "posterior", "total")):
                if pre + n in p and _num(p[pre + n].get("value")) is not None:
                    R[destino][jaw][esp] = _num(p[pre + n]["value"])
    p = pares("yaGonDuiChengData")
    for jaw, pre in (("sup", "upper"), ("inf", "lower")):
        for n, esp in (("Front", "anterior"), ("Middle", "media"), ("After", "posterior")):
            v = p.get(pre + n)
            if v and _num(v.get("leftValue")) is not None and _num(v.get("rightValue")) is not None:
                R["simetria"][jaw][esp] = dict(izq=_num(v["leftValue"]), der=_num(v["rightValue"]))
    p = pares("yaGonFengXiData")
    for k, jaw in (("upperValue", "sup"), ("lowerValue", "inf")):
        if k in p and str(p[k].get("value")) in FORMA:
            R["forma_arco"][jaw] = FORMA[str(p[k]["value"])]
    return R if R["anchos"] else None
