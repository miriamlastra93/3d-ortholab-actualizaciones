"""Marco anatómico de un par de arcadas escaneadas (para las vistas rápidas y la apertura en bisagra).

- arriba: normal del plano oclusal (eje de menor varianza), hacia la arcada superior;
- adelante: dentro del plano, el eje de la parábola que mejor ajusta la arcada, hacia su vértice (los incisivos);
- derecha del paciente: adelante × arriba.
"""
from __future__ import annotations

import numpy as np


def _muestra(v, n=40000, semilla=0):
    if len(v) <= n:
        return v
    return v[np.random.default_rng(semilla).choice(len(v), n, replace=False)]


def marco(superior=None, inferior=None) -> dict:
    """{"centro", "der", "adel", "arriba"} (vectores unitarios en coordenadas del escáner)."""
    arcos = [a for a in (superior, inferior) if a is not None and len(a)]
    P = np.vstack([_muestra(np.asarray(a, float)) for a in arcos])
    c = P.mean(0)
    X = P - c
    w, vec = np.linalg.eigh(X.T @ X / len(X))
    arriba = vec[:, 0]  # menor varianza
    if superior is not None and inferior is not None:
        if np.dot(np.asarray(superior).mean(0) - np.asarray(inferior).mean(0), arriba) < 0:
            arriba = -arriba
    base = vec[:, 1:]  # plano oclusal
    # adelante: la parábola de la arcada (s = a·t² + b·t + c) que mejor ajusta; el vértice (incisivos) va al frente
    Q = X @ base
    mejor, d_mejor = np.inf, None
    for th in np.radians(np.arange(0, 180, 2)):
        u = np.array([np.cos(th), np.sin(th)])
        s_, t_ = Q @ u, Q @ np.array([-u[1], u[0]])
        A = np.column_stack([t_ ** 2, t_, np.ones_like(t_)])
        coef, *_ = np.linalg.lstsq(A, s_, rcond=None)
        err = float(np.mean((A @ coef - s_) ** 2)) / (float(np.var(s_)) + 1e-9)
        if coef[0] != 0 and err < mejor:
            mejor, d_mejor = err, (base @ u) * (-np.sign(coef[0]))  # abre hacia atrás: el vértice es el frente
    adel = d_mejor / np.linalg.norm(d_mejor)
    der = np.cross(adel, arriba)
    der /= np.linalg.norm(der)
    arriba = np.cross(der, adel)
    return {"centro": c, "der": der, "adel": adel, "arriba": arriba}


def bisagra(m: dict, inferior) -> tuple:
    """(punto, eje) de la apertura: detrás de los molares y por encima del plano oclusal (cerca del cóndilo)."""
    v = np.asarray(inferior, float) - m["centro"]
    atras = float((v @ m["adel"]).min())
    punto = m["centro"] + m["adel"] * (atras - 25.0) + m["arriba"] * 35.0
    return punto, m["der"]


def rotar(puntos, punto, eje, grados):
    """Rodrigues: gira los puntos alrededor del eje que pasa por `punto`."""
    t = np.radians(grados)
    k = np.asarray(eje, float) / np.linalg.norm(eje)
    p = np.asarray(puntos, float) - punto
    rot = p * np.cos(t) + np.cross(k, p) * np.sin(t) + np.outer(p @ k, k) * (1 - np.cos(t))
    return (rot + punto).astype(np.float32)
