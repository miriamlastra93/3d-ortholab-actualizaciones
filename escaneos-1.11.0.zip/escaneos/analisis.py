"""Análisis de modelos en el visor del doctor (lo hace el propio programa, en la computadora del doctor).

Adaptado de la skill «analisis-modelos-ortholab» de 3D OrthoLab (paso1_preparar / paso2_medir), sin figuras y con
poca memoria: solo numpy, scipy y scikit-image (vienen en el .exe).

Marco de trabajo «A» (como la skill): oclusión en el plano z = 0, superior arriba (+z), anterior = −y,
x negativo = derecha del paciente, línea media superior en x = 0. M (4×4) lleva del escáner a ese marco.

Flujo:
    caso = preparar(sup, inf, anchos_accudesign, accudesign)   # alinea, mapas, curvas, propone puntos (≈20–60 s)
    res = medir(caso)                                          # medidas (rápido; se repite al mover un punto)
Los puntos (`caso.P`) y los anchos (`caso.anchos`) los puede corregir el doctor; luego se vuelve a llamar medir().
"""
from __future__ import annotations

import numpy as np

# orden de dientes desde la línea media hacia distal (permanentes; en dentición mixta se usa el temporal)
LADO = {("sup", "der"): ["11", "12", "13", "14", "15", "16", "17"], ("sup", "izq"): ["21", "22", "23", "24", "25", "26", "27"],
        ("inf", "der"): ["41", "42", "43", "44", "45", "46", "47"], ("inf", "izq"): ["31", "32", "33", "34", "35", "36", "37"]}
TEMPORAL = {"3": "3", "4": "4", "5": "5"}  # posición → posición del temporal (13→53, 14→54, 15→55…)
# anchos mesiodistales promedio (mm), solo para ubicar los dientes cuando no hay anchos medidos
PROMEDIO = {"1": (8.6, 5.3), "2": (6.6, 5.9), "3": (7.6, 6.8), "4": (7.0, 7.0), "5": (6.6, 7.2), "6": (10.2, 11.1),
            "7": (9.3, 10.4)}

# Moyers al 75 % (Moyers 1988, tabla clásica): suma de incisivos inferiores → 3+4+5 previsto por cuadrante
MOYERS_SI = [19.5, 20.0, 20.5, 21.0, 21.5, 22.0, 22.5, 23.0, 23.5, 24.0, 24.5, 25.0, 25.5, 26.0, 26.5, 27.0, 27.5, 28.0,
             28.5, 29.0]
MOYERS_SUP = [20.6, 20.9, 21.2, 21.5, 21.8, 22.0, 22.3, 22.6, 22.9, 23.1, 23.4, 23.7, 24.0, 24.2, 24.5, 24.8, 25.0, 25.3,
              25.6, 25.9]
MOYERS_INF = [20.1, 20.4, 20.7, 21.0, 21.3, 21.6, 21.9, 22.2, 22.5, 22.8, 23.1, 23.4, 23.7, 24.0, 24.2, 24.5, 24.8, 25.1,
              25.4, 25.7]

CONTACTO_BINS = [0.1, 0.3, 0.6, 1.0, 2.0]
CONTACTO_COLORES = ["#d7191c", "#fdae61", "#ffe14d", "#7fc97f", "#7fb8e0"]


class ErrorAnalisis(Exception):
    pass


# ----------------------------------------------------------------------------- utilidades
def aplicar(M, V):
    V = np.asarray(V, np.float64)
    return (V @ M[:3, :3].T + M[:3, 3]).astype(np.float32)


def inversa(M):
    Mi = np.eye(4)
    Mi[:3, :3] = M[:3, :3].T
    Mi[:3, 3] = -M[:3, :3].T @ M[:3, 3]
    return Mi


def normales(V, F):
    """Normales por vértice (promedio de las caras, ponderado por área)."""
    V = np.asarray(V, np.float32)
    F = np.asarray(F, np.int64)
    n = np.zeros_like(V)
    fn = np.cross(V[F[:, 1]] - V[F[:, 0]], V[F[:, 2]] - V[F[:, 0]])
    for k in range(3):
        np.add.at(n, F[:, k], fn)
    n /= np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    return n


def area_vertice(V, F):
    F = np.asarray(F, np.int64)
    a = 0.5 * np.linalg.norm(np.cross(V[F[:, 1]] - V[F[:, 0]], V[F[:, 2]] - V[F[:, 0]]), axis=1)
    va = np.zeros(len(V), np.float64)
    for k in range(3):
        np.add.at(va, F[:, k], a / 3)
    return va


def ancho(anchos, diente):
    """Ancho del diente (o de su temporal en dentición mixta: 13 → 53)."""
    w = anchos.get(diente) or 0
    if not w and diente[1] in TEMPORAL:
        w = anchos.get(str(int(diente[0]) + 4) + diente[1]) or 0
    return float(w)


# ----------------------------------------------------------------------------- alineación
def alinear(U, L):
    """M (4×4): oclusión en z = 0, superior +z, línea media en x = 0, anterior −y. Solo rota y traslada."""
    from scipy.optimize import minimize
    from scipy.spatial import cKDTree

    Up, Lp = np.asarray(U, np.float64), np.asarray(L, np.float64)
    rng = np.random.default_rng(0)
    Ls = Lp[rng.choice(len(Lp), min(len(Lp), 250000), replace=False)]
    d, _ = cKDTree(Ls).query(Up, distance_upper_bound=1.5)
    C = Up[np.isfinite(d)]
    if len(C) < 200:
        raise ErrorAnalisis("Los modelos no están en oclusión (el superior y el inferior casi no se tocan).")
    c0 = C.mean(0)
    _, _, vt = np.linalg.svd(C - c0, full_matrices=False)
    n = vt[2]
    if (Up.mean(0) - Lp.mean(0)) @ n < 0:
        n = -n
    v = np.cross(n, [0, 0, 1])
    c = n @ [0, 0, 1]
    vx = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
    R = np.eye(3) + vx + vx @ vx / (1 + c)
    M = np.eye(4)
    M[:3, :3] = R
    M[:3, 3] = -R @ c0
    Ua = aplicar(M, Up)
    T = Ua[(Ua[:, 2] > -2) & (Ua[:, 2] < 4)]
    P = T[rng.choice(len(T), min(12000, len(T)), replace=False), :2].astype(np.float64)
    pm0 = P.mean(0)
    P = P - pm0
    tree = cKDTree(P)

    def costo(q):
        th, cc = q
        t = np.radians(th)
        a = np.array([np.cos(t), np.sin(t)])
        nn = np.array([-a[1], a[0]])
        s = (P @ nn) - cc
        dd, _ = tree.query(P - 2 * s[:, None] * nn)
        return np.mean(np.minimum(dd, 3) ** 2)

    mejor = min((costo((th, cc)), th, cc) for th in np.arange(0, 180, 3) for cc in np.arange(-8, 8.1, 1))
    r = minimize(costo, [mejor[1], mejor[2]], method="Nelder-Mead")
    th, cc = r.x
    t = np.radians(th)
    a = np.array([np.cos(t), np.sin(t)])
    nn = np.array([-a[1], a[0]])
    # ¿hacia dónde está el frente? Los puntos de corona pegados al eje de simetría son los incisivos. Con mordida
    # abierta los incisivos superiores quedan fuera de la banda: se usan también las coronas inferiores.
    La_ = aplicar(M, Lp[::3])
    Q = np.vstack([Ua[(Ua[:, 2] > -2) & (Ua[:, 2] < 9)][::3, :2], La_[(La_[:, 2] > -9) & (La_[:, 2] < 2)][:, :2]])
    Q = Q.astype(np.float64) - pm0
    cerca = Q[np.abs(Q @ nn - cc) < 4]
    if len(cerca) and (cerca @ a).mean() > (Q @ a).mean():
        a = -a
    ang = np.arctan2(a[0], a[1])
    Rz = np.eye(4)
    Rz[:2, :2] = [[np.cos(ang), -np.sin(ang)], [np.sin(ang), np.cos(ang)]]
    M = Rz @ M
    x_eje = float((Rz[:2, :2] @ (pm0 + cc * nn))[0])  # la recta de simetría, ya girada
    Ua = aplicar(M, Up)
    Pm = Ua[(Ua[:, 2] > -2) & (Ua[:, 2] < 4)][:, :2].astype(np.float64)[::5]
    tr = cKDTree(Pm)
    xs = np.arange(x_eje - 3, x_eje + 3, 0.1)
    x0 = xs[np.argmin([np.mean(np.minimum(tr.query(np.c_[2 * x - Pm[:, 0], Pm[:, 1]])[0], 3) ** 2) for x in xs])]
    Tx = np.eye(4)
    Tx[0, 3] = -x0
    return Tx @ M, float(r.fun)


# ----------------------------------------------------------------------------- mapas de profundidad
def mapa(V, F, superior, res=0.25):
    """Superficie oclusal vista desde abajo (superior: z mínima) o desde arriba (inferior: z máxima).
    Muestrea también el interior de cada triángulo (sin huecos por los que se vea la tapa del zócalo)."""
    from scipy.ndimage import gaussian_filter, maximum_filter, minimum_filter

    V = np.asarray(V, np.float32)
    F = np.asarray(F, np.int64)
    x0, y0 = float(V[:, 0].min()), float(V[:, 1].min())
    nx = int((V[:, 0].max() - x0) / res) + 1
    ny = int((V[:, 1].max() - y0) / res) + 1
    H = np.full(ny * nx, np.inf if superior else -np.inf, np.float32)
    op = np.minimum if superior else np.maximum

    def volcar(P):
        ix = np.clip(((P[:, 0] - x0) / res).astype(np.int64), 0, nx - 1)
        iy = np.clip(((P[:, 1] - y0) / res).astype(np.int64), 0, ny - 1)
        op.at(H, iy * nx + ix, P[:, 2])

    volcar(V)
    e = np.max(np.stack([np.linalg.norm(V[F[:, i]] - V[F[:, (i + 1) % 3]], axis=1) for i in range(3)]), axis=0)
    n = int(np.clip(np.ceil(np.percentile(e, 90) / 0.15), 1, 6))
    for i in range(n + 1):
        for j in range(n + 1 - i):
            k = n - i - j
            if (i, j, k) in ((n, 0, 0), (0, n, 0), (0, 0, n)):
                continue
            for a in range(0, len(F), 400000):  # por bloques: poca memoria
                f = F[a:a + 400000]
                volcar((i * V[f[:, 0]] + j * V[f[:, 1]] + k * V[f[:, 2]]) / n)
    H = H.reshape(ny, nx)
    vacio = ~np.isfinite(H)
    if vacio.any():
        f = minimum_filter(H, 3) if superior else maximum_filter(H, 3)
        H = np.where(vacio, f, H)
    vacio = ~np.isfinite(H)
    H[vacio] = np.nan
    Hs = gaussian_filter(np.where(vacio, np.nanmean(H), H), 0.6).astype(np.float32)
    Hs[vacio] = np.nan
    return Hs, x0, y0, res


def altura(D, x, y):
    H, x0, y0, res = D
    i = int(np.clip(round((y - y0) / res), 0, H.shape[0] - 1))
    j = int(np.clip(round((x - x0) / res), 0, H.shape[1] - 1))
    v = H[max(0, i - 2):i + 3, max(0, j - 2):j + 3]
    return float(np.nanmedian(v)) if np.isfinite(v).any() else 0.0


def altura_cerca(D, x, y, radio=5.0):
    """Altura de la superficie en (x, y); si ahí no hay modelo (borde de los incisivos, una línea que sale por delante
    de la arcada), la del punto del modelo más cercano dentro de «radio» mm. None si no hay nada cerca. Solo para
    dibujar: así los trazos quedan pegados al modelo y no «salen volando» al plano z = 0 (Miriam, Korkhaus anterior)."""
    H, x0, y0, res = D
    i = int(round((y - y0) / res))
    j = int(round((x - x0) / res))
    r = max(2, int(np.ceil(radio / res)))
    i0, i1 = max(0, i - r), min(H.shape[0], i + r + 1)
    j0, j1 = max(0, j - r), min(H.shape[1], j + r + 1)
    if i0 >= i1 or j0 >= j1:
        return None
    v = H[i0:i1, j0:j1]
    ok = np.isfinite(v)
    if not ok.any():
        return None
    ii, jj = np.nonzero(ok)
    d = (ii + i0 - i) ** 2 + (jj + j0 - j) ** 2
    cerca = d <= d.min() + 2  # los más cercanos (mediana de unos pocos: sin picos)
    return float(np.median(v[ii[cerca], jj[cerca]]))


# ----------------------------------------------------------------------------- curva de arcada y puntos
def curva_arcada(D, superior):
    from scipy.ndimage import gaussian_filter1d, median_filter

    H, x0, y0, res = D
    ys, xs = np.mgrid[0:H.shape[0], 0:H.shape[1]]
    X, Y = x0 + xs * res, y0 + ys * res
    # 9 mm: con mordida abierta los incisivos quedan lejos del plano oclusal (cada sector se queda luego con
    # su banda de 2 mm más oclusal; los sectores posteriores siguen exigiendo corona cerca del plano)
    m = ((H < 9) if superior else (H > -9)) & ~np.isnan(H)
    px, py, ph = X[m], Y[m], H[m]
    yc = py.mean()
    th = np.degrees(np.arctan2(px, -(py - yc)))
    r = np.hypot(px, py - yc)
    bins = np.arange(-120, 121, 1.5)
    R = np.full(len(bins), np.nan)
    for i, b in enumerate(bins):
        mk = np.abs(th - b) < 1.0
        if mk.sum() <= 20:
            continue
        hb = ph[mk]
        ref = np.percentile(hb, 2) if superior else np.percentile(hb, 98)
        mm = (hb < ref + 2.0) if superior else (hb > ref - 2.0)
        if abs(b) > 45 and ((ref > 2.5) if superior else (ref < -2.5)):
            continue
        if mm.sum() > 10:
            R[i] = np.median(r[mk][mm])
    ok = ~np.isnan(R)
    idx = np.nonzero(ok)[0]
    for a_, b_ in zip(idx[:-1], idx[1:]):
        if 1 < b_ - a_ <= 12:
            R[a_ + 1:b_] = np.interp(np.arange(a_ + 1, b_), [a_, b_], [R[a_], R[b_]])
    ok = ~np.isnan(R)
    i0 = int(np.argmin(np.abs(bins)))
    if not ok[i0]:
        raise ErrorAnalisis("No encontré la arcada en el modelo.")
    lo = hi = i0
    while lo - 1 >= 0 and ok[lo - 1]:
        lo -= 1
    while hi + 1 < len(bins) and ok[hi + 1]:
        hi += 1
    bb = bins[lo:hi + 1]
    RR = gaussian_filter1d(median_filter(R[lo:hi + 1], 7, mode="nearest"), 4, mode="nearest")
    t = np.radians(bb)
    P = np.c_[RR * np.sin(t), yc - RR * np.cos(t)]
    seg = np.r_[0, np.cumsum(np.linalg.norm(np.diff(P, axis=0), axis=1))]
    return P, seg - np.interp(0, bb, seg)  # s negativo = derecha del paciente


def en_s(P, s, sv):
    return np.array([np.interp(sv, s, P[:, 0]), np.interp(sv, s, P[:, 1])])


def s_de(P, s, q):
    """Posición a lo largo de la curva del punto más cercano a q (x, y)."""
    d = np.hypot(P[:, 0] - q[0], P[:, 1] - q[1])
    i = int(np.argmin(d))
    if 0 < i < len(P) - 1:  # afinar entre vecinos
        a, b = (i - 1, i) if d[i - 1] < d[i + 1] else (i, i + 1)
        u = P[b] - P[a]
        t = float(np.clip((np.asarray(q) - P[a]) @ u / max(u @ u, 1e-9), 0, 1))
        return float(s[a] + t * (s[b] - s[a]))
    return float(s[i])


def segmentar(D, semillas, superior, thr=3.0):
    from scipy.ndimage import binary_dilation
    from skimage.segmentation import watershed

    H, x0, y0, res = D
    Hn = np.nan_to_num(H, nan=(99 if superior else -99))
    elev = Hn if superior else -Hn
    mask = (Hn < thr) if superior else (Hn > -thr)
    ys, xs = np.mgrid[0:H.shape[0], 0:H.shape[1]]
    X, Y = x0 + xs * res, y0 + ys * res
    mk = np.zeros(H.shape, np.int32)
    ids = {}
    for i, (t, (x, y)) in enumerate(semillas.items(), 1):
        dd = np.where(mask, np.hypot(X - x, Y - y), 99)
        iy, ix = np.unravel_index(np.argmin(dd), dd.shape)
        if dd[iy, ix] < 3:
            mk[max(0, iy - 2):iy + 3, max(0, ix - 2):ix + 3] = i
            ids[i] = t
    lab = watershed(elev, mk, mask=mask)
    cen = {}
    for i, t in ids.items():
        m = lab == i
        if m.sum() * res * res < 12:
            continue
        hh = Hn[m]
        ref = hh.min() if superior else hh.max()
        mm = m & ((Hn < ref + 1.8) if superior else (Hn > ref - 1.8))
        cen[t] = [round(float(X[mm].mean()), 2), round(float(Y[mm].mean()), 2)]
    cont = {}
    inv = {t: i for i, t in ids.items()}
    for (a, b) in (("34", "35"), ("44", "45"), ("14", "15"), ("24", "25")):
        if a in inv and b in inv and a in cen and b in cen:
            bd = binary_dilation(lab == inv[a], iterations=2) & binary_dilation(lab == inv[b], iterations=2)
            if bd.sum() < 3:
                continue
            Pp = np.c_[X[bd], Y[bd]]
            mid = (np.array(cen[a]) + np.array(cen[b])) / 2
            dv = np.array(cen[b]) - np.array(cen[a])
            dv /= np.linalg.norm(dv)
            nv = np.array([-dv[1], dv[0]])
            q = Pp[np.argsort(np.abs((Pp - mid) @ nv))[:max(3, len(Pp) // 10)]].mean(0)
            cont[(a, b)] = [round(float(q[0]), 2), round(float(q[1]), 2)]
    return cen, cont


def anchos_completos(anchos):
    """Anchos para ubicar dientes: los medidos y, donde falten, el promedio."""
    out = {}
    for (jaw, _), dientes in LADO.items():
        for t in dientes:
            w = ancho(anchos, t)
            out[t] = w if w > 0.5 else PROMEDIO[t[1]][0 if jaw == "sup" else 1]
    return out


def proponer(DU, DL, curvas, anchos, AD=None):
    AD = AD or {}
    WD = anchos_completos(anchos)
    out = {"sup": {}, "inf": {}, "centros": {"sup": {}, "inf": {}}, "revisar": []}
    lm = AD.get("linea_media") or {}
    shift_inf = 0.0
    if lm.get("mm"):
        shift_inf = lm["mm"] * (1 if (lm.get("direccion") or "").lower().startswith("izq") else -1)
    for jaw, D in (("sup", DU), ("inf", DL)):
        P, s = curvas[jaw]
        s_mid = 0.0
        if jaw == "inf" and shift_inf:
            ss = np.linspace(-15, 15, 301)
            xx = np.array([en_s(P, s, v)[0] for v in ss])
            s_mid = float(ss[np.argmin(np.abs(xx - shift_inf))])
        apj = (AD.get("apinamiento") or {}).get(jaw, {})
        kx, ky = [0.0], [0.0]
        for seg in ("3-3", "5-5", "6-6", "7-7"):
            v = apj.get(seg) or {}
            if v.get("dientes") and v.get("arcada") and v["dientes"] / 2 > kx[-1]:
                kx.append(v["dientes"] / 2)
                ky.append(v["arcada"] / 2)
        if len(kx) < 2:
            kx, ky = [0, 1], [0, 1]

        def a_arco(c, kx=kx, ky=ky):
            return float(np.interp(c, kx, ky)) if c <= kx[-1] else ky[-1] + (c - kx[-1]) * (ky[-1] / kx[-1])

        for lado, sg in (("der", -1), ("izq", 1)):
            acc = 0.0
            for t in LADO[(jaw, lado)]:
                c = en_s(P, s, s_mid + sg * a_arco(acc + WD[t] / 2))
                out["centros"][jaw][t] = [round(float(c[0]), 2), round(float(c[1]), 2)]
                acc += WD[t]
                if jaw == "inf" and t[1] == "4":
                    cc = en_s(P, s, s_mid + sg * a_arco(acc))
                    out["inf"]["c34/35" if lado == "izq" else "c44/45"] = [round(float(cc[0]), 2), round(float(cc[1]), 2)]
        prop = dict(out["centros"][jaw])
        semillas = dict(prop)
        for _ in range(3):
            cen, cont = segmentar(D, semillas, jaw == "sup")
            semillas = dict(prop)
            semillas.update(cen)
        revisar = []
        ks = list(cen)
        for i_ in range(len(ks)):
            for j_ in range(i_ + 1, len(ks)):
                a_, b_ = ks[i_], ks[j_]
                if np.hypot(cen[a_][0] - cen[b_][0], cen[a_][1] - cen[b_][1]) < 3:
                    revisar += [a_, b_]
        for t in set(revisar):
            cen.pop(t, None)
        for t, c in list(cen.items()):
            if np.hypot(c[0] - prop[t][0], c[1] - prop[t][1]) > 0.6 * WD[t]:
                revisar.append(t)
                cen[t] = prop[t]
        out["revisar"].extend(sorted(set(revisar)))
        out["centros"][jaw].update(cen)
        for t in (("14", "24", "16", "26") if jaw == "sup" else ("36", "46")):
            out[jaw][t] = out["centros"][jaw][t]
        if jaw == "inf":
            for a_, b_, k_ in (("34", "35", "c34/35"), ("44", "45", "c44/45")):
                if (a_, b_) in cont:
                    out["inf"][k_] = cont[(a_, b_)]
    out["incisivos"] = {t: out["centros"][j][t][0] for j, ts in (("sup", ("11", "21")), ("inf", ("41", "31"))) for t in ts}
    return out


# ----------------------------------------------------------------------------- el caso
class Caso:
    """Todo lo que hace falta para medir (en memoria): modelos alineados, mapas, curvas, puntos y anchos.
    etiquetas: {"sup": FDI por vértice, "inf": …} (la separación de dientes del escáner, si el paquete la trae):
    con ella los puntos salen del diente correcto y el visor puede pintar cada diente."""

    def __init__(self, U, FU, L, FL, M, costo, anchos, AD, etiquetas=None):
        self.U, self.FU, self.L, self.FL = U, FU, L, FL
        self.M, self.costo = M, costo
        self.anchos = {k: float(v) for k, v in (anchos or {}).items() if v}
        self.anchos_fuente = "accudesign" if self.anchos else "promedio"
        self.AD = AD or {}
        self.etiquetas = {j: np.array(e, np.uint8) for j, e in (etiquetas or {}).items()
                          if e is not None and len(e) == len(U if j == "sup" else L)}
        self._etiquetas0 = {j: e.copy() for j, e in self.etiquetas.items()}  # como llegaron (para deshacer)
        self._hist, self._rehacer = [], []  # deshacer / rehacer de «Marcar diente»
        self._normales = {}
        self.criterio = {}   # lo que el doctor fija a su criterio: clases, forma de arcada…
        self.renombres = []  # números de diente corregidos por el doctor: [(arcada, antes, ahora)]
        self.DU = mapa(U, FU, True)
        self.DL = mapa(L, FL, False)
        self.curvas = {"sup": curva_arcada(self.DU, True), "inf": curva_arcada(self.DL, False)}
        self._contactos = None
        self.reproponer()

    def z(self, jaw, x, y):
        return altura(self.DU if jaw == "sup" else self.DL, x, y)

    def z_cerca(self, jaw, x, y, radio=5.0):
        """Para dibujar: la altura del modelo en (x, y) o en su punto más cercano (None si no hay modelo cerca)."""
        return altura_cerca(self.DU if jaw == "sup" else self.DL, x, y, radio)

    def reproponer(self):
        self.P = proponer(self.DU, self.DL, self.curvas, self.anchos, self.AD)
        self.P["ajustes"] = {}  # puntos de clase molar/canina y líneas medias movidos por el doctor
        self.P["md"] = {}       # puntos mesial/distal movidos por el doctor
        self._puntos_de_etiquetas()

    # ------------------------------------------------------------------ «Marcar diente»: deshacer y rehacer
    def __getattr__(self, nombre):
        # casos creados antes de «Marcar diente» (guardados o de las pruebas) no traen estas listas
        if nombre in ("_hist", "_rehacer"):
            self.__dict__[nombre] = []
            return self.__dict__[nombre]
        if nombre == "_normales":
            self.__dict__[nombre] = {}
            return self.__dict__[nombre]
        raise AttributeError(nombre)

    def _foto(self):
        return ({j: e.copy() for j, e in self.etiquetas.items()}, [list(x) for x in self.renombres])

    def _anotar_paso(self):
        self._hist.append(self._foto())
        del self._hist[:-30]
        self._rehacer = []

    def deshacer(self) -> bool:
        if not self._hist:
            return False
        self._rehacer.append(self._foto())
        self.etiquetas, self.renombres = self._hist.pop()
        self._refrescar_puntos()
        return True

    def rehacer(self) -> bool:
        if not self._rehacer:
            return False
        self._hist.append(self._foto())
        self.etiquetas, self.renombres = self._rehacer.pop()
        self._refrescar_puntos()
        return True

    def _refrescar_puntos(self):
        """Tras cambiar la separación: los puntos de cada diente, sin perder lo que el doctor ya acomodó."""
        self._puntos_de_etiquetas()
        for jaw in self.etiquetas:
            hay = set((self.P.get("presentes") or {}).get(jaw, []))
            for t in [t for t in self.P["centros"][jaw] if t not in hay]:
                self.P["centros"][jaw].pop(t, None)

    def _numero_libre(self, jaw, cerca_de, hacia_der=None):
        """El número sin usar más cercano a `cerca_de` en el orden de la arcada (prefiriendo ese lado)."""
        orden = [int(n) for n in ORDEN_ARCADA[jaw]]
        lab = self.etiquetas[jaw]
        usados = set(int(t) for t in np.unique(lab) if t)
        k = orden.index(cerca_de) if cerca_de in orden else len(orden) // 2
        libres = [(abs(j - k) + (0.5 if hacia_der is not None and (j < k) != hacia_der else 0.0), j)
                  for j, n in enumerate(orden) if n not in usados]
        return orden[min(libres)[1]] if libres else None

    def _camino(self, jaw, idx, semillas, peso=14.0, barrera=None):
        """Distancia sobre la malla de cada vértice de `idx` a cada semilla, donde cruzar un surco (la unión entre
        dos dientes, el borde de la encía) cuesta mucho más que andar sobre una corona. → matriz semillas × idx."""
        from scipy.sparse import coo_matrix
        from scipy.sparse.csgraph import dijkstra

        V = (self.U if jaw == "sup" else self.L).astype(np.float64)
        F = np.asarray(self.FU if jaw == "sup" else self.FL)
        if jaw not in self._normales:
            self._normales[jaw] = normales(V, F).astype(np.float64)
        N = self._normales[jaw]
        local = np.full(len(V), -1, np.int64)
        local[idx] = np.arange(len(idx))
        Fl = local[F]
        Fl = Fl[(Fl >= 0).all(1)]
        a = np.r_[Fl[:, 0], Fl[:, 1], Fl[:, 2]]
        b = np.r_[Fl[:, 1], Fl[:, 2], Fl[:, 0]]
        pa, pb = V[idx[a]], V[idx[b]]
        d = pb - pa
        largo = np.maximum(np.linalg.norm(d, axis=1), 1e-9)
        surco = np.maximum(0.0, -((N[idx[b]] - N[idx[a]]) * d).sum(1) / largo)  # > 0 donde la superficie es cóncava
        w = largo * (1.0 + peso * surco)
        if barrera is not None:  # un surco marcado no se cruza: es el borde del diente
            pasa = surco < barrera
            a, b, w = a[pasa], b[pasa], largo[pasa]
        G = coo_matrix((np.r_[w, w], (np.r_[a, b], np.r_[b, a])), shape=(len(idx), len(idx))).tocsr()
        return dijkstra(G, directed=False, indices=local[np.asarray(semillas)])

    def agregar_diente(self, jaw, pid, numero=None, anotar=True):
        """«Añadir dientes» (como MetronTrack: doble clic en la zona): marca un diente en el vértice `pid`.
        - Sobre un «diente» que en realidad son dos: lo separa por el surco entre ambos (no con un corte recto);
          la parte donde se hizo clic es el diente nuevo.
        - Sobre una corona que quedó sin marcar: la marca hasta su borde.
        `numero`: el que eligió el doctor (si está libre); si no, el libre más cercano. → número puesto o None."""
        lab = self.etiquetas.get(jaw)
        if lab is None or not 0 <= pid < len(lab):
            return None
        V = (self.U if jaw == "sup" else self.L).astype(np.float64)
        usados = set(int(t) for t in np.unique(lab) if t)
        if numero is not None and int(numero) in usados:
            numero = None
        t = int(lab[pid])
        antes = self._foto()
        if t:  # dentro de un diente marcado: son dos
            idx = np.flatnonzero(lab == t)
            if len(idx) < 300:
                return None
            lejos = idx[int(np.argmax(np.linalg.norm(V[idx, :2] - V[pid, :2], axis=1)))]
            nuevo_m = None
            for _ in range(3):  # la otra semilla se acomoda al centro de la otra parte
                D = self._camino(jaw, idx, [pid, lejos])
                nuevo_m = D[0] <= D[1]
                otra = idx[~nuevo_m]
                if len(otra) < 60:
                    break
                c = V[otra].mean(0)
                lejos2 = otra[int(np.argmin(np.linalg.norm(V[otra] - c, axis=1)))]
                if lejos2 == lejos:
                    break
                lejos = lejos2
            if nuevo_m is None or nuevo_m.sum() < 120 or (~nuevo_m).sum() < 120:
                return None
            if numero is None:
                yc = V[lab > 0, 1].mean()
                ang = lambda q: float(np.arctan2(q[:, 0], -(q[:, 1] - yc)).mean())  # noqa: E731
                numero = self._numero_libre(jaw, t, ang(V[idx[nuevo_m]]) < ang(V[idx[~nuevo_m]]))
            if numero is None:
                return None
            lab[idx[nuevo_m]] = int(numero)
        else:  # una corona sin marcar: crece desde el clic hasta el surco de la encía o del diente vecino
            h = -V[:, 2] if jaw == "sup" else V[:, 2]  # altura hacia oclusal
            # hasta dónde baja la corona: el borde de la encía de los dientes marcados más cercanos
            marcados = np.flatnonzero(lab > 0)
            nivel = h[pid] - 7.0
            if len(marcados):
                dm = np.linalg.norm(V[marcados, :2] - V[pid, :2], axis=1)
                vecinos = [t for t in np.unique(lab[marcados[dm < 14.0]]) if t]
                if vecinos:
                    nivel = float(np.mean([np.percentile(h[lab == t], 5) for t in vecinos]))
            cerca = np.flatnonzero((lab == 0) & (np.linalg.norm(V - V[pid], axis=1) < 11.0) & (h > nivel))
            if len(cerca) < 120 or pid not in cerca:
                return None
            D = self._camino(jaw, cerca, [pid], barrera=0.25)[0]
            dentro = cerca[D < 16.0]
            if len(dentro) < 120:
                return None
            if numero is None:
                marcados = np.flatnonzero(lab > 0)
                vecino = int(lab[marcados[int(np.argmin(np.linalg.norm(V[marcados] - V[pid], axis=1)))]]) if len(marcados) else 0
                numero = self._numero_libre(jaw, vecino)
            if numero is None:
                return None
            lab[dentro] = int(numero)
        self._hist.append(antes)
        del self._hist[:-30]
        self._rehacer = []
        if anotar:
            self.renombres.append([jaw, "agregar", int(pid), int(numero)])
        self._puntos_de_etiquetas()
        return int(numero)

    def renumerar(self, jaw, antes, ahora, anotar=True):
        """El doctor corrige el número de un diente (0 = no es un diente). Si el número nuevo ya lo tenía otro
        diente de la arcada, se intercambian."""
        lab = self.etiquetas.get(jaw)
        if lab is None or antes == ahora:
            return
        if anotar:
            self._anotar_paso()
        a, b = lab == antes, lab == ahora
        lab[a] = ahora
        if ahora:
            lab[b] = antes
        if anotar:
            self.renombres.append([jaw, int(antes), int(ahora)])
        self._puntos_de_etiquetas()

    def dividir(self, jaw, fdi, x, y, anotar=True):
        """El doctor parte en dos un «diente» que en realidad son dos, con un corte que pasa por (x, y) y cruza
        la arcada. La mitad que queda hacia un número libre lo toma; la otra conserva el suyo. → el número nuevo
        (None si no se pudo)."""
        lab = self.etiquetas.get(jaw)
        orden = [int(n) for n in ORDEN_ARCADA[jaw]]
        if lab is None or fdi not in orden:
            return None
        V = self.U if jaw == "sup" else self.L
        m = np.flatnonzero(lab == fdi)
        P = self.curvas[jaw][0]
        i = int(np.clip(np.argmin(np.hypot(P[:, 0] - x, P[:, 1] - y)), 1, len(P) - 2))
        u = P[i + 1] - P[i - 1]
        u = u / max(np.linalg.norm(u), 1e-9)
        lado = (V[m, :2] - np.array([x, y])) @ u > 0
        if lado.sum() < 150 or (~lado).sum() < 150:
            return None
        yc = V[lab > 0, 1].mean()
        ang = lambda q: float(np.arctan2(q[:, 0], -(q[:, 1] - yc)).mean())  # noqa: E731  (− = derecha del paciente)
        hacia_der = lado if ang(V[m[lado]]) < ang(V[m[~lado]]) else ~lado
        if anotar:
            self._anotar_paso()
        usados = set(int(t) for t in np.unique(lab) if t)
        k = orden.index(fdi)
        libres = sorted((abs(j - k), j) for j, n in enumerate(orden) if n not in usados)
        if not libres:
            return None
        j = libres[0][1]
        nuevo = orden[j]
        lab[m[hacia_der if j < k else ~hacia_der]] = nuevo
        if anotar:
            self.renombres.append([jaw, "dividir", int(fdi), round(float(x), 2), round(float(y), 2)])
        self._puntos_de_etiquetas()
        return nuevo

    def unir(self, jaw, a, b, anotar=True):
        """El doctor une dos pedazos que son un solo diente: el pedazo `b` pasa a ser parte del diente `a`."""
        lab = self.etiquetas.get(jaw)
        if lab is None or a == b or not a or not b:
            return
        if anotar:
            self._anotar_paso()
        lab[lab == b] = a
        if anotar:
            self.renombres.append([jaw, "unir", int(a), int(b)])
        self.P["centros"][jaw].pop(str(int(b)), None)
        self._puntos_de_etiquetas()

    def aplicar_cambio(self, cambio):
        """Repite una corrección guardada de la separación de dientes (renumerar, dividir o unir)."""
        jaw = cambio[0]
        if cambio[1] == "agregar":
            self.agregar_diente(jaw, int(cambio[2]), int(cambio[3]), anotar=False)
        elif cambio[1] == "dividir":
            self.dividir(jaw, int(cambio[2]), float(cambio[3]), float(cambio[4]), anotar=False)
        elif cambio[1] == "unir":
            self.unir(jaw, int(cambio[2]), int(cambio[3]), anotar=False)
        else:
            self.renumerar(jaw, int(cambio[1]), int(cambio[2]), anotar=False)

    def restaurar_dientes(self):
        """Regresa a la separación de dientes con la que llegó el caso."""
        self._anotar_paso()
        self.etiquetas = {j: e.copy() for j, e in self._etiquetas0.items()}
        self.renombres = []
        self.reproponer()

    def dientes(self, jaw):
        """FDI por vértice de la arcada (0 = encía), o None si el caso no trae la separación de dientes."""
        return self.etiquetas.get(jaw)

    def _puntos_de_etiquetas(self):
        """Con la separación de dientes: el centro de la mesa oclusal (o del borde incisal) de cada diente, los
        contactos 34/35 y 44/45 y el centro de los incisivos salen de su propio diente."""
        from scipy.spatial import cKDTree

        P = self.P
        for jaw, lab in self.etiquetas.items():
            V = self.U if jaw == "sup" else self.L
            puntos = {}
            for t in np.unique(lab):
                if not t:
                    continue
                Vt = V[lab == t]
                if len(Vt) < 150:
                    continue
                nombre = str(int(t))
                if nombre[0] in "5678":  # temporal: ocupa el lugar de su sucesor (53 → 13)
                    nombre = str(int(nombre[0]) - 4) + nombre[1]
                z = Vt[:, 2]
                if nombre[1] == "3":      # canino: la punta de su cúspide
                    q = Vt[np.argmin(z)] if jaw == "sup" else Vt[np.argmax(z)]
                    centro = [float(q[0]), float(q[1])]
                else:                     # incisivos: su borde; premolares y molares: el centroide de la parte oclusal
                    alto = 1.8 if nombre[1] in "12" else 4.0
                    mesa = Vt[z < z.min() + alto] if jaw == "sup" else Vt[z > z.max() - alto]
                    centro = [float(mesa[:, 0].mean()), float(mesa[:, 1].mean())]
                puntos[nombre] = Vt
                P["centros"][jaw][nombre] = [round(centro[0], 2), round(centro[1], 2)]
            ce = P["centros"][jaw]
            for t in (("14", "24", "16", "26") if jaw == "sup" else ("36", "46")):
                if t in puntos:
                    P[jaw][t] = ce[t]
            if jaw == "inf":
                for a, b, k in (("34", "35", "c34/35"), ("44", "45", "c44/45")):
                    if a in puntos and b in puntos:
                        d, _ = cKDTree(puntos[b][:, :2]).query(puntos[a][:, :2])
                        cerca = puntos[a][d < max(0.8, float(d.min()) + 0.5)]
                        P["inf"][k] = [round(float(cerca[:, 0].mean()), 2), round(float(cerca[:, 1].mean()), 2)]
            for t in (("11", "21") if jaw == "sup" else ("41", "31")):
                if t in puntos:
                    P["incisivos"][t] = ce[t][0]
            P["revisar"] = [t for t in P.get("revisar", []) if t not in puntos]
            P.setdefault("presentes", {})[jaw] = sorted(puntos)

    def contactos(self):
        """Distancia de cada vértice a la otra arcada (mm) y máscara de caras oclusales."""
        if self._contactos is None:
            from scipy.spatial import cKDTree

            out = {}
            for k, A, FA, B, sg in (("sup", self.U, self.FU, self.L, -1), ("inf", self.L, self.FL, self.U, 1)):
                N = normales(A, FA)
                cerca = np.abs(A[:, 2]) < 6  # solo coronas cerca del plano oclusal (el zócalo no cuenta)
                Bc = B[np.abs(B[:, 2]) < 8]
                d = np.full(len(A), 9.0, np.float32)
                if len(Bc):
                    d[cerca] = cKDTree(Bc).query(A[cerca], distance_upper_bound=9.0)[0].clip(0, 9.0)
                out[k] = {"d": d, "occl": (N[:, 2] * sg > 0.25) & cerca, "area": area_vertice(A, FA)}
            self._contactos = out
        return self._contactos


def preparar(sup, inf, anchos=None, AD=None, progreso=None, etiquetas=None):
    """sup / inf: (vértices, caras) en coordenadas del escáner, en oclusión."""
    def avisar(t):
        if progreso:
            progreso(t)
    (Vu, Fu), (Vl, Fl) = sup, inf
    avisar("Alineando las arcadas…")
    M, costo = alinear(Vu, Vl)
    U, L = aplicar(M, Vu), aplicar(M, Vl)
    avisar("Ubicando los dientes…")
    return realinear(Caso(U, np.asarray(Fu), L, np.asarray(Fl), M, costo, anchos, AD, etiquetas))


def realinear(c: Caso) -> Caso:
    """Con los dientes identificados, endereza el marco si la alineación automática quedó girada (pasa en
    escaneos parciales o muy asimétricos): el plano oclusal por las puntas de los dientes y la línea media por
    los pares de dientes homólogos (13-23, 14-24…). Si ya estaba derecho, devuelve el mismo caso."""
    tips = {}
    for jaw, lab in c.etiquetas.items():
        V = c.U if jaw == "sup" else c.L
        for t in np.unique(lab):
            Vt = V[lab == t]
            if not t or len(Vt) < 150:
                continue
            z = Vt[:, 2]
            mesa = Vt[z < z.min() + 2.0] if jaw == "sup" else Vt[z > z.max() - 2.0]
            n = int(t)
            if n > 50:  # temporal: el lugar de su sucesor
                n -= 40
            tips[n] = mesa.mean(0).astype(np.float64)
    R = np.eye(3)
    # 1) plano oclusal: por las puntas de los dientes de una arcada (la que tenga más y mejor repartidos)
    for cuad in ((1, 2), (4, 3)):
        P = np.array([p for t, p in tips.items() if t // 10 in cuad])
        if len(P) < 5:
            continue
        P0 = P - P.mean(0)
        _, sv, vt = np.linalg.svd(P0, full_matrices=False)
        if sv[1] < 12.0:  # casi en línea: no definen un plano
            continue
        n = vt[2] if vt[2][2] > 0 else -vt[2]
        ang = np.degrees(np.arccos(np.clip(n[2], -1, 1)))
        if 3.0 < ang < 30.0:
            v = np.cross(n, [0, 0, 1.0])
            vx = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
            R = np.eye(3) + vx + vx @ vx / (1 + n[2])
        break
    # 2) giro en el plano y línea media: los pares de dientes homólogos
    pares = [(tips[a], tips[b]) for der, izq in ((1, 2), (4, 3)) for k in range(1, 8)
             for a, b in [(der * 10 + k, izq * 10 + k)] if a in tips and b in tips]
    giro, x0 = 0.0, 0.0
    if len(pares) >= 2:
        d = np.array([(R @ b - R @ a)[:2] for a, b in pares])
        d = d[np.linalg.norm(d, axis=1) > 4.0]
        if len(d) >= 2:
            u = (d / np.linalg.norm(d, axis=1, keepdims=True)).mean(0)
            g = float(np.degrees(np.arctan2(u[1], u[0])))
            if abs(g) < 45.0:
                giro = g
    t = np.radians(-giro)
    Rz = np.array([[np.cos(t), -np.sin(t), 0], [np.sin(t), np.cos(t), 0], [0, 0, 1.0]])
    R = Rz @ R
    if len(pares) >= 2:
        x0 = float(np.mean([0.5 * (R @ a + R @ b)[0] for a, b in pares]))
    total = np.degrees(np.arccos(np.clip((np.trace(R) - 1) / 2, -1, 1)))
    # solo si quedó claramente girado: en un caso bien alineado no se toca nada (sus medidas ya están validadas)
    if total < 10.5:
        return c
    centro = np.mean(list(tips.values()), axis=0)
    T = np.eye(4)
    T[:3, :3] = R
    T[:3, 3] = centro - R @ centro  # gira alrededor del centro de los dientes (el plano oclusal sigue en z ≈ 0)
    T[0, 3] -= x0
    nuevo = Caso(aplicar(T, c.U), c.FU, aplicar(T, c.L), c.FL, T @ c.M, c.costo,
                 None if c.anchos_fuente == "medido" else c.anchos, c.AD, c.etiquetas)
    nuevo.criterio, nuevo.renombres = c.criterio, c.renombres
    nuevo.realineado = True
    return nuevo


# ----------------------------------------------------------------------------- medidas
def _presente(c: Caso, jaw, diente) -> bool:
    """¿Está ese diente? (sin la separación de dientes no se puede saber: se da por presente)."""
    pres = (c.P.get("presentes") or {}).get(jaw)
    return True if pres is None else diente in pres


def _anteriores(c: Caso, jaw):
    """Vértices de los dientes anteriores de la arcada (con la separación de dientes); si no, toda la arcada."""
    V = c.U if jaw == "sup" else c.L
    lab = c.etiquetas.get(jaw)
    if lab is None:
        return V
    cuad = (1, 2, 5, 6) if jaw == "sup" else (3, 4, 7, 8)
    m = np.isin(lab, [q * 10 + k for q in cuad for k in (1, 2, 3)])
    return V[m] if m.sum() > 200 else V


def overjet(c: Caso):
    Uv, Lv = _anteriores(c, "sup"), _anteriores(c, "inf")
    yfu = Uv[Uv[:, 2] < 3][:, 1].min() if (Uv[:, 2] < 3).any() else Uv[:, 1].min()
    yfl = Lv[Lv[:, 2] > -3][:, 1].min() if (Lv[:, 2] > -3).any() else Lv[:, 1].min()
    res = {}
    for t, tl in (("11", "41"), ("21", "31")):
        if not (_presente(c, "sup", t) and _presente(c, "inf", tl)) or t not in c.P["incisivos"]:
            continue  # falta uno de los dos dientes: no se mide
        xc = c.P["incisivos"][t]
        su = Uv[(np.abs(Uv[:, 0] - xc) < 0.4) & (Uv[:, 1] < yfu + 12)]
        # el inferior se corta por el centro de su propio incisivo (probado contra el escáner en 46 casos: cortar las
        # dos arcadas por el mismo plano concordaba peor)
        xl = c.P["incisivos"].get(tl, xc)
        sl = Lv[(np.abs(Lv[:, 0] - xl) < 0.4) & (Lv[:, 1] < yfl + 12)]
        if len(su) < 5 or len(sl) < 5:
            continue
        zu = float(su[:, 2].min())
        yu = float(su[su[:, 2] < zu + 0.35][:, 1].min())
        zl = float(sl[:, 2].max())
        band = sl[(sl[:, 2] < zl - 0.6) & (sl[:, 2] > zl - 1.6)]
        yl = float(band[:, 1].min() if len(band) else sl[:, 1].min())
        res[t] = dict(par=f"{t}/{tl}", x=float(xc), xl=float(xl), z_up=zu, y_up=yu, z_lo=zl, y_lo=yl,
                      overjet=yl - yu, overbite=zl - zu)
    return res


def corte(c: Caso, jaw, x, ancho_=0.4, y_max=14):
    """Puntos (y, z) del corte sagital por x (para dibujar el perfil del incisivo)."""
    V = c.U if jaw == "sup" else c.L
    yf = V[(V[:, 2] < 3) if jaw == "sup" else (V[:, 2] > -3)][:, 1].min()
    s = V[(np.abs(V[:, 0] - x) < ancho_) & (V[:, 1] < yf + y_max) & (np.abs(V[:, 2]) < 14)]
    return s[:, 1:3]


def contactos(c: Caso):
    C = c.contactos()
    up = c.P["sup"]
    a, b = np.array(up["14"]), np.array(up["24"])
    dv = b - a
    n = np.array([-dv[1], dv[0]]) / np.linalg.norm(dv)
    if n[1] > 0:
        n = -n
    pm = (a + b) / 2
    mm = (np.array(up["16"]) + np.array(up["26"])) / 2
    xmid = (c.P["incisivos"]["11"] + c.P["incisivos"]["21"]) / 2
    res = {}
    for k, V in (("sup", c.U), ("inf", c.L)):
        d, ok, ar = C[k]["d"], C[k]["occl"] & (C[k]["d"] < 2), C[k]["area"]
        sp = (V[:, :2] - pm) @ n
        sm = (V[:, :2] - mm) @ n
        zona = np.where(sp > 4.0, 0, np.where(sm > 5.5, 1, 2))
        lado = np.where(V[:, 0] < xmid, 0, 1)
        r = {}
        for zi, zn in enumerate(("ant", "prem", "mol")):
            for si, sn in enumerate(("der", "izq")):
                mk = ok & (zona == zi) & (lado == si)
                r[f"{zn}_{sn}"] = dict(c01=float(ar[mk & (d < 0.1)].sum()), c03=float(ar[mk & (d < 0.3)].sum()),
                                       c06=float(ar[mk & (d < 0.6)].sum()))
        res[k] = r
    return res


def colores_contacto(d, occl, base=(226, 222, 208)):
    rgb = np.tile(np.array(base, np.uint8), (len(d), 1))
    prev = -1.0
    for lim, col in zip(CONTACTO_BINS, CONTACTO_COLORES):
        m = occl & (d < lim) & (d >= prev)
        rgb[m] = [int(col[i:i + 2], 16) for i in (1, 3, 5)]
        prev = lim
    return rgb


def korkhaus(c: Caso, oj):
    if "11" not in oj or "21" not in oj:
        return None
    Uv, Lv = c.U, c.L
    ws = [ancho(c.anchos, t) if _presente(c, "sup", t) else 0.0 for t in ("12", "11", "21", "22")]
    SI = sum(ws) if all(ws) else 0.0  # sin los cuatro incisivos no hay «ideal»

    def normal(a, b):
        d = np.array(b) - np.array(a)
        n = np.array([-d[1], d[0]]) / np.linalg.norm(d)
        return n if n[1] < 0 else -n

    def largo_ant(V, a, b, xr, zr):
        n = normal(a, b)
        m = (V[:, 0] > xr[0]) & (V[:, 0] < xr[1]) & (V[:, 2] > zr[0]) & (V[:, 2] < zr[1]) & (V[:, 1] < (a[1] + b[1]) / 2)
        Pp = V[m, :2].astype(np.float64)
        if not len(Pp):
            return None, n, None
        s = (Pp - np.array(a)) @ n
        i = int(s.argmax())
        return float(s[i]), n, Pp[i]

    up, lo = c.P["sup"], c.P["inf"]
    a, b = np.array(up["14"]), np.array(up["24"])
    xr_u = (min(oj["11"]["x"], oj["21"]["x"]) - 4.8, max(oj["11"]["x"], oj["21"]["x"]) + 4.8)
    z_e = min(oj["11"]["z_up"], oj["21"]["z_up"])
    Lo, nu, Pu = largo_ant(Uv, a, b, xr_u, (z_e - 0.3, z_e + 7))
    c1, c2 = np.array(lo["c34/35"]), np.array(lo["c44/45"])
    zt = max(oj["11"]["z_lo"], oj["21"]["z_lo"])
    xr_l = (min(oj["11"]["xl"], oj["21"]["xl"]) - 4.0, max(oj["11"]["xl"], oj["21"]["xl"]) + 4.0)
    Lu, nl, Pl = largo_ant(Lv, c2, c1, xr_l, (zt - 6, zt + 0.2))
    K = dict(SI=SI, prem_u=float(np.linalg.norm(b - a)), mol_u=float(np.linalg.norm(np.array(up["26"]) - np.array(up["16"]))),
             prem_l=float(np.linalg.norm(c1 - c2)), mol_l=float(np.linalg.norm(np.array(lo["36"]) - np.array(lo["46"]))),
             Lo=Lo, Lu=Lu, nu=nu.tolist(), nl=nl.tolist(),
             Pu=None if Pu is None else Pu.tolist(), Pl=None if Pl is None else Pl.tolist())
    if SI > 0:
        K.update(prem_id=SI * 100 / 85, mol_id=SI * 100 / 65, Lo_id=SI * 100 / 160, Lu_id=SI * 100 / 160 - 2)
    return K


def anchuras(c: Caso):
    ce = c.P["centros"]
    out = {}
    for jaw, pares in (("sup", (("canina", "13", "23"), ("premolar", "14", "24"), ("molar", "16", "26"))),
                       ("inf", (("canina", "43", "33"), ("premolar", "44", "34"), ("molar", "46", "36")))):
        out[jaw] = {}
        for nombre, a, b in pares:
            if a in ce[jaw] and b in ce[jaw]:
                out[jaw][nombre] = float(np.hypot(*(np.array(ce[jaw][a]) - np.array(ce[jaw][b]))))
    return out


NIVELES_ARCADA = {"sup": (("anterior", "13", "23"), ("media", "14", "24"), ("posterior", "16", "26")),
                  "inf": (("anterior", "43", "33"), ("media", "44", "34"), ("posterior", "46", "36"))}


def simetria(c: Caso) -> dict:
    """{arcada: {nivel: {der, izq, dif, p_der, p_izq}}}: distancia (mm) de caninos, primeros premolares y primeros
    molares de cada lado al eje medio de la arcada (x = 0)."""
    out = {}
    for jaw, niveles in NIVELES_ARCADA.items():
        ce = c.P["centros"][jaw]
        out[jaw] = {}
        for nivel, d, i in niveles:
            if d in ce and i in ce:
                der, izq = -float(ce[d][0]), float(ce[i][0])
                out[jaw][nivel] = dict(der=der, izq=izq, dif=abs(der - izq), p_der=list(ce[d]), p_izq=list(ce[i]))
    return out


def longitud(c: Caso) -> dict:
    """{arcada: {frente: y, nivel: mm…}}: profundidad de la arcada sobre el eje medio, desde el borde de los
    incisivos centrales hasta la línea de caninos, de primeros premolares y de primeros molares."""
    out = {}
    for jaw, niveles in NIVELES_ARCADA.items():
        ce = c.P["centros"][jaw]
        cent = [ce[t][1] for t in (("11", "21") if jaw == "sup" else ("41", "31")) if t in ce]
        if not cent:
            continue
        frente = float(min(cent))
        out[jaw] = {"frente": frente}
        for nivel, d, i in niveles:
            if d in ce and i in ce:
                out[jaw][nivel] = float((ce[d][1] + ce[i][1]) / 2 - frente)
    return out


def bolton(anchos):
    sup6 = [ancho(anchos, t) for t in ("13", "12", "11", "21", "22", "23")]
    inf6 = [ancho(anchos, t) for t in ("43", "42", "41", "31", "32", "33")]
    sup12 = sup6 + [ancho(anchos, t) for t in ("14", "15", "16", "24", "25", "26")]
    inf12 = inf6 + [ancho(anchos, t) for t in ("44", "45", "46", "34", "35", "36")]
    out = {}
    if all(sup6) and all(inf6):
        r = sum(inf6) / sum(sup6) * 100
        out["anterior"] = dict(sup=sum(sup6), inf=sum(inf6), relacion=r, norma=78.8, de=1.72,
                               exceso_inf=sum(inf6) - sum(sup6) * 78.8 / 100, exceso_sup=sum(sup6) - sum(inf6) * 100 / 78.8)
    if all(sup12) and all(inf12):
        r = sum(inf12) / sum(sup12) * 100
        out["global"] = dict(sup=sum(sup12), inf=sum(inf12), relacion=r, norma=91.5, de=1.51,
                             exceso_inf=sum(inf12) - sum(sup12) * 91.5 / 100, exceso_sup=sum(sup12) - sum(inf12) * 100 / 91.5)
    return out


def espacio(c: Caso):
    """Espacio disponible (por la curva de arcada, de mesial del 6 a mesial del 6) frente a lo que necesitan los
    dientes de 5 a 5. Negativo = apiñamiento."""
    out = {}
    for jaw in ("sup", "inf"):
        P, s = c.curvas[jaw]
        ce = c.P["centros"][jaw]
        d = ("16", "26") if jaw == "sup" else ("46", "36")
        if not all(t in ce for t in d):
            continue
        disp = 0.0
        for t in d:
            disp += abs(s_de(P, s, ce[t])) - ancho(c.anchos, t) / 2 if ancho(c.anchos, t) else abs(s_de(P, s, ce[t])) - 5
        ws = [ancho(c.anchos, t) for lado in ("der", "izq") for t in LADO[(jaw, lado)][:5]]
        if not all(ws):  # con anchos incompletos el cálculo engaña: mejor no darlo
            continue
        nec = sum(ws)
        out[jaw] = dict(disponible=disp, necesario=nec, discrepancia=disp - nec)
    return out


SEGMENTOS = {"3-3": 3, "5-5": 5, "6-6": 6, "7-7": 7}


def apinamiento(c: Caso, md: dict, dudosos=()) -> dict:
    """{arcada: {segmento: {dientes, arcada, apinamiento, fuente}}} para 3-3, 5-5, 6-6 y 7-7, como MetronTrack:
    tamaño de los dientes frente al tamaño de la arcada (positivo = apiñamiento, negativo = espacio). Lo del
    escáner si viene en el paquete; si no, medido aquí sobre la curva de la arcada entre los puntos distales."""
    out = {"sup": {}, "inf": {}}
    ad = (c.AD or {}).get("apinamiento") or {}
    for jaw in ("sup", "inf"):
        P, s = c.curvas[jaw]
        for seg, n in SEGMENTOS.items():
            x = (ad.get(jaw) or {}).get(seg)
            if x and x.get("dientes") and x.get("arcada"):
                out[jaw][seg] = dict(dientes=x["dientes"], arcada=x["arcada"],
                                     apinamiento=x["dientes"] - x["arcada"], fuente="escáner")
                continue
            dientes = [t for lado in ("der", "izq") for t in LADO[(jaw, lado)][:n]]
            ws = [ancho(c.anchos, t) for t in dientes]
            if not all(ws) or not all(t in md for t in dientes) or any(t in dudosos for t in dientes):
                continue  # con un diente mal separado la suma sería falsa
            # tamaño de la arcada: sobre la curva de la arcada, de distal a distal del último diente del segmento
            fin = [LADO[(jaw, lado)][n - 1] for lado in ("der", "izq")]
            pos = [s_de(P, s, md[t]["d"][:2]) for t in fin]
            if min(pos) <= s[0] + 0.3 or max(pos) >= s[-1] - 0.3:
                continue  # la curva no llega hasta ahí (segundos molares): mejor no darlo que darlo corto
            # el largo se mide sobre la curva SUAVE (la que se dibuja): la curva cruda serpentea de diente en
            # diente y daba una arcada unos 2 mm más larga que la de MetronTrack
            from scipy.ndimage import gaussian_filter1d

            tramo = (s >= min(pos)) & (s <= max(pos))
            if tramo.sum() >= 4:
                Ps = np.c_[gaussian_filter1d(P[:, 0], 5, mode="nearest"), gaussian_filter1d(P[:, 1], 5, mode="nearest")][tramo]
                arc = float(np.hypot(*np.diff(Ps, axis=0).T).sum())
            else:
                arc = float(abs(pos[0]) + abs(pos[1]))
            out[jaw][seg] = dict(dientes=sum(ws), arcada=arc, apinamiento=sum(ws) - arc, fuente="medido aquí")
    return out


def moyers(c: Caso):
    """Análisis de dentición mixta: lo que necesitarán 3+4+5 (Moyers 75 % y Tanaka-Johnston) frente al espacio
    de distal del lateral a mesial del primer molar permanente, por cuadrante."""
    si = [ancho(c.anchos, t) for t in ("31", "32", "41", "42")]
    if not all(si):
        return None
    SI = sum(si)
    out = {"SI": SI, "sup_previsto": float(np.interp(SI, MOYERS_SI, MOYERS_SUP)),
           "inf_previsto": float(np.interp(SI, MOYERS_SI, MOYERS_INF)),
           "sup_tanaka": SI / 2 + 11.0, "inf_tanaka": SI / 2 + 10.5, "fuera_de_tabla": not (19.5 <= SI <= 29.0),
           "cuadrantes": {}}
    for jaw in ("sup", "inf"):
        P, s = c.curvas[jaw]
        ce = c.P["centros"][jaw]
        for lado in ("der", "izq"):
            dientes = LADO[(jaw, lado)]
            lat, mol = dientes[1], dientes[5]
            if lat not in ce or mol not in ce:
                continue
            w_lat = ancho(c.anchos, lat) or PROMEDIO["2"][0 if jaw == "sup" else 1]
            w_mol = ancho(c.anchos, mol) or PROMEDIO["6"][0 if jaw == "sup" else 1]
            d2 = abs(s_de(P, s, ce[lat])) + w_lat / 2
            m6 = abs(s_de(P, s, ce[mol])) - w_mol / 2
            prev = out[f"{jaw}_previsto"]
            cuad = {("sup", "der"): "1", ("sup", "izq"): "2", ("inf", "izq"): "3", ("inf", "der"): "4"}[(jaw, lado)]
            out["cuadrantes"][cuad] = dict(jaw=jaw, lado=lado, disponible=m6 - d2, previsto=prev,
                                           discrepancia=m6 - d2 - prev)
    return out


def spee(c: Caso):
    """Profundidad de la curva de Spee (mm) por lado: lo más que queda una cúspide inferior por debajo de la recta
    que va del borde del incisivo central a la cúspide distal del último molar. Se mide con la cúspide de cada
    diente (necesita la separación de dientes); los dientes ausentes se saltan. Sin ella: no valorable."""
    out = {}
    cor = coronas(c, "inf")
    if not cor:
        return out
    for lado in ("der", "izq"):
        ts = [t for t in LADO[("inf", lado)] if t in cor]
        if len(ts) < 5 or ts[0][1] != "1" or ts[-1][1] not in "67":
            continue
        pts = []
        for t in ts:
            Vt = cor[t]
            if t[1] in "67":  # molares: sus cúspides vestibulares
                cx = Vt[:, 0].mean()
                Vb = Vt[(Vt[:, 0] - cx) * (-1 if lado == "der" else 1) > 0.5]
                Vt = Vb if len(Vb) > 30 else Vt
            if t == ts[-1]:   # último molar: su cúspide distal
                Vd = Vt[Vt[:, 1] > Vt[:, 1].mean()]
                Vt = Vd if len(Vd) > 30 else Vt
            pts.append(Vt[np.argmax(Vt[:, 2])])
        pts = np.array(pts, float)
        a, b = pts[0], pts[-1]
        h = (b - a)[:2]
        largo = float(np.linalg.norm(h))
        if largo < 5:
            continue
        pos = (pts[:, :2] - a[:2]) @ (h / largo)
        recta = a[2] + pos / largo * (b[2] - a[2])
        prof = (recta - pts[:, 2])[1:-1]
        out[lado] = float(max(prof.max() * np.cos(np.arctan2(b[2] - a[2], largo)), 0.0))
        # las cúspides que se usaron (incisivo → último molar), para dibujar la curva en el informe
        out.setdefault("puntos", {})[lado] = pts.tolist()
    if out:
        out["promedio"] = float(np.mean([out[k] for k in ("der", "izq") if k in out]))
    return out


ORDEN_ARCADA = {"sup": LADO[("sup", "der")][::-1] + LADO[("sup", "izq")],
                "inf": LADO[("inf", "der")][::-1] + LADO[("inf", "izq")]}


def coronas(c: Caso, jaw):
    """{diente: vértices de su corona} con la separación de dientes (los temporales, en el lugar de su sucesor)."""
    lab = c.etiquetas.get(jaw)
    out = {}
    if lab is None:
        return out
    V = c.U if jaw == "sup" else c.L
    for t in np.unique(lab):
        if t:
            n = str(int(t))
            if n[0] in "5678":
                n = str(int(n[0]) - 4) + n[1]
            Vt = V[lab == t]
            if len(Vt) >= 150:
                out[n] = Vt
    return out


def mesiodistal(c: Caso) -> dict:
    """{diente: {"m": punto mesial, "d": punto distal, "ancho": mm}}: la línea mesiodistal de cada diente, entre sus
    puntos de contacto con los vecinos (sigue la angulación del diente, como en MetronTrack). Sin vecino (último
    molar, diente ausente al lado), el punto es el extremo de la corona en esa dirección."""
    from scipy.spatial import cKDTree

    out = {}
    for jaw in ("sup", "inf"):
        cor = coronas(c, jaw)
        if not cor:
            continue
        # zona de contacto: la mitad oclusal de la corona (la encía interdental no cuenta)
        alto = {}
        for t, Vt in cor.items():
            z = Vt[:, 2]
            alto[t] = Vt[z < z.min() + 5.5] if jaw == "sup" else Vt[z > z.max() - 5.5]
        arboles = {t: cKDTree(v) for t, v in alto.items()}
        orden = [t for t in ORDEN_ARCADA[jaw] if t in cor]
        hacia = {t: {} for t in orden}  # punto de la corona hacia cada vecino
        for a, b in zip(orden[:-1], orden[1:]):
            ia, ib = ORDEN_ARCADA[jaw].index(a), ORDEN_ARCADA[jaw].index(b)
            if ib - ia != 1:
                continue  # falta un diente entre los dos
            da, _ = arboles[b].query(alto[a])
            db, _ = arboles[a].query(alto[b])
            if da.min() > 3.0:
                continue  # diastema grande: cada uno toma su propio extremo
            # el punto de contacto es el CENTRO de toda la cara de contacto (de vestibular a lingual), no la
            # esquina donde las dos coronas quedan más cerca: con la esquina, el eje salía girado en dientes derechos
            cerca = max(float(da.min()) + 0.6, 1.2)
            hacia[a][b] = alto[a][da < cerca].mean(0)
            hacia[b][a] = alto[b][db < cerca].mean(0)
        for k, t in enumerate(orden):
            cen = alto[t].mean(0)
            i = ORDEN_ARCADA[jaw].index(t)
            centro_arcada = len(ORDEN_ARCADA[jaw]) / 2 - 0.5
            paso_mesial = 1 if i < centro_arcada else -1  # hacia la línea media
            vec_m = ORDEN_ARCADA[jaw][i + paso_mesial] if 0 <= i + paso_mesial < len(ORDEN_ARCADA[jaw]) else None
            vec_d = ORDEN_ARCADA[jaw][i - paso_mesial] if 0 <= i - paso_mesial < len(ORDEN_ARCADA[jaw]) else None
            pm, pd = hacia[t].get(vec_m), hacia[t].get(vec_d)

            def extremo(desde):
                u = cen - desde
                u[2] = 0
                u /= max(np.linalg.norm(u), 1e-9)
                s_ = (alto[t] - cen) @ u
                return alto[t][s_ > s_.max() - 0.5].mean(0)

            if pm is None and pd is None:
                P, s_ = c.curvas[jaw]
                sc = s_de(P, s_, cen[:2])
                tg = np.r_[en_s(P, s_, sc + 1.0) - en_s(P, s_, sc - 1.0), 0.0]
                tg /= max(np.linalg.norm(tg), 1e-9)
                q = (alto[t] - cen) @ tg
                e1, e2 = alto[t][q > q.max() - 0.5].mean(0), alto[t][q < q.min() + 0.5].mean(0)
                lado = 1 if i >= centro_arcada else -1  # +x = izquierda del paciente
                pm, pd = (e2, e1) if (e1[0] - e2[0]) * lado > 0 else (e1, e2)
            elif pm is None:
                pm = extremo(pd)
            elif pd is None:
                pd = extremo(pm)
            # los puntos de contacto quedan hundidos dentro de la corona: se llevan a los extremos de la corona
            # (su mitad oclusal) sobre el eje mesiodistal del diente
            eje = np.array([pm[0] - pd[0], pm[1] - pd[1]], float)
            ne = float(np.linalg.norm(eje))
            if ne > 1.0:
                eje /= ne
                # la línea es la que une los dos contactos, alargada hasta los extremos de la corona: los dos puntos
                # quedan SOBRE esa misma recta (antes cada extremo se iba de lado y la línea se veía girada)
                medio = 0.5 * (np.asarray(pm[:2], float) + np.asarray(pd[:2], float))
                q = (alto[t][:, :2] - medio) @ eje
                hi, lo = np.percentile(q, 99.5), np.percentile(q, 0.5)
                zm = float(alto[t][q >= hi - 0.25][:, 2].mean())
                zd = float(alto[t][q <= lo + 0.25][:, 2].mean())
                pm = np.r_[medio + eje * hi, zm]
                pd = np.r_[medio + eje * lo, zd]
            mov = (c.P.get("md") or {}).get(t) or {}
            pm = np.array(mov.get("m", pm), float)
            pd = np.array(mov.get("d", pd), float)
            out[t] = {"m": [float(x) for x in pm], "d": [float(x) for x in pd], "movido": bool(mov),
                      "ancho": float(np.linalg.norm(pm[:2] - pd[:2]))}
    return out


TOL_CLASE = 1.5  # mm de la cúspide superior respecto a su referencia inferior que todavía son Clase I (2026-11-19)


def _clase(d, tol):
    """d: mm que el punto superior queda por delante (mesial) del inferior de referencia."""
    if abs(d) <= tol:
        return 0, "Clase I"
    return (1 if abs(d) <= tol + 2 else 2), ("Clase II" if d > 0 else "Clase III")


def clases(c: Caso, md: dict) -> dict:
    """Relación molar (cúspide mesiovestibular del primer molar superior frente al surco vestibular del inferior) y
    canina (cúspide del canino superior frente a la tronera canino–premolar inferior), por lado. Necesita la
    separación de dientes. d > 0: el superior queda por delante (mesial) → Clase II."""
    from scipy.ndimage import gaussian_filter1d
    from scipy.signal import find_peaks

    out = {"molar": {}, "canina": {}}
    aj = c.P.get("ajustes") or {}
    sup, inf = coronas(c, "sup"), coronas(c, "inf")
    for lado, (u6, l6, u3, l3, l4) in (("der", ("16", "46", "13", "43", "44")), ("izq", ("26", "36", "23", "33", "34"))):
        sx = -1.0 if lado == "der" else 1.0  # vestibular = lejos de la línea media
        if u6 in sup and l6 in inf and u6 in md and l6 in md:
            eu = np.array(md[u6]["m"]) - np.array(md[u6]["d"])
            eu[2] = 0
            eu /= max(np.linalg.norm(eu), 1e-9)
            bu = np.array([-eu[1], eu[0], 0.0])
            if bu[0] * sx < 0:
                bu = -bu
            V = sup[u6]
            cen = V.mean(0)
            q = V - cen
            mv = V[(q @ eu > 0.8) & (q @ bu > 0.8)]
            el = np.array(md[l6]["m"]) - np.array(md[l6]["d"])
            largo = float(np.linalg.norm(el[:2]))
            el[2] = 0
            el /= max(np.linalg.norm(el), 1e-9)
            bl = np.array([-el[1], el[0], 0.0])
            if bl[0] * sx < 0:
                bl = -bl
            W = inf[l6]
            cl = W.mean(0)
            ql = W - cl
            vest = W[ql @ bl > 1.0]
            if len(mv) > 20 and len(vest) > 50:
                cusp = mv[np.argmin(mv[:, 2])]
                # perfil de las cúspides vestibulares del inferior a lo largo de su eje (de distal a mesial)
                dist_p = np.array(md[l6]["d"])
                pos = (vest - dist_p) @ el
                bins = np.arange(0, largo + 0.3, 0.3)
                perfil = np.array([vest[(pos >= b) & (pos < b + 0.3)][:, 2].max() if ((pos >= b) & (pos < b + 0.3)).any()
                                   else np.nan for b in bins])
                ok = np.isfinite(perfil)
                surco = None
                cusp_inf = []  # las dos cúspides vestibulares del molar inferior (mesial y distal al surco)
                if ok.sum() > 8:
                    perfil = gaussian_filter1d(np.interp(np.arange(len(bins)), np.nonzero(ok)[0], perfil[ok]), 1.5)
                    picos, _ = find_peaks(perfil, prominence=0.15, distance=5)
                    cand = []
                    for a, b in zip(picos[:-1], picos[1:]):
                        v = float(bins[a + int(np.argmin(perfil[a:b + 1]))] + 0.15)
                        if 0.40 <= v / max(largo, 1e-9) <= 0.70:  # el surco mesiovestibular queda a ~43 % de mesial
                            cand.append((abs(v / largo - 0.57), v, a, b))
                    if cand:
                        _, surco, a, b = min(cand)
                        for pico in (b, a):  # mesiovestibular, distovestibular
                            fr = vest[np.abs((vest - dist_p) @ el - (bins[pico] + 0.15)) < 0.5]
                            if len(fr):
                                cusp_inf.append([float(v) for v in fr[np.argmax(fr[:, 2])]])
                if surco is None:
                    surco = 0.57 * largo  # el surco vestibular queda a ~43 % de mesial
                p_surco = dist_p + el * surco
                # el surco, sobre la cara vestibular (lo más alto de esa franja de la corona)
                franja = vest[np.abs((vest - dist_p) @ el - surco) < 0.5]
                p_surco = franja[np.argmax(franja[:, 2])].astype(float) if len(franja) else p_surco
                cusp = np.array(aj.get(f"molar_{lado}_sup", cusp), float)      # movidos por el doctor
                p_surco = np.array(aj.get(f"molar_{lado}_inf", p_surco), float)
                # como se ve de lado (vista lateral): cuánto queda la cúspide por delante (−y) del surco. Medirlo
                # sobre el eje inclinado del molar metía la diferencia vestíbulo-lingual entre los dos puntos
                d = float(p_surco[1] - cusp[1])
                # Clase I hasta ±1.5 mm (antes 2.5: Renata, 1.6 mm a la derecha, salía Clase I y la Dra. la
                # diagnosticó Clase II; su lado izquierdo, 1.0 mm, sigue Clase I)
                n, nombre = _clase(d, TOL_CLASE)
                out["molar"][lado] = dict(d=d, nivel=n, clase=nombre, cuspide=[float(x) for x in cusp],
                                          surco=[float(x) for x in p_surco], cuspides_inf=cusp_inf,
                                          eje=[float(x) for x in el])
        if u3 in sup and l3 in md and l4 in md:
            V = sup[u3]
            cusp = V[np.argmin(V[:, 2])]
            tron = (np.array(md[l3]["d"]) + np.array(md[l4]["m"])) / 2
            el = np.array(md[l3]["m"]) - np.array(md[l3]["d"])
            el[2] = 0
            el /= max(np.linalg.norm(el), 1e-9)
            cusp = np.array(aj.get(f"canina_{lado}_sup", cusp), float)
            tron = np.array(aj.get(f"canina_{lado}_inf", tron), float)
            cusp_inf = [[float(v) for v in inf[t][np.argmax(inf[t][:, 2])]] for t in (l3, l4) if t in inf]
            # a lo largo de la arcada (del premolar al canino inferiores): ahí la arcada va inclinada, y medir en
            # línea recta hacia adelante convertía el resalte normal del canino en «mesial»
            tg = (np.array(cusp_inf[0][:2]) - np.array(cusp_inf[1][:2])) if len(cusp_inf) == 2 else el[:2]
            tg = tg / max(np.linalg.norm(tg), 1e-9)
            d = float((cusp[:2] - tron[:2]) @ tg)
            n, nombre = _clase(d, TOL_CLASE)  # antes 3.0 (Renata: 2.0 mm a la derecha = Clase II para la Dra.)
            out["canina"][lado] = dict(d=d, nivel=n, clase=nombre, cuspide=[float(x) for x in cusp],
                                       tronera=[float(x) for x in tron], cuspides_inf=cusp_inf,
                                       eje=[float(x) for x in el])
    return out


def linea_media(c: Caso, md=None):
    """Desviación de la línea media inferior respecto a la superior (mm) y de cada una respecto al eje de simetría de
    la arcada superior (x = 0). Con la separación de dientes, cada línea media es el contacto entre sus centrales."""
    md = md or {}
    i = c.P["incisivos"]

    def contacto(a, b):
        if a in md and b in md:
            return (md[a]["m"][0] + md[b]["m"][0]) / 2, [(md[a]["m"][k] + md[b]["m"][k]) / 2 for k in range(3)]
        return (i[a] + i[b]) / 2, None

    faltan = [t for jaw, ts in (("sup", ("11", "21")), ("inf", ("41", "31"))) for t in ts if not _presente(c, jaw, t)]
    if faltan:
        return dict(mm=0.0, direccion="no valorable", sup=0.0, inf=0.0, p_sup=None, p_inf=None, valorable=False,
                    faltan=faltan)
    sup, p_sup = contacto("11", "21")
    inf, p_inf = contacto("41", "31")
    aj = c.P.get("ajustes") or {}
    sup, inf = float(aj.get("lm_sup", sup)), float(aj.get("lm_inf", inf))  # movidas por el doctor
    d = inf - sup
    return dict(mm=abs(d), direccion=("izquierda" if d > 0 else "derecha") if abs(d) >= 0.05 else "centrada",
                sup=float(sup), inf=float(inf), p_sup=p_sup, p_inf=p_inf)


def denticion(c) -> dict:
    """¿Dentición mixta o permanente? Mixta = hay dientes de leche marcados (51–85). Que falte un canino o un
    premolar NO basta (puede ser una extracción): eso solo la deja «dudosa», para que el doctor la confirme.
    Lo que el doctor (o la Dra. al enviar el caso) fija a mano manda: criterio["denticion"] = «Mixta» / «Permanente»."""
    temporales, faltan = False, False
    for jaw, lab in (getattr(c, "etiquetas", None) or {}).items():
        if (np.asarray(lab) > 50).any():
            temporales = True
        pres = set((c.P.get("presentes") or {}).get(jaw, []))
        cuad = ("1", "2") if jaw == "sup" else ("3", "4")
        if any(q + k not in pres for q in cuad for k in "345"):
            faltan = True
    fijo = (getattr(c, "criterio", None) or {}).get("denticion")
    fijo = fijo if fijo in ("Mixta", "Permanente") else None
    mixta = (fijo == "Mixta") if fijo else temporales
    return dict(mixta=mixta, temporales=temporales, dudosa=not fijo and not temporales and faltan, fija=bool(fijo))


def medir(c: Caso) -> dict:
    oj = overjet(c)
    md = mesiodistal(c)
    if md and (not c.anchos or c.anchos_fuente == "medido"):  # sin anchos del escáner: los medidos aquí, sobre la línea mesiodistal de cada diente
        c.anchos = {t: round(v["ancho"], 1) for t, v in md.items()}
        c.anchos_fuente = "medido"
    # una «corona» mucho más ancha de lo esperable es una etiqueta que cubre dos dientes: lo que dependa de ella
    # no es valorable hasta que el doctor corrija la separación
    dudosos = []
    for t, v in md.items():
        jaw = "sup" if t[0] in "12" else "inf"
        esperado = PROMEDIO[t[1]][0 if jaw == "sup" else 1] if t[1] in PROMEDIO else 10.0
        if v["ancho"] > max(1.35 * esperado, esperado + 3.0) and not v.get("movido"):
            dudosos.append(t)
    for t in dudosos:
        if t not in c.P["revisar"]:
            c.P["revisar"].append(t)
    res = {"md": md, "simetria": simetria(c), "longitud": longitud(c), "apinamiento": apinamiento(c, md, dudosos), "clases": clases(c, md) if md else {"molar": {}, "canina": {}}, "overjet": oj, "contactos": contactos(c), "korkhaus": korkhaus(c, oj), "anchuras": anchuras(c),
           "bolton": bolton({t: w for t, w in c.anchos.items() if t not in dudosos}), "espacio": espacio(c), "moyers": moyers(c), "spee": spee(c),
           "linea_media": linea_media(c, md), "anchos": dict(c.anchos), "anchos_fuente": c.anchos_fuente,
           "costo": c.costo}
    res["dudosos"] = dudosos
    for cual, por_lado in (("molar", {"der": ("16", "46"), "izq": ("26", "36")}),
                           ("canina", {"der": ("13", "43", "44"), "izq": ("23", "33", "34")})):
        for lado, dientes in por_lado.items():
            mal = [t for t in dientes if t in dudosos]
            if mal and lado in res["clases"][cual]:
                res["clases"][cual][lado] = dict(d=0.0, clase="No valorable", nivel=9, falta=True,
                                                 motivo="revisa la separación del diente " + ", ".join(mal))
    res["denticion"] = denticion(c)
    res["mixta"] = res["denticion"]["mixta"]  # Moyers solo existe en dentición mixta
    # lo que el doctor fijó a su criterio manda sobre lo calculado
    for cual in ("molar", "canina"):
        for lado in ("der", "izq"):
            fijo = c.criterio.get(f"{cual}_{lado}")
            if fijo:
                x = res["clases"][cual].setdefault(lado, {"d": 0.0})
                x.update(clase=fijo, nivel=0 if fijo == "Clase I" else 9 if fijo == "No valorable" else 1,
                         criterio=True)
            elif lado not in res["clases"][cual] and len(c.etiquetas) == 2:
                # con la separación de dientes y sin medida: falta alguno de los dientes de la relación
                res["clases"][cual][lado] = dict(d=0.0, clase="No valorable", nivel=9, falta=True)
    forma = dict((c.AD or {}).get("forma_arco") or {})
    for jaw in ("sup", "inf"):
        if c.criterio.get(f"forma_{jaw}"):
            forma[jaw] = c.criterio[f"forma_{jaw}"]
    res["forma"] = forma
    res["criterio"] = dict(c.criterio)
    res["resumen"] = resumen(res, c.AD)
    return res


# ----------------------------------------------------------------------------- lectura clínica
def nivel_overjet(v):
    if v is None:
        return 9, ""
    if v <= 0:
        return 3, "mordida cruzada anterior" if v < 0 else "borde a borde"
    if v <= 3:
        return 0, "normal"
    if v <= 5:
        return 1, "aumentado leve"
    if v <= 8:
        return 2, "aumentado"
    return 3, "muy aumentado"


def nivel_overbite(v):
    if v is None:
        return 9, ""
    if v < 0:
        return 3, "mordida abierta"
    if v <= 3:
        return 0, "normal"
    if v <= 5:
        return 1, "profunda leve"
    return 2, "profunda"


def nivel_korkhaus(medido, ideal):
    d = medido - ideal
    a = abs(d)
    n = 0 if a < 1 else 1 if a < 2 else 2 if a < 3 else 3
    if n == 0:
        return 0, "normal"
    return n, ("compresión" if d < 0 else "expansión") + (" leve" if n == 1 else " moderada" if n == 2 else " marcada")


def nivel_bolton(b):
    z = (b["relacion"] - b["norma"]) / b["de"]
    if abs(z) <= 1:
        return 0, "normal"
    exceso = "exceso inferior" if z > 0 else "exceso superior"
    mm = b["exceso_inf"] if z > 0 else b["exceso_sup"]
    return (1 if abs(z) <= 2 else 2), f"{exceso} {abs(mm):.1f} mm"


def nivel_espacio(disc):
    if disc >= 0:
        return 0, f"espacio {disc:.1f} mm" if disc >= 0.5 else "sin discrepancia"
    a = -disc
    return (1 if a <= 4 else 2 if a <= 8 else 3), f"apiñamiento {'leve' if a <= 4 else 'moderado' if a <= 8 else 'severo'}"


def resumen(r, AD=None) -> list:
    """[(nivel, título, texto, análisis)] para la tarjeta «Resumen»."""
    out = []
    oj = r["overjet"]
    if oj:
        vals = [v["overjet"] for v in oj.values()]
        ob = [v["overbite"] for v in oj.values()]
        n1, t1 = nivel_overjet(max(vals))
        n2, t2 = nivel_overbite(max(ob) if min(ob) >= 0 else min(ob))
        out.append((max(n1, n2), "Overjet y overbite",
                    f"Overjet {max(vals):.1f} mm ({t1}) · overbite {(max(ob) if min(ob) >= 0 else min(ob)):.1f} mm ({t2})",
                    "overjet"))
    ct = r["contactos"]
    if ct:
        z = ct["sup"]
        firmes = {k: v["c01"] for k, v in z.items()}
        total = sum(firmes.values())
        der = sum(v for k, v in firmes.items() if k.endswith("der"))
        izq = total - der
        n = 0 if total > 4 and min(der, izq) > 0.25 * total else 1 if total > 1 else 2
        txt = f"{total:.1f} mm² de contacto firme · derecha {der:.1f} / izquierda {izq:.1f}"
        out.append((n, "Contactos oclusales", txt, "contactos"))
    K = r["korkhaus"]
    if K and K.get("prem_id"):
        n1, t1 = nivel_korkhaus(K["prem_u"], K["prem_id"])
        n2, t2 = nivel_korkhaus(K["mol_u"], K["mol_id"])
        out.append((max(n1, n2), "Korkhaus superior", f"Premolar {t1} · molar {t2}", "korkhaus"))
    b = r["bolton"]
    if b.get("anterior"):
        n, t = nivel_bolton(b["anterior"])
        out.append((n, "Bolton", f"Anterior {b['anterior']['relacion']:.1f} % ({t})", "bolton"))
    ap = r.get("apinamiento") or {}
    partes, nmax = [], 0
    for jaw, nm in (("sup", "superior"), ("inf", "inferior")):
        x = (ap.get(jaw) or {}).get("6-6") or (ap.get(jaw) or {}).get("5-5")
        if x:
            n, t = nivel_espacio(-x["apinamiento"])
            nmax = max(nmax, n)
            partes.append(f"{nm}: {t} ({-x['apinamiento']:+.1f} mm)")
    if partes:
        out.append((nmax, "Apiñamiento", " · ".join(partes), "espacio"))
    mo = r["moyers"]
    if mo and mo["cuadrantes"] and r.get("mixta", True):
        peor = min(mo["cuadrantes"].values(), key=lambda q: q["discrepancia"])
        n, _ = nivel_espacio(peor["discrepancia"])
        out.append((n, "Moyers (dentición mixta)", f"Peor cuadrante: {peor['discrepancia']:+.1f} mm para 3-4-5", "moyers"))
    cl = r.get("clases") or {}
    ad = AD or {}
    partes, nmax = [], 0
    for k, nombre, clave_ad in (("molar", "Molar", "relacion_molar"), ("canina", "Canina", "relacion_canina")):
        lados = []
        for lado, nl in (("der", "der."), ("izq", "izq.")):
            if lado in cl.get(k, {}):
                lados.append(f"{nl} {cl[k][lado]['clase']}")
                if cl[k][lado]["nivel"] != 9:
                    nmax = max(nmax, cl[k][lado]["nivel"])
            elif (ad.get(clave_ad) or {}).get(lado):
                lados.append(f"{nl} {ad[clave_ad][lado].replace('Relación ', '')}")
        if lados:
            partes.append(f"{nombre}: " + ", ".join(lados))
    if partes:
        out.append((nmax, "Clase molar y canina", " · ".join(partes), "molar"))
    lm = r["linea_media"]
    if lm.get("valorable", True):
        txt = (f"Línea media inferior {lm['mm']:.1f} mm a la {lm['direccion']}" if lm["direccion"] != "centrada"
               else "Las líneas medias coinciden")
        out.append((0 if lm["mm"] <= 2 else 1, "Líneas medias", txt, "lmedia"))
    else:
        out.append((9, "Líneas medias", "No valorable: falta un incisivo central", "lmedia"))
    sp = r["spee"]
    fa = r.get("forma") or ad.get("forma_arco") or {}
    partes = []
    if fa:
        partes.append(f"Forma: superior {fa.get('sup', '—').lower()}, inferior {fa.get('inf', '—').lower()}")
    if sp.get("promedio") is not None:
        partes.append(f"Spee {sp['promedio']:.1f} mm")
    if partes:
        out.append((0 if (sp.get("promedio") or 0) <= 2.7 else 1, "Arcada", " · ".join(partes), "arcada"))
    return out
