"""Corre la identificación de dientes con IA en el motor de IA del equipo (PyTorch + CUDA, en la GPU), fuera de la
app: dientes_ia_worker.py entrada.npz salida.npz. La entrada trae U, FU, L, FL (arcadas ya alineadas); la salida,
las probabilidades por vértice pu / pl (uint8, 0–255). Avisa el avance con líneas «PASO n/total texto»."""
import importlib.util
import os
import sys
import traceback

import numpy as np


def main(entrada, salida):
    aqui = os.path.dirname(os.path.abspath(__file__))
    spec = importlib.util.spec_from_file_location("dientes_ia", os.path.join(aqui, "dientes_ia.py"))
    ia = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(ia)
    z = np.load(entrada)
    total = 2 * len(ia.VISTAS)
    hechos = [0]

    def avisar(texto):
        hechos[0] += 1
        print(f"PASO {hechos[0]}/{total} {texto}", flush=True)

    out = {}
    for jaw, V, F in (("sup", "U", "FU"), ("inf", "L", "FL")):
        if V in z.files and len(z[V]):
            p = ia.probabilidades(z[V], z[F], jaw, progreso=avisar)
            out["p" + ("u" if jaw == "sup" else "l")] = (p * 255).round().astype(np.uint8)
    np.savez_compressed(salida, **out)


if __name__ == "__main__":
    try:
        main(sys.argv[1], sys.argv[2])
    except Exception as exc:  # noqa: BLE001
        traceback.print_exc()
        print(f"ERROR {exc}", flush=True)
        sys.exit(1)
