"""Pestaña «Análisis» del visor (inspirada en MetronTrack): barra de análisis a la derecha, tarjeta con la tabla,
la norma y «Qué mide», y los trazos dibujados sobre el modelo 3D. El análisis lo hace esta app (analisis.py) en la
computadora del doctor; el doctor puede mover los puntos y corregir los anchos dentarios, y todo se vuelve a medir.
"""
from __future__ import annotations

import os

import numpy as np
from PySide6 import QtCore, QtGui, QtWidgets
from PySide6.QtCore import Qt

from . import analisis as A

TURQ = "#1995AD"
NIVEL = {0: ("#2e9e5b", "normal"), 1: ("#d39b1c", "leve"), 2: ("#e07b22", "moderado"), 3: ("#d64541", "marcado"),
         9: ("#8b949e", "")}

ANALISIS = [  # clave, título de la tarjeta, etiqueta corta bajo el ícono
    ("resumen", "Resumen", "Resumen"),
    ("dientes", "Dientes y numeración", "Dientes"),
    ("espacio", "Medición de apiñamiento dental", "Apiñamiento"),
    ("bolton", "Medición de la relación de Bolton", "Bolton"),
    ("moyers", "Moyers (dentición mixta)", "Moyers"),
    ("oclusion", "Relación oclusal y corte", "Oclusión"),
    ("contactos", "Contactos oclusales", "Contactos"),
    ("korkhaus", "Korkhaus", "Korkhaus"),
    ("arcada", "Medición de la arcada dental", "Arcada"),
]
SUBS = {  # análisis con pestañas, como en MetronTrack
    "oclusion": [("overjet", "Sobremordida y resalte"), ("molar", "Relación molar"), ("canina", "Relación canina"),
                 ("lmedia", "Línea media"), ("corte", "Corte de oclusión")],  # el corte ya es parte de «Oclusión»
    "espacio": [("3-3", "3-3"), ("5-5", "5-5"), ("6-6", "6-6"), ("7-7", "7-7")],
    "bolton": [("arcada", "Medición de la arcada dental"), ("ancho", "Medición del ancho del diente")],
    "arcada": [("ancho", "Ancho del arco dental"), ("longitud", "Longitud del arco dental"),
               ("simetria", "Simetría de arcada dental"), ("forma", "Análisis de forma de arco")],
}
DE_SUB = {sub: clave for clave, subs in SUBS.items() if clave == "oclusion" for sub, _ in subs}


def icono_vista_contactos(cual, activo=False) -> QtGui.QIcon:
    """Dibujo de cada forma de ver las arcadas en «Contactos»: cerradas (los dientes en mordida, de frente),
    abiertas (la boca abierta) u oclusal (las dos arcadas por oclusal, lado a lado)."""
    import math

    ruta = os.path.join(_ICONOS, f"v_{cual}.png")  # la ilustración (en el turquesa de la marca), si está
    if os.path.exists(ruta):
        base = QtGui.QPixmap(ruta)
        if not base.isNull():
            lienzo = QtGui.QPixmap(296, 192)
            lienzo.fill(Qt.transparent)
            q = QtGui.QPainter(lienzo)
            q.setRenderHint(QtGui.QPainter.SmoothPixmapTransform)
            if not activo:
                q.setOpacity(0.72)  # sin elegir, un poco más tenue
            esc = base.scaled(lienzo.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
            q.drawPixmap((lienzo.width() - esc.width()) // 2, (lienzo.height() - esc.height()) // 2, esc)
            q.end()
            return QtGui.QIcon(lienzo)
    W, H = 184, 120  # se dibuja al doble y se muestra a la mitad: bordes limpios
    pm = QtGui.QPixmap(W, H)
    pm.fill(Qt.transparent)
    p = QtGui.QPainter(pm)
    p.setRenderHint(QtGui.QPainter.Antialiasing)
    borde = QtGui.QColor("#0f6a7c" if activo else "#7d8894")
    diente = QtGui.QColor("#ffffff")
    encia = QtGui.QColor("#f2a7a0" if activo else "#e3c3c0")  # rosada: se lee como boca de inmediato
    lapiz = QtGui.QPen(borde, 2.4, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)

    def corona(w, h, tipo):
        """Contorno de una corona vista de frente, con el cuello en y = 0 y el borde en y = h (hacia abajo)."""
        c = QtGui.QPainterPath()
        c.moveTo(-w * 0.36, 0)
        c.quadTo(0, -h * 0.24, w * 0.36, 0)                                   # el festón de la encía
        c.cubicTo(w * 0.54, h * 0.30, w * 0.52, h * 0.72, w * 0.44, h * 0.86)  # cara distal
        if tipo == "canino":                                                   # cúspide en punta
            c.quadTo(w * 0.30, h * 0.97, 0, h)
            c.quadTo(-w * 0.30, h * 0.97, -w * 0.44, h * 0.86)
        elif tipo == "premolar":                                               # redondeado
            c.quadTo(w * 0.34, h * 1.02, 0, h)
            c.quadTo(-w * 0.34, h * 1.02, -w * 0.44, h * 0.86)
        else:                                                                  # incisivo: borde recto
            c.quadTo(w * 0.42, h, w * 0.26, h)
            c.lineTo(-w * 0.26, h)
            c.quadTo(-w * 0.42, h, -w * 0.44, h * 0.86)
        c.cubicTo(-w * 0.52, h * 0.72, -w * 0.54, h * 0.30, -w * 0.36, 0)
        return c

    def fila(y_cuello, superior):
        """Una arcada de frente: encía rosada y diez dientes con su forma (central, lateral, canino y dos
        premolares por lado), más chicos y más altos hacia los lados, como se ve una sonrisa."""
        if superior:
            piezas = (("incisivo", 24, 34), ("incisivo", 18, 29), ("canino", 18, 32), ("premolar", 13, 23),
                      ("premolar", 11, 19))
        else:
            piezas = (("incisivo", 14, 25), ("incisivo", 15, 26), ("canino", 16, 28), ("premolar", 13, 21),
                      ("premolar", 11, 18))
        sg = 1 if superior else -1
        lugares, x = [], 0.0
        for tipo, w, h in piezas:
            lugares.append((x + w / 2, tipo, w, h))
            x += w - 1.5
        medio_ancho = x + 4
        # la encía: una banda que sigue a los cuellos
        banda = QtGui.QPainterPath()
        banda.moveTo(W / 2 - medio_ancho, y_cuello - sg * 15)
        banda.quadTo(W / 2, y_cuello - sg * 22, W / 2 + medio_ancho, y_cuello - sg * 15)
        banda.lineTo(W / 2 + medio_ancho, y_cuello + sg * 9)
        banda.quadTo(W / 2, y_cuello + sg * 3, W / 2 - medio_ancho, y_cuello + sg * 9)
        banda.closeSubpath()
        p.setPen(Qt.NoPen)
        p.setBrush(encia)
        p.drawPath(banda)
        p.setPen(lapiz)
        p.setBrush(diente)
        for lado in (-1, 1):
            for cx_, tipo, w, h in reversed(lugares):  # de atrás hacia adelante: los centrales quedan encima
                giro = QtGui.QTransform()
                giro.translate(W / 2 + lado * cx_, y_cuello + sg * (cx_ / medio_ancho) ** 2 * 5)
                giro.scale(lado, sg)
                p.drawPath(giro.map(corona(w, h, tipo)))

    def arcada(cx, cy, abre_abajo):
        """Una arcada por oclusal: una U de dientes."""
        tam = (15, 15, 14, 12, 11, 11, 12, 14, 15, 15)
        p.setPen(lapiz)
        p.setBrush(diente)
        for k, t in enumerate(tam):
            f = math.pi * (k + 0.5) / len(tam)
            x = cx - 30 * math.cos(f)
            y = cy + (1 if abre_abajo else -1) * (34 - 62 * math.sin(f)) * 0.5 + (0 if abre_abajo else 0)
            y = (cy + 30 - 58 * math.sin(f)) if abre_abajo else (cy - 30 + 58 * math.sin(f))
            p.drawRoundedRect(QtCore.QRectF(x - t / 2, y - t / 2, t, t), 4.5, 4.5)

    if cual == "cerradas":       # en mordida: los superiores cubren un poco a los inferiores
        fila(84, False)
        fila(22, True)
    elif cual == "abiertas":     # la boca abierta: se ve el fondo oscuro entre las dos arcadas
        p.setPen(Qt.NoPen)
        p.setBrush(QtGui.QColor("#3d4753" if activo else "#8a94a0"))
        p.drawRoundedRect(QtCore.QRectF(W / 2 - 60, 20, 120, 80), 26, 26)
        fila(108, False)
        fila(12, True)
    else:
        arcada(50, 60, True)
        arcada(134, 60, False)
    p.end()
    return QtGui.QIcon(pm)


def _arco(p, cx, cy, rx, ry):
    """Arcada vista por oclusal: una U con el frente arriba."""
    camino = QtGui.QPainterPath()
    camino.moveTo(cx - rx, cy + ry)
    camino.cubicTo(cx - rx, cy - ry * 1.6, cx + rx, cy - ry * 1.6, cx + rx, cy + ry)
    p.drawPath(camino)
    return camino


def _dibujar_icono(clave, color, n=64):
    """Íconos propios, dibujados (se entienden sin leer): n×n px."""
    pm = QtGui.QPixmap(n, n)
    pm.fill(Qt.transparent)
    p = QtGui.QPainter(pm)
    p.setRenderHint(QtGui.QPainter.Antialiasing)
    c = QtGui.QColor(color)
    pluma = QtGui.QPen(c, 4.5, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
    fina = QtGui.QPen(c, 3, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
    p.setPen(pluma)
    p.setBrush(Qt.NoBrush)
    if clave == "resumen":  # lista con palomitas
        for k, y in enumerate((16, 32, 48)):
            p.setPen(fina)
            p.drawPolyline([QtCore.QPointF(8, y), QtCore.QPointF(12, y + 4), QtCore.QPointF(19, y - 5)])
            p.setPen(pluma)
            p.drawLine(28, y, 56, y)
    elif clave == "oclusion":  # incisivo superior por delante del inferior, de perfil, con la cota
        sup = QtGui.QPainterPath()
        sup.moveTo(30, 4)
        sup.cubicTo(14, 8, 8, 26, 14, 40)
        sup.cubicTo(22, 30, 34, 22, 40, 6)
        sup.closeSubpath()
        inf = QtGui.QPainterPath()
        inf.moveTo(34, 30)
        inf.cubicTo(30, 40, 34, 52, 42, 60)
        inf.cubicTo(50, 52, 48, 38, 34, 30)
        inf.closeSubpath()
        p.setBrush(c)
        p.setPen(Qt.NoPen)
        p.setOpacity(0.95)
        p.drawPath(sup)
        p.setOpacity(0.55)
        p.drawPath(inf)
        p.setOpacity(1)
        p.setPen(fina)
        p.drawLine(14, 50, 32, 50)
        p.drawLine(14, 45, 14, 55)
        p.drawLine(32, 45, 32, 55)
    elif clave == "dientes":  # diente con su número
        cam = QtGui.QPainterPath()
        cam.moveTo(14, 30)
        cam.cubicTo(8, 10, 26, 6, 32, 14)
        cam.cubicTo(38, 6, 56, 10, 50, 30)
        cam.cubicTo(48, 44, 44, 58, 40, 58)
        cam.cubicTo(36, 58, 36, 42, 32, 42)
        cam.cubicTo(28, 42, 28, 58, 24, 58)
        cam.cubicTo(20, 58, 16, 44, 14, 30)
        p.drawPath(cam)
        f = p.font()
        f.setPixelSize(17)
        f.setBold(True)
        p.setFont(f)
        p.drawText(QtCore.QRectF(14, 12, 36, 24), Qt.AlignCenter, "11")
    elif clave == "corte":  # dientes en oclusión atravesados por el plano de corte
        p.setPen(fina)
        for x in (6, 24, 42):
            p.drawRoundedRect(QtCore.QRectF(x, 12, 16, 18), 5, 5)
            p.drawRoundedRect(QtCore.QRectF(x, 34, 16, 18), 5, 5)
        p.setPen(QtGui.QPen(c, 5, Qt.SolidLine, Qt.RoundCap))
        p.drawLine(32, 3, 32, 61)
    elif clave == "contactos":  # molar por oclusal con puntos de contacto
        p.drawRoundedRect(QtCore.QRectF(9, 11, 46, 42), 15, 15)
        p.setPen(fina)
        p.drawLine(32, 20, 32, 44)
        p.drawLine(20, 32, 44, 32)
        p.setPen(Qt.NoPen)
        p.setBrush(c)
        for x, y in ((22, 23), (43, 24), (23, 42), (42, 41)):
            p.drawEllipse(QtCore.QPointF(x, y), 4.5, 4.5)
    elif clave == "korkhaus":  # arcada con los anchos transversales
        _arco(p, 32, 34, 22, 20)
        p.setPen(fina)
        for y, dx in ((30, 15), (48, 20)):
            p.drawLine(32 - dx, y, 32 + dx, y)
            for sx in (-1, 1):
                x = 32 + sx * dx
                p.drawPolyline([QtCore.QPointF(x - sx * 5, y - 4), QtCore.QPointF(x, y), QtCore.QPointF(x - sx * 5, y + 4)])
    elif clave == "espacio":  # dientes encimados sobre la curva de la arcada
        p.setPen(fina)
        _arco(p, 32, 40, 24, 16)
        p.setBrush(QtGui.QBrush(QtGui.QColor(color)))
        for x, y, g in ((16, 24, -24), (28, 15, 14), (40, 17, -16), (50, 27, 30)):
            p.save()
            p.translate(x, y)
            p.rotate(g)
            p.setOpacity(0.9)
            p.drawRoundedRect(QtCore.QRectF(-6, -8, 12, 16), 4, 4)
            p.restore()
    elif clave == "bolton":  # tres dientes con la cota mesiodistal de uno
        p.setPen(fina)
        for x, w in ((5, 15), (23, 18), (44, 15)):
            p.drawRoundedRect(QtCore.QRectF(x, 10, w, 26), 6, 6)
        p.setPen(pluma)
        p.drawLine(23, 50, 41, 50)
        p.setPen(fina)
        p.drawLine(23, 43, 23, 57)
        p.drawLine(41, 43, 41, 57)
    elif clave == "moyers":  # arcada con el tramo 3-4-5 marcado y el germen por erupcionar
        p.setOpacity(0.45)
        camino = _arco(p, 32, 34, 22, 20)
        p.setOpacity(1)
        tramo = QtGui.QPainterPath()
        for k, t in enumerate(np.linspace(0.08, 0.36, 12)):
            q = camino.pointAtPercent(t)
            tramo.moveTo(q) if k == 0 else tramo.lineTo(q)
        p.setPen(QtGui.QPen(c, 8, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        p.drawPath(tramo)
        p.setPen(fina)
        p.drawLine(46, 34, 46, 52)
        p.drawPolyline([QtCore.QPointF(40, 40), QtCore.QPointF(46, 33), QtCore.QPointF(52, 40)])
    elif clave == "arcada":  # la curva de la arcada con sus dientes
        camino = _arco(p, 32, 34, 22, 20)
        p.setPen(Qt.NoPen)
        p.setBrush(c)
        for t in np.linspace(0.02, 0.98, 9):
            p.drawEllipse(camino.pointAtPercent(t), 5, 5)
    p.end()
    return pm


_ICONOS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "iconos")


def _icono_de_archivo(clave, color):
    """El ícono ilustrado (iconos/<clave>.png: una silueta blanca con transparencia) pintado de `color`.
    None si no hay archivo: se usa entonces el dibujado por código."""
    ruta = os.path.join(_ICONOS, clave + ".png")
    if not os.path.exists(ruta):
        return None
    base = QtGui.QPixmap(ruta)
    if base.isNull():
        return None
    pm = QtGui.QPixmap(base.size())
    pm.fill(Qt.transparent)
    p = QtGui.QPainter(pm)
    p.drawPixmap(0, 0, base)
    p.setCompositionMode(QtGui.QPainter.CompositionMode_SourceIn)  # conserva la forma, cambia el color
    p.fillRect(pm.rect(), QtGui.QColor(color))
    p.end()
    return pm


def icono(clave):
    """Ícono de la barra en los colores de la marca: turquesa oscuro en reposo, blanco al estar elegido."""
    ic = QtGui.QIcon()
    for color, modo, estado in (("#0f6a7c", QtGui.QIcon.Normal, QtGui.QIcon.Off),
                                ("#ffffff", QtGui.QIcon.Normal, QtGui.QIcon.On),
                                ("#b8c0c8", QtGui.QIcon.Disabled, QtGui.QIcon.Off)):
        ic.addPixmap(_icono_de_archivo(clave, color) or _dibujar_icono(clave, color), modo, estado)
    return ic

QUE_MIDE = {
    "resumen": "Lo principal del caso de un vistazo. Toca una línea para ver el análisis.",
    "dientes": "Cada diente separado y numerado (FDI). Si un número está mal, haz clic en el diente y corrígelo: "
               "todo el análisis se vuelve a medir.",
    "forma": "La curva de la arcada y su forma.",
    "longitud": "Profundidad de cada arcada sobre su eje medio, desde el borde de los incisivos hasta caninos, "
                "premolares y molares. También la curva de Spee y la altura del paladar.",
    "simetria": "Qué tan lejos queda cada lado (caninos, premolares y molares) del eje medio de la arcada.",
    "overjet": "Resalte (overjet) y sobremordida (overbite) en un corte sagital por el centro de cada central superior.",
    "molar": "Dónde cae la cúspide mesiovestibular del primer molar superior respecto al surco mesiovestibular del "
             "primer molar inferior.",
    "canina": "Dónde cae la cúspide del canino superior respecto a la tronera entre el canino y el primer premolar "
              "inferiores.",
    "lmedia": "Línea media superior (entre 11 y 21) e inferior (entre 41 y 31): cuánto se desvían entre sí y "
              "respecto al eje de la arcada.",
    "corte": "El perfil de los dientes en el lugar que elijas, en mm.",
    "contactos": "Qué tan cerca quedan las arcadas en oclusión, diente por diente. Rojo = contacto firme.",
    "korkhaus": "Ancho de la arcada en premolares y molares, y largo anterior, frente a lo ideal para el tamaño "
                "de los incisivos superiores (SI).",
    "espacio": "Tamaño de los dientes frente al tamaño de la arcada, por segmentos. La línea verde de cada diente "
               "es su ancho mesiodistal.",
    "bolton": "Proporción entre el tamaño de los dientes inferiores y superiores.",
    "moyers": "Para pacientes en crecimiento: cuánto medirán canino y premolares (3-4-5) que aún no erupcionan, "
              "frente al espacio que hay de distal del lateral a mesial del primer molar.",
    "arcada": "Forma, anchura y simetría de las arcadas, y curva de Spee.",
}

NORMA = {
    "overjet": "Overjet: 0–3 mm normal · 3–5 aumentado leve · 5–8 aumentado · >8 muy aumentado · ≤0 borde a borde "
               "o cruzada.<br>Overbite: 0–3 mm (≈ 1/3 de la corona) · 3–5 profunda leve · >5 profunda · <0 mordida "
               "abierta.<br>Con incisivos rotados el valor cambia a lo ancho de la corona: mueve el corte con "
               "«Ajustar cortes».",
    "molar": "Medida en vista lateral. Clase I (neutra): la cúspide cae en el surco (±1.5 mm). Clase II: la cúspide "
             "superior queda por delante (mesial) del surco. Clase III: queda por detrás (distal).",
    "canina": "Medida a lo largo de la arcada. Clase I (neutra): la cúspide cae en la tronera (±1.5 mm). Clase II: queda "
              "por delante (mesial). Clase III: queda por detrás (distal).",
    "lmedia": "Desviación entre líneas medias: hasta 2 mm se considera aceptable.",
    "contactos": "Distancia entre arcadas en las caras oclusales: <0.1 mm contacto firme · 0.1–0.3 casi en contacto "
                 "· 0.3–0.6 cercano. Áreas en mm². Confirmar en clínica con papel de articular.",
    "korkhaus": "Ideal (Pont/Korkhaus) con SI = 12+11+21+22: premolar = SI×100/85 · molar = SI×100/65 · largo anterior "
                "superior Lo = SI×100/160 · inferior Lu = Lo − 2.<br>Diferencia <1 mm normal · 1–2 leve · 2–3 "
                "moderada · >3 marcada (negativo = compresión).",
    "espacio": "Apiñamiento = tamaño de los dientes − tamaño de la arcada: hasta 4 mm leve · 4–8 moderado · >8 severo. "
               "Negativo = sobra espacio (diastemas).",
    "bolton": "Relación anterior 78.8 ± 1.72 % (6 dientes) · relación general 91.5 ± 1.51 % (12 dientes).",
    "moyers": "Moyers al 75 % (tabla clásica) con la suma de los 4 incisivos inferiores; Tanaka-Johnston como "
              "segunda opinión (superior SI/2 + 11 mm, inferior SI/2 + 10.5 mm). Discrepancia = espacio disponible "
              "− espacio necesario por cuadrante (negativo = faltará espacio).",
    "arcada": "Los anchos se miden entre los centros de las coronas (caninos, primeros premolares y primeros molares).",
    "longitud": "Curva de Spee 2 ± 0.7 mm, medida con la cúspide de cada diente inferior.",
    "simetria": "Hasta 2 mm de diferencia entre el lado derecho y el izquierdo se considera simétrico.",
}

# puntos que el doctor puede mover: clave → (arcada, dónde vive en caso.P, nombre)
PUNTOS = {
    "overjet": [("sup", "inc", "11"), ("sup", "inc", "21"), ("inf", "inc", "41"), ("inf", "inc", "31")],
    "korkhaus": [("sup", "sup", "14"), ("sup", "sup", "24"), ("sup", "sup", "16"), ("sup", "sup", "26"),
                 ("inf", "inf", "c44/45"), ("inf", "inf", "c34/35"), ("inf", "inf", "46"), ("inf", "inf", "36")],
    "moyers": [("sup", "cen", "12"), ("sup", "cen", "22"), ("sup", "cen", "16"), ("sup", "cen", "26"),
               ("inf", "cen", "42"), ("inf", "cen", "32"), ("inf", "cen", "46"), ("inf", "cen", "36")],
    "molar": [("sup", "aj", "molar_der_sup", "Cúspide MV del 16"), ("inf", "aj", "molar_der_inf", "Surco MV del 46"),
              ("sup", "aj", "molar_izq_sup", "Cúspide MV del 26"), ("inf", "aj", "molar_izq_inf", "Surco MV del 36")],
    "canina": [("sup", "aj", "canina_der_sup", "Cúspide del 13"), ("inf", "aj", "canina_der_inf", "Tronera 43/44"),
               ("sup", "aj", "canina_izq_sup", "Cúspide del 23"), ("inf", "aj", "canina_izq_inf", "Tronera 33/34")],
    "lmedia": [("sup", "aj", "lm_sup", "Línea media superior"), ("inf", "aj", "lm_inf", "Línea media inferior")],
    "arcada": [("sup", "cen", "13"), ("sup", "cen", "23"), ("sup", "cen", "14"), ("sup", "cen", "24"),
               ("sup", "cen", "16"), ("sup", "cen", "26"), ("inf", "cen", "43"), ("inf", "cen", "33"),
               ("inf", "cen", "44"), ("inf", "cen", "34"), ("inf", "cen", "46"), ("inf", "cen", "36")],
}


PUNTOS["simetria"] = PUNTOS["longitud"] = PUNTOS["arcada"]  # los mismos centros de caninos, premolares y molares


SIN_DIENTES = ("dientes", "corte")  # lo único que se puede usar sin los dientes identificados


def texto_punto(pt):
    return pt[3] if len(pt) > 3 else pt[2].lstrip("c")


CLASES = ["Clase I", "Clase II", "Clase III", "No valorable"]
FORMAS = ["Oval", "Redondo puntiagudo", "Cuadrado redondeado", "Puntiagudo", "Cuadrado"]


def chip(texto, nivel):
    """El estado de una medida: un punto del color de su nivel y la palabra en ese color."""
    c = NIVEL.get(nivel, NIVEL[9])[0]
    return f'<span style="color:{c};font-weight:600;">●&nbsp;{texto}</span>'


def mm(v, d=1):
    return "—" if v is None else f"{v:.{d}f}"


def tabla(enc, filas):
    h = ['<table cellspacing="0" cellpadding="6" width="100%" style="border-collapse:collapse;font-size:9.5pt;">',
         "<tr>" + "".join(f'<td style="color:#8792a0;font-size:8pt;border-bottom:1px solid #d5dde2;">{e}</td>'
                          for e in enc) + "</tr>"]
    for f in filas:
        h.append("<tr>" + "".join(f'<td style="border-bottom:1px solid #eef1f4;">{c}</td>' for c in f) + "</tr>")
    h.append("</table>")
    return "".join(h)


def etiqueta(html, muted=False):
    lb = QtWidgets.QLabel(html)
    lb.setWordWrap(True)
    lb.setTextFormat(Qt.RichText)
    if muted:
        lb.setStyleSheet("color:#6b7682;font-size:9pt;")
    return lb


# ----------------------------------------------------------------------------- el corte sagital en 2D
class CorteSagital(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(230)
        self.sup = self.inf = None
        self.r = None

    def poner(self, sup, inf, r):
        self.sup, self.inf, self.r = sup, inf, r
        self.update()

    def paintEvent(self, _):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        p.fillRect(self.rect(), QtGui.QColor("#f3f5f7"))
        if self.r is None or self.sup is None:
            p.setPen(QtGui.QColor("#8b949e"))
            p.drawText(self.rect(), Qt.AlignCenter, "Sin corte")
            return
        r = self.r
        # encuadre: los dos bordes incisales y espacio para las cotas (con overjet grande se aleja)
        yc = (r["y_up"] + r["y_lo"]) / 2 + 1.5
        zc = (r["z_up"] + r["z_lo"]) / 2
        half = max(8.0, abs(r["y_lo"] - r["y_up"]) / 2 + 6.0, abs(r["z_lo"] - r["z_up"]) / 2 + 7.0)
        W, H = self.width(), self.height()
        esc = min(W, H) / (2 * half)

        def px(y, z):  # anterior a la izquierda, arriba = +z
            return QtCore.QPointF(W / 2 + (y - yc) * esc, H / 2 - (z - zc) * esc)

        for pts, col in ((self.sup, "#58b947"), (self.inf, "#f26a1b")):
            p.setPen(Qt.NoPen)
            p.setBrush(QtGui.QColor(col))
            for y, z in pts[::max(1, len(pts) // 2500)]:
                q = px(y, z)
                if 0 <= q.x() <= W and 0 <= q.y() <= H:
                    p.drawEllipse(q, 1.3, 1.3)
        roj, ver = QtGui.QColor("#d64541"), QtGui.QColor("#1f7a8c")
        pen = QtGui.QPen(roj, 1.4, Qt.DashLine)
        p.setPen(pen)
        yu, yl, zu, zl = r["y_up"], r["y_lo"], r["z_up"], r["z_lo"]
        zb = min(zu, zl) - 2.5
        p.drawLine(px(yu, zu + 0.6), px(yu, zb))
        p.drawLine(px(yl, zl), px(yl, zb))
        p.setPen(QtGui.QPen(roj, 2))
        p.drawLine(px(yu, zb), px(yl, zb))
        f = p.font()
        f.setBold(True)
        f.setPointSize(9)
        p.setFont(f)
        p.drawText(px(min(yu, yl), zb - 0.6) + QtCore.QPointF(0, 14), f"Overjet {r['overjet']:.1f} mm")
        xo = max(yu, yl) + 3.0
        p.setPen(QtGui.QPen(ver, 1.4, Qt.DashLine))
        p.drawLine(px(min(yu, yl) - 0.5, zu), px(xo + 0.4, zu))
        p.drawLine(px(min(yu, yl) - 0.5, zl), px(xo + 0.4, zl))
        p.setPen(QtGui.QPen(ver, 2))
        p.drawLine(px(xo, zu), px(xo, zl))
        p.drawText(px(xo + 0.5, (zu + zl) / 2) + QtCore.QPointF(2, 4), f"Overbite {r['overbite']:.1f} mm")
        p.setPen(QtGui.QColor("#8b949e"))
        f.setBold(False)
        f.setPointSize(8)
        p.setFont(f)
        p.drawText(QtCore.QRectF(6, H - 20, W - 12, 16), Qt.AlignLeft, "← anterior")
        p.drawText(QtCore.QRectF(6, H - 20, W - 12, 16), Qt.AlignRight, "superior verde · inferior naranja")


class GraficaCorte(QtWidgets.QWidget):
    """Perfil del corte libre (como «Visualización de la oclusión» de MetronTrack): cuadrícula en mm,
    superior en verde e inferior en naranja."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(330)
        self.sup = self.inf = None

    def poner(self, sup, inf, rotulos=None):
        """sup / inf: segmentos (n, 2, 2) en mm sobre el plano (horizontal, vertical). rotulos: qué hay a la
        izquierda y a la derecha de la gráfica (p. ej. «lingual», «vestibular»)."""
        self.sup, self.inf, self.rotulos = sup, inf, rotulos
        self.update()

    def paintEvent(self, _):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        W, H = self.width(), self.height()
        p.fillRect(self.rect(), QtGui.QColor("#f3f5f7"))
        todos = [s.reshape(-1, 2) for s in (self.sup, self.inf) if s is not None and len(s)]
        if not todos:
            p.setPen(QtGui.QColor("#6b7682"))
            p.drawText(self.rect(), Qt.AlignCenter, "El plano no corta los modelos")
            return
        P = np.vstack(todos)
        c = (P.min(0) + P.max(0)) / 2
        medio = max(float((P.max(0) - P.min(0)).max()) / 2 * 1.12, 6.0)
        m = 30  # margen para los números
        esc = (min(W, H) - 2 * m) / (2 * medio)

        def px(q):
            return QtCore.QPointF(W / 2 + (q[0] - c[0]) * esc, H / 2 - (q[1] - c[1]) * esc)

        paso = 5 if medio < 30 else 10
        f = p.font()
        f.setPointSize(8)
        p.setFont(f)
        for k in range(int(np.floor((c[0] - medio) / paso)), int(np.ceil((c[0] + medio) / paso)) + 1):
            x = px((k * paso, 0)).x()
            if m <= x <= W - 6:
                p.setPen(QtGui.QPen(QtGui.QColor("#d5dbe1"), 1))
                p.drawLine(QtCore.QPointF(x, 6), QtCore.QPointF(x, H - m + 8))
                p.setPen(QtGui.QColor("#5b6570"))
                p.drawText(QtCore.QRectF(x - 20, H - m + 10, 40, 14), Qt.AlignCenter, str(k * paso))
        for k in range(int(np.floor((c[1] - medio) / paso)), int(np.ceil((c[1] + medio) / paso)) + 1):
            y = px((0, k * paso)).y()
            if 6 <= y <= H - m + 8:
                p.setPen(QtGui.QPen(QtGui.QColor("#d5dbe1"), 1))
                p.drawLine(QtCore.QPointF(m, y), QtCore.QPointF(W - 6, y))
                p.setPen(QtGui.QColor("#5b6570"))
                p.drawText(QtCore.QRectF(0, y - 7, m - 4, 14), Qt.AlignRight | Qt.AlignVCenter, str(k * paso))
        for segs, col in ((self.sup, "#58b947"), (self.inf, "#f26a1b")):
            if segs is None:
                continue
            p.setPen(QtGui.QPen(QtGui.QColor(col), 2.2, Qt.SolidLine, Qt.RoundCap))
            for a, b in segs:
                p.drawLine(px(a), px(b))
        if getattr(self, "rotulos", None):
            p.setPen(QtGui.QColor("#3d4753"))
            p.drawText(QtCore.QRectF(m + 4, H - m - 8, 120, 14), Qt.AlignLeft, "← " + self.rotulos[0])
            p.drawText(QtCore.QRectF(W - 130, H - m - 8, 124, 14), Qt.AlignRight, self.rotulos[1] + " →")
        p.setPen(QtGui.QColor("#58b947"))
        p.drawText(QtCore.QRectF(m + 4, 6, 120, 14), Qt.AlignLeft, "— superior")
        p.setPen(QtGui.QColor("#f26a1b"))
        p.drawText(QtCore.QRectF(m + 84, 6, 120, 14), Qt.AlignLeft, "— inferior")


# ----------------------------------------------------------------------------- el cálculo, en segundo plano
class Trabajador(QtCore.QObject):
    listo = QtCore.Signal(object, int)
    fallo = QtCore.Signal(str, int)
    progreso = QtCore.Signal(str, int)

    def __init__(self, sup, inf, anchos, AD, gen, etiquetas=None):
        super().__init__()
        self.args = (sup, inf, anchos, AD, etiquetas)
        self.gen = gen

    @QtCore.Slot()
    def correr(self):
        try:
            sup, inf, anchos, AD, etiquetas = self.args
            caso = A.preparar(sup, inf, anchos, AD, progreso=lambda t: self.progreso.emit(t, self.gen),
                              etiquetas=etiquetas)
            self.progreso.emit("Midiendo…", self.gen)
            caso.contactos()
            self.listo.emit(caso, self.gen)
        except A.ErrorAnalisis as exc:
            self.fallo.emit(str(exc), self.gen)
        except Exception as exc:  # noqa: BLE001
            self.fallo.emit(f"No se pudo analizar el caso: {exc}", self.gen)


class TrabajadorIA(QtCore.QObject):
    """Identifica los dientes de las dos arcadas con IA (solo en la PC de la Dra.)."""
    listo = QtCore.Signal(object, int)
    fallo = QtCore.Signal(str, int)
    progreso = QtCore.Signal(str, int)

    def __init__(self, caso, gen, sin_zocalo=None):
        super().__init__()
        self.caso, self.gen = caso, gen
        # (superior, inferior) del escaneo sin zócalo, en coordenadas del escáner, cuando lo analizado es el modelo
        # zocalado: la IA trabaja mucho mejor sobre el escaneo tal cual y luego se pasa la numeración
        self.sin_zocalo = sin_zocalo

    @QtCore.Slot()
    def correr(self):
        try:
            from . import dientes_ia

            self.progreso.emit("Preparando la identificación de dientes…", self.gen)
            c = self.caso
            avisar = lambda t: self.progreso.emit(t, self.gen)  # noqa: E731
            crudo = None
            if self.sin_zocalo:
                try:
                    s = A.preparar(*self.sin_zocalo)
                    crudo = {"sup": (s.U, s.FU), "inf": (s.L, s.FL)}
                except Exception:  # noqa: BLE001  (no se pudo alinear: se identifica sobre el zocalado)
                    crudo = None
            out = dientes_ia.identificar_arcadas(c.U, c.FU, c.L, c.FL, progreso=avisar, sin_zocalo=crudo)
            self.listo.emit(out, self.gen)
        except Exception as exc:  # noqa: BLE001
            self.fallo.emit(f"No se pudieron identificar los dientes: {exc}", self.gen)


class BarrasContacto(QtWidgets.QWidget):
    """Contacto oclusal por zona, derecha contra izquierda, en barras (se lee de un vistazo): la barra fuerte es
    el contacto firme (< 0.1 mm) y la clara, lo que queda casi en contacto (< 0.3 mm). La derecha del paciente va
    a la izquierda, como se le mira."""
    ZONAS = (("ant", "Anterior"), ("prem", "Premolares"), ("mol", "Molares"))

    def __init__(self, ct, parent=None):
        super().__init__(parent)
        self.ct = ct
        self.setFixedSize(396, 150)

    def paintEvent(self, _ev):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        medio, alto, y0 = self.width() / 2, 26, 30
        etiqueta_w = 84                      # la zona se nombra en el centro
        largo = medio - etiqueta_w / 2 - 44  # lo más que mide una barra
        tope = max([self.ct[f"{z}_{l}"]["c03"] for z, _ in self.ZONAS for l in ("der", "izq")] + [1.0])
        f = p.font()
        f.setPointSizeF(8.5)
        f.setBold(True)
        p.setFont(f)
        p.setPen(QtGui.QColor("#3d4753"))
        p.drawText(QtCore.QRectF(0, 4, medio - etiqueta_w / 2, 18), Qt.AlignRight | Qt.AlignVCenter, "Derecha  ")
        p.drawText(QtCore.QRectF(medio + etiqueta_w / 2, 4, medio - etiqueta_w / 2, 18), Qt.AlignLeft | Qt.AlignVCenter,
                   "  Izquierda")
        for i, (z, nombre) in enumerate(self.ZONAS):
            y = y0 + i * (alto + 12)
            f.setBold(False)
            p.setFont(f)
            p.setPen(QtGui.QColor("#3d4753"))
            p.drawText(QtCore.QRectF(medio - etiqueta_w / 2, y, etiqueta_w, alto), Qt.AlignCenter, nombre)
            for lado, sg in (("der", -1), ("izq", 1)):
                v = self.ct[f"{z}_{lado}"]
                x0 = medio + sg * etiqueta_w / 2
                p.setPen(Qt.NoPen)
                p.setBrush(QtGui.QColor("#eef1f4"))  # el riel
                p.drawRoundedRect(QtCore.QRectF(min(x0, x0 + sg * largo), y + 5, largo, alto - 10), 5, 5)
                for clave, color in (("c03", "#fdc98f"), ("c01", "#d7191c")):
                    ancho = largo * min(1.0, v[clave] / tope)
                    if ancho > 0.5:
                        p.setBrush(QtGui.QColor(color))
                        p.drawRoundedRect(QtCore.QRectF(min(x0, x0 + sg * ancho), y + 5, ancho, alto - 10), 5, 5)
                f.setBold(True)
                p.setFont(f)
                p.setPen(QtGui.QColor("#1f2933"))
                caja = QtCore.QRectF(x0 + sg * largo + (4 if sg > 0 else -44), y, 40, alto)
                p.drawText(caja, (Qt.AlignLeft if sg > 0 else Qt.AlignRight) | Qt.AlignVCenter, f"{v['c01']:.1f}")
        p.end()


class SelectorNumero(QtWidgets.QDialog):
    """Elegir el número de un diente en un cuadro con forma de arcada (como MetronTrack al añadir un diente):
    por fuera los permanentes, por dentro los de leche. Los que ya están marcados salen apagados."""

    def __init__(self, jaw, usados, parent=None):
        import math

        super().__init__(parent, Qt.Popup | Qt.FramelessWindowHint)
        self.numero = None
        self.setFixedSize(292, 250)
        self.setStyleSheet("QDialog{background:#ffffff;border:1px solid #c3ccd4;border-radius:10px;}")
        t = QtWidgets.QLabel("¿Qué diente es?", self)
        t.setStyleSheet("color:#1f2933;font-weight:600;background:transparent;")
        t.move(12, 8)
        sup = jaw == "sup"
        q_der, q_izq = (1, 2) if sup else (4, 3)
        anillos = [([q_der * 10 + k for k in range(8, 0, -1)] + [q_izq * 10 + k for k in range(1, 9)], 122, 178, 26),
                   ([(q_der + 4) * 10 + k for k in range(5, 0, -1)] + [(q_izq + 4) * 10 + k for k in range(1, 6)], 74, 112, 24)]
        cx = 146
        for nums, rx, ry, lado in anillos:
            for i, n in enumerate(nums):
                f = math.pi * (i + 0.5) / len(nums)
                x = cx - rx * math.cos(f)
                y = (228 - ry * math.sin(f)) if sup else (36 + ry * math.sin(f))
                b = QtWidgets.QPushButton(str(n), self)
                b.setFixedSize(lado, lado)
                b.move(int(x - lado / 2), int(y - lado / 2))
                b.setCursor(Qt.PointingHandCursor)
                b.setEnabled(n not in usados)
                b.setStyleSheet(
                    f"QPushButton{{padding:0;font-size:8pt;border-radius:{lado // 2}px;background:#ffffff;color:#1f2933;"
                    "border:1px solid #6b7682;}"
                    f"QPushButton:hover{{background:{TURQ};color:white;border-color:{TURQ};}}"
                    "QPushButton:disabled{background:#eef1f4;color:#b8c0c8;border-color:#d5dbe1;}")
                b.setToolTip(f"Diente {n}" + (" (ya está marcado)" if n in usados else ""))
                b.clicked.connect(lambda _on, k=n: self._elegir(k))

    def _elegir(self, n):
        self.numero = n
        self.accept()


# ----------------------------------------------------------------------------- el panel
class PanelAnalisis(QtWidgets.QFrame):
    """Tarjeta + barra de análisis. `pagina` dibuja los trazos y maneja la cámara."""

    def __init__(self, pagina):
        super().__init__()
        self.pagina = pagina
        self.caso = None
        self.res = None
        self.actual = "resumen"
        self.sub = {clave: subs[0][0] for clave, subs in SUBS.items()}
        self.sub["espacio"] = "6-6"
        self.diente_sel = None  # (arcada, diente) elegido con un clic en Apiñamiento / Bolton
        self.punto_activo = None  # (arcada, dónde, nombre) a mover con el siguiente clic
        self._t_md = QtCore.QTimer(self)  # mientras se arrastra un punto mesial/distal: volver a medir sin atascar
        self._t_md.setSingleShot(True)
        self._t_md.timeout.connect(self._md_en_vivo)
        self.md_modo = None       # «Marcar diente»: None · "agregar" · "borrar" · "leche" · "area"
        self.md_sel = None        # «Modificar área»: (arcada, diente) que se está retocando
        self.md_goma = False      # … con la goma (quitar) en vez del lápiz (pintar)
        self.md_radio = 1.2       # … radio del pincel (mm)
        self._md_antes = None     # … cómo estaba al entrar (para ✕)
        self.md_num = None        # número elegido a mano en el cuadro de dientes
        self.md_preguntar = True  # al añadir un diente, preguntar su número (como MetronTrack)
        self.setObjectName("panelan")
        self.setStyleSheet(
            "QFrame#panelan{background:#ffffff;border-radius:12px;}"
            "QFrame#panelan QPushButton{background:#ffffff;color:#3d4753;border:1px solid #cfd8dd;border-radius:9px;"
            "padding:6px 10px;}"
            "QFrame#panelan QPushButton:hover{border-color:#1995AD;color:#0f6a7c;}"
            "QFrame#panelan QPushButton:checked{background:#1995AD;color:white;border-color:#1995AD;font-weight:600;}"
            "QFrame#panelan QPushButton#pestana{background:#eef2f4;border:none;border-radius:9px;font-size:9pt;"
            "color:#5b6570;padding:6px 8px;}"
            "QFrame#panelan QPushButton#pestana:hover{color:#0f6a7c;background:#e2f3f7;}"
            "QFrame#panelan QPushButton#pestana:checked{background:#1995AD;color:white;font-weight:600;}"
            "QFrame#panelan QScrollBar:vertical{background:#eef1f4;width:10px;}"
            "QFrame#panelan QScrollBar::handle:vertical{background:#c3ccd4;border-radius:5px;min-height:30px;}")
        h = QtWidgets.QHBoxLayout(self)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(0)
        # barra de análisis, pegada al visor (como MetronTrack): ícono dibujado + nombre
        barra = QtWidgets.QFrame()
        barra.setFixedWidth(84)
        barra.setStyleSheet("QFrame{background:#eef1f4;border-top-left-radius:12px;border-bottom-left-radius:12px;}")
        bv = QtWidgets.QVBoxLayout(barra)
        bv.setContentsMargins(5, 6, 5, 6)
        bv.setSpacing(2)
        self.grupo = QtWidgets.QButtonGroup(self)
        for i, (clave, texto, corto) in enumerate(ANALISIS):
            b = QtWidgets.QToolButton()
            b.setIcon(icono(clave))
            b.setIconSize(QtCore.QSize(26, 26))
            b.setText(corto)
            b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
            b.setToolTip(texto)
            b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor)
            b.setFixedSize(74, 52)
            b.setStyleSheet(f"QToolButton{{border:none;border-radius:10px;font-size:8pt;background:transparent;"
                            f"color:#4a5560;padding:2px 0;}}"
                            f"QToolButton:hover{{background:#dfe6eb;}}"
                            f"QToolButton:checked{{background:{TURQ};color:white;font-weight:600;}}"
                            f"QToolButton:disabled{{color:#b8c0c8;}}")
            self.grupo.addButton(b, i)
            bv.addWidget(b, 0, Qt.AlignHCenter)
        bv.addStretch(1)
        self.grupo.idClicked.connect(lambda i: self.mostrar(ANALISIS[i][0]))
        h.addWidget(barra)
        # tarjeta
        tarjeta = QtWidgets.QWidget()
        tarjeta.setFixedWidth(430)
        tv = QtWidgets.QVBoxLayout(tarjeta)
        tv.setContentsMargins(14, 12, 10, 12)
        self.t_titulo = QtWidgets.QLabel("Análisis")
        self.t_titulo.setStyleSheet("font-size:13pt;font-weight:700;color:#1f2933;")
        tv.addWidget(self.t_titulo)
        self.t_que = etiqueta("", muted=True)
        tv.addWidget(self.t_que)
        self.scroll = QtWidgets.QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.scroll.setStyleSheet("QScrollArea{background:transparent;border:none;}")
        self.scroll.viewport().setObjectName("vp")
        self.scroll.viewport().setStyleSheet("QWidget#vp{background:transparent;}")
        tv.addWidget(self.scroll, 1)
        self.b_norma = QtWidgets.QToolButton()
        self.b_norma.setText("Valor de referencia ▾")
        self.b_norma.setCheckable(True)
        self.b_norma.setStyleSheet("QToolButton{border:none;color:#3d4753;font-weight:600;background:transparent;}")
        self.b_norma.toggled.connect(lambda on: (self.l_norma.setVisible(on),
                                                 self.b_norma.setText("Valor de referencia " + ("▴" if on else "▾"))))
        tv.addWidget(self.b_norma)
        self.l_norma = etiqueta("", muted=True)
        self.l_norma.setVisible(False)
        tv.addWidget(self.l_norma)
        tv.addWidget(etiqueta("Úselo junto con las condiciones clínicas.", muted=True))
        h.addWidget(tarjeta)
        self.esperando("Abre un caso para analizarlo.")

    # ------------------------------------------------------------------ estados
    def _contenido(self, w):
        w.setObjectName("contenido")
        w.setStyleSheet("QWidget#contenido{background:transparent;} QLabel{color:#1f2933;}")
        old = self.scroll.takeWidget()
        if old is not None:
            old.deleteLater()
        self.scroll.setWidget(w)

    def esperando(self, texto):
        self.caso = self.res = None
        self.t_titulo.setText("Análisis")
        self.t_que.setText("")
        self.l_norma.setText("")
        w = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(w)
        lb = etiqueta(texto)
        lb.setStyleSheet("color:#3d4753;font-size:11pt;")
        v.addWidget(lb)
        v.addStretch(1)
        self._contenido(w)
        for b in self.grupo.buttons():
            b.setEnabled(False)

    def poner_caso(self, caso):
        self.caso = caso
        for b in self.grupo.buttons():
            b.setEnabled(True)
        self.remedir(redibujar=False)
        self.mostrar(self.actual)

    def remedir(self, redibujar=True):
        self.res = A.medir(self.caso)
        # Moyers solo existe en dentición mixta: en permanente su botón no aparece
        mixta = bool(self.res.get("mixta"))
        self.grupo.button([k for k, _, _ in ANALISIS].index("moyers")).setVisible(mixta)
        if not mixta and self.actual == "moyers":
            self.actual = "resumen"
        if redibujar:
            self.mostrar(self.actual, mover_camara=False)

    # ------------------------------------------------------------------ mostrar un análisis
    @property
    def vista(self):
        """Lo que se dibuja en el modelo: el análisis o, en «Relación oclusal», su pestaña."""
        if self.actual == "arcada":
            return {"ancho": "arcada"}.get(self.sub["arcada"], self.sub["arcada"])
        return self.sub["oclusion"] if self.actual == "oclusion" else self.actual

    def mostrar(self, clave, mover_camara=True):
        if clave in DE_SUB:  # p. ej. «molar» → Relación oclusal, pestaña Relación molar
            self.sub[DE_SUB[clave]] = clave
            clave = DE_SUB[clave]
        self.actual = clave
        self.punto_activo = None
        if self.pagina._clic == "punto":
            self.pagina.modo_clic(None)
        self.grupo.button([k for k, _, _ in ANALISIS].index(clave)).setChecked(True)
        self.t_titulo.setText(dict((k, t) for k, t, _ in ANALISIS)[clave])
        ayuda = self.vista
        self.t_que.setText(QUE_MIDE[ayuda])
        self.l_norma.setText(NORMA.get(ayuda, ""))
        self.b_norma.setVisible(ayuda in NORMA)
        self.l_norma.setVisible(self.b_norma.isChecked() and ayuda in NORMA)
        if self.res is None:
            return
        w = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(w)
        v.setContentsMargins(0, 4, 4, 4)
        if not self.caso.etiquetas and clave not in SIN_DIENTES and self.vista not in SIN_DIENTES:
            # sin los dientes identificados no se analiza: los números saldrían de dientes equivocados
            if clave == "oclusion":
                v.addWidget(self._pestanas(clave))  # para poder pasar a «Corte de oclusión», que sí se puede usar
            self._card_faltan_dientes(v)
            v.addStretch(1)
            self._contenido(w)
            self.pagina.dibujar_analisis("bloqueado", self.caso, self.res, mover_camara)
            return
        if clave in SUBS:
            v.addWidget(self._pestanas(clave))
        getattr(self, "_card_" + (self.vista if clave == "oclusion" else clave))(v)
        if clave in ("espacio", "bolton") and self.caso.etiquetas:
            v.addWidget(self._ajuste_diente())
        if self.vista in PUNTOS and self.vista not in ("molar", "canina"):  # en molar y canina se arrastran en el modelo
            v.addWidget(self._ajustar(self.vista))
        v.addStretch(1)
        self._contenido(w)
        self.pagina.dibujar_analisis(self.vista, self.caso, self.res, mover_camara)

    def _pestanas(self, clave):
        w = QtWidgets.QWidget()
        g = QtWidgets.QGridLayout(w)
        g.setContentsMargins(0, 0, 0, 4)
        g.setSpacing(4)
        grupo = QtWidgets.QButtonGroup(w)
        subs = SUBS[clave]
        por_fila = 4 if clave == "espacio" else 2
        for i, (sub, texto) in enumerate(subs):
            b = QtWidgets.QPushButton(texto)
            b.setCheckable(True)
            b.setChecked(self.sub[clave] == sub)
            b.setObjectName("pestana")
            grupo.addButton(b, i)
            g.addWidget(b, i // por_fila, i % por_fila)
        grupo.idClicked.connect(lambda i, clave=clave: self._elegir_sub(clave, SUBS[clave][i][0]))
        return w

    def _elegir_sub(self, clave, sub):
        self.sub[clave] = sub
        self.mostrar(clave, mover_camara=(clave in ("oclusion", "arcada")))

    def _ajustar(self, clave):
        from .odontograma import Odontograma

        caja = QtWidgets.QGroupBox("Ajustar puntos" if clave != "overjet" else "Ajustar cortes")
        caja.setStyleSheet("QGroupBox{color:#3d4753;font-weight:600;border:1px solid #d5dbe1;border-radius:8px;"
                           "margin-top:10px;padding-top:12px;}")
        g = QtWidgets.QGridLayout(caja)
        self._bpuntos = QtWidgets.QButtonGroup(caja)
        self._bpuntos.setExclusive(True)
        self._odo = None
        dientes = [pt for pt in PUNTOS[clave] if len(pt) == 3 and pt[2].isdigit()]
        otros = [pt for pt in PUNTOS[clave] if pt not in dientes]
        fila = 0
        if dientes:  # los dientes se eligen en un dibujo, no en una cuadrícula de números
            g.addWidget(etiqueta("Haz clic en un diente del dibujo y luego en el modelo, donde va su punto. Se vuelve "
                                 "a medir solo.", muted=True), fila, 0, 1, 4)
            tocados = set(self.caso.P.get("tocados") or [])
            sel = self.punto_activo[2] if self.punto_activo in dientes else None
            self._odo = Odontograma(elegibles=[pt[2] for pt in dientes],
                                    tocados=[pt[2] for pt in dientes if f"{pt[1]}:{pt[2]}" in tocados], sel=sel,
                                    textos={pt[2]: f"Diente {pt[2]}" + (" · ajustado a mano" if f"{pt[1]}:{pt[2]}" in tocados else "")
                                            for pt in dientes})
            self._odo.elegido.connect(lambda t: self._elegir_punto(next((pt for pt in dientes if pt[2] == t), None)))
            g.addWidget(self._odo, fila + 1, 0, 1, 4, Qt.AlignHCenter)
            fila += 2
            if any(f"{pt[1]}:{pt[2]}" in tocados for pt in dientes):
                g.addWidget(etiqueta('<span style="color:#f2643d;">●</span> ajustado a mano', muted=True), fila, 0, 1, 4)
                fila += 1
        if otros:
            if not dientes:
                g.addWidget(etiqueta("Elige un punto y haz clic en el modelo donde debe ir. Se vuelve a medir solo.",
                                     muted=True), fila, 0, 1, 4)
                fila += 1
            por_fila = 2
            for i, pt in enumerate(otros):
                texto = texto_punto(pt)
                b = QtWidgets.QPushButton(("Contacto " + texto) if pt[2].startswith("c") else texto)
                b.setCheckable(True)
                b.setStyleSheet(f"QPushButton:checked{{background:{TURQ};color:white;}}")
                b.toggled.connect(lambda on, pt=pt: self._elegir_punto(pt if on else None))
                self._bpuntos.addButton(b)
                g.addWidget(b, fila + i // por_fila, (i % por_fila) * 2, 1, 2)
            fila += (len(otros) + 1) // por_fila
        b_res = QtWidgets.QPushButton("Restablecer automático")
        b_res.setFlat(True)
        b_res.setCursor(Qt.PointingHandCursor)
        b_res.setStyleSheet("QPushButton{background:transparent;border:none;color:#1995AD;text-decoration:underline;"
                            "padding:2px;text-align:left;}QPushButton:hover{color:#0f6a7c;}")
        b_res.clicked.connect(self._restablecer)
        g.addWidget(b_res, fila, 0, 1, 4)
        return caja

    def _elegir_punto(self, pt):
        self.punto_activo = pt
        self.pagina.modo_clic("punto" if pt else None)

    def mover_punto(self, jaw, x, y, z=0.0):
        """El doctor hizo clic en el modelo con un punto elegido: (x, y, z) en el marco del análisis."""
        if not self.punto_activo or self.caso is None:
            return False
        pj, donde, nombre = self.punto_activo[:3]
        if pj != jaw:
            self.pagina.aviso(f"Ese punto va en la arcada {'superior' if pj == 'sup' else 'inferior'}.")
            return True
        P = self.caso.P
        xyz = [round(float(x), 2), round(float(y), 2), round(float(z), 2)]
        if donde in ("inc", "cen", "sup", "inf") and f"{donde}:{nombre}" not in P.setdefault("tocados", []):
            P["tocados"].append(f"{donde}:{nombre}")  # para la marquita del odontograma
        if donde == "inc":
            P["incisivos"][nombre] = xyz[0]
        elif donde == "cen":
            P["centros"][jaw][nombre] = xyz[:2]
            if nombre in P[jaw]:
                P[jaw][nombre] = P["centros"][jaw][nombre]
        elif donde == "aj":  # clase molar / canina (punto 3D) y líneas medias (solo x)
            P.setdefault("ajustes", {})[nombre] = xyz[0] if nombre.startswith("lm_") else xyz
        elif donde == "md":  # punto mesial o distal de un diente: cambia su ancho
            diente, extremo = nombre
            P.setdefault("md", {}).setdefault(diente, {})[extremo] = xyz
            md = A.mesiodistal(self.caso).get(diente)
            if md:
                self.caso.anchos[diente] = round(md["ancho"], 1)
                self.caso.anchos_fuente = "doctor"
        else:
            P[jaw][nombre] = xyz[:2]
            if nombre in P["centros"][jaw]:
                P["centros"][jaw][nombre] = P[jaw][nombre]
        activo = self.punto_activo
        self.pagina.guardar_ediciones()
        self.remedir()
        # dejar elegido el siguiente punto de la lista (más rápido para ajustar varios)
        lista = PUNTOS.get(self.vista, [])
        if activo in lista and len(lista) > 2:
            sig = lista[(lista.index(activo) + 1) % len(lista)]
            if getattr(self, "_odo", None) is not None and len(sig) == 3 and sig[2].isdigit():
                self._odo.elegir(sig[2])
            for b in self._bpuntos.buttons():
                if b.text() in (texto_punto(sig), "Contacto " + texto_punto(sig)):
                    b.setChecked(True)
        return True

    # --- ajustes a criterio del doctor
    def mover_md(self, jaw, diente, extremo, x, y, z, final=False):
        """El doctor arrastra el punto mesial («m») o distal («d») de un diente sobre su superficie: cambia su
        ancho. Mientras arrastra, las tablas se vuelven a medir unas veces por segundo; al soltar (`final`), se
        guarda. → el ancho nuevo (mm)."""
        if self.caso is None:
            return None
        self.caso.P.setdefault("md", {}).setdefault(diente, {})[extremo] = [round(float(x), 2), round(float(y), 2),
                                                                           round(float(z), 2)]
        md = A.mesiodistal(self.caso).get(diente)
        if md:
            self.caso.anchos[diente] = round(md["ancho"], 1)
            self.caso.anchos_fuente = "doctor"
        if final:
            self._t_md.stop()
            self.pagina.guardar_ediciones()
            self.remedir()
        elif not self._t_md.isActive():
            self._t_md.start(110)
        return md["ancho"] if md else None

    def _md_en_vivo(self):
        self.remedir()
        self.pagina.md_tras_remedir()

    def elegir_diente(self, jaw, fdi):
        """Clic en un diente del modelo (Apiñamiento / Bolton): queda elegido para mover sus puntos mesial y distal."""
        nombre = str(fdi)
        if nombre[0] in "5678":
            nombre = str(int(nombre[0]) - 4) + nombre[1]
        self.diente_sel = (jaw, nombre)
        self.mostrar(self.actual, mover_camara=False)

    def _ajuste_diente(self):
        caja = QtWidgets.QGroupBox("Ajustar un diente")
        caja.setStyleSheet("QGroupBox{color:#3d4753;font-weight:600;border:1px solid #d5dbe1;border-radius:8px;"
                           "margin-top:10px;padding-top:12px;}")
        g = QtWidgets.QGridLayout(caja)
        # el odontograma: aquí sale qué diente es (y su ancho) al hacer clic en el modelo, o se elige desde aquí
        md_todos = self.res.get("md") or {}
        if md_todos:
            from .odontograma import Odontograma

            ajustados = set(self.caso.P.get("md") or {})
            textos = {}
            for d in md_todos:
                w = A.ancho(self.caso.anchos, d) or md_todos[d].get("ancho", 0)
                textos[d] = f"ancho {w:.1f} mm" + (" · ajustado a mano" if d in ajustados else "")
            odo = Odontograma(elegibles=list(md_todos), tocados=[d for d in md_todos if d in ajustados], textos=textos,
                              sel=self.diente_sel[1] if self.diente_sel else None)
            odo.elegido.connect(self._odo_diente)
            g.addWidget(odo, 0, 0, 1, 2, Qt.AlignHCenter)
        if not self.diente_sel:
            g.addWidget(etiqueta("Si la línea verde de un diente quedó mal, <b>arrastra el punto de su extremo</b> "
                                 "sobre el diente. Haz clic en un diente para ver su número y su ancho.", True),
                        1, 0, 1, 2)
            return caja
        jaw, t = self.diente_sel
        md = (self.res.get("md") or {}).get(t)
        ancho = A.ancho(self.caso.anchos, t) or (md or {}).get("ancho", 0)
        g.addWidget(etiqueta(f"<b>Diente {t}</b> · ancho mesiodistal {ancho:.1f} mm"), 1, 0, 1, 2)
        g.addWidget(etiqueta("<b>Arrastra</b> cualquiera de sus dos puntos (mesial o distal) sobre el diente para "
                             "corregir su línea; al soltar queda. O elige el punto aquí y haz clic en el modelo.",
                             True), 2, 0, 1, 2)
        self._bpuntos = QtWidgets.QButtonGroup(caja)
        for i, (extremo, texto) in enumerate((("m", "Mover punto mesial"), ("d", "Mover punto distal"))):
            b = QtWidgets.QPushButton(texto)
            b.setCheckable(True)
            b.toggled.connect(lambda on, e=extremo: self._elegir_punto((jaw, "md", (t, e)) if on else None))
            self._bpuntos.addButton(b)
            g.addWidget(b, 3, i)
        if (self.caso.P.get("md") or {}).get(t):
            b = QtWidgets.QPushButton("Regresar este diente a lo automático")
            b.clicked.connect(lambda: self._soltar_diente(t))
            g.addWidget(b, 4, 0, 1, 2)
        return caja

    def _soltar_diente(self, t):
        (self.caso.P.get("md") or {}).pop(t, None)
        md = A.mesiodistal(self.caso).get(t)
        escaner = ((self.caso.AD or {}).get("anchos") or {}).get(t)
        if escaner or md:
            self.caso.anchos[t] = escaner or round(md["ancho"], 1)
        self.pagina.guardar_ediciones()
        self.remedir()

    def _combo_criterio(self, clave, opciones, calculado=""):
        """Lista para que el doctor fije un valor a su criterio («Automático» = lo calculado)."""
        cb = QtWidgets.QComboBox()
        cb.setStyleSheet("QComboBox{background:#ffffff;color:#1f2933;border:1px solid #cfd6dd;border-radius:6px;"
                         "padding:3px 8px;}QComboBox QAbstractItemView{background:#ffffff;color:#1f2933;"
                         "selection-background-color:#1995AD;selection-color:white;}")
        cb.addItem("Automático" + (f" ({calculado})" if calculado else ""), "")
        for o in opciones:
            cb.addItem(o, o)
        fijo = self.caso.criterio.get(clave, "")
        cb.setCurrentIndex(max(0, cb.findData(fijo)))
        cb.currentIndexChanged.connect(lambda _i, cb=cb: self._fijar_criterio(clave, cb.currentData()))
        return cb

    def _fijar_criterio(self, clave, valor):
        if valor:
            self.caso.criterio[clave] = valor
        else:
            self.caso.criterio.pop(clave, None)
        self.pagina.guardar_ediciones()
        QtCore.QTimer.singleShot(0, self.remedir)  # la lista se destruye al redibujar: después de este evento

    def _fila_criterio(self, v, titulo, combos):
        caja = QtWidgets.QGroupBox(titulo)
        caja.setStyleSheet("QGroupBox{color:#3d4753;font-weight:600;border:1px solid #d5dbe1;border-radius:8px;"
                           "margin-top:10px;padding-top:12px;}")
        f = QtWidgets.QFormLayout(caja)
        for texto, combo in combos:
            lb = QtWidgets.QLabel(texto)
            lb.setStyleSheet("color:#1f2933;")
            f.addRow(lb, combo)
        v.addWidget(caja)

    def _card_faltan_dientes(self, v):
        from .pagina import puede_enviar

        aviso = etiqueta("<b>Primero hay que identificar los dientes.</b>")
        aviso.setStyleSheet("color:#b3541e;font-size:11pt;")
        v.addWidget(aviso)
        v.addWidget(etiqueta("Este caso no trae la separación de dientes (cada diente con su número). Sin ella el "
                             "análisis mediría dientes equivocados, así que no se muestra."))
        if puede_enviar():
            from . import dientes_ia

            if dientes_ia.disponible():
                b = QtWidgets.QPushButton("Identificar los dientes con IA")
                b.setCursor(Qt.PointingHandCursor)
                b.setStyleSheet(f"QPushButton{{background:{TURQ};color:white;border:none;border-radius:8px;"
                                f"padding:9px 12px;font-weight:600;font-size:10pt;}}"
                                f"QPushButton:hover{{background:#147a8f;}}")
                b.clicked.connect(self.pagina.identificar_ia)
                v.addWidget(b)
                v.addWidget(etiqueta("Tarda cerca de medio minuto. Es una <b>propuesta</b>: al terminar revisa en "
                                     "«Dientes» que cada número sea el correcto (clic en un diente para corregirlo) "
                                     "antes de usar el análisis.", True))
                v.addWidget(etiqueta("<b>O con MetronTrack</b> (la numeración que tú revisas ahí):"))
            v.addWidget(etiqueta("<b>Cómo se identifica</b><br>"
                                 "1. Abre este caso en IntraoralScan → MetronTrack → <b>Marcar diente</b>.<br>"
                                 "2. Revisa que cada diente tenga su número y corrige el que esté mal.<br>"
                                 "3. Entra a «Análisis de medidas» para que se guarde, y cierra MetronTrack.<br>"
                                 "4. Vuelve a abrir aquí la carpeta del caso."))
        else:
            v.addWidget(etiqueta("Pide a 3D OrthoLab que te vuelva a mandar el caso con los dientes identificados."))
        v.addWidget(etiqueta("Mientras tanto puedes ver los modelos, usar «Oclusión → Corte de oclusión» y medir con «Medir».", True))

    def _card_dientes(self, v):
        if not self.caso.etiquetas:
            self._card_faltan_dientes(v)
            return
        filas = []
        for jaw, nombre in (("sup", "Superior"), ("inf", "Inferior")):
            lab = self.caso.dientes(jaw)
            nums = sorted(int(t) for t in set(lab.tolist()) if t) if lab is not None else []
            filas.append([nombre, str(len(nums)), " ".join(str(n) for n in nums)])
        if getattr(self.pagina, "_dientes_locales", False):
            aviso = etiqueta("<b>Numeración propuesta por la IA: revísala.</b> Puede equivocarse de número, sobre todo "
                             "si faltan dientes. Recorre los dientes con el ratón y corrige el que esté mal.")
            aviso.setStyleSheet("color:#b3541e;")
            v.addWidget(aviso)
        v.addWidget(self._barra_marcar())
        if self.md_modo == "area":
            self._card_area(v)
            return
        den = self.res.get("denticion") or {}
        fila = QtWidgets.QWidget()
        fh = QtWidgets.QHBoxLayout(fila)
        fh.setContentsMargins(0, 0, 0, 0)
        fh.addWidget(etiqueta("<b>Dentición</b>"))
        fh.addWidget(self._combo_criterio("denticion", ["Permanente", "Mixta"],
                                          "mixta" if den.get("temporales") else "permanente"), 1)
        v.addWidget(fila)
        if den.get("dudosa"):
            v.addWidget(etiqueta("Falta algún canino o premolar y no hay dientes de leche marcados. Si es dentición "
                                 "mixta, elígela aquí (o marca los dientes de leche): solo así aparece Moyers.", True))
        v.addWidget(self._cuadro_dientes())
        pista = {"agregar": "<b>Añadir dientes:</b> haz <b>doble clic</b> sobre el diente que falta. Si está pegado a "
                            "otro (apiñados y pintados como uno), se separa por el surco entre los dos.",
                 "borrar": "<b>Borrar:</b> haz clic en el diente (o pedazo) que no debe estar marcado.",
                 "leche": "<b>Dientes de leche:</b> haz clic en un diente para marcarlo como temporal (o de vuelta "
                          "a permanente)."}.get(self.md_modo)
        if self.md_num:
            pista = (f"<b>Diente {self.md_num} elegido.</b> Haz clic en ese diente en el modelo para ponerle el "
                     f"número, o doble clic donde falta para marcarlo como {self.md_num}.")
        v.addWidget(etiqueta(pista or "Doble clic sobre un diente que falta lo añade. Clic en un diente: cambiar "
                                      "su número, dividirlo o unirlo. O elige el número en el cuadro y márcalo."))
        self._aviso_dudosos_dientes(v)
        if getattr(self.pagina, "_dientes_locales", False):
            from . import dientes_ia

            if dientes_ia.disponible():
                b = QtWidgets.QPushButton("Volver a identificar con IA")
                b.clicked.connect(self.pagina.identificar_ia)
                v.addWidget(b)
        elif getattr(self.pagina, "_dientes_fijos", False):
            b = QtWidgets.QPushButton("Deshacer mis correcciones de dientes")
            b.setToolTip("Regresa a la separación de dientes con la que llegó el caso")
            b.clicked.connect(self._deshacer_renombres)
            v.addWidget(b)
        elif self.caso.renombres:
            v.addWidget(etiqueta(f"Has hecho {len(self.caso.renombres)} corrección(es) a los dientes.", True))
            b = QtWidgets.QPushButton("Deshacer mis correcciones de dientes")
            b.clicked.connect(self._deshacer_renombres)
            v.addWidget(b)

    # ------------------------------------------------------------------ «Marcar diente» (como MetronTrack)
    def _barra_marcar(self):
        w = QtWidgets.QWidget()
        h = QtWidgets.QHBoxLayout(w)
        h.setContentsMargins(0, 2, 0, 2)
        h.setSpacing(4)
        for clave, texto, ayuda in (("area", "✎ Modificar área", "Pintar o borrar a mano el área de un diente"),
                                    ("agregar", "＋ Añadir", "Añadir dientes: doble clic en la zona"),
                                    ("borrar", "✕ Borrar", "Clic en un diente para quitarle la marca"),
                                    ("leche", "De leche", "Dientes de leche: clic en un diente, temporal / permanente")):
            b = QtWidgets.QPushButton(texto)
            b.setStyleSheet("padding:5px 5px;")
            b.setCheckable(True)
            b.setChecked(self.md_modo == clave)
            b.setToolTip(ayuda)
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda on, k=clave: self._md_poner(k if on else None, None))
            h.addWidget(b)
        for texto, ayuda, hay, fn in (("↶", "Deshacer", bool(self.caso._hist), self._md_deshacer),
                                      ("↷", "Rehacer", bool(self.caso._rehacer), self._md_rehacer)):
            b = QtWidgets.QPushButton(texto)
            b.setToolTip(ayuda)
            b.setFixedWidth(34)
            b.setEnabled(hay)
            b.clicked.connect(fn)
            h.addWidget(b)
        return w

    def _cuadro_dientes(self):
        """Los 32 dientes dibujados: de color los marcados. Un clic elige el número para ponerlo a mano en el modelo."""
        from .odontograma import Odontograma

        llenos, textos = [], {}
        for jaw in ("sup", "inf"):
            lab = self.caso.dientes(jaw)
            for n in (int(t) for t in np.unique(lab) if t) if lab is not None else ():
                t = str(n - 40 if n > 50 else n)
                llenos.append(t)
                textos[t] = f"Diente {n} · de leche" if n > 50 else f"Diente {n} · marcado"
        odo = Odontograma(elegibles=None, llenos=llenos, textos=textos, sel=str(self.md_num) if self.md_num else None)
        odo.elegido.connect(lambda t: QtCore.QTimer.singleShot(0, lambda: self._md_poner(None, int(t) if t else None)))
        w = QtWidgets.QWidget()
        h = QtWidgets.QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        h.addWidget(odo, 0, Qt.AlignHCenter)
        return w

    def _md_poner(self, modo, num):
        if self.md_modo == "area" and modo != "area" and self.md_sel:
            self._area_terminar(True)  # salir de «Modificar área» guarda lo pintado
        self.md_modo, self.md_num = modo, num
        if modo != "area":
            self.md_sel = None
        self.mostrar("dientes", mover_camara=False)

    # ------------------------------------------------------------------ «Modificar área» (pincel y goma)
    def _card_area(self, v):
        if not self.md_sel:
            v.addWidget(etiqueta("<b>Por favor, selecciona un diente</b>: haz clic en él en el modelo."))
            v.addWidget(etiqueta("Después lo retocas con el lápiz (pintar lo que es de ese diente) o la goma (quitar "
                                 "lo que no). Sirve para dientes apiñados que quedaron mal separados.", True))
            return
        jaw, fdi = self.md_sel
        v.addWidget(etiqueta(f"<b>Diente {fdi}</b> (en naranja). Pinta con el botón izquierdo sobre el modelo; para "
                             "girarlo usa el botón derecho."))
        fila = QtWidgets.QWidget()
        h = QtWidgets.QHBoxLayout(fila)
        h.setContentsMargins(0, 2, 0, 2)
        h.setSpacing(4)
        for goma, texto, ayuda in ((False, "✎ Lápiz", "Pintar: esto es del diente"), (True, "◻ Goma", "Borrar: esto no es del diente")):
            b = QtWidgets.QPushButton(texto)
            b.setCheckable(True)
            b.setChecked(self.md_goma == goma)
            b.setToolTip(ayuda)
            b.clicked.connect(lambda _on, g=goma: (setattr(self, "md_goma", g), self.mostrar("dientes", mover_camara=False)))
            h.addWidget(b)
        for texto, ayuda, hay, fn in (("↶", "Deshacer", bool(self.caso._hist), self._area_deshacer),
                                      ("↷", "Rehacer", bool(self.caso._rehacer), self._area_rehacer)):
            b = QtWidgets.QPushButton(texto)
            b.setToolTip(ayuda)
            b.setFixedWidth(34)
            b.setEnabled(hay)
            b.clicked.connect(fn)
            h.addWidget(b)
        v.addWidget(fila)
        fila2 = QtWidgets.QWidget()
        h2 = QtWidgets.QHBoxLayout(fila2)
        h2.setContentsMargins(0, 0, 0, 0)
        h2.addWidget(etiqueta("Mínimo", True))
        sl = QtWidgets.QSlider(Qt.Horizontal)
        sl.setRange(4, 40)  # décimas de mm
        sl.setValue(int(round(self.md_radio * 10)))
        sl.setToolTip("Tamaño del pincel")
        sl.valueChanged.connect(lambda x: setattr(self, "md_radio", x / 10.0))
        h2.addWidget(sl, 1)
        h2.addWidget(etiqueta("Máximo", True))
        v.addWidget(fila2)
        fila3 = QtWidgets.QWidget()
        h3 = QtWidgets.QHBoxLayout(fila3)
        h3.setContentsMargins(0, 4, 0, 0)
        bx = QtWidgets.QPushButton("✕ Cancelar")
        bx.clicked.connect(lambda: self._area_terminar(False))
        bok = QtWidgets.QPushButton("✓ Listo")
        bok.setStyleSheet(f"QPushButton{{background:{TURQ};color:white;border:none;font-weight:600;}}")
        bok.clicked.connect(lambda: self._area_terminar(True))
        otro = QtWidgets.QPushButton("Otro diente")
        otro.setToolTip("Guardar este y elegir otro diente para retocar")
        otro.clicked.connect(lambda: (self._area_terminar(True, seguir=True)))
        for b in (bx, otro, bok):
            h3.addWidget(b)
        v.addWidget(fila3)

    def area_elegir(self, jaw, fdi):
        """Clic en un diente con «Modificar área» activa y sin diente elegido."""
        self.md_sel = (jaw, int(fdi))
        self._md_antes = self.caso._foto()
        self.mostrar("dientes", mover_camara=False)

    def area_trazo(self):
        """La página avisa que terminó un trazo: se actualizan los botones de deshacer."""
        self.mostrar("dientes", mover_camara=False)

    def _area_deshacer(self):
        if self.caso.deshacer():
            self.mostrar("dientes", mover_camara=False)

    def _area_rehacer(self):
        if self.caso.rehacer():
            self.mostrar("dientes", mover_camara=False)

    def _area_terminar(self, guardar, seguir=False):
        if not guardar and self._md_antes is not None:
            self.caso.etiquetas, self.caso.renombres = self._md_antes
        self._md_antes = None
        self.md_sel = None
        if not seguir:
            self.md_modo = None
        self.caso._refrescar_puntos()
        if guardar:
            self.pagina.guardar_dientes(fijo=True)
            self.pagina.guardar_ediciones()
        self.remedir()

    def _md_hecho(self, texto=None):
        self.pagina.guardar_dientes()
        self.pagina.guardar_ediciones()
        self.remedir()
        if texto:
            self.pagina.aviso(texto)

    def _md_deshacer(self):
        if self.caso.deshacer():
            self._md_hecho("Deshecho.")

    def _md_rehacer(self):
        if self.caso.rehacer():
            self._md_hecho("Rehecho.")

    def _md_arcada(self, jaw, num):
        return (jaw == "sup") == (int(num) // 10 in (1, 2, 5, 6))

    def marcar_doble_clic(self, jaw, pid):
        """Doble clic sobre el modelo en «Dientes»: añade ahí un diente (con el número elegido, si hay)."""
        num = self.md_num
        if num and not self._md_arcada(jaw, num):
            self.pagina.aviso(f"El {num} es de la otra arcada.")
            return
        if not num and self.md_preguntar:
            lab = self.caso.dientes(jaw)
            sel = SelectorNumero(jaw, set(int(t) for t in np.unique(lab) if t), self.window())
            p = QtGui.QCursor.pos()
            sel.move(p.x() + 14, max(0, p.y() - 120))
            if not sel.exec() or not sel.numero:
                return  # ✕: no se añade nada
            num = sel.numero
        puesto = self.caso.agregar_diente(jaw, pid, num)
        if puesto is None:
            self.pagina.aviso("No pude marcar un diente ahí. Haz doble clic en el centro de la corona.")
            return
        self.md_num = None
        self._md_hecho(f"Diente {puesto} marcado. Si el número no es el correcto, haz clic en él y cámbialo."
                       + ("" if not num or puesto == num else f" (El {num} ya estaba usado.)"))

    def marcar_clic(self, jaw, fdi) -> bool:
        """Clic en un diente con una herramienta de «Marcar diente» activa. False = no había: va el menú."""
        if self.md_modo == "area":
            return True  # el clic ya lo usó el pincel (o eligió el diente)
        if self.md_modo == "borrar":
            self.caso.renumerar(jaw, fdi, 0)
            self._md_hecho(f"Diente {fdi} borrado.")
            return True
        if self.md_modo == "leche":
            k, q = fdi % 10, fdi // 10
            if q <= 4 and k > 5:
                self.pagina.aviso("Solo hay dientes de leche del 1 al 5.")
                return True
            self.caso.renumerar(jaw, fdi, fdi + 40 if q <= 4 else fdi - 40)
            self._md_hecho()
            return True
        if self.md_num:
            if not self._md_arcada(jaw, self.md_num):
                self.pagina.aviso(f"El {self.md_num} es de la otra arcada.")
                return True
            num, self.md_num = self.md_num, None
            self.caso.renumerar(jaw, fdi, num)
            self._md_hecho(f"Ese diente ahora es el {num}.")
            return True
        return False

    def _deshacer_renombres(self):
        if self.pagina.quitar_dientes_fijos():
            return  # se volvió a abrir el caso con la separación con la que llegó
        self.caso.restaurar_dientes()
        self.pagina.guardar_ediciones()
        self.remedir()

    def dividir(self, jaw, fdi, x, y):
        nuevo = self.caso.dividir(jaw, fdi, x, y)
        if nuevo is None:
            self.pagina.aviso("No pude dividirlo ahí: haz clic justo donde se tocan los dos dientes.")
            return
        self.pagina.guardar_dientes()
        self.pagina.guardar_ediciones()
        self.remedir()
        self.pagina.aviso(f"Dividido: quedaron el {fdi} y el {nuevo}. Si algún número no es el correcto, haz clic "
                          "en el diente y cámbialo.")

    def unir(self, jaw, a, b):
        self.caso.unir(jaw, a, b)
        self.pagina.guardar_dientes()
        self.pagina.guardar_ediciones()
        self.remedir()

    def renumerar(self, jaw, antes, ahora):
        self.caso.renumerar(jaw, antes, ahora)
        self.pagina.guardar_dientes()
        self.pagina.guardar_ediciones()
        self.remedir()

    def _restablecer(self):
        if self.caso is None:
            return
        self.caso.reproponer()
        self.pagina.guardar_ediciones()
        self.remedir()

    # ------------------------------------------------------------------ tarjetas
    def _card_resumen(self, v):
        filas = sorted(self.res["resumen"], key=lambda f: (0 if f[0] in (1, 2, 3) else 1 if f[0] == 0 else 2, -f[0]))
        revisar = sum(1 for f in filas if f[0] in (1, 2, 3))
        bien = sum(1 for f in filas if f[0] == 0)
        cab = QtWidgets.QWidget()
        ch = QtWidgets.QHBoxLayout(cab)
        ch.setContentsMargins(0, 0, 0, 4)
        ch.setSpacing(8)
        for n, texto, color, fondo in ((revisar, "a revisar", "#b36a08", "#fdf3e1"), (bien, "en norma", "#1f8a4c", "#e6f5ec")):
            caja = QtWidgets.QLabel(f"<span style='font-size:17pt;font-weight:700;color:{color};'>{n}</span>"
                                    f"<br><span style='color:{color};'>{texto}</span>")
            caja.setTextFormat(Qt.RichText)
            caja.setAlignment(Qt.AlignCenter)
            caja.setStyleSheet(f"background:{fondo};border-radius:10px;padding:8px;")
            ch.addWidget(caja, 1)
        v.addWidget(cab)
        for nivel, titulo, texto, destino in filas:
            color = NIVEL.get(nivel, NIVEL[9])[0]
            palabra = {0: "en norma", 1: "leve", 2: "moderado", 3: "marcado"}.get(nivel, "sin valorar")
            b = QtWidgets.QPushButton()
            b.setCursor(Qt.PointingHandCursor)
            b.setToolTip("Ver este análisis")
            b.setStyleSheet("QPushButton{text-align:left;padding:0;border:1px solid #e1e6ea;border-radius:10px;"
                            "background:#ffffff;}QPushButton:hover{border-color:#1995AD;background:#f3fafb;}")
            lay = QtWidgets.QHBoxLayout(b)
            lay.setContentsMargins(0, 0, 10, 0)
            lay.setSpacing(10)
            barra = QtWidgets.QFrame()
            barra.setFixedWidth(5)
            barra.setStyleSheet(f"background:{color};border-top-left-radius:10px;border-bottom-left-radius:10px;")
            barra.setAttribute(Qt.WA_TransparentForMouseEvents)
            lay.addWidget(barra)
            lb = etiqueta(f"<b>{titulo}</b> &nbsp;<span style='color:{color};font-weight:600;'>{palabra}</span>"
                          f"<br><span style='color:#5b6570;'>{texto}</span>")
            lb.setAttribute(Qt.WA_TransparentForMouseEvents)
            lb.setContentsMargins(0, 7, 0, 7)
            lay.addWidget(lb, 1)
            flecha = QtWidgets.QLabel("›")
            flecha.setStyleSheet("color:#9aa5b1;font-size:14pt;")
            flecha.setAttribute(Qt.WA_TransparentForMouseEvents)
            lay.addWidget(flecha)
            b.setFixedHeight(max(52, lb.heightForWidth(330) + 6))  # al alto de su texto, sin hueco
            b.clicked.connect(lambda _=False, d=destino: self.mostrar(d))
            v.addWidget(b)
        if self.res["anchos_fuente"] == "medido":
            v.addWidget(etiqueta("Este caso no trae los anchos dentarios del escáner: se midieron aquí, sobre la línea "
                                 "mesiodistal de cada diente.", True))
        if self.res["anchos_fuente"] == "promedio":
            v.addWidget(etiqueta("Este caso no trae los anchos dentarios del escáner: Korkhaus, Bolton y Moyers usan "
                                 "anchos promedio hasta que los midas («Espacio y Bolton» → tabla de anchos).", True))
        if self.caso.P.get("revisar"):
            v.addWidget(etiqueta("Revisa la ubicación automática de: " + ", ".join(self.caso.P["revisar"]) +
                                 " (puedes moverlos en cada análisis).", True))

    def _card_overjet(self, v):
        oj = self.res["overjet"]
        ad = (self.caso.AD or {}).get("oclusion") or {}
        filas = []
        for t, r in oj.items():
            n1, t1 = A.nivel_overjet(r["overjet"])
            n2, t2 = A.nivel_overbite(r["overbite"])
            fila = [r["par"], f"{r['overjet']:.1f} {chip(t1, n1)}", f"{r['overbite']:.1f} {chip(t2, n2)}"]
            filas.append(fila)
        v.addWidget(etiqueta(tabla(["Par", "Overjet (mm)", "Overbite (mm)"], filas)))
        if ad:
            fs = [[k, mm(x.get("overjet")), mm(x.get("overbite"))] for k, x in ad.items()]
            v.addWidget(etiqueta("<b>Software del escáner</b> (todos los pares)", True))
            v.addWidget(etiqueta(tabla(["Par", "Overjet", "Overbite"], fs)))
        fila = QtWidgets.QHBoxLayout()
        fila.addWidget(etiqueta("<b>Corte sagital</b>"))
        fila.addStretch(1)
        self._seg_corte = QtWidgets.QButtonGroup(v.parentWidget())
        for i, t in enumerate(("11", "21")):
            b = QtWidgets.QPushButton(t)
            b.setCheckable(True)
            b.setFixedWidth(44)
            b.setStyleSheet(f"QPushButton:checked{{background:{TURQ};color:white;}}")
            self._seg_corte.addButton(b, i)
            fila.addWidget(b)
        v.addLayout(fila)
        self.corte = CorteSagital()
        v.addWidget(self.corte)
        self._seg_corte.idClicked.connect(lambda i: self._poner_corte(("11", "21")[i]))
        self._seg_corte.button(0).setChecked(True)
        self._poner_corte("11")

    def _poner_corte(self, t):
        r = self.res["overjet"].get(t)
        if r is None:
            self.corte.poner(None, None, None)
            return
        self.corte.poner(A.corte(self.caso, "sup", r["x"]), A.corte(self.caso, "inf", r["xl"]), r)

    def _card_corte(self, v):
        v.addWidget(etiqueta("<b>1. Haz clic en un diente</b> del modelo: el corte (el plano azul) pasa por ahí."))
        v.addWidget(etiqueta("<b>2. Mira la gráfica</b>, a la izquierda del modelo: el perfil del diente superior en "
                             "verde y del inferior en naranja, sobre una cuadrícula en mm."))
        v.addWidget(etiqueta("<b>3. Afina</b> con la barra «Mover», que recorre el corte por la arcada."))
        v.addWidget(etiqueta("<b>Tipos de corte</b><br>"
                             "<b>Por el diente</b>: atraviesa el diente de vestibular a lingual (en los incisivos es el "
                             "corte del overjet).<br>"
                             "<b>Sagital</b>: de adelante hacia atrás.<br>"
                             "<b>Transversal</b>: de lado a lado, para ver las dos hemiarcadas."))
        v.addWidget(etiqueta("Con ⤢ agrandas la gráfica.", True))

    def _card_molar(self, v):
        self._card_clase(v, "molar", "relacion_molar")

    def _card_canina(self, v):
        self._card_clase(v, "canina", "relacion_canina")

    def _card_clase(self, v, cual, clave_ad):
        """Relación molar / canina: una tarjeta por lado con la clase en grande; tocarla lleva el modelo a ese
        lado. Los puntos se acomodan arrastrándolos en el modelo (sin botones)."""
        cl = (self.res.get("clases") or {}).get(cual) or {}
        ad = (self.caso.AD or {}).get(clave_ad) or {}
        lado_visto = getattr(self.pagina, "_mini_lado", "der")
        fila = QtWidgets.QWidget()
        h = QtWidgets.QHBoxLayout(fila)
        h.setContentsMargins(0, 2, 0, 2)
        h.setSpacing(8)
        for lado, nombre, vista in (("der", "Derecha", "derecha"), ("izq", "Izquierda", "izquierda")):
            x = cl.get(lado)
            activo = lado == lado_visto
            caja = QtWidgets.QFrame()
            caja.setObjectName("lado")
            caja.setStyleSheet("QFrame#lado{background:%s;border:%s;border-radius:12px;}" % (
                ("#e2f3f7", "2px solid " + TURQ) if activo else ("#f7f9fa", "1px solid #d5dbe1")))
            cv = QtWidgets.QVBoxLayout(caja)
            cv.setContentsMargins(10, 8, 10, 10)
            cv.setSpacing(3)
            ver = QtWidgets.QPushButton(("● " if activo else "") + nombre + ("" if activo else "  ›  ver"))
            ver.setCursor(Qt.PointingHandCursor)
            ver.setToolTip("Ver el lado " + nombre.lower() + " en el modelo")
            ver.setStyleSheet("QPushButton{background:transparent;border:none;text-align:left;padding:0;color:"
                              + ("#0f6a7c" if activo else "#3d4753") + ";font-weight:700;font-size:9.5pt;}"
                              "QPushButton:hover{color:" + TURQ + ";}")
            ver.clicked.connect(lambda _on, k=vista: QtCore.QTimer.singleShot(0, lambda: self._ver_lado(k)))
            cv.addWidget(ver)
            if x:
                color = NIVEL.get(x["nivel"], NIVEL[9])[0]
                grande = QtWidgets.QLabel(x["clase"])
                grande.setAlignment(Qt.AlignCenter)
                grande.setStyleSheet("background:" + color + ";color:white;font-size:15pt;font-weight:700;"
                                     "border-radius:8px;padding:6px 2px;")
                cv.addWidget(grande)
                sentido = "en posición" if abs(x["d"]) < 0.25 else ("hacia mesial" if x["d"] > 0 else "hacia distal")
                if x.get("criterio"):
                    detalle = "fijada a tu criterio"
                elif x.get("falta"):
                    detalle = x.get("motivo") or "falta un diente de esta relación"
                else:
                    detalle = f"{abs(x['d']):.1f} mm {sentido}"
            else:
                grande = QtWidgets.QLabel("—")
                grande.setAlignment(Qt.AlignCenter)
                grande.setStyleSheet("font-size:15pt;color:#9aa4ae;padding:6px;")
                cv.addWidget(grande)
                detalle = "sin medir aquí"
            d = etiqueta(detalle, True)
            d.setAlignment(Qt.AlignCenter)
            cv.addWidget(d)
            if ad.get(lado):
                e = etiqueta("Escáner: " + ad[lado].replace("Relación ", "").lower(), True)
                e.setAlignment(Qt.AlignCenter)
                cv.addWidget(e)
            combo = self._combo_criterio(f"{cual}_{lado}", CLASES)
            combo.setItemText(0, "Volver a lo automático" if self.caso.criterio.get(f"{cual}_{lado}")
                              else "Cambiar a mi criterio…")
            combo.setToolTip("Si no estás de acuerdo con la clase medida, elige la tuya")
            cv.addWidget(combo)
            h.addWidget(caja, 1)
        v.addWidget(fila)
        if not cl:
            v.addWidget(etiqueta("Para medirla aquí hace falta la separación de dientes; se muestra lo que midió el "
                                 "escáner.", True))
            return
        if cual == "molar":
            arriba, abajo = ("cúspide mesiovestibular del primer molar superior",
                             "surco mesiovestibular del primer molar inferior")
        else:
            arriba, abajo = "cúspide del canino superior", "tronera entre el canino y el primer premolar inferiores"
        ayuda = QtWidgets.QFrame()
        ayuda.setObjectName("ayuda")
        ayuda.setStyleSheet("QFrame#ayuda{background:#f7f9fa;border-radius:10px;}")
        av = QtWidgets.QVBoxLayout(ayuda)
        av.setContentsMargins(10, 8, 10, 8)
        av.setSpacing(3)
        av.addWidget(etiqueta("<b>¿Un punto quedó mal? Arrástralo en el modelo.</b>"))
        av.addWidget(etiqueta("<span style='color:#f2643d;font-size:12pt;'>●</span> " + arriba + "<br>"
                              "<span style='color:#6c5ce7;font-size:12pt;'>●</span> " + abajo))
        av.addWidget(etiqueta("Se vuelve a medir al soltarlo.", True))
        v.addWidget(ayuda)
        b_res = QtWidgets.QPushButton("Regresar los puntos a lo automático")
        b_res.setFlat(True)
        b_res.setCursor(Qt.PointingHandCursor)
        b_res.setStyleSheet("QPushButton{background:transparent;border:none;color:#1995AD;text-decoration:underline;"
                            "padding:2px;text-align:left;}QPushButton:hover{color:#0f6a7c;}")
        b_res.clicked.connect(self._restablecer)
        v.addWidget(b_res)

    def _ver_lado(self, vista):
        self.pagina.camara(vista)
        self.mostrar(self.actual, mover_camara=False)

    def _card_lmedia(self, v):
        lm = self.res["linea_media"]
        ad = (self.caso.AD or {}).get("linea_media") or {}
        if not lm.get("valorable", True):
            v.addWidget(etiqueta(chip("No valorable", 9) + " Falta un incisivo central (" + ", ".join(lm.get("faltan", []))
                                 + "): no hay línea media que medir en esa arcada."))
            return

        def lado(x):
            return "centrada" if abs(x) < 0.05 else f"{abs(x):.1f} mm a la {'izquierda' if x > 0 else 'derecha'}"
        n = 0 if lm["mm"] <= 2 else 1 if lm["mm"] <= 4 else 2
        filas = [["Superior respecto al eje de la arcada", lado(lm["sup"])],
                 ["Inferior respecto al eje de la arcada", lado(lm["inf"])],
                 ["<b>Inferior respecto a la superior</b>",
                  f"<b>{lado(lm['inf'] - lm['sup'])}</b> {chip('aceptable' if n == 0 else 'desviada', n)}"]]
        if ad.get("mm") is not None:
            filas.append(["Escáner (inferior respecto a superior)",
                          f"{ad['mm']:.1f} mm" + (f" a la {ad['direccion'].lower()}" if ad.get("direccion") and ad["mm"] else "")])
        v.addWidget(etiqueta(tabla(["Línea media", "Desviación"], filas)))
        v.addWidget(etiqueta("<span style='color:#f2643d;'>●</span> Arcada superior &nbsp;&nbsp; "
                             "<span style='color:#6c5ce7;'>●</span> Arcada inferior"))
        v.addWidget(etiqueta("Derecha e izquierda son las del paciente. <b>Arrastra el punto</b> coral o el violeta para mover "
                             "su línea media. De lado, cada línea se ve como un plano.", True))

    def _card_contactos(self, v):
        def titulo(texto):
            lb = etiqueta(texto)
            lb.setStyleSheet("color:#6b7682;font-size:8pt;font-weight:700;letter-spacing:1px;margin-top:6px;")
            v.addWidget(lb)

        # --- 1. cómo ver las arcadas
        titulo("VER LAS ARCADAS")
        fila = QtWidgets.QWidget()
        h = QtWidgets.QHBoxLayout(fila)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(6)
        actual = {"junto": "cerradas", "abiertas": "abiertas"}.get(self.pagina.disp, "oclusal")
        self._b_ct = {}
        for clave, texto, sub, ayuda in (
                ("cerradas", "Cerradas", "en mordida", "Las arcadas en oclusión, de frente"),
                ("abiertas", "Abiertas", "boca abierta", "La boca abierta: se ven las dos caras oclusales"),
                ("oclusal", "Oclusal", "lado a lado", "Las dos arcadas por oclusal, una junto a la otra")):
            b = QtWidgets.QToolButton()
            b.setText(f"{texto}\n{sub}")
            b.setIcon(icono_vista_contactos(clave, clave == actual))
            b.setIconSize(QtCore.QSize(74, 48))
            b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
            b.setCheckable(True)
            b.setChecked(clave == actual)
            b.setToolTip(ayuda)
            b.setCursor(Qt.PointingHandCursor)
            b.setFixedSize(126, 98)
            b.setStyleSheet(f"QToolButton{{background:#f4f6f8;color:#3d4753;border:1px solid #d5dbe1;border-radius:10px;"
                            f"font-size:8.5pt;padding-top:4px;}}"
                            f"QToolButton:hover{{border-color:{TURQ};}}"
                            f"QToolButton:checked{{background:#e2f3f7;border:2px solid {TURQ};color:#0f6a7c;font-weight:600;}}")
            b.clicked.connect(lambda _on, k=clave: QtCore.QTimer.singleShot(0, lambda: self.pagina.contactos_ver(k)))
            h.addWidget(b)
            self._b_ct[clave] = b
        v.addWidget(fila)
        # --- 2. el corte
        puesto = bool(getattr(self.pagina, "_corte_contactos", False))
        bc = QtWidgets.QPushButton(("✓  Corte puesto: haz clic en un diente" if puesto else "✂  Ver el perfil de un diente (corte)"))
        bc.setCheckable(True)
        bc.setChecked(puesto)
        bc.setCursor(Qt.PointingHandCursor)
        bc.setToolTip("Pone un plano de corte y su gráfica; haz clic en un diente para llevarlo ahí")
        bc.setStyleSheet(f"QPushButton{{padding:7px;}}QPushButton:checked{{background:{TURQ};color:white;font-weight:600;}}")
        bc.clicked.connect(lambda on: QtCore.QTimer.singleShot(0, lambda: self.pagina.contactos_corte(on)))
        v.addWidget(bc)
        # --- 3. el resultado, de un vistazo
        ct = self.res["contactos"]["sup"]
        zonas = ("ant", "prem", "mol")
        der = sum(ct[f"{z}_der"]["c01"] for z in zonas)
        izq = sum(ct[f"{z}_izq"]["c01"] for z in zonas)
        total = der + izq
        if total <= 1.0:
            nivel, lectura = 2, "muy poco contacto firme"
        elif min(der, izq) <= 0.25 * total:
            nivel, lectura = 1, f"carga más el lado {'derecho' if der > izq else 'izquierdo'}"
        elif total <= 4.0:
            nivel, lectura = 1, "poco contacto firme"
        else:
            nivel, lectura = 0, "repartido en los dos lados"
        titulo("CONTACTO FIRME")
        v.addWidget(etiqueta(f"<span style='font-size:15pt;font-weight:700;'>{total:.1f} mm²</span> &nbsp;{chip(lectura, nivel)}"
                             f"<br><span style='color:#6b7682;'>derecha {der:.1f} · izquierda {izq:.1f}</span>"))
        v.addWidget(BarrasContacto(ct), 0, Qt.AlignHCenter)
        v.addWidget(etiqueta("<span style='color:#d7191c;'>■</span> firme (a menos de 0.1 mm) &nbsp; "
                             "<span style='color:#fdc98f;'>■</span> casi en contacto (a menos de 0.3 mm). Áreas en mm². "
                             "Los colores del modelo están explicados junto a él.", True))

    def contactos_marcar(self):
        """La página cambió cómo se ven las arcadas: se marca el botón que corresponde."""
        actual = {"junto": "cerradas", "abiertas": "abiertas"}.get(self.pagina.disp, "oclusal")
        try:
            for clave, b in (getattr(self, "_b_ct", None) or {}).items():
                b.setChecked(clave == actual)
                b.setIcon(icono_vista_contactos(clave, clave == actual))
        except RuntimeError:  # la tarjeta ya se redibujó
            self._b_ct = {}

    def _card_korkhaus(self, v):
        K = self.res["korkhaus"]
        if not K:
            v.addWidget(etiqueta("No se pudo medir: faltan los cortes de los incisivos."))
            return
        if not K.get("prem_id"):
            v.addWidget(etiqueta("Faltan los anchos de 12, 11, 21 y 22 para calcular lo ideal. Escríbelos en "
                                 "«Espacio y Bolton»."))
        filas = []

        def fila(nombre, med, ideal):
            if med is None:
                return [nombre, "—", "—", ""]
            if ideal is None:
                return [nombre, f"{med:.1f}", "—", ""]
            n, t = A.nivel_korkhaus(med, ideal)
            return [nombre, f"{med:.1f}", f"{ideal:.1f}", f"{med - ideal:+.1f} {chip(t, n)}"]
        filas.append(["<b>Superior</b>", "", "", ""])
        filas.append(fila("Premolar 14–24", K["prem_u"], K.get("prem_id")))
        filas.append(fila("Molar 16–26", K["mol_u"], K.get("mol_id")))
        filas.append(fila("Largo anterior Lo", K["Lo"], K.get("Lo_id")))
        filas.append(["<b>Inferior</b>", "", "", ""])
        filas.append(fila("Premolar 44/45–34/35", K["prem_l"], K.get("prem_id")))
        filas.append(fila("Molar 46–36", K["mol_l"], K.get("mol_id")))
        filas.append(fila("Largo anterior Lu", K["Lu"], K.get("Lu_id")))
        v.addWidget(etiqueta(tabla(["", "Medido", "Ideal", "Diferencia"], filas)))
        fuente = {"accudesign": "del escáner", "doctor": "corregidos por ti", "promedio": "promedio",
                  "medido": "medidos aquí"}
        v.addWidget(etiqueta(f"SI (12+11+21+22) = {K['SI']:.1f} mm · anchos {fuente.get(self.res['anchos_fuente'])}.",
                             True))
        if self.res["korkhaus"].get("Lo") and self.res["korkhaus"].get("Lu"):
            v.addWidget(etiqueta(f"Lo − Lu = {K['Lo'] - K['Lu']:.1f} mm (norma 2 mm).", True))

    def _card_espacio(self, v):
        seg = self.sub["espacio"]
        ap = self.res.get("apinamiento") or {}
        self._aviso_dudosos(v)
        celdas = {"dientes": [], "arcada": [], "ap": []}
        fuentes = set()
        for jaw in ("sup", "inf"):
            x = (ap.get(jaw) or {}).get(seg)
            if x:
                n, t = A.nivel_espacio(-x["apinamiento"])
                celdas["dientes"].append(f"{x['dientes']:.1f}")
                celdas["arcada"].append(f"{x['arcada']:.1f}")
                celdas["ap"].append(f"{x['apinamiento']:+.1f} {chip(t, n)}")
                fuentes.add(x["fuente"])
            else:
                for k in celdas:
                    celdas[k].append("—")
        v.addWidget(etiqueta(tabla(["Medición de datos", "Arcada superior", "Arcada inferior"],
                                   [["Tamaño de diente"] + celdas["dientes"], ["Tamaño de arcada"] + celdas["arcada"],
                                    ["Apiñamiento"] + celdas["ap"]])))
        if fuentes:
            v.addWidget(etiqueta(f"Medidas (mm) · {' y '.join(sorted(fuentes))} · de {seg[0]} a {seg[2]}.", True))
        else:
            v.addWidget(etiqueta("Faltan anchos dentarios para este segmento: escríbelos abajo.", True))
        if self.caso.etiquetas:
            v.addWidget(etiqueta("Pasa el mouse sobre un diente del modelo: se pinta y muestra su número y su ancho.",
                                 True))
        self._lista_anchos(v)

    def _aviso_dudosos_dientes(self, v):
        dud = self.res.get("dudosos") or []
        if dud:
            aviso = etiqueta(f"<b>Parece que el {', '.join(dud)} son dos dientes juntos</b> (mide demasiado). Haz clic "
                             "donde se tocan y elige «Dividir aquí».")
            aviso.setStyleSheet("color:#b3541e;")
            v.addWidget(aviso)

    def _odo_diente(self, t):
        """Clic en un diente del odontograma de anchos: queda elegido (se resalta y se ven sus puntos en el modelo)."""
        if not t:
            self.diente_sel = None
            QtCore.QTimer.singleShot(0, lambda: self.mostrar(self.actual, mover_camara=False))
            return
        jaw = "sup" if t[0] in "12" else "inf"
        QtCore.QTimer.singleShot(0, lambda: (self.elegir_diente(jaw, int(t)), self.pagina.resaltar_diente(jaw, t)))

    def _aviso_dudosos(self, v):
        """Un «diente» demasiado ancho es una separación que cubre dos dientes: sin corregirla no se da la medida."""
        dud = self.res.get("dudosos") or []
        if not dud:
            return
        aviso = etiqueta(f"<b>Revisa la separación del diente {', '.join(dud)}.</b> Mide más de lo que puede medir "
                         "un diente: seguramente son dos dientes juntos. Hasta corregirlo en «Dientes» no se calcula "
                         "lo que depende de él.")
        aviso.setStyleSheet("color:#b3541e;")
        v.addWidget(aviso)
        b = QtWidgets.QPushButton("Ir a «Dientes» para corregirlo")
        b.clicked.connect(lambda: self.mostrar("dientes"))
        v.addWidget(b)

    def _lista_anchos(self, v):
        fuente = {"accudesign": "del escáner", "doctor": "corregidos por ti", "promedio": "sin medir",
                  "medido": "medidos aquí sobre la línea mesiodistal"}.get(self.res["anchos_fuente"], "")
        v.addWidget(etiqueta(f"<b>Lista de anchos de los dientes</b> (mm) · {fuente}"))
        v.addWidget(etiqueta("Doble clic en un valor para corregirlo.", True))
        v.addWidget(self._tabla_anchos())

    def _card_bolton(self, v):
        b = self.res["bolton"]
        self._aviso_dudosos(v)
        if self.sub["bolton"] == "ancho":
            self._lista_anchos(v)
            return
        filas = []
        for k, nombre, n_d in (("anterior", "anterior", 6), ("global", "general", 12)):
            x = b.get(k)
            if not x:
                filas.append([f"Relación {nombre}", "—"])
                continue
            n, t = A.nivel_bolton(x)
            filas.append([f"Suma de las {n_d} piezas inferiores", f"{x['inf']:.1f}"])
            filas.append([f"Suma de las {n_d} piezas superiores", f"{x['sup']:.1f}"])
            filas.append([f"<b>Relación {nombre}</b>", f"<b>{x['relacion']:.2f} %</b> {chip(t, n)}"])
        v.addWidget(etiqueta(tabla(["Medición de datos", "Medidas"], filas)))
        if not b:
            v.addWidget(etiqueta("Faltan anchos dentarios: escríbelos en la pestaña «Medición del ancho del diente».",
                                 True))
        v.addWidget(etiqueta("Medidas (mm). En el modelo, la línea verde de cada diente es su ancho mesiodistal.", True))

    def _tabla_anchos(self):
        filas = [["17", "16", "15", "14", "13", "12", "11"], ["21", "22", "23", "24", "25", "26", "27"],
                 ["47", "46", "45", "44", "43", "42", "41"], ["31", "32", "33", "34", "35", "36", "37"]]
        t = QtWidgets.QTableWidget(8, 7)
        t.horizontalHeader().setVisible(False)
        t.verticalHeader().setVisible(False)
        t.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        t.setStyleSheet("QTableWidget{background:#ffffff;gridline-color:#d5dbe1;font-size:9pt;color:#1f2933;border:1px solid #d5dbe1;}")
        an = self.caso.anchos
        for i, fila in enumerate(filas):
            for j, d in enumerate(fila):
                h = QtWidgets.QTableWidgetItem(d)
                h.setFlags(Qt.ItemIsEnabled)
                h.setForeground(QtGui.QColor("#6b7682"))
                h.setBackground(QtGui.QColor("#eef1f4"))
                h.setTextAlignment(Qt.AlignCenter)
                t.setItem(2 * i, j, h)
                w = A.ancho(an, d)
                it = QtWidgets.QTableWidgetItem(f"{w:.1f}" if w else "")
                it.setTextAlignment(Qt.AlignCenter)
                it.setForeground(QtGui.QColor("#1f2933"))
                it.setBackground(QtGui.QColor("#ffffff"))
                it.setToolTip(f"Ancho del {d} (doble clic para escribirlo)")
                it.setData(Qt.UserRole, d)
                t.setItem(2 * i + 1, j, it)
        t.resizeRowsToContents()
        t.setFixedHeight(sum(t.rowHeight(i) for i in range(8)) + 4)
        t.itemChanged.connect(self._ancho_cambiado)
        return t

    def _ancho_cambiado(self, it):
        d = it.data(Qt.UserRole)
        if not d:
            return
        try:
            w = float(it.text().replace(",", ".")) if it.text().strip() else 0.0
        except ValueError:
            return
        if w and not 2 <= w <= 15:
            self.pagina.aviso("Ese ancho no parece de un diente (2 a 15 mm).")
            return
        if w:
            self.caso.anchos[d] = w
        else:
            self.caso.anchos.pop(d, None)
        self.caso.anchos_fuente = "doctor"
        self.pagina.guardar_ediciones()
        self.res = A.medir(self.caso)  # sin redibujar la tarjeta (se está editando la tabla)

    def _card_moyers(self, v):
        mo = self.res["moyers"]
        if not mo:
            v.addWidget(etiqueta("Faltan los anchos de los incisivos inferiores (31, 32, 41, 42). Escríbelos en "
                                 "«Espacio y Bolton»."))
            return
        if not self.res.get("mixta", True):
            v.addWidget(etiqueta("Este caso tiene dentición permanente completa en caninos y premolares: Moyers es para "
                                 "dentición mixta y aquí solo es de referencia.", True))
        v.addWidget(etiqueta(f"Suma de incisivos inferiores: <b>{mo['SI']:.1f} mm</b>"))
        filas = [["Superior", f"{mo['sup_previsto']:.1f}", f"{mo['sup_tanaka']:.1f}"],
                 ["Inferior", f"{mo['inf_previsto']:.1f}", f"{mo['inf_tanaka']:.1f}"]]
        v.addWidget(etiqueta("<b>3-4-5 previsto</b> (mm por cuadrante)"))
        v.addWidget(etiqueta(tabla(["", "Moyers 75 %", "Tanaka-Johnston"], filas)))
        if mo["fuera_de_tabla"]:
            v.addWidget(etiqueta("La suma está fuera de la tabla de Moyers (19.5–29 mm): valor extrapolado.", True))
        filas = []
        nom = {"1": "Cuadrante 1 (sup. der.)", "2": "Cuadrante 2 (sup. izq.)", "3": "Cuadrante 3 (inf. izq.)",
               "4": "Cuadrante 4 (inf. der.)"}
        for q in ("1", "2", "3", "4"):
            c = mo["cuadrantes"].get(q)
            if c:
                n, t = A.nivel_espacio(c["discrepancia"])
                filas.append([nom[q], f"{c['disponible']:.1f}", f"{c['previsto']:.1f}",
                              f"{c['discrepancia']:+.1f} {chip(t, n)}"])
        v.addWidget(etiqueta("<b>Espacio por cuadrante</b> (de distal del 2 a mesial del 6)"))
        v.addWidget(etiqueta(tabla(["", "Disponible", "Necesario", "Discrepancia"], filas)))

    def _card_arcada(self, v):
        an = self.res["anchuras"]
        ad = self.caso.AD or {}
        sub = self.sub["arcada"]
        if sub == "forma":
            fa = self.res.get("forma") or {}
            esc = ad.get("forma_arco") or {}
            v.addWidget(etiqueta(tabla(["Medición de datos", "Medidas"],
                                       [["Arcada superior", fa.get("sup", "—")], ["Arcada inferior", fa.get("inf", "—")]])))
            self._fila_criterio(v, "A tu criterio", [
                (nombre, self._combo_criterio(f"forma_{jaw}", FORMAS, esc.get(jaw, "")))
                for jaw, nombre in (("sup", "Arcada superior"), ("inf", "Arcada inferior"))])
            v.addWidget(etiqueta("«Automático» es la forma que clasificó el escáner. En el modelo: la curva de cada "
                                 "arcada con los puntos de contacto entre dientes.", True))
            return
        if sub == "ancho":
            filas = []
            aa = ad.get("anchura_arco") or {}
            for k, kn, ka in (("canina", "Anterior (caninos)", "anterior"), ("premolar", "Media (premolares)", "media"),
                              ("molar", "Posterior (molares)", "posterior")):
                filas.append([kn] + [f"{an[j][k]:.1f}" if k in an.get(j, {}) else "—" for j in ("sup", "inf")]
                             + [mm((aa.get(j) or {}).get(ka)) for j in ("sup", "inf")])
            v.addWidget(etiqueta(tabla(["", "Sup. aquí", "Inf. aquí", "Sup. escáner", "Inf. escáner"], filas)))
            v.addWidget(etiqueta("Medidas (mm). «Aquí»: entre los centros de las coronas que ves en el modelo.", True))
            return
        if sub == "simetria":
            sim = self.res.get("simetria") or {}
            si = ad.get("simetria") or {}
            filas = []
            for j, nj in (("sup", "Superior"), ("inf", "Inferior")):
                for n in ("anterior", "media", "posterior"):
                    x = (sim.get(j) or {}).get(n)
                    e = (si.get(j) or {}).get(n)
                    if not x and not e:
                        continue
                    if x:
                        aqui = [f"{x['der']:.1f}", f"{x['izq']:.1f}",
                                f"{x['dif']:.1f} {chip('simétrica' if x['dif'] <= 2 else 'asimétrica', 0 if x['dif'] <= 2 else 1)}"]
                    else:
                        aqui = ["—", "—", "—"]
                    filas.append([f"{nj} {n}"] + aqui + [f"{e['der']:.1f} / {e['izq']:.1f}" if e else "—"])
            v.addWidget(etiqueta(tabla(["", "Derecha", "Izquierda", "Diferencia", "Escáner (der. / izq.)"], filas)))
            v.addWidget(etiqueta("Medidas (mm) al eje medio. En el modelo: la línea gris es el eje y cada línea de color va "
                                 "del diente al eje (amarillo caninos, rojo premolares, verde molares).", True))
            return
        lon = self.res.get("longitud") or {}
        la = ad.get("longitud_arco") or {}
        filas = []
        for n, texto in (("anterior", "Hasta caninos"), ("media", "Hasta primeros premolares"),
                         ("posterior", "Hasta primeros molares")):
            filas.append([texto] + [mm((lon.get(j) or {}).get(n)) for j in ("sup", "inf")])
        v.addWidget(etiqueta("<b>Longitud de la arcada</b> (mm, medida aquí desde el borde incisal)"))
        v.addWidget(etiqueta(tabla(["", "Superior", "Inferior"], filas)))
        if la.get("sup") or la.get("inf"):
            filas = [[n.capitalize()] + [mm((la.get(j) or {}).get(n)) for j in ("sup", "inf")]
                     for n in ("anterior", "media", "posterior", "total")]
            v.addWidget(etiqueta("<b>Longitud por tramos</b> (mm, escáner)"))
            v.addWidget(etiqueta(tabla(["", "Superior", "Inferior"], filas)))
        sp = self.res["spee"]
        sad = ad.get("spee") or {}
        filas = [["Derecha", mm(sp.get("der")), mm(sad.get("der"))], ["Izquierda", mm(sp.get("izq")), mm(sad.get("izq"))]]
        v.addWidget(etiqueta("<b>Curva de Spee</b> (mm)"))
        v.addWidget(etiqueta(tabla(["", "Medida aquí", "Escáner"], filas)))
        if ad.get("altura_palatina"):
            v.addWidget(etiqueta(f"<b>Altura palatina</b>: {ad['altura_palatina']:.1f} mm (escáner)"))
