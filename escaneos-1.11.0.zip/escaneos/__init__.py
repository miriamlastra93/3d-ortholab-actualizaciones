"""Análisis de modelos (exclusivo 3D OrthoLab): visor de los escaneos intraorales que manda 3D OrthoLab (.3dol)."""


def abrir(app):
    """La tarjeta del inicio: abre el módulo a pantalla completa dentro de la app."""
    from .. import _guardia

    if not _guardia.exigir(app):
        return
    pagina = getattr(app, "_escaneos_page", None)
    if pagina is None:
        from .pagina import AnalisisModelos

        pagina = AnalisisModelos(app)
        pagina.volver.connect(app.show_home)
        app.root.addWidget(pagina)
        app._escaneos_page = pagina
    app.root.setCurrentWidget(pagina)
